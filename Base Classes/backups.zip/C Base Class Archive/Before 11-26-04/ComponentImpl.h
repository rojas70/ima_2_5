// ComponentImpl.h: Inheritable implementation of the IMA2 IComponent interface.
//
// Last Modified: Robert Olivares (8/28/01)
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMPONENTIMPL_H__1688ECC9_E093_4852_A1D0_949A3F0B4573__INCLUDED_)
#define AFX_COMPONENTIMPL_H__1688ECC9_E093_4852_A1D0_949A3F0B4573__INCLUDED_
#pragma once

#import "C:\Ima2\System\Framework\Ima2.tlb" raw_interfaces_only, raw_native_types, no_namespace, named_guids 

class CComponentImpl : public IComponent
{
	// ************************************************************************************************************
	// Public member variables
	// ************************************************************************************************************
	public:

		/*
		BSTR					m_Path;			// The full path and name of this component.
		BSTR					m_Machine;		// The machine that this component was created.
		BSTR					m_PID;			// The ProgID of this component.
		long					m_Process;		// The Process ID of this component.
		long					m_Thread;		// The Thread ID of this component.
		*/

		IMA2_DistributingInfo	m_Info;			// Contains all the information the distributing layer needs to function

		ILocator *				m_Locator;				// The pointer for the locator where this component is registered.
		IBindings *				m_Bindings;				// The pointer for the our bindings collection.
		IConfigureBindings *	m_ConfigureBindings;	// The interface that allows us to configure the bindings collection.

	public:

	// ************************************************************************************************************
	// Constructor & Destructor
	// ************************************************************************************************************
		CComponentImpl::CComponentImpl()	
		{ 
			m_Info.IsContainer	= false;	// Default is false; derived container classes should change this to true.
			m_Info.Name			= NULL;
			m_Info.Path			= NULL;
			m_Info.Machine		= NULL;
			m_Info.PID			= NULL;
			m_Info.Process		= 0;
			m_Info.Thread		= 0;

			m_Locator			= NULL;
			m_Bindings			= NULL;
			m_ConfigureBindings = NULL;
		}

		CComponentImpl::~CComponentImpl()	
		{
			// If our IComponent.Destruct() function hasn't been called, call it now.
			if (m_Info.Path != NULL) Destruct();
		}

	// ************************************************************************************************************
	// Overrideable events for derived classes
	// ************************************************************************************************************

		// Called after the component has been constructed and its Locator, Name, PID, and Machine fields filled.
		virtual STDMETHODIMP OnConstruct(void)	{return S_OK;}

		// Called right before the component has been destructed and its Locator, Name, PID, and Machine fields released.
		virtual STDMETHODIMP OnDestruct(void)	{return S_OK;}

	// ************************************************************************************************************
	// Basic IMA2 component implementation of IComponent::Construct() and IComponent::Destruct(). 
	//
	// These two functions should *not* be overridden. Instead, it is reccommended that the 
	// OnActivate and OnDeactivate events be overridden for customization.
	// ************************************************************************************************************

		virtual STDMETHODIMP Construct (BSTR Path, BSTR PID, ILocator ** AL)
		{
			USES_CONVERSION;									// ASCII to Unicode conversion support
			char	cn[]	= "                            ";	// Computer name buffer
			ULONG	cns		= sizeof(cn);						// Actual computer name size
			
			// Check to make sure we haven't been constructed before.
			if (m_Info.Path != NULL) return(E_FAIL);

			// Check to make sure we're not being incorrectly constructed.
			if ((Path == NULL) || (PID == NULL)) return(E_FAIL);

			// Retrieve this computer's name
			GetComputerName(cn, &cns);

			// Copy our strings and fill in other information
			m_Info.Path			= SysAllocString(Path);
			m_Info.PID			= SysAllocString(PID);
			m_Info.Machine		= SysAllocString(T2OLE(cn));
			m_Info.Process		= GetCurrentProcessId();
			m_Info.Thread 		= GetCurrentThreadId();
			m_Info.IsContainer	= false;

			// Retrieve our component's name from its path
			m_Info.Name			= NameFromPath(Path);

			// Get our lovely Locator.
			m_Locator	= *AL;
			m_Locator->AddRef();

			// Fire off the "event" to derived classes.
			OnConstruct();

			return S_OK;
		}


		virtual STDMETHODIMP Destruct ()
		{
			HRESULT hres;
			
			// We aren't constructed or have already been destructed.
			if (m_Info.Path == NULL) return(E_FAIL);

			// Pass on the message to derived classes.
			hres = OnDestruct();
			
			// Free our internal memory stores
			SysFreeString(m_Info.Name);
			SysFreeString(m_Info.Path);
			SysFreeString(m_Info.PID);
			SysFreeString(m_Info.Machine);

			// Eliminate the bindings collection if we have one.
			if (m_Bindings != NULL) 
			{
				m_ConfigureBindings->Destruct();
				m_ConfigureBindings->Release();
				m_Bindings->Release();
			}

			m_Locator->Release();
			return hres;
		}

	// ************************************************************************************************************
	// Basic Distributed Programming Functions
	// ************************************************************************************************************

		virtual STDMETHODIMP get_Distributing (struct IMA2_DistributingInfo * pInfo)
		{
			// Create a copy of our data to return.
			(*pInfo).Name			= SysAllocString(m_Info.Name);
			(*pInfo).Path			= SysAllocString(m_Info.Path);
			(*pInfo).PID 			= SysAllocString(m_Info.PID);
			(*pInfo).Machine		= SysAllocString(m_Info.Machine);
			(*pInfo).IsContainer	= m_Info.IsContainer;
			(*pInfo).Process		= m_Info.Process;
			(*pInfo).Thread			= m_Info.Thread;

			return S_OK;
		}

	// ************************************************************************************************************
	// Binding Functions
	// ************************************************************************************************************

		virtual STDMETHODIMP get_Bindings(IBindings ** pRetVal)
		{
			if (m_Bindings != NULL) m_Bindings->AddRef();
			*pRetVal = m_Bindings;
			return S_OK;
		}


	// ************************************************************************************************************
	// Persistence functions
	// ************************************************************************************************************

		virtual STDMETHODIMP Load (VARIANT Data)
		{
			return S_OK;
		}

		virtual STDMETHODIMP Save (VARIANT * pVal)
		{
			pVal->vt = VT_EMPTY;
			return S_OK;
		}

		virtual STDMETHODIMP DataSize (LONG * pVal)
		{
			*pVal = 0;
			return S_OK;
		}


	// ************************************************************************************************************
	// Non-IComponent utility functions for simplifying things. Callable from inheriting class.
	// ************************************************************************************************************

	protected:

		// Returns whether or not a COM object is an IMA2 container as well.
		bool IsContainer(IUnknown *pObj)
		{
			IUnknown *pCI = NULL;

			// Check for NULL pointer.
			if (pObj == NULL) return false;

			// Obtain a pointer to IContainer interface if possible, then release on success.
			pObj->QueryInterface(IID_IContainer, (void **)&pCI);
			if (pCI != NULL) 
			{
				pCI->Release();
				return true;
			}
			else
			{
				return false;
			}
		}

		// Locates and copies just the name from a path string of the form "\\Locator\Parent\Child".
		// The result string will contain "child" and must be deallocated by the caller.
		BSTR NameFromPath(BSTR Path)
		{
			#define uint unsigned int

			uint	i;
			uint	NameLen;
			uint	PathLen		= SysStringLen(Path);
			uint	NameStart	= 0;
			BSTR	Result		= NULL;

			// Check for no path.
			if (PathLen == 0) return NULL;

			// Search path string backwards for last slash character (#92)
			for (i = PathLen - 1; i > 0; i--)
				if (Path[i] == 92) { NameStart = i + 1; break; }

			// Allocate space for our name string
			NameLen = PathLen - NameStart;
			Result	= SysAllocStringLen(NULL, NameLen);

			// Copy just the name over to our result string
			for (i = NameStart; i < PathLen; i++)
				Result[i - NameStart] = Path[i];

			return Result;
		}

		// Initializes the bindings collection for this object.
		STDMETHODIMP InitializeBindings()
		{
			HRESULT		hres;
			CLSID		BCID;
			BSTR		Owner	= SysAllocString(m_Info.Path);
			ILocator *	AL		= m_Locator;

			if (m_Bindings != NULL) return E_FAIL;

			m_Locator->AddRef();
				
			// Need to get its CLSID, create the object, get configuration interface, and construct it.
			#pragma warning(disable: 4530)
			try 
			{
				hres = CLSIDFromProgID(L"IMA2_Bindings.Bindings", &BCID);
				hres = CoCreateInstance(BCID, NULL, CLSCTX_SERVER, IID_IBindings, (void **)&m_Bindings);
				hres = m_Bindings->QueryInterface(IID_IConfigureBindings, (void **)&m_ConfigureBindings);
				hres = m_ConfigureBindings->Construct(Owner, &AL);
			}
			catch (...)
			{
				return hres;
			}

			return hres;
		}

		// Adds a simple binding to the bindings list.
		STDMETHODIMP AddSimpleBinding(OLECHAR * Name)
		{
			IMA2_BindingInfo		BindInfo;
			HRESULT					hres;

			// If the bindings collection doesn't exist...
			if (m_Bindings == NULL) 
			{
				hres = InitializeBindings();		// Create one.
				if (hres != 0) return hres;			// Something happened, so return the error.
			}

			// Set up the binding information structure.
			BindInfo.IIDs		= NULL;
			BindInfo.PIDs		= NULL;
			BindInfo.Path		= NULL;
			BindInfo.BindType	= BT_Default;
			BindInfo.Name		= SysAllocString(Name);

			// Call the bindings object to add us to its list.
			hres = m_ConfigureBindings->Add(&BindInfo);
			
			// Clean up
			SysFreeString(BindInfo.Name);
			return hres;
		}

		// Retrieves a pointer to a specified interface on the given binding, NULL if not bound.
		void * GetBinding(UCHAR * Name, REFIID riid)
		{

			HRESULT		hres;
			IUnknown *	pIUnk;
			void *		retval;

			hres = m_Bindings->get_Pointers((unsigned short*)Name, (IComponent **)&pIUnk);
			if (hres != S_OK) return NULL;

			hres = pIUnk->QueryInterface(riid, &retval);
			if (hres != S_OK) return NULL;

			return retval;
		}

		STDMETHODIMP ValidatePointers(int NumPointers, void * Ptr1, ...)
		{
			va_list			vl;
			IUnknown **		Ptrs = NULL;
			int				NullCount = 0;
			int				i = 0;

			if (NumPointers <= 0) return E_FAIL;

			Ptrs = (IUnknown **)malloc(NumPointers * sizeof(IUnknown *));

			Ptrs[0] = (IUnknown *)Ptr1;
			if (Ptrs[0] == NULL) NullCount++;

			va_start( vl, Ptr1 );

			// Step through the list and count invalid pointers.
			for(i = 1; i >= NumPointers - 1; i++ )
			{
				Ptrs[i] = va_arg( vl, IUnknown *);
				if (Ptrs[i] == NULL) NullCount++;
				// Attempt to TRY/CATCH and AddRef/Release pair here to confirm functional pointer.
			}

			va_end( vl );

			// If any invalid pointers were found, go through the list and release the valid ones.
			if (NullCount > 0)
			{
				for(i = 0; i >= NumPointers - 1; i++ )
					if (Ptrs[i] != NULL) (IUnknown *)Ptrs[i]->Release();
				return E_FAIL;
			}

			return S_OK;
		}

};

#endif // !defined(AFX_COMPONENTIMPL_H__1688ECC9_E093_4852_A1D0_949A3F0B4573__INCLUDED_)
