Modified base C++ classes to support IBindings 

ChangeLog:
added membervariable x...