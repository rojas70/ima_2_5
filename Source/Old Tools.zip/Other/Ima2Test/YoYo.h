// YoYo.h : Declaration of the CYoYo

#ifndef __YOYO_H_
#define __YOYO_H_

#include "resource.h"       // main symbols
#include "C:\Ima2\Source\BaseClasses\ComponentImpl.h"

/////////////////////////////////////////////////////////////////////////////
// CYoYo
class ATL_NO_VTABLE CYoYo : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CYoYo, &CLSID_YoYo>,
	public IDispatchImpl<IYoYo, &IID_IYoYo, &LIBID_IMA2TESTLib>,
	public CComponentImpl
{
public:
	BSTR m_Str;

	CYoYo()
	{
		m_Str = NULL;
	}
/*
STDMETHODIMP OnDeactivate(void)				{return S_OK;}
STDMETHODIMP OnActivate(void)				{return S_OK;}
STDMETHODIMP OnDestruct(void)				{return S_OK;}
STDMETHODIMP put_State(struct tagVARIANT)	{return S_OK;}
STDMETHODIMP get_State(struct tagVARIANT *)	{return S_OK;}
*/
	STDMETHODIMP OnConstruct(void)				
	{
		m_Str = SysAllocString(L"Whoa!");
		return S_OK;
	}
	

DECLARE_REGISTRY_RESOURCEID(IDR_YOYO)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CYoYo)
	COM_INTERFACE_ENTRY(IYoYo)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IComponent)
END_COM_MAP()

// IYoYo
public:
	STDMETHOD(get_Weee)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_Weee)(/*[in]*/ BSTR newVal);
// IComponent


};

#endif //__YOYO_H_
