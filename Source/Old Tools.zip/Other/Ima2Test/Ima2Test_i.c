/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Tue Aug 28 14:12:39 2001
 */
/* Compiler settings for C:\DOCUMENTS AND SETTINGS\OLIVARRE\DESKTOP\Ima2Test\Ima2Test.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_IYoYo = {0x8BC3B4AC,0x9569,0x4399,{0xA6,0x78,0x19,0x5C,0x40,0x91,0x47,0xCD}};


const IID IID_IFooCmp = {0xE0EA4AAC,0xAFF2,0x4E29,{0xA7,0x85,0x22,0xD6,0xE4,0x96,0xF8,0x1E}};


const IID LIBID_IMA2TESTLib = {0xB93AB146,0xE19F,0x4B04,{0x87,0x40,0x21,0xFC,0x70,0xF4,0x5B,0xB7}};


const CLSID CLSID_YoYo = {0x747E24B9,0xA3CB,0x42ED,{0xB9,0x70,0xA8,0x51,0x35,0x5C,0x6B,0xEA}};


const CLSID CLSID_FooCmp = {0xC5D52AC3,0xB521,0x4C5A,{0xA4,0xD2,0x49,0x36,0x68,0x38,0x61,0xCE}};


#ifdef __cplusplus
}
#endif

