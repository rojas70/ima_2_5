// FooCmp.cpp : Implementation of CFooCmp
#include "stdafx.h"
#include "Ima2Test.h"
#include "FooCmp.h"

/////////////////////////////////////////////////////////////////////////////
// CFooCmp


STDMETHODIMP CFooCmp::get_Blah(short *pVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CFooCmp::put_Blah(short newVal)
{
	// TODO: Add your implementation code here

	return S_OK;
}
