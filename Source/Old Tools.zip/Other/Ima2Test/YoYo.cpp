// YoYo.cpp : Implementation of CYoYo
#include "stdafx.h"
#include "Ima2Test.h"
#include "YoYo.h"

/////////////////////////////////////////////////////////////////////////////
// CYoYo


STDMETHODIMP CYoYo::get_Weee(BSTR *pVal)
{
	*pVal = SysAllocString(m_Str);
	return S_OK;
}

STDMETHODIMP CYoYo::put_Weee(BSTR newVal)
{
	SysReAllocString(&m_Str,newVal);
	return S_OK;
}
