// ComponentImpl.h: Inheritable implementation of the IMA2 IComponent interface.
//
// Last Modified: Robert Olivares (8/28/01)
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_COMPONENTIMPL_H__1688ECC9_E093_4852_A1D0_949A3F0B4573__INCLUDED_)
#define AFX_COMPONENTIMPL_H__1688ECC9_E093_4852_A1D0_949A3F0B4573__INCLUDED_
#pragma once

#import "C:\Ima2\System\Framework\Ima2.tlb" raw_interfaces_only, raw_native_types, no_namespace, named_guids 

class CComponentImpl : public IComponent
{
	// ************************************************************************************************************
	// Public member variables
	// ************************************************************************************************************
	public:
	
		VARIANT_BOOL	m_Activated;	// Whether or not this component is currently activated. 
		BSTR			m_Path;			// The full path and name of this component.
		BSTR			m_Machine;		// The machine that this component was created.
		BSTR			m_PID;			// The ProgID of this component.
		long			m_Process;		// The Process ID of this component.
		long			m_Thread;		// The Thread ID of this component.
		ILocator *		m_pLocator;		// The pointer fo the locator where this component is registered.

	public:

	// ************************************************************************************************************
	// Constructor & Destructor
	// ************************************************************************************************************
		CComponentImpl::CComponentImpl()	
		{ 
			m_Path		= NULL;
			m_PID		= NULL;
			m_Machine	= NULL;
			m_pLocator	= NULL;
			m_Process	= 0;
			m_Thread	= 0;
		}

		CComponentImpl::~CComponentImpl()	{}

	// ************************************************************************************************************
	// Overrideable events for derived classes
	// ************************************************************************************************************

		// Called after the component has been constructed and its Locator, Name, PID, and Machine fields filled.
		STDMETHODIMP OnConstruct(void)	{return S_OK;}

		// Called right before the component has been destructed and its Locator, Name, PID, and Machine fields released.
		STDMETHODIMP OnDestruct(void)	{return S_OK;}

		// Called when the component is activated from an inactive state.
		STDMETHODIMP OnActivate(void)	{return S_OK;}

		// Called when the component is deactivated from an active state.
		STDMETHODIMP OnDeactivate(void)	{return S_OK;}

	// ************************************************************************************************************
	// Basic IMA2 component implementation of IComponent::Construct() and IComponent::Destruct(). 
	//
	// These two functions should *not* be overriden unless for a very good reason. Instead, 
	// it is reccommended that the OnActivate and OnDeactivate events be overriden for customization.
	// ************************************************************************************************************

		STDMETHODIMP Construct (BSTR Path, BSTR PID, ILocator ** AL)
		{
			USES_CONVERSION;
			char cn[]	= "                            ";
			ULONG cns	= sizeof(cn);
			
			if (m_Path != NULL) return(E_FAIL);

			GetComputerName(cn, &cns);

			m_Path		= SysAllocString(Path);
			m_PID		= SysAllocString(PID);
			m_Machine	= SysAllocString(T2OLE(cn));
			m_pLocator	= *AL;
			m_Process	= GetCurrentProcessId();
			m_Thread 	= GetCurrentThreadId();

			m_pLocator->AddRef();

			OnConstruct();

			return S_OK;
		}

		STDMETHODIMP Destruct ()
		{
			HRESULT hres;
			
			if (m_Path == NULL) return(E_FAIL);

			hres = OnDestruct();
			SysFreeString(m_Path);
			SysFreeString(m_PID);
			SysFreeString(m_Machine);
			m_pLocator->Release();
			return hres;
		}

	// ************************************************************************************************************
	// ************************************************************************************************************

		STDMETHODIMP get_Activated (VARIANT_BOOL * pVal)
		{
			*pVal = m_Activated;
			return S_OK;
		}

		STDMETHODIMP put_Activated (VARIANT_BOOL newVal)
		{
			if (newVal == m_Activated) 
			{
				ATLTRACE("Redundant call to IComponent::put_Activated.");
				return S_OK;
			}
			else
			{
				m_Activated = newVal;
				if (m_Activated)	return OnActivate();
				else				return OnDeactivate();
			}
		}

		STDMETHODIMP get_Path (BSTR * pVal)
		{
			*pVal = SysAllocString(m_Path);
			return S_OK;
		}

		STDMETHODIMP get_PID (BSTR * pVal)
		{
			*pVal = SysAllocString(m_PID);
			return S_OK;
		}

		STDMETHODIMP get_Machine (BSTR * pVal)
		{
			*pVal = SysAllocString(m_Machine);
			return S_OK;
		}

		STDMETHODIMP get_Process (long * pVal)
		{
			*pVal = m_Process;
			return S_OK;
		}

		STDMETHODIMP get_Thread (long * pVal)
		{
			*pVal = m_Thread;
			return S_OK;
		}

	// ************************************************************************************************************
	// Persistence and State functions
	// ************************************************************************************************************

		STDMETHODIMP Load (VARIANT Data)
		{
			return S_OK;
		}

		STDMETHODIMP Save (VARIANT * pVal)
		{
			pVal->vt = VT_EMPTY;
			return S_OK;
		}

		STDMETHODIMP DataSize (LONG * pVal)
		{
			*pVal = 0;
			return S_OK;
		}

		STDMETHODIMP put_State(VARIANT newVal)	
		{ 
			return S_OK;
		}
		
		STDMETHODIMP get_State(VARIANT * pVal)	
		{ 
			pVal->vt = VT_EMPTY;
			return S_OK;
		}
};

#endif // !defined(AFX_COMPONENTIMPL_H__1688ECC9_E093_4852_A1D0_949A3F0B4573__INCLUDED_)
