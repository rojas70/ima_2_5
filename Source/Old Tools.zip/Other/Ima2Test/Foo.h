// Foo.h: interface for the Foo class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_FOO_H__72C9BCE1_7487_4E40_A2D4_FD5F8308AB5A__INCLUDED_)
#define AFX_FOO_H__72C9BCE1_7487_4E40_A2D4_FD5F8308AB5A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class Foo  
{
public:
	Foo();
	virtual ~Foo();

};

#endif // !defined(AFX_FOO_H__72C9BCE1_7487_4E40_A2D4_FD5F8308AB5A__INCLUDED_)
