// FooCmp.h : Declaration of the CFooCmp

#ifndef __FOOCMP_H_
#define __FOOCMP_H_

#include "resource.h"       // main symbols
#include "C:\Ima2\Source\BaseClasses\ComponentImpl.h"

/////////////////////////////////////////////////////////////////////////////
// CFooCmp
class ATL_NO_VTABLE CFooCmp : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CFooCmp, &CLSID_FooCmp>,
	public IDispatchImpl<IFooCmp, &IID_IFooCmp, &LIBID_IMA2TESTLib>,
	public CComponentImpl
{
public:
	short m_Blech ;

	CFooCmp()
	{
		m_Blech = 0;
	}

	STDMETHODIMP OnConstruct(void)				
	{
		m_Blech = 32;
		return S_OK;
	}

DECLARE_REGISTRY_RESOURCEID(IDR_FOOCMP)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CFooCmp)
	COM_INTERFACE_ENTRY(IFooCmp)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IComponent)
END_COM_MAP()

// IFooCmp
public:
	STDMETHOD(get_Blah)(/*[out, retval]*/ short *pVal);
	STDMETHOD(put_Blah)(/*[in]*/ short newVal);
};

#endif //__FOOCMP_H_
