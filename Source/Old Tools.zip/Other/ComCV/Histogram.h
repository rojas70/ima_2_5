// Histogram.h : Declaration of the CHistogram

#ifndef __HISTOGRAM_H_
#define __HISTOGRAM_H_

#include "resource.h"       // main symbols
#include <cv.h>

/////////////////////////////////////////////////////////////////////////////
// CHistogram
class ATL_NO_VTABLE CHistogram : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CHistogram, &CLSID_Histogram>,
	public IDispatchImpl<IHistogram, &IID_IHistogram, &LIBID_COMCVLib>
{
public:
	CHistogram()
	{
	}

	CvHistogram * m_pCvHist;

DECLARE_REGISTRY_RESOURCEID(IDR_HISTOGRAM)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CHistogram)
	COM_INTERFACE_ENTRY(IHistogram)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IHistogram
public:
	STDMETHOD (ReadFromFile)		(BSTR FileName);

};

#endif //__HISTOGRAM_H_
