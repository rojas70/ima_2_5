// CVL.cpp : Implementation of CCVL
#include "stdafx.h"
#include "ComCV.h"
#include "CVL.h"

/////////////////////////////////////////////////////////////////////////////
// CCVL

//************************************************************************************************************************
// Optical Flow
//************************************************************************************************************************

STDMETHODIMP CCVL::CalcOpticalFlowLK(IImage *srcA, IImage *srcB, Size *winSize, IImage *velx, IImage *vely)
{
	::cvCalcOpticalFlowLK(	((CImage *)srcA)->m_pHeader, ((CImage *)srcB)->m_pHeader, 
							*((CvSize *)winSize), 
							((CImage *)velx)->m_pHeader, ((CImage *)vely)->m_pHeader);
	return(S_OK);
}

//************************************************************************************************************************
// Thresholding
//************************************************************************************************************************
STDMETHODIMP CCVL::CalcBackProject(IImage *srcImg, IHistogram *srcHist, IImage* dstImg)
{
	cvCalcBackProject(	&((CImage*)srcImg)->m_pHeader, 
						((CImage*)dstImg)->m_pHeader,
						((CHistogram*)srcHist)->m_pCvHist);
	return S_OK;
}

//************************************************************************************************************************
// CamSHIFT
//************************************************************************************************************************
/*

  	int* numBinArray;
	int w,h,i;
	float** thresh;
	int minS=10;
	int minV=25;
	int maxV=230;
	
	numBinArray = new int[1];
	numBinArray[0] = 256;

	// TODO: Add your implementation code here
	m_pIPLInputImage[0]->imageData	= (char*)Input;
	m_pIPLOutputImage->imageData	= (char*) Output;

	w = m_pIPLInputImage[0]->width;
	h = m_pIPLInputImage[0]->height;

	// Must use cvConvertPixelsToPlane
	  IplImage*  planeH=cvCreateImage(cvSize(w,h),IPL_DEPTH_8U, 1);
      IplImage*  planeS=cvCreateImage(cvSize(w,h),IPL_DEPTH_8U, 1);
      IplImage*  planeV=cvCreateImage(cvSize(w,h),IPL_DEPTH_8U, 1);
      
//	  cvCvtPixToPlane(m_pIPLInputImage[0],planeH,planeS,planeV,NULL);
	  cvCvtPixToPlane(m_pIPLInputImage[0],planeH,planeS,planeV,NULL);
      
	  uchar* Himg=(uchar*) planeH->imageData;
	  uchar* Simg=(uchar*) planeS->imageData;
	  uchar* Vimg=(uchar*) planeV->imageData;

	  for (i=0; i <w*h; i++)
	  {
            if( Simg[i] < minS || Vimg[i] < minV || Vimg[i] > maxV )

                Himg[i] = 0;
	  }
	  
	  IplImage* arrayOfPlanes[1];
	  arrayOfPlanes[0]=planeH;


	cvCalcBackProject(arrayOfPlanes, m_pIPLOutputImage, m_pCVHistogram);

	cvReleaseImage(&planeH);
	cvReleaseImage(&planeS);
	cvReleaseImage(&planeV);
	cvReleaseImage(arrayOfPlanes);

	delete [] numBinArray;

  return S_OK;

  */

STDMETHODIMP CCVL::CamShift(IImage* imgProb, Rect * windowIn, TermCriteria * criteria, ConnectedComp * out, Box2D* box)
{
	int	iterations = -1;

	//cvTermCriteria(CV_TERMCRIT_EPS | CV_TERMCRIT_ITER, 10, 10)
	iterations = cvCamShift(	((CImage *)imgProb)->m_pHeader, 
								*((CvRect *)windowIn),
								*((CvTermCriteria *)criteria),
								(CvConnectedComp *)out, 
								(CvBox2D *)box);

	return S_OK;
}

//************************************************************************************************************************
// Morphology
//************************************************************************************************************************

STDMETHODIMP CCVL::Erode(IImage* src, IImage* dst, int iterations)
{
	cvErode(	((CImage *)src)->m_pHeader, 
				((CImage *)dst)->m_pHeader, 
				NULL, iterations);
	return S_OK;
}

STDMETHODIMP CCVL::Dilate(IImage* src, IImage* dst, int iterations)
{
	cvDilate(	((CImage *)src)->m_pHeader, 
				((CImage *)dst)->m_pHeader, 
				NULL, iterations);
	return S_OK;
}
