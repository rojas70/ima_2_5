/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 5.01.0164 */
/* at Mon Oct 01 15:47:58 2001
 */
/* Compiler settings for C:\Ima2\Source\ComCV\ComCV.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ComCV_h__
#define __ComCV_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IImage_FWD_DEFINED__
#define __IImage_FWD_DEFINED__
typedef interface IImage IImage;
#endif 	/* __IImage_FWD_DEFINED__ */


#ifndef __ICanvas_FWD_DEFINED__
#define __ICanvas_FWD_DEFINED__
typedef interface ICanvas ICanvas;
#endif 	/* __ICanvas_FWD_DEFINED__ */


#ifndef __ICVL_FWD_DEFINED__
#define __ICVL_FWD_DEFINED__
typedef interface ICVL ICVL;
#endif 	/* __ICVL_FWD_DEFINED__ */


#ifndef __IIPL_FWD_DEFINED__
#define __IIPL_FWD_DEFINED__
typedef interface IIPL IIPL;
#endif 	/* __IIPL_FWD_DEFINED__ */


#ifndef __IHistogram_FWD_DEFINED__
#define __IHistogram_FWD_DEFINED__
typedef interface IHistogram IHistogram;
#endif 	/* __IHistogram_FWD_DEFINED__ */


#ifndef __Image_FWD_DEFINED__
#define __Image_FWD_DEFINED__

#ifdef __cplusplus
typedef class Image Image;
#else
typedef struct Image Image;
#endif /* __cplusplus */

#endif 	/* __Image_FWD_DEFINED__ */


#ifndef __IPL_FWD_DEFINED__
#define __IPL_FWD_DEFINED__

#ifdef __cplusplus
typedef class IPL IPL;
#else
typedef struct IPL IPL;
#endif /* __cplusplus */

#endif 	/* __IPL_FWD_DEFINED__ */


#ifndef __Histogram_FWD_DEFINED__
#define __Histogram_FWD_DEFINED__

#ifdef __cplusplus
typedef class Histogram Histogram;
#else
typedef struct Histogram Histogram;
#endif /* __cplusplus */

#endif 	/* __Histogram_FWD_DEFINED__ */


#ifndef __Canvas_FWD_DEFINED__
#define __Canvas_FWD_DEFINED__

#ifdef __cplusplus
typedef class Canvas Canvas;
#else
typedef struct Canvas Canvas;
#endif /* __cplusplus */

#endif 	/* __Canvas_FWD_DEFINED__ */


#ifndef __CVL_FWD_DEFINED__
#define __CVL_FWD_DEFINED__

#ifdef __cplusplus
typedef class CVL CVL;
#else
typedef struct CVL CVL;
#endif /* __cplusplus */

#endif 	/* __CVL_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

/* interface __MIDL_itf_ComCV_0000 */
/* [local] */ 





typedef /* [version][uuid] */ struct  Rect
    {
    int x;
    int y;
    int width;
    int height;
    }	Rect;

typedef /* [version][uuid] */ struct  Point
    {
    int x;
    int y;
    }	Point;

typedef /* [version][uuid] */ struct  Size
    {
    int width;
    int height;
    }	Size;

typedef /* [version][uuid] */ struct  Point2D32f
    {
    float x;
    float y;
    }	Point2D32f;

typedef /* [version][uuid] */ struct  Size2D32f
    {
    float x;
    float y;
    }	Size2D32f;

typedef /* [version][uuid] */ struct  Box2D
    {
    Point2D32f center;
    Size2D32f size;
    float angle;
    }	Box2D;

typedef /* [version][uuid] */ struct  TermCriteria
    {
    int type;
    int maxIter;
    float epsilon;
    }	TermCriteria;

typedef /* [version][uuid] */ struct  Matrix3
    {
    float m[ 3 ][ 3 ];
    }	Matrix3;

typedef /* [version][uuid] */ struct  Matrix4
    {
    float m[ 4 ][ 4 ];
    }	Matrix4;

typedef /* [version][uuid] */ struct  ConnectedComp
    {
    double area;
    double value;
    Rect rect;
    }	ConnectedComp;

typedef /* [version][uuid] */ 
enum TCEnums
    {	TC_ITER	= 1,
	TC_NUMB	= 1,
	TC_EPS	= 2
    }	TCEnums;

typedef /* [version][uuid] */ 
enum PlaneNumber
    {	PLANE_RED	= 2,
	PLANE_GREEN	= 1,
	PLANE_BLUE	= 0
    }	PlaneNumber;

typedef /* [version][uuid] */ 
enum ChannelCount
    {	CC_GREY	= 1,
	CC_PLANE	= 1,
	CC_RGB	= 3
    }	ChannelCount;

typedef /* [version][uuid] */ 
enum BitDepths
    {	BD_NORMAL	= 8
    }	BitDepths;

typedef /* [version][uuid] */ 
enum HistType
    {	HIST_ARRAY	= 0,
	HIST_TREE	= 1
    }	HistType;

typedef /* [version][uuid] */ 
enum CompareMethod
    {	COMP_CORREL	= 0,
	COMP_CHISQR	= 1,
	COMP_INTERSECT	= 2
    }	CompareMethod;

typedef /* [version][uuid] */ 
enum HistFlag
    {	HIST_MEMALLOCATED	= 1,
	HIST_HEADERALLOCATED	= 2,
	HIST_UNIFORM	= 4,
	HIST_THRESHALLOCATED	= 8
    }	HistFlag;



extern RPC_IF_HANDLE __MIDL_itf_ComCV_0000_v0_0_c_ifspec;
extern RPC_IF_HANDLE __MIDL_itf_ComCV_0000_v0_0_s_ifspec;

#ifndef __IImage_INTERFACE_DEFINED__
#define __IImage_INTERFACE_DEFINED__

/* interface IImage */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IImage;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("2E0054AF-9E87-412D-BEBC-36C995814D0E")
    IImage : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SetImageBuffer( 
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *newVal,
            ChannelCount Channels,
            BitDepths BitDepth) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SelectEntireRegion( void) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Width( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Height( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Channels( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_BitDepth( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_BytesPerRow( 
            /* [retval][out] */ short __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Data( 
            /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Data( 
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreateBlankImage( 
            /* [in] */ short width,
            /* [in] */ short height,
            /* [defaultvalue][in] */ ChannelCount Channels = CC_RGB,
            /* [defaultvalue][in] */ BitDepths BitDepth = BD_NORMAL) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetPlane( 
            /* [in] */ PlaneNumber plane,
            /* [retval][out] */ IImage __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Size( 
            /* [retval][out] */ Size __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadImage( 
            /* [in] */ BSTR Filename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE WriteImage( 
            /* [in] */ BSTR Filename) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Resize( 
            /* [in] */ short width,
            /* [in] */ short height) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Crop( 
            /* [in] */ short left,
            /* [in] */ short top,
            /* [in] */ short width,
            /* [in] */ short height) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Canvas( 
            /* [retval][out] */ ICanvas __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CopyImage( 
            /* [in] */ IImage __RPC_FAR *srcImage) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_Bytes( 
            /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_Bytes( 
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SelectRegion( 
            /* [in] */ Rect __RPC_FAR *region) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreateCopy( 
            /* [retval][out] */ IImage __RPC_FAR *__RPC_FAR *pVal) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IImageVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IImage __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IImage __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IImage __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IImage __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IImage __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IImage __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IImage __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SetImageBuffer )( 
            IImage __RPC_FAR * This,
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *newVal,
            ChannelCount Channels,
            BitDepths BitDepth);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SelectEntireRegion )( 
            IImage __RPC_FAR * This);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Width )( 
            IImage __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Height )( 
            IImage __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Channels )( 
            IImage __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BitDepth )( 
            IImage __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_BytesPerRow )( 
            IImage __RPC_FAR * This,
            /* [retval][out] */ short __RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Data )( 
            IImage __RPC_FAR * This,
            /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Data )( 
            IImage __RPC_FAR * This,
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreateBlankImage )( 
            IImage __RPC_FAR * This,
            /* [in] */ short width,
            /* [in] */ short height,
            /* [defaultvalue][in] */ ChannelCount Channels,
            /* [defaultvalue][in] */ BitDepths BitDepth);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetPlane )( 
            IImage __RPC_FAR * This,
            /* [in] */ PlaneNumber plane,
            /* [retval][out] */ IImage __RPC_FAR *__RPC_FAR *pVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Size )( 
            IImage __RPC_FAR * This,
            /* [retval][out] */ Size __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadImage )( 
            IImage __RPC_FAR * This,
            /* [in] */ BSTR Filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *WriteImage )( 
            IImage __RPC_FAR * This,
            /* [in] */ BSTR Filename);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Resize )( 
            IImage __RPC_FAR * This,
            /* [in] */ short width,
            /* [in] */ short height);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Crop )( 
            IImage __RPC_FAR * This,
            /* [in] */ short left,
            /* [in] */ short top,
            /* [in] */ short width,
            /* [in] */ short height);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Canvas )( 
            IImage __RPC_FAR * This,
            /* [retval][out] */ ICanvas __RPC_FAR *__RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CopyImage )( 
            IImage __RPC_FAR * This,
            /* [in] */ IImage __RPC_FAR *srcImage);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Bytes )( 
            IImage __RPC_FAR * This,
            /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_Bytes )( 
            IImage __RPC_FAR * This,
            /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *pVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SelectRegion )( 
            IImage __RPC_FAR * This,
            /* [in] */ Rect __RPC_FAR *region);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreateCopy )( 
            IImage __RPC_FAR * This,
            /* [retval][out] */ IImage __RPC_FAR *__RPC_FAR *pVal);
        
        END_INTERFACE
    } IImageVtbl;

    interface IImage
    {
        CONST_VTBL struct IImageVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IImage_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IImage_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IImage_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IImage_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IImage_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IImage_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IImage_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IImage_SetImageBuffer(This,newVal,Channels,BitDepth)	\
    (This)->lpVtbl -> SetImageBuffer(This,newVal,Channels,BitDepth)

#define IImage_SelectEntireRegion(This)	\
    (This)->lpVtbl -> SelectEntireRegion(This)

#define IImage_get_Width(This,pVal)	\
    (This)->lpVtbl -> get_Width(This,pVal)

#define IImage_get_Height(This,pVal)	\
    (This)->lpVtbl -> get_Height(This,pVal)

#define IImage_get_Channels(This,pVal)	\
    (This)->lpVtbl -> get_Channels(This,pVal)

#define IImage_get_BitDepth(This,pVal)	\
    (This)->lpVtbl -> get_BitDepth(This,pVal)

#define IImage_get_BytesPerRow(This,pVal)	\
    (This)->lpVtbl -> get_BytesPerRow(This,pVal)

#define IImage_get_Data(This,pVal)	\
    (This)->lpVtbl -> get_Data(This,pVal)

#define IImage_put_Data(This,pVal)	\
    (This)->lpVtbl -> put_Data(This,pVal)

#define IImage_CreateBlankImage(This,width,height,Channels,BitDepth)	\
    (This)->lpVtbl -> CreateBlankImage(This,width,height,Channels,BitDepth)

#define IImage_GetPlane(This,plane,pVal)	\
    (This)->lpVtbl -> GetPlane(This,plane,pVal)

#define IImage_get_Size(This,pVal)	\
    (This)->lpVtbl -> get_Size(This,pVal)

#define IImage_ReadImage(This,Filename)	\
    (This)->lpVtbl -> ReadImage(This,Filename)

#define IImage_WriteImage(This,Filename)	\
    (This)->lpVtbl -> WriteImage(This,Filename)

#define IImage_Resize(This,width,height)	\
    (This)->lpVtbl -> Resize(This,width,height)

#define IImage_Crop(This,left,top,width,height)	\
    (This)->lpVtbl -> Crop(This,left,top,width,height)

#define IImage_get_Canvas(This,pVal)	\
    (This)->lpVtbl -> get_Canvas(This,pVal)

#define IImage_CopyImage(This,srcImage)	\
    (This)->lpVtbl -> CopyImage(This,srcImage)

#define IImage_get_Bytes(This,pVal)	\
    (This)->lpVtbl -> get_Bytes(This,pVal)

#define IImage_put_Bytes(This,pVal)	\
    (This)->lpVtbl -> put_Bytes(This,pVal)

#define IImage_SelectRegion(This,region)	\
    (This)->lpVtbl -> SelectRegion(This,region)

#define IImage_CreateCopy(This,pVal)	\
    (This)->lpVtbl -> CreateCopy(This,pVal)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImage_SetImageBuffer_Proxy( 
    IImage __RPC_FAR * This,
    /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *newVal,
    ChannelCount Channels,
    BitDepths BitDepth);


void __RPC_STUB IImage_SetImageBuffer_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImage_SelectEntireRegion_Proxy( 
    IImage __RPC_FAR * This);


void __RPC_STUB IImage_SelectEntireRegion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IImage_get_Width_Proxy( 
    IImage __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IImage_get_Width_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IImage_get_Height_Proxy( 
    IImage __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IImage_get_Height_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IImage_get_Channels_Proxy( 
    IImage __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IImage_get_Channels_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IImage_get_BitDepth_Proxy( 
    IImage __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IImage_get_BitDepth_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IImage_get_BytesPerRow_Proxy( 
    IImage __RPC_FAR * This,
    /* [retval][out] */ short __RPC_FAR *pVal);


void __RPC_STUB IImage_get_BytesPerRow_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IImage_get_Data_Proxy( 
    IImage __RPC_FAR * This,
    /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *pVal);


void __RPC_STUB IImage_get_Data_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IImage_put_Data_Proxy( 
    IImage __RPC_FAR * This,
    /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *pVal);


void __RPC_STUB IImage_put_Data_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImage_CreateBlankImage_Proxy( 
    IImage __RPC_FAR * This,
    /* [in] */ short width,
    /* [in] */ short height,
    /* [defaultvalue][in] */ ChannelCount Channels,
    /* [defaultvalue][in] */ BitDepths BitDepth);


void __RPC_STUB IImage_CreateBlankImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImage_GetPlane_Proxy( 
    IImage __RPC_FAR * This,
    /* [in] */ PlaneNumber plane,
    /* [retval][out] */ IImage __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB IImage_GetPlane_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IImage_get_Size_Proxy( 
    IImage __RPC_FAR * This,
    /* [retval][out] */ Size __RPC_FAR *pVal);


void __RPC_STUB IImage_get_Size_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImage_ReadImage_Proxy( 
    IImage __RPC_FAR * This,
    /* [in] */ BSTR Filename);


void __RPC_STUB IImage_ReadImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImage_WriteImage_Proxy( 
    IImage __RPC_FAR * This,
    /* [in] */ BSTR Filename);


void __RPC_STUB IImage_WriteImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImage_Resize_Proxy( 
    IImage __RPC_FAR * This,
    /* [in] */ short width,
    /* [in] */ short height);


void __RPC_STUB IImage_Resize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImage_Crop_Proxy( 
    IImage __RPC_FAR * This,
    /* [in] */ short left,
    /* [in] */ short top,
    /* [in] */ short width,
    /* [in] */ short height);


void __RPC_STUB IImage_Crop_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IImage_get_Canvas_Proxy( 
    IImage __RPC_FAR * This,
    /* [retval][out] */ ICanvas __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB IImage_get_Canvas_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImage_CopyImage_Proxy( 
    IImage __RPC_FAR * This,
    /* [in] */ IImage __RPC_FAR *srcImage);


void __RPC_STUB IImage_CopyImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE IImage_get_Bytes_Proxy( 
    IImage __RPC_FAR * This,
    /* [retval][out] */ SAFEARRAY __RPC_FAR * __RPC_FAR *pVal);


void __RPC_STUB IImage_get_Bytes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE IImage_put_Bytes_Proxy( 
    IImage __RPC_FAR * This,
    /* [in] */ SAFEARRAY __RPC_FAR * __RPC_FAR *pVal);


void __RPC_STUB IImage_put_Bytes_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImage_SelectRegion_Proxy( 
    IImage __RPC_FAR * This,
    /* [in] */ Rect __RPC_FAR *region);


void __RPC_STUB IImage_SelectRegion_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IImage_CreateCopy_Proxy( 
    IImage __RPC_FAR * This,
    /* [retval][out] */ IImage __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB IImage_CreateCopy_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IImage_INTERFACE_DEFINED__ */


#ifndef __ICanvas_INTERFACE_DEFINED__
#define __ICanvas_INTERFACE_DEFINED__

/* interface ICanvas */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICanvas;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("8C5C17D3-CFE4-4A47-9BB3-FD637C36A7F3")
    ICanvas : public IDispatch
    {
    public:
        virtual /* [helpstring][hidden][id][propget] */ HRESULT STDMETHODCALLTYPE get_Source( 
            /* [retval][out] */ IImage __RPC_FAR *__RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][hidden][id][propputref] */ HRESULT STDMETHODCALLTYPE putref_Source( 
            /* [in] */ IImage __RPC_FAR *newVal) = 0;
        
        virtual /* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE get_AntiAlias( 
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal) = 0;
        
        virtual /* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE put_AntiAlias( 
            /* [in] */ VARIANT_BOOL __RPC_FAR *pNewVal) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DrawLine( 
            /* [in] */ Point __RPC_FAR *pt1,
            /* [in] */ Point __RPC_FAR *pt2,
            int color,
            int thickness) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DrawRect( 
            /* [in] */ Point __RPC_FAR *pt1,
            /* [in] */ Point __RPC_FAR *pt2,
            int color,
            int thickness) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DrawCircle( 
            /* [in] */ Point __RPC_FAR *center,
            int radius,
            int color,
            int thickness) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DrawEllipse( 
            /* [in] */ Point __RPC_FAR *center,
            /* [in] */ Size __RPC_FAR *axes,
            double angle,
            double startAngle,
            double endAngle,
            int color,
            int thickness) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICanvasVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICanvas __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICanvas __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICanvas __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ICanvas __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ICanvas __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ICanvas __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ICanvas __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][hidden][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_Source )( 
            ICanvas __RPC_FAR * This,
            /* [retval][out] */ IImage __RPC_FAR *__RPC_FAR *pVal);
        
        /* [helpstring][hidden][id][propputref] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *putref_Source )( 
            ICanvas __RPC_FAR * This,
            /* [in] */ IImage __RPC_FAR *newVal);
        
        /* [helpstring][id][propget] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *get_AntiAlias )( 
            ICanvas __RPC_FAR * This,
            /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);
        
        /* [helpstring][id][propput] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *put_AntiAlias )( 
            ICanvas __RPC_FAR * This,
            /* [in] */ VARIANT_BOOL __RPC_FAR *pNewVal);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DrawLine )( 
            ICanvas __RPC_FAR * This,
            /* [in] */ Point __RPC_FAR *pt1,
            /* [in] */ Point __RPC_FAR *pt2,
            int color,
            int thickness);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DrawRect )( 
            ICanvas __RPC_FAR * This,
            /* [in] */ Point __RPC_FAR *pt1,
            /* [in] */ Point __RPC_FAR *pt2,
            int color,
            int thickness);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DrawCircle )( 
            ICanvas __RPC_FAR * This,
            /* [in] */ Point __RPC_FAR *center,
            int radius,
            int color,
            int thickness);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DrawEllipse )( 
            ICanvas __RPC_FAR * This,
            /* [in] */ Point __RPC_FAR *center,
            /* [in] */ Size __RPC_FAR *axes,
            double angle,
            double startAngle,
            double endAngle,
            int color,
            int thickness);
        
        END_INTERFACE
    } ICanvasVtbl;

    interface ICanvas
    {
        CONST_VTBL struct ICanvasVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICanvas_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICanvas_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICanvas_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICanvas_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICanvas_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICanvas_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICanvas_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICanvas_get_Source(This,pVal)	\
    (This)->lpVtbl -> get_Source(This,pVal)

#define ICanvas_putref_Source(This,newVal)	\
    (This)->lpVtbl -> putref_Source(This,newVal)

#define ICanvas_get_AntiAlias(This,pVal)	\
    (This)->lpVtbl -> get_AntiAlias(This,pVal)

#define ICanvas_put_AntiAlias(This,pNewVal)	\
    (This)->lpVtbl -> put_AntiAlias(This,pNewVal)

#define ICanvas_DrawLine(This,pt1,pt2,color,thickness)	\
    (This)->lpVtbl -> DrawLine(This,pt1,pt2,color,thickness)

#define ICanvas_DrawRect(This,pt1,pt2,color,thickness)	\
    (This)->lpVtbl -> DrawRect(This,pt1,pt2,color,thickness)

#define ICanvas_DrawCircle(This,center,radius,color,thickness)	\
    (This)->lpVtbl -> DrawCircle(This,center,radius,color,thickness)

#define ICanvas_DrawEllipse(This,center,axes,angle,startAngle,endAngle,color,thickness)	\
    (This)->lpVtbl -> DrawEllipse(This,center,axes,angle,startAngle,endAngle,color,thickness)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][hidden][id][propget] */ HRESULT STDMETHODCALLTYPE ICanvas_get_Source_Proxy( 
    ICanvas __RPC_FAR * This,
    /* [retval][out] */ IImage __RPC_FAR *__RPC_FAR *pVal);


void __RPC_STUB ICanvas_get_Source_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][hidden][id][propputref] */ HRESULT STDMETHODCALLTYPE ICanvas_putref_Source_Proxy( 
    ICanvas __RPC_FAR * This,
    /* [in] */ IImage __RPC_FAR *newVal);


void __RPC_STUB ICanvas_putref_Source_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propget] */ HRESULT STDMETHODCALLTYPE ICanvas_get_AntiAlias_Proxy( 
    ICanvas __RPC_FAR * This,
    /* [retval][out] */ VARIANT_BOOL __RPC_FAR *pVal);


void __RPC_STUB ICanvas_get_AntiAlias_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id][propput] */ HRESULT STDMETHODCALLTYPE ICanvas_put_AntiAlias_Proxy( 
    ICanvas __RPC_FAR * This,
    /* [in] */ VARIANT_BOOL __RPC_FAR *pNewVal);


void __RPC_STUB ICanvas_put_AntiAlias_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICanvas_DrawLine_Proxy( 
    ICanvas __RPC_FAR * This,
    /* [in] */ Point __RPC_FAR *pt1,
    /* [in] */ Point __RPC_FAR *pt2,
    int color,
    int thickness);


void __RPC_STUB ICanvas_DrawLine_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICanvas_DrawRect_Proxy( 
    ICanvas __RPC_FAR * This,
    /* [in] */ Point __RPC_FAR *pt1,
    /* [in] */ Point __RPC_FAR *pt2,
    int color,
    int thickness);


void __RPC_STUB ICanvas_DrawRect_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICanvas_DrawCircle_Proxy( 
    ICanvas __RPC_FAR * This,
    /* [in] */ Point __RPC_FAR *center,
    int radius,
    int color,
    int thickness);


void __RPC_STUB ICanvas_DrawCircle_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICanvas_DrawEllipse_Proxy( 
    ICanvas __RPC_FAR * This,
    /* [in] */ Point __RPC_FAR *center,
    /* [in] */ Size __RPC_FAR *axes,
    double angle,
    double startAngle,
    double endAngle,
    int color,
    int thickness);


void __RPC_STUB ICanvas_DrawEllipse_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICanvas_INTERFACE_DEFINED__ */


#ifndef __ICVL_INTERFACE_DEFINED__
#define __ICVL_INTERFACE_DEFINED__

/* interface ICVL */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_ICVL;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("E2ADF9F5-1BBE-4297-8049-EF109E519DB7")
    ICVL : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CalcOpticalFlowLK( 
            /* [in] */ IImage __RPC_FAR *srcA,
            /* [in] */ IImage __RPC_FAR *srcB,
            /* [in] */ Size __RPC_FAR *winSize,
            /* [in] */ IImage __RPC_FAR *velx,
            /* [in] */ IImage __RPC_FAR *vely) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CamShift( 
            /* [in] */ IImage __RPC_FAR *imgProb,
            /* [in] */ Rect __RPC_FAR *windowIn,
            /* [in] */ TermCriteria __RPC_FAR *criteria,
            /* [out][in] */ ConnectedComp __RPC_FAR *out,
            /* [out][in] */ Box2D __RPC_FAR *box) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CalcBackProject( 
            /* [in] */ IImage __RPC_FAR *srcImg,
            /* [in] */ IHistogram __RPC_FAR *srcHist,
            /* [in] */ IImage __RPC_FAR *dstImg) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Erode( 
            /* [in] */ IImage __RPC_FAR *src,
            /* [in] */ IImage __RPC_FAR *dst,
            /* [defaultvalue] */ int iterations = 1) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Dilate( 
            /* [in] */ IImage __RPC_FAR *src,
            /* [in] */ IImage __RPC_FAR *dst,
            /* [defaultvalue] */ int iterations = 1) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct ICVLVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            ICVL __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            ICVL __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            ICVL __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            ICVL __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            ICVL __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            ICVL __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            ICVL __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CalcOpticalFlowLK )( 
            ICVL __RPC_FAR * This,
            /* [in] */ IImage __RPC_FAR *srcA,
            /* [in] */ IImage __RPC_FAR *srcB,
            /* [in] */ Size __RPC_FAR *winSize,
            /* [in] */ IImage __RPC_FAR *velx,
            /* [in] */ IImage __RPC_FAR *vely);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CamShift )( 
            ICVL __RPC_FAR * This,
            /* [in] */ IImage __RPC_FAR *imgProb,
            /* [in] */ Rect __RPC_FAR *windowIn,
            /* [in] */ TermCriteria __RPC_FAR *criteria,
            /* [out][in] */ ConnectedComp __RPC_FAR *out,
            /* [out][in] */ Box2D __RPC_FAR *box);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CalcBackProject )( 
            ICVL __RPC_FAR * This,
            /* [in] */ IImage __RPC_FAR *srcImg,
            /* [in] */ IHistogram __RPC_FAR *srcHist,
            /* [in] */ IImage __RPC_FAR *dstImg);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Erode )( 
            ICVL __RPC_FAR * This,
            /* [in] */ IImage __RPC_FAR *src,
            /* [in] */ IImage __RPC_FAR *dst,
            /* [defaultvalue] */ int iterations);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Dilate )( 
            ICVL __RPC_FAR * This,
            /* [in] */ IImage __RPC_FAR *src,
            /* [in] */ IImage __RPC_FAR *dst,
            /* [defaultvalue] */ int iterations);
        
        END_INTERFACE
    } ICVLVtbl;

    interface ICVL
    {
        CONST_VTBL struct ICVLVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define ICVL_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define ICVL_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define ICVL_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define ICVL_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define ICVL_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define ICVL_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define ICVL_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define ICVL_CalcOpticalFlowLK(This,srcA,srcB,winSize,velx,vely)	\
    (This)->lpVtbl -> CalcOpticalFlowLK(This,srcA,srcB,winSize,velx,vely)

#define ICVL_CamShift(This,imgProb,windowIn,criteria,out,box)	\
    (This)->lpVtbl -> CamShift(This,imgProb,windowIn,criteria,out,box)

#define ICVL_CalcBackProject(This,srcImg,srcHist,dstImg)	\
    (This)->lpVtbl -> CalcBackProject(This,srcImg,srcHist,dstImg)

#define ICVL_Erode(This,src,dst,iterations)	\
    (This)->lpVtbl -> Erode(This,src,dst,iterations)

#define ICVL_Dilate(This,src,dst,iterations)	\
    (This)->lpVtbl -> Dilate(This,src,dst,iterations)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICVL_CalcOpticalFlowLK_Proxy( 
    ICVL __RPC_FAR * This,
    /* [in] */ IImage __RPC_FAR *srcA,
    /* [in] */ IImage __RPC_FAR *srcB,
    /* [in] */ Size __RPC_FAR *winSize,
    /* [in] */ IImage __RPC_FAR *velx,
    /* [in] */ IImage __RPC_FAR *vely);


void __RPC_STUB ICVL_CalcOpticalFlowLK_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICVL_CamShift_Proxy( 
    ICVL __RPC_FAR * This,
    /* [in] */ IImage __RPC_FAR *imgProb,
    /* [in] */ Rect __RPC_FAR *windowIn,
    /* [in] */ TermCriteria __RPC_FAR *criteria,
    /* [out][in] */ ConnectedComp __RPC_FAR *out,
    /* [out][in] */ Box2D __RPC_FAR *box);


void __RPC_STUB ICVL_CamShift_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICVL_CalcBackProject_Proxy( 
    ICVL __RPC_FAR * This,
    /* [in] */ IImage __RPC_FAR *srcImg,
    /* [in] */ IHistogram __RPC_FAR *srcHist,
    /* [in] */ IImage __RPC_FAR *dstImg);


void __RPC_STUB ICVL_CalcBackProject_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICVL_Erode_Proxy( 
    ICVL __RPC_FAR * This,
    /* [in] */ IImage __RPC_FAR *src,
    /* [in] */ IImage __RPC_FAR *dst,
    /* [defaultvalue] */ int iterations);


void __RPC_STUB ICVL_Erode_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ICVL_Dilate_Proxy( 
    ICVL __RPC_FAR * This,
    /* [in] */ IImage __RPC_FAR *src,
    /* [in] */ IImage __RPC_FAR *dst,
    /* [defaultvalue] */ int iterations);


void __RPC_STUB ICVL_Dilate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __ICVL_INTERFACE_DEFINED__ */


#ifndef __IIPL_INTERFACE_DEFINED__
#define __IIPL_INTERFACE_DEFINED__

/* interface IIPL */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IIPL;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("A469FEE4-34F4-4130-BDD7-FB3D847D7EF6")
    IIPL : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE RGB2HSV( 
            /* [in] */ IImage __RPC_FAR *rgbImage,
            /* [in] */ IImage __RPC_FAR *hsvImage) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IIPLVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IIPL __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IIPL __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IIPL __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IIPL __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IIPL __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IIPL __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IIPL __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *RGB2HSV )( 
            IIPL __RPC_FAR * This,
            /* [in] */ IImage __RPC_FAR *rgbImage,
            /* [in] */ IImage __RPC_FAR *hsvImage);
        
        END_INTERFACE
    } IIPLVtbl;

    interface IIPL
    {
        CONST_VTBL struct IIPLVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IIPL_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IIPL_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IIPL_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IIPL_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IIPL_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IIPL_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IIPL_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IIPL_RGB2HSV(This,rgbImage,hsvImage)	\
    (This)->lpVtbl -> RGB2HSV(This,rgbImage,hsvImage)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IIPL_RGB2HSV_Proxy( 
    IIPL __RPC_FAR * This,
    /* [in] */ IImage __RPC_FAR *rgbImage,
    /* [in] */ IImage __RPC_FAR *hsvImage);


void __RPC_STUB IIPL_RGB2HSV_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IIPL_INTERFACE_DEFINED__ */


#ifndef __IHistogram_INTERFACE_DEFINED__
#define __IHistogram_INTERFACE_DEFINED__

/* interface IHistogram */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IHistogram;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("6E247538-7A9B-453B-8416-9F0B96C4D5C3")
    IHistogram : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadFromFile( 
            /* [in] */ BSTR FileName) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IHistogramVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IHistogram __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IHistogram __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IHistogram __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IHistogram __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IHistogram __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IHistogram __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IHistogram __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadFromFile )( 
            IHistogram __RPC_FAR * This,
            /* [in] */ BSTR FileName);
        
        END_INTERFACE
    } IHistogramVtbl;

    interface IHistogram
    {
        CONST_VTBL struct IHistogramVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IHistogram_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IHistogram_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IHistogram_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IHistogram_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IHistogram_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IHistogram_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IHistogram_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IHistogram_ReadFromFile(This,FileName)	\
    (This)->lpVtbl -> ReadFromFile(This,FileName)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IHistogram_ReadFromFile_Proxy( 
    IHistogram __RPC_FAR * This,
    /* [in] */ BSTR FileName);


void __RPC_STUB IHistogram_ReadFromFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IHistogram_INTERFACE_DEFINED__ */



#ifndef __COMCVLib_LIBRARY_DEFINED__
#define __COMCVLib_LIBRARY_DEFINED__

/* library COMCVLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_COMCVLib;

EXTERN_C const CLSID CLSID_Image;

#ifdef __cplusplus

class DECLSPEC_UUID("21B75F23-C369-4777-9F0E-195B65623E65")
Image;
#endif

EXTERN_C const CLSID CLSID_IPL;

#ifdef __cplusplus

class DECLSPEC_UUID("15A612D5-5030-4CF6-A2FA-1A890E5146C1")
IPL;
#endif

EXTERN_C const CLSID CLSID_Histogram;

#ifdef __cplusplus

class DECLSPEC_UUID("6ECA18D2-A53D-4DD9-A14F-DC8C03FAC24C")
Histogram;
#endif

EXTERN_C const CLSID CLSID_Canvas;

#ifdef __cplusplus

class DECLSPEC_UUID("61BE5D38-7BFB-4CD0-81B0-C8DC00C0AB17")
Canvas;
#endif

EXTERN_C const CLSID CLSID_CVL;

#ifdef __cplusplus

class DECLSPEC_UUID("6BC06698-8499-46D2-A701-F1FAFFDED323")
CVL;
#endif
#endif /* __COMCVLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  LPSAFEARRAY_UserSize(     unsigned long __RPC_FAR *, unsigned long            , LPSAFEARRAY __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  LPSAFEARRAY_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  LPSAFEARRAY_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 
void                      __RPC_USER  LPSAFEARRAY_UserFree(     unsigned long __RPC_FAR *, LPSAFEARRAY __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
