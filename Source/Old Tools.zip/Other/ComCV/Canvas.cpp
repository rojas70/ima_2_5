// Canvas.cpp : Implementation of CCanvas
#include "stdafx.h"
#include "ComCV.h"
#include "Canvas.h"
#include "Image.h"

/////////////////////////////////////////////////////////////////////////////
// CCanvas


STDMETHODIMP CCanvas::get_Source(IImage **pVal)
{
	(*pVal) = (IImage *)m_pImage;
	(*pVal)->AddRef();
	return S_OK;
}

STDMETHODIMP CCanvas::putref_Source(IImage *newVal)
{
	if (m_pImage != NULL) m_pImage->Release();
	m_pImage = newVal;
	return S_OK;
}

STDMETHODIMP CCanvas::get_AntiAlias(VARIANT_BOOL* pVal)
{
	*pVal = m_AntiAlias;
	return S_OK;
}

STDMETHODIMP CCanvas::put_AntiAlias(VARIANT_BOOL* pNewVal)
{
	m_AntiAlias = *pNewVal;
	return S_OK;
}

/*F///////////////////////////////////////////////////////////////////////////////////////
//
//    Name:    cvLine
//    Purpose:
//      Draws line on the image ROI between two points
//    Context:
//    Parameters:
//        img  - image where the line is drawn.
//        pt1  - starting point
//        pt2  - ending point
//        thickness - line thickness. 1 means simple line.
//                    if line is thick, function draws the line with round endings.
//        color - line color(or brightness)
//    Returns:
//F*/
STDMETHODIMP CCanvas::DrawLine(Point *pt1, Point *pt2, int color, int thickness)
{
	if(m_AntiAlias) 
	{
		cvLineAA(	((CImage *)m_pImage)->m_pHeader, 
					*((CvPoint *)pt1), 
					*((CvPoint *)pt2), color, thickness);
	}
	else
	{
		cvLine(	((CImage *)m_pImage)->m_pHeader, 
				*((CvPoint *)pt1), 
				*((CvPoint *)pt2), color, thickness);
	}
	return S_OK;
}

/*F///////////////////////////////////////////////////////////////////////////////////////
//
//    Name:    cvRectangle
//    Purpose:
//      Draws rectangle on the image ROI
//    Context:
//    Parameters:
//        img  - image where the rectangle is drawn.
//        pt1  - one of the rectangle corners
//        pt2  - opposite corner of the rectangle
//        thickness - thickness of the lines that made up rectangle. CV_DEFAULT(1)
//        color - line color(or brightness)
//    Returns:
//F*/
STDMETHODIMP CCanvas::DrawRect(Point *pt1, Point *pt2, int color, int thickness)
{
	cvRectangle(	((CImage *)m_pImage)->m_pHeader, 
					*((CvPoint *)pt1), 
					*((CvPoint *)pt2), color, thickness);
	return S_OK;
}


/*F///////////////////////////////////////////////////////////////////////////////////////
//
//    Name:    cvCircle
//    Purpose:
//      Draws circle on the image ROI
//    Context:
//    Parameters:
//        img  - image.
//        center - circle center
//        radius - circle radius(must be >= 0)
//        color - circle color(or brightness)
//        thickenss - thickness of drawn circle. <0 means filled circle. CV_DEFAULT(1)
//    Returns:
//F*/
STDMETHODIMP CCanvas::DrawCircle(Point *center, int radius, int color, int thickness)
{
	if(m_AntiAlias) 
	{
		cvCircleAA(	((CImage *)m_pImage)->m_pHeader, 
					*((CvPoint *)center), 
					radius, color, thickness);
	}
	else
	{
		cvCircle(	((CImage *)m_pImage)->m_pHeader, 
					*((CvPoint *)center), 
					radius, color, thickness);
	}	
	return S_OK;
}

/*F///////////////////////////////////////////////////////////////////////////////////////
//
//    Name:    cvEllipse
//    Purpose:
//      Draws elliptic arc
//    Context:
//    Parameters:
//        img  - image.
//        center - ellipse center
//        axes - half axes of the ellipse
//        angle - ellipse angle
//        startAngle - starting angle of elliptic arc
//        endAngle - ending angle of elliptic arc
//        color - ellipse color(or brightness)
//        thickness - arc thickness CV_DEFAULT(1) 
//        scale - number of fractioanl bits in center coordinates and axes sizes. CV_DEFAULT(0) 
//    Returns:
//F*/
STDMETHODIMP CCanvas::DrawEllipse(Point *center, Size * axes, double angle, double startAngle, double endAngle, int color, int thickness)
{
	if(m_AntiAlias) 
	{
		cvEllipseAA(((CImage *)m_pImage)->m_pHeader, 
					*((CvPoint *)center), 
					*((CvSize *)axes), 
					angle, startAngle, endAngle, color, thickness);
	}
	else
	{
		cvEllipse(	((CImage *)m_pImage)->m_pHeader, 
					*((CvPoint *)center), 
					*((CvSize *)axes), 
					angle, startAngle, endAngle, color, thickness);
	}
	return S_OK;
}
