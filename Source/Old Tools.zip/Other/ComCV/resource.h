//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ComCV.rc
//
#define IDS_PROJNAME                    100
#define IDR_IMAGE                       102
#define IDR_CONNECTEDCOMP               109
#define IDR_IPL                         110
#define IDR_HISTOGRAM                   112
#define IDR_CANVAS                      114
#define IDR_CVL                         118

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           119
#endif
#endif
