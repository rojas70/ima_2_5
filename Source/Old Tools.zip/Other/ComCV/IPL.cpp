// IPL.cpp : Implementation of CIPL
#include "stdafx.h"
#include "ComCV.h"
#include "Ipl.h"

/////////////////////////////////////////////////////////////////////////////
// CIPL

STDMETHODIMP CIPL::RGB2HSV(IImage* rgbImage, IImage* hsvImage)
{
	IplImage *			src = ((CImage*)rgbImage)->m_pHeader;
	IplImage *			dst = ((CImage*)hsvImage)->m_pHeader;
	struct _IplROI *	r1 = src->roi;
	struct _IplROI *	r2 = dst->roi;

	// Save ROIs
	src->roi = NULL;	dst->roi = NULL;	
	
	// Convert with NULL ROIs
	iplRGB2HSV(src, dst);					
	
	// Restore ROIs
	src->roi = r1;		dst->roi = r2;

	return S_OK;
}
