// Histogram.cpp : Implementation of CHistogram
#include "stdafx.h"
#include "ComCV.h"
#include "Histogram.h"

/////////////////////////////////////////////////////////////////////////////
// CHistogram
#define LARGE_CHAR 40800

STDMETHODIMP CHistogram::ReadFromFile(BSTR FileName)
{
	USES_CONVERSION;
	FILE *	fp;
	long	lInfo;
	char *	token;
	char *	pcRet;
	char	szTemp[LARGE_CHAR];

	long	DataCount = 0;
	float	Data[256];

	// Open hist file
	fp = fopen(OLE2T(FileName), "rt");
	if(fp == NULL)	return !S_OK;
	
	// Initialize token loops
	pcRet = fgets(szTemp,LARGE_CHAR,fp);
	lInfo = feof(fp) || ferror(fp);

	// Retrieve values
	while(lInfo == 0)
	{
		token = strtok(szTemp, " ,\t\n");
		while(token != NULL )
		{
			Data[DataCount++] = (float) atof(token);
			token = strtok( NULL, " ,\t\n");
		}
		pcRet = fgets(szTemp,LARGE_CHAR,fp);
		lInfo = feof(fp) || ferror(fp);
	}

	// Close file
	fclose(fp);
	
	int			numBinArray[1] = {256};
	float**		thresh = new float* [1];

	thresh[0]		= new float[2];
	thresh[0][0]	= 0.0;
	thresh[0][1]	= 256.0;
	
	m_pCvHist = cvCreateHist(1, numBinArray, CV_HIST_ARRAY);
	cvMakeHistHeaderForArray(1, numBinArray, m_pCvHist, Data, thresh, 1);


	// Now what?

	return S_OK;
}
