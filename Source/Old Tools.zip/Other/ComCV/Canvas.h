// Canvas.h : Declaration of the CCanvas

#ifndef __CANVAS_H_
#define __CANVAS_H_

#include "resource.h"       // main symbols

//#include "Point.h"
//#include "Size.h"
#include <cv.h>

/////////////////////////////////////////////////////////////////////////////
// CCanvas
class ATL_NO_VTABLE CCanvas : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCanvas, &CLSID_Canvas>,
	public IDispatchImpl<ICanvas, &IID_ICanvas, &LIBID_COMCVLib>
{
public:
	CCanvas()
	{
		m_AntiAlias = false;
		m_pImage = NULL;
	}

	IImage *		m_pImage;
	VARIANT_BOOL	m_AntiAlias;

DECLARE_REGISTRY_RESOURCEID(IDR_CANVAS)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCanvas)
	COM_INTERFACE_ENTRY(ICanvas)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ICanvas
public:
	STDMETHOD (get_Source)		(/*[out, retval]*/ IImage **pVal);
	STDMETHOD (putref_Source)	(/*[in]*/ IImage * newVal);
	STDMETHOD (get_AntiAlias)	(/*[out, retval]*/ VARIANT_BOOL *pVal);
	STDMETHOD (put_AntiAlias)	(/*[in]*/ VARIANT_BOOL * pNewVal);

	STDMETHOD (DrawLine)		(Point *pt1, Point *pt2, int color, int thickness);
	STDMETHOD (DrawRect)		(Point *pt1, Point *pt2, int color, int thickness);
	STDMETHOD (DrawCircle)		(Point *center, int radius, int color, int thickness);
	STDMETHOD (DrawEllipse)		(Point *center, Size * axes, double angle, double startAngle, double endAngle, int color, int thickness);

};

#endif //__CANVAS_H_