// Image.cpp : Implementation of CImage
#include "stdafx.h"
#include "ComCV.h"
#include "Image.h"
#include "vlgrfmts.h"

/////////////////////////////////////////////////////////////////////////////
// CImage

// **********************************************************************************
// ****************************** Constructor and Destructor ************************ 
// **********************************************************************************

CImage::CImage()
{
	HRESULT hres;
	m_pHeader	= NULL;
	m_pSA		= NULL;
	m_pData		= NULL;
	
	hres = CoCreateInstance(CLSID_Canvas, NULL, CLSCTX_INPROC, IID_ICanvas, (void **)&m_pCanvas);
	m_pCanvas->m_pImage = (IImage *)this;

	m_Width	= m_Height = m_Channels = m_BitDepth = m_BytesPerRow = 0;
}

CImage::~CImage()
{
	Clear();
	m_pCanvas->Release();
}

STDMETHODIMP CImage::Clear()
{
	HRESULT hres;
	if (m_pHeader != NULL)	
	{ 
		cvReleaseImageHeader(&m_pHeader); 
	}
	if (m_pSA != NULL)		
	{ 
		hres = SafeArrayUnaccessData(m_pSA); 
		hres = SafeArrayDestroy(m_pSA); 
		m_pSA = NULL; 
	}
	m_Width = m_Height = m_Channels = m_BitDepth = m_BytesPerRow = m_Size.height = m_Size.width = 0;
	return S_OK;
}


void CImage::UpdateImageInfo()
{
	m_Channels		= m_pHeader->nChannels;
	m_BitDepth		= m_pHeader->depth;
	m_BytesPerRow	= (short)m_pSA->rgsabound[1].cElements;
	m_Height		= (short)m_pSA->rgsabound[0].cElements;
	m_Width			= (short)(m_BytesPerRow / m_Channels);	
	m_Size.height	= m_Height;
	m_Size.width	= m_Width;
}

// **********************************************************************************
// ***************************** Image Creation Functions ***************************
// **********************************************************************************

STDMETHODIMP CImage::CreateBlankImage(short width, short height, ChannelCount Channels, BitDepths BitDepth)
{
	// Release existing data
	Clear();

	// Create SafeArray bounds
	SAFEARRAYBOUND	bounds[2];	
	bounds[0].lLbound = 0;	bounds[0].cElements = width * (BitDepth >> 3) * Channels;
	bounds[1].lLbound = 0;	bounds[1].cElements = height;	

	// Allocate data
	m_pSA = SafeArrayCreate(VT_UI1, 2, bounds);
	SafeArrayAccessData(m_pSA, &m_pData);

	// Create & Copy Image Header
	m_pHeader = cvCreateImageHeader(cvSize(width, height),BitDepth, Channels);

	// Retrieve width and height information from SA.
	UpdateImageInfo();

	// Set ipl image data
	cvSetImageData(m_pHeader, m_pData, m_BytesPerRow);

	// Select the entire region by default.
	SelectEntireRegion();

	return S_OK;
}

// Takes an IplImage * and copies its data to a new image buffer.
HRESULT CImage::CreateFromHeader(IplImage *src)
{
	// Create a new image according to source specs
	CreateBlankImage(src->width, src->height, (ChannelCount)(src->nChannels), (BitDepths)(src->depth));

	// Exit if invalid image
	if ((src == NULL) || (src->imageData == NULL)) return !S_OK;

	// Copy data to safearray
	CopyMemory(m_pData, src->imageData, sizeof(BYTE) * src->imageSize);
	
	return S_OK;
}

// Accepts a SAFEARRAY and constructs an IPLIMAGE around it.
STDMETHODIMP CImage::SetImageBuffer(SAFEARRAY ** Src, ChannelCount Channels, BitDepths BitDepth)
{
	// If we're creating a new image, destroy the old one.
	Clear();	
	if ((*Src) == NULL) return S_OK;

	// Attach to the array
	m_pSA = (*Src);
	SafeArrayAccessData(m_pSA, &m_pData);

	// Construct an ipl image header
	m_pHeader = cvCreateImageHeader(cvSize(m_pSA->rgsabound[1].cElements / Channels , m_pSA->rgsabound[0].cElements), BitDepth, Channels);

	// Retrieve width and height information.
	UpdateImageInfo();

	// Set ipl image data
	cvSetImageData(m_pHeader, m_pData, m_pSA->rgsabound[1].cElements);

	// Select the entire region by default.
	SelectEntireRegion();

    return S_OK;
}

// Takes an IImage * and copies its data to a new image buffer within this object.
STDMETHODIMP CImage::CopyImage(IImage * srcImage)
{
	CreateFromHeader(((CImage *)srcImage)->m_pHeader);
	return S_OK;
}

// Makes a new Image object and copies this Image's data to it.
STDMETHODIMP CImage::CreateCopy(IImage ** pVal)
{
	CImage *	img;
	HRESULT		hres;
	
	hres = CoCreateInstance(CLSID_Image, NULL, CLSCTX_INPROC, IID_IImage, (void **) pVal);
	if (hres != S_OK) return hres;

	img = (CImage *)(*pVal);
	img->CreateFromHeader(m_pHeader);

	return S_OK;
}

// **********************************************************************************
// ****************************** Object based methods ****************************** 
// **********************************************************************************


// **********************************************************************************
// ****************************** Variant based methods ****************************** 
// **********************************************************************************


// **********************************************************************************
// *********************************** Properties *********************************** 
// **********************************************************************************

STDMETHODIMP CImage::get_Canvas(ICanvas **pVal)
{
	*pVal = m_pCanvas;
	m_pCanvas->AddRef();
	return S_OK;
}

STDMETHODIMP CImage::get_Width(short *pVal)
{
	*pVal = m_Width;
	return S_OK;
}

STDMETHODIMP CImage::get_Height(short *pVal)
{
	*pVal = m_Height;
	return S_OK;
}

STDMETHODIMP CImage::get_Channels(short *pVal)
{
	*pVal = m_Channels;
	return S_OK;
}

STDMETHODIMP CImage::get_BitDepth(short *pVal)
{
	*pVal = m_BitDepth;
	return S_OK;
}

STDMETHODIMP CImage::get_BytesPerRow(short *pVal)
{
	*pVal = m_BytesPerRow;
	return S_OK;
}

// Returns a 2D byte array of the image data.
STDMETHODIMP CImage::get_Data(SAFEARRAY **pVal)
{
	SAFEARRAYBOUND	rgsabound[2];	// Used to allocate SafeArray descriptor
	if (m_pData == NULL) return S_OK;

	rgsabound[0].cElements	= m_pSA->rgsabound[1].cElements;
	rgsabound[0].lLbound	= m_pSA->rgsabound[1].lLbound;
	rgsabound[1].cElements	= m_pSA->rgsabound[0].cElements;
	rgsabound[1].lLbound	= m_pSA->rgsabound[0].lLbound;

	// Create the array and descriptor, lock it, and return fail if out of memory.
	(*pVal) = SafeArrayCreate(VT_UI1, 2, rgsabound);
	CopyMemory((*pVal)->pvData, m_pData, sizeof(BYTE) * m_BytesPerRow * m_Height);
	
//	HRESULT hres = SafeArrayCopy(m_pSA, pVal);
//	return hres;
	
	return S_OK;
}

STDMETHODIMP CImage::put_Data(SAFEARRAY **pVal)
{
	if (	(*pVal)->rgsabound[0].cElements != m_pSA->rgsabound[0].cElements && 
			(*pVal)->rgsabound[1].cElements != m_pSA->rgsabound[1].cElements)
	{
		CopyMemory(m_pData, (*pVal)->pvData, sizeof(BYTE) * m_BytesPerRow * m_Height);
		return S_OK;
	}
	return !S_OK;
}

// Returns a 1D byte array of the image data.
STDMETHODIMP CImage::get_Bytes(SAFEARRAY **pVal)
{
	SAFEARRAYBOUND	rgsabound[1];	// Used to allocate SafeArray descriptor
	if (m_pData == NULL) return S_OK;

	rgsabound[0].cElements	= m_pSA->rgsabound[1].cElements * m_pSA->rgsabound[0].cElements;
	rgsabound[0].lLbound	= 0;

	// Create the array and descriptor, lock it, and return fail if out of memory.
	(*pVal) = SafeArrayCreate(VT_UI1, 1, rgsabound);
	CopyMemory((*pVal)->pvData, m_pData, sizeof(BYTE) * m_BytesPerRow * m_Height);
	
	return S_OK;
}

STDMETHODIMP CImage::put_Bytes(SAFEARRAY **pVal)
{
	if ((*pVal)->cbElements = m_BytesPerRow * m_Height)
	{
		CopyMemory(m_pData, (*pVal)->pvData, sizeof(BYTE) * m_BytesPerRow * m_Height);
		return S_OK;
	}
	return !S_OK;
}


STDMETHODIMP CImage::GetPlane(PlaneNumber plane, IImage **pVal)
{
	CImage *	rv;
	HRESULT		hres;
	
	// If no source image, then exit
	if (m_pData == NULL) return !S_OK;
	
	// Create a new image object	
	hres = CoCreateInstance(CLSID_Image, NULL, CLSCTX_INPROC, IID_IImage, (void **)&rv);
	if (hres != S_OK) return hres;
	
	//  Create a new image with just one channel.
	rv->CreateBlankImage(m_Width, m_Height, CC_PLANE, (BitDepths)m_BitDepth);
	if (hres != S_OK) return hres;

	// Copy the image plane over
	switch (plane)
	{
		case 0:		cvCvtPixToPlane(m_pHeader, rv->m_pHeader, NULL, NULL, NULL); break;
		case 1:		cvCvtPixToPlane(m_pHeader, NULL, rv->m_pHeader, NULL, NULL); break;
		case 2:		cvCvtPixToPlane(m_pHeader, NULL, NULL, rv->m_pHeader, NULL); break;
		case 3:		cvCvtPixToPlane(m_pHeader, NULL, NULL, NULL, rv->m_pHeader); break;
	}

	// Return the image object
	*pVal = (IImage *)rv;

	return S_OK;
}



STDMETHODIMP CImage::get_Size(Size *pVal)
{
	*pVal = m_Size; 
	return S_OK;
}

/********************************************************************************************************************/
/* File I/O *********************************************************************************************************/
/********************************************************************************************************************/

// Gary R. Bradski  7/18/00
// JUST SOME READ-WRITE BMP UTILITIES USING cvlgrfmts.lib
// Read in a BMP and convert it into an IPL
// fin      The file name of the BMP with path
// plannar  If set, convert the image to plannar
// flip     If set, mirror the image around the horizontal axis, set IPL_ORIGIN_BL)
STDMETHODIMP CImage::ReadImage(BSTR Filename)
{
    char fin[255];
	wcstombs(fin, Filename, sizeof(fin));

	/********************************** Begin extracted block **********************************/
    int filter;
    int width=0,height=0,color=55,hdr_ret=0,close_ret = 0,rd_ret = 0;
    IplImage *I;
    filter = gr_fmt_find_filter(fin );     //Get file type
    hdr_ret = gr_fmt_read_header( filter, &width, &height, &color );//image params

    I = cvCreateImageHeader( cvSize(width, height), IPL_DEPTH_8U, 3); //create image header
    
	// *RO* - Fix the problem created by the problem fix. (QWORD alginment is nice for speed, but not for SafeArrays)
	//I->align = IPL_ALIGN_QWORD;  //fix the problem that cvCreateImage uses align 4
    
	I->depth != IPL_DEPTH_32F ? iplAllocateImage( I, 0, 0 ) : iplAllocateImageFP( I, 0, 0 );
    rd_ret =  gr_fmt_read_data(filter, I->imageData, I->widthStep, color); //read in the data, origin TL
    close_ret =  gr_fmt_close_filter( filter );
    /********************************** End extracted block **********************************/

	// Copy the image and its header, then deallocate the original header.
	CreateFromHeader(I);
	cvReleaseImage(&I);

    return S_OK;
}

//////////////////////////////////////////
// Write IPL image to disk
// fout     Path\filename to write to
// I        IPL image to be written
//
// I may be any of
// dataOrder Plane or Pixel
// 1 channel (GRAY) or 3 (RGB)
// 8U, 8S, 32F
// Origin TL or BL (if BL, image is flipped to conform to TL bmps)
//
// If image is not RGB or GRAY, RGB is simply imposed on the Image.  E.g. if it's YUV,
// the image will be stored as BGR with B=Y, G=U, and R=V
STDMETHODIMP CImage::WriteImage(BSTR Filename)
{
    char fout[255];
	IplImage *I;
	
	wcstombs(fout, Filename, sizeof(fout));
	I = m_pHeader;	// I'm Sooooooo Lazy

    /********************************** Begin extracted block **********************************/
	IplImage *Isav,*Itmp;
	Isav = iplCloneImage(I);
    //Convert to pixel order if needed
    if(Isav->dataOrder == IPL_DATA_ORDER_PLANE)
    {
        Itmp = iplCreateImageHeader(Isav->nChannels,
                        Isav->alphaChannel, Isav->depth, Isav->colorModel,
                        Isav->channelSeq, IPL_DATA_ORDER_PIXEL, Isav->origin, Isav->align,
                        Isav->width, Isav->height, NULL, NULL,NULL,NULL);
        if(Isav->depth == IPL_DEPTH_32F)
              iplAllocateImageFP(Itmp, 1,0.0);
        else
            iplAllocateImage(Itmp, 1,0);
        iplConvert(Isav, Itmp);
        iplDeallocate (Isav, IPL_IMAGE_ALL);
        Isav = Itmp;
    }
    //Image is now pixel order.  Convert to 8U if needed.
    if(Isav->depth == IPL_DEPTH_8S)
        Isav->depth = IPL_DEPTH_8U;
    else if(Isav->depth == IPL_DEPTH_32F)
    {   
        float min,max;
        iplMinMaxFP (Isav, &min, &max);
        Itmp = iplCreateImageHeader(Isav->nChannels,
                        Isav->alphaChannel, IPL_DEPTH_8U, Isav->colorModel,
                        Isav->channelSeq, IPL_DATA_ORDER_PIXEL, Isav->origin, Isav->align,
                        Isav->width, Isav->height, NULL, NULL,NULL,NULL);
        iplAllocateImage(Itmp, 1,0);
        if(min >= max) max = (float)(min + 1.0);
        iplScaleFP (Isav, Itmp, min, max);
        iplDeallocate (Isav, IPL_IMAGE_ALL);
        Isav = Itmp;
    }
    //Image is now pixel order, 8U.  Convert to RGB if needed
    if(Isav->nChannels == 3)
    {
        strcpy(Isav->colorModel,"RGB");
        strcpy(Isav->channelSeq,"BGR");
    }
    else if(Isav->nChannels == 1)
    {
        Itmp = iplCreateImageHeader(3,
                        Isav->alphaChannel, IPL_DEPTH_8U, "RGB",
                        "BGR", IPL_DATA_ORDER_PIXEL, Isav->origin, Isav->align,
                        Isav->width, Isav->height, NULL, NULL,NULL,NULL);
        iplAllocateImage(Itmp, 1,0);
        iplGrayToColor (Isav, Itmp, 1.0, 1.0, 1.0);
        iplDeallocate (Isav, IPL_IMAGE_ALL);
        Isav = Itmp;
    }
    else
        return !S_OK;
    //Image is now pixel order, 8U, RGB, flip it if the origin is BL
    if(Isav->origin == IPL_ORIGIN_BL)
    {
        iplMirror(Isav, Isav, 0);
    }
    //FINALLY, WRITE THE IMAGE:
    int write_ret = gr_fmt_write_image( Isav->imageData, Isav->widthStep, 
                             Isav->width, Isav->height, Isav->colorModel[0] == 'R'?1:0,
                             fout, "bmp");
    //Return image to its original state
    iplDeallocate(Isav, IPL_IMAGE_ALL);
    /********************************** End extracted block **********************************/
	
	return S_OK;
}

// **********************************************************************************
// ****************************** Functional Interface ****************************** 
// **********************************************************************************

STDMETHODIMP CImage::SelectEntireRegion()
{
	CvRect			cvr;
	
	if (m_pData == NULL) return !S_OK;

	cvr.x = 0;
	cvr.y = 0;
	cvr.width = m_Width;
	cvr.height = m_Height;

	cvSetImageROI(m_pHeader, cvr);

	return S_OK;
}

STDMETHODIMP CImage::SelectRegion(Rect * region)
{
	cvSetImageROI(m_pHeader, *((CvRect*)region));
	return S_OK;
}


STDMETHODIMP CImage::Resize(short width, short height)
{
	// TODO: Add your implementation code here

	return S_OK;
}

STDMETHODIMP CImage::Crop(short left, short top, short width, short height)
{
	// TODO: Add your implementation code here

	return S_OK;
}

