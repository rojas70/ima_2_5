// CVL.h : Declaration of the CCVL

#ifndef __CVL_H_
#define __CVL_H_

#include "resource.h"       // main symbols
#include "Image.h"
#include "Histogram.h"
#include <cv.h>

/////////////////////////////////////////////////////////////////////////////
// CCVL
class ATL_NO_VTABLE CCVL : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CCVL, &CLSID_CVL>,
	public IDispatchImpl<ICVL, &IID_ICVL, &LIBID_COMCVLib>
{
public:
	CCVL()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_CVL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CCVL)
	COM_INTERFACE_ENTRY(ICVL)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// ICVL
public:

	// Optical Flow
	STDMETHOD (CalcOpticalFlowLK)	(IImage *srcA, IImage *srcB, Size *winSize, IImage *velx, IImage *vely);
	
	// CamSHIFT
	STDMETHOD (CamShift)			(IImage* imgProb, Rect * windowIn, TermCriteria * criteria, ConnectedComp * out, Box2D* box);
	
	// Back Projection
	STDMETHOD (CalcBackProject)		(IImage *srcImg, IHistogram *hist, IImage* dstImg);
	
	// Morphology
	STDMETHOD (Erode)				(IImage* src, IImage* dst, int iterations);
	STDMETHOD (Dilate)				(IImage* src, IImage* dst, int iterations);
};

#endif //__CVL_H_
