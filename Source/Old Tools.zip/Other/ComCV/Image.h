// Image.h : Declaration of the CImage

#ifndef __IMAGE_H_
#define __IMAGE_H_

#include "resource.h"       // main symbols
#include "Canvas.h"
#include <ipl.h>
#include <cv.h>

/////////////////////////////////////////////////////////////////////////////
// CImage
class ATL_NO_VTABLE CImage : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CImage, &CLSID_Image>,
	public IDispatchImpl<IImage, &IID_IImage, &LIBID_COMCVLib>
{
	private:
		void UpdateImageInfo();

	public:
		CImage();
		~CImage();

		// Public member variables
		IplImage *	m_pHeader;
		SAFEARRAY *	m_pSA;
		void *		m_pData;
		
		CCanvas *	m_pCanvas;

		Size 		m_Size;
		short		m_Width, m_Height, m_BitDepth, m_Channels, m_BytesPerRow;

		// Public functions
		HRESULT CImage::CreateFromHeader(IplImage *src);

	DECLARE_REGISTRY_RESOURCEID(IDR_IMAGE)

	DECLARE_PROTECT_FINAL_CONSTRUCT()

	BEGIN_COM_MAP(CImage)
		COM_INTERFACE_ENTRY(IImage)
		COM_INTERFACE_ENTRY(IDispatch)
	END_COM_MAP()
	// IImage
	public:
		// Image creation & destructor functions
		STDMETHOD (SetImageBuffer)		(/*[in]*/ SAFEARRAY ** newVal, ChannelCount Channels, BitDepths BitDepth);
		STDMETHOD (CreateBlankImage)	(/*[in]*/ short width, short height, ChannelCount Channels, BitDepths BitDepth);
		STDMETHOD (CopyImage)			(/*[in]*/ IImage * srcImage);
		STDMETHOD (ReadImage)			(/*[in]*/ BSTR Filename);
		STDMETHOD (WriteImage)			(/*[in]*/ BSTR Filename);
		STDMETHOD (CreateCopy)			(/*[in]*/ IImage ** retval);

		// ROI Interface
		STDMETHOD (SelectEntireRegion)	();
		STDMETHOD (SelectRegion)		(Rect * region);

		// Functional Interface
		STDMETHOD (Clear)				();
		STDMETHOD (Resize)				(short width, short height);
		STDMETHOD (Crop)				(short left, short top, short width, short height);

		// Data Array Properties
		STDMETHOD (get_Data)			(/*[out, retval]*/ SAFEARRAY ** pVal);
		STDMETHOD (put_Data)			(/*[in]*/ SAFEARRAY **pVal);
		STDMETHOD (get_Bytes)			(/*[out, retval]*/ SAFEARRAY ** pVal);
		STDMETHOD (put_Bytes)			(/*[in]*/ SAFEARRAY **pVal);

		// Basic Properties
		STDMETHOD (get_Size)			(/*[out, retval]*/ Size *pVal);
		STDMETHOD (get_Height)			(/*[out, retval]*/ short *pVal);
		STDMETHOD (get_Width)			(/*[out, retval]*/ short *pVal);
		STDMETHOD (get_Channels)		(/*[out, retval]*/ short *pVal);
		STDMETHOD (get_BitDepth)		(/*[out, retval]*/ short *pVal);
		STDMETHOD (get_BytesPerRow)		(/*[out, retval]*/ short *pVal);

		// Plane & Canvas Functions
		STDMETHOD (GetPlane)			(PlaneNumber plane, IImage **pVal);
		STDMETHOD (get_Canvas)			(/*[out, retval]*/ ICanvas** pVal);
};


#endif //__IMAGE_H_
