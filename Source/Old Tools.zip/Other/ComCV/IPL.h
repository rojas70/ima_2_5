// IPL.h : Declaration of the CIPL

#ifndef __IPL_H_
#define __IPL_H_

#include "resource.h"       // main symbols
#include "Image.h"
#include <cv.h>
#include <ipl.h>

/////////////////////////////////////////////////////////////////////////////
// CIPL
class ATL_NO_VTABLE CIPL : 
	public CComObjectRootEx<CComSingleThreadModel>,
	public CComCoClass<CIPL, &CLSID_IPL>,
	public IDispatchImpl<IIPL, &IID_IIPL, &LIBID_COMCVLib>
{
public:
	CIPL()
	{
	}

DECLARE_REGISTRY_RESOURCEID(IDR_IPL)

DECLARE_PROTECT_FINAL_CONSTRUCT()

BEGIN_COM_MAP(CIPL)
	COM_INTERFACE_ENTRY(IIPL)
	COM_INTERFACE_ENTRY(IDispatch)
END_COM_MAP()

// IIPL
public:
	STDMETHOD (RGB2HSV)	(IImage* rgbImage, IImage* hsvImage);

};

#endif //__IPL_H_
