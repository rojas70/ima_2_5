/* this ALWAYS GENERATED file contains the definitions for the interfaces */


/* File created by MIDL compiler version 3.01.75 */
/* at Thu Aug 09 11:11:59 2001
 */
/* Compiler settings for ICVLProject.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: none
*/
//@@MIDL_FILE_HEADING(  )
#include "rpc.h"
#include "rpcndr.h"
#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ICVLProject_h__
#define __ICVLProject_h__

#ifdef __cplusplus
extern "C"{
#endif 

/* Forward Declarations */ 

#ifndef __IICVLComponent_FWD_DEFINED__
#define __IICVLComponent_FWD_DEFINED__
typedef interface IICVLComponent IICVLComponent;
#endif 	/* __IICVLComponent_FWD_DEFINED__ */


#ifndef __ICVLComponent_FWD_DEFINED__
#define __ICVLComponent_FWD_DEFINED__

#ifdef __cplusplus
typedef class ICVLComponent ICVLComponent;
#else
typedef struct ICVLComponent ICVLComponent;
#endif /* __cplusplus */

#endif 	/* __ICVLComponent_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IICVLComponent_INTERFACE_DEFINED__
#define __IICVLComponent_INTERFACE_DEFINED__

/****************************************
 * Generated header for interface: IICVLComponent
 * at Thu Aug 09 11:11:59 2001
 * using MIDL 3.01.75
 ****************************************/
/* [unique][helpstring][dual][uuid][object] */ 



EXTERN_C const IID IID_IICVLComponent;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    interface DECLSPEC_UUID("EF910130-40BC-11D5-9207-00E02903BD46")
    IICVLComponent : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Threshold( 
            long Input,
            long Output,
            double Value) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Initialize( 
            long __RPC_FAR *InputInfo,
            long __RPC_FAR *OutputInfo) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CreateHistogram( 
            long Input,
            int flag) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CalcBackProjectImage( 
            long Input,
            long Output) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CamShift( 
            long Input,
            int __RPC_FAR *window,
            int __RPC_FAR *iter,
            double __RPC_FAR *center) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReadHistFile( 
            float __RPC_FAR *data,
            long __RPC_FAR *datasize) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE CloseFile( void) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE OpenFile( void) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IICVLComponentVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IICVLComponent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IICVLComponent __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IICVLComponent __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IICVLComponent __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IICVLComponent __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IICVLComponent __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IICVLComponent __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Threshold )( 
            IICVLComponent __RPC_FAR * This,
            long Input,
            long Output,
            double Value);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Initialize )( 
            IICVLComponent __RPC_FAR * This,
            long __RPC_FAR *InputInfo,
            long __RPC_FAR *OutputInfo);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CreateHistogram )( 
            IICVLComponent __RPC_FAR * This,
            long Input,
            int flag);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CalcBackProjectImage )( 
            IICVLComponent __RPC_FAR * This,
            long Input,
            long Output);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CamShift )( 
            IICVLComponent __RPC_FAR * This,
            long Input,
            int __RPC_FAR *window,
            int __RPC_FAR *iter,
            double __RPC_FAR *center);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReadHistFile )( 
            IICVLComponent __RPC_FAR * This,
            float __RPC_FAR *data,
            long __RPC_FAR *datasize);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *CloseFile )( 
            IICVLComponent __RPC_FAR * This);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *OpenFile )( 
            IICVLComponent __RPC_FAR * This);
        
        END_INTERFACE
    } IICVLComponentVtbl;

    interface IICVLComponent
    {
        CONST_VTBL struct IICVLComponentVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IICVLComponent_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IICVLComponent_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IICVLComponent_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IICVLComponent_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IICVLComponent_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IICVLComponent_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IICVLComponent_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IICVLComponent_Threshold(This,Input,Output,Value)	\
    (This)->lpVtbl -> Threshold(This,Input,Output,Value)

#define IICVLComponent_Initialize(This,InputInfo,OutputInfo)	\
    (This)->lpVtbl -> Initialize(This,InputInfo,OutputInfo)

#define IICVLComponent_CreateHistogram(This,Input,flag)	\
    (This)->lpVtbl -> CreateHistogram(This,Input,flag)

#define IICVLComponent_CalcBackProjectImage(This,Input,Output)	\
    (This)->lpVtbl -> CalcBackProjectImage(This,Input,Output)

#define IICVLComponent_CamShift(This,Input,window,iter,center)	\
    (This)->lpVtbl -> CamShift(This,Input,window,iter,center)

#define IICVLComponent_ReadHistFile(This,data,datasize)	\
    (This)->lpVtbl -> ReadHistFile(This,data,datasize)

#define IICVLComponent_CloseFile(This)	\
    (This)->lpVtbl -> CloseFile(This)

#define IICVLComponent_OpenFile(This)	\
    (This)->lpVtbl -> OpenFile(This)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IICVLComponent_Threshold_Proxy( 
    IICVLComponent __RPC_FAR * This,
    long Input,
    long Output,
    double Value);


void __RPC_STUB IICVLComponent_Threshold_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IICVLComponent_Initialize_Proxy( 
    IICVLComponent __RPC_FAR * This,
    long __RPC_FAR *InputInfo,
    long __RPC_FAR *OutputInfo);


void __RPC_STUB IICVLComponent_Initialize_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IICVLComponent_CreateHistogram_Proxy( 
    IICVLComponent __RPC_FAR * This,
    long Input,
    int flag);


void __RPC_STUB IICVLComponent_CreateHistogram_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IICVLComponent_CalcBackProjectImage_Proxy( 
    IICVLComponent __RPC_FAR * This,
    long Input,
    long Output);


void __RPC_STUB IICVLComponent_CalcBackProjectImage_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IICVLComponent_CamShift_Proxy( 
    IICVLComponent __RPC_FAR * This,
    long Input,
    int __RPC_FAR *window,
    int __RPC_FAR *iter,
    double __RPC_FAR *center);


void __RPC_STUB IICVLComponent_CamShift_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IICVLComponent_ReadHistFile_Proxy( 
    IICVLComponent __RPC_FAR * This,
    float __RPC_FAR *data,
    long __RPC_FAR *datasize);


void __RPC_STUB IICVLComponent_ReadHistFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IICVLComponent_CloseFile_Proxy( 
    IICVLComponent __RPC_FAR * This);


void __RPC_STUB IICVLComponent_CloseFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IICVLComponent_OpenFile_Proxy( 
    IICVLComponent __RPC_FAR * This);


void __RPC_STUB IICVLComponent_OpenFile_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IICVLComponent_INTERFACE_DEFINED__ */



#ifndef __ICVLPROJECTLib_LIBRARY_DEFINED__
#define __ICVLPROJECTLib_LIBRARY_DEFINED__

/****************************************
 * Generated header for library: ICVLPROJECTLib
 * at Thu Aug 09 11:11:59 2001
 * using MIDL 3.01.75
 ****************************************/
/* [helpstring][version][uuid] */ 



EXTERN_C const IID LIBID_ICVLPROJECTLib;

#ifdef __cplusplus
EXTERN_C const CLSID CLSID_ICVLComponent;

class DECLSPEC_UUID("EF910131-40BC-11D5-9207-00E02903BD46")
ICVLComponent;
#endif
#endif /* __ICVLPROJECTLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif
