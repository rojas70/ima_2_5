// ICVLComponent.cpp : Implementation of CICVLComponent
#include "stdafx.h"

#include "I:\Include\BasicIMA.h"
#include "I:\Include\coreobj.h"
#include "I:\Include\Component.h"


#include "ICVLProject.h"
#include "ICVLComponent.h"

/////////////////////////////////////////////////////////////////////////////
// CICVLComponent

STDMETHODIMP CICVLComponent::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_IICVLComponent,
	};
	for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


//
// Name		- MechanismActivate
// Purpose	- "Do it" method for IMA mechanisms.

ULONG CICVLComponent::MechanismActivate(ULONG flags, ULONG operation)
{
	// TODO: Implement the operations that this component supports.

	return S_OK;
}


//
// Name		- MechanismReset
// Purpose	- Standard way for IMA components to 

HRESULT CICVLComponent::MechanismReset(ULONG flags)
{

	return S_OK;
}


//
// Name		- FinalComponentInitialization
// Purpose	- Called to do allow the component to do any final setup.
// *NOTE: This may be called more than once after a component is inserted!

HRESULT CICVLComponent::FinalComponentInitialization(ULONG ulFlags, IUnknown *pIUnkAManager)
{

	return S_OK;
}


//
// Name		- SaveComponentToStream
// Purpose	- Save the state of this component from storage.

HRESULT CICVLComponent::SaveComponentToStream(LPSTREAM pStm)
{
	// TODO: Save persistent to pStm

	return S_OK;
}


//
// Name		- InitComponentFromStream
// Purpose	- Initialize the state of this component from storage.

HRESULT CICVLComponent::InitComponentFromStream(LPSTREAM pStm)
{
	// TODO: Load persistent state from pStm

	return S_OK;
}


//
// Name		-	GetMaxStreamSize
// Purpose	-	Return the size of the stream necessary to save this object.

ULONG	CICVLComponent::GetMaxStreamSize()
{
	// TODO: Return a count of the amount of memory bytes that you require for
	//		 storage.

	return S_OK;
}

STDMETHODIMP CICVLComponent::Initialize(long * InputInfo, long * OutputInfo)
{
	// InputInfo, OutputInfo hold (width, height, depth) of images

	int ChannelsIn, ChannelsOut;
	CvSize ImageSizeIn, ImageSizeOut;

	//  Initialize the CvSize struct for both input and output images
	ImageSizeIn.width = InputInfo[0];
	ImageSizeIn.height = InputInfo[1];
	if(InputInfo[2] == 1)
		ChannelsIn = 1;
	else if(InputInfo[2] == 3)
		ChannelsIn = 3;

	ImageSizeOut.width = OutputInfo[0];
	ImageSizeOut.height = OutputInfo[1];
	if(OutputInfo[2] == 1)
		ChannelsOut = 1;
	else if(OutputInfo[2] == 3)
		ChannelsOut = 3;

	m_pIPLInputImage[0] = cvCreateImageHeader(ImageSizeIn, IPL_DEPTH_8U, ChannelsIn);
	m_pIPLInputImage[1] = cvCreateImageHeader(ImageSizeIn, IPL_DEPTH_8U, ChannelsIn);
	m_pIPLOutputImage   = cvCreateImageHeader(ImageSizeOut, IPL_DEPTH_8U, ChannelsOut);
		
	return S_OK;
}

STDMETHODIMP CICVLComponent::Threshold(long Input, long Output, double Value)
{
	double  max;
	max = 255;

	m_pIPLInputImage[0]->imageData	= (char*)Input;
	m_pIPLOutputImage->imageData	= (char*) Output;

	cvThreshold(m_pIPLInputImage[0],m_pIPLOutputImage, Value, max, CV_THRESH_BINARY);	

	
	return S_OK;
}

STDMETHODIMP CICVLComponent::CreateHistogram(long Input, int flag)
{
	// TODO: Add your implementation code here
	int* numBinArray;
	int w,h,i;
	double histNorm;
	float** thresh;

	thresh = new float*[1];

	thresh[0] = new float[2];
	thresh[0][0] = 0.0;
	thresh[0][1] = 256.0;

	numBinArray = new int[1];
	numBinArray[0] = 256;

/*	numBinArray = new int[3];
	numBinArray[0] = 256;
	numBinArray[1] = 1;
	numBinArray[2] = 256;
*/
	if ( flag == 99 )
	{
		m_pIPLInputImage[0]->imageData	= (char*)Input;
		w = m_pIPLInputImage[0]->width;
		h = m_pIPLInputImage[0]->height;

		IplImage*  planeH=cvCreateImage(cvSize(w,h),IPL_DEPTH_8U, 1);
		IplImage*  planeS=cvCreateImage(cvSize(w,h),IPL_DEPTH_8U, 1);
		IplImage*  planeV=cvCreateImage(cvSize(w,h),IPL_DEPTH_8U, 1);
      
		  cvCvtPixToPlane(m_pIPLInputImage[0],planeH,planeS,planeV,NULL);
      
		IplImage* arrayOfPlanes[3];
		arrayOfPlanes[0]=planeH;
		arrayOfPlanes[1]=planeS;
		arrayOfPlanes[2]=planeV;

		//  Then must use cvSetHistThresh
		m_pCVHistogram = cvCreateHist(1,numBinArray,CV_HIST_ARRAY);
	//double  cvNorm( IplImage* imgA, IplImage* imgB, int norm_type, IplImage* mask CV_DEFAULT(0) );


		cvSetHistThresh( m_pCVHistogram, thresh,  1);


		cvCalcHist(arrayOfPlanes,m_pCVHistogram,0);
		ATLTRACE ("ICVL: CreateHistogram\n");
	}

	else
	{

		float * histdata;
		long	histSize=256;
		ReadHistFile(histdata, &histSize);
		
//		for (i=0; i<histSize; i++)
//					histdata[i]*=2000;
		m_pCVHistogram = cvCreateHist(1,numBinArray,CV_HIST_ARRAY);
		cvMakeHistHeaderForArray(1,numBinArray,m_pCVHistogram, histdata, thresh, 1);
//		cvSetHistThresh( m_pCVHistogram, thresh,  1);
	
	}

	for (i=0; i< thresh[0][1]; i++)
	{
		ATLTRACE("Histogram: %d: %e\n", i, m_pCVHistogram->array[i]);
	}

	delete [] thresh;
	delete [] numBinArray;
	return S_OK;
}

STDMETHODIMP CICVLComponent::CalcBackProjectImage(long Input, long Output)
{
	int* numBinArray;
	int w,h,i;
	float** thresh;
	int minS=10;
	int minV=25;
	int maxV=230;
	
	numBinArray = new int[1];
	numBinArray[0] = 256;

	// TODO: Add your implementation code here
	m_pIPLInputImage[0]->imageData	= (char*)Input;
	m_pIPLOutputImage->imageData	= (char*) Output;

	w = m_pIPLInputImage[0]->width;
	h = m_pIPLInputImage[0]->height;

	// Must use cvConvertPixelsToPlane
	  IplImage*  planeH=cvCreateImage(cvSize(w,h),IPL_DEPTH_8U, 1);
      IplImage*  planeS=cvCreateImage(cvSize(w,h),IPL_DEPTH_8U, 1);
      IplImage*  planeV=cvCreateImage(cvSize(w,h),IPL_DEPTH_8U, 1);
      
//	  cvCvtPixToPlane(m_pIPLInputImage[0],planeH,planeS,planeV,NULL);
	  cvCvtPixToPlane(m_pIPLInputImage[0],planeH,planeS,planeV,NULL);
      
	  uchar* Himg=(uchar*) planeH->imageData;
	  uchar* Simg=(uchar*) planeS->imageData;
	  uchar* Vimg=(uchar*) planeV->imageData;

	  for (i=0; i <w*h; i++)
	  {
            if( Simg[i] < minS || Vimg[i] < minV || Vimg[i] > maxV )

                Himg[i] = 0;
	  }
	  
	  IplImage* arrayOfPlanes[1];
	  arrayOfPlanes[0]=planeH;


	cvCalcBackProject(arrayOfPlanes, m_pIPLOutputImage, m_pCVHistogram);

	cvReleaseImage(&planeH);
	cvReleaseImage(&planeS);
	cvReleaseImage(&planeV);
	cvReleaseImage(arrayOfPlanes);

	delete [] numBinArray;

  return S_OK;
}

/*IplConvKernel*  cvCreateStructuringElementEx( int  cols,    int rows,
                                                      int  anchorX, int anchorY,
                                                      CvElementShape shape,
                                                      int* values CV_DEFAULT(0) );

OPENCVAPI  void  cvErode( IplImage* src, IplImage* dst,
                       IplConvKernel* element CV_DEFAULT(0),
                       int iterations CV_DEFAULT(1) );


OPENCVAPI  void  cvMorphologyEx( IplImage* src, IplImage* dst,
                              IplImage* temp, IplConvKernel* element,
                              CvMorphOp operation, int iterations CV_DEFAULT(1) );


OPENCVAPI  void  cvDilate( IplImage* src, IplImage* dst,
                        IplConvKernel* element CV_DEFAULT(0),
                        int iterations CV_DEFAULT(1) );
						*/


STDMETHODIMP CICVLComponent::CamShift(long Input, int* window, int* iter, double* center)
{
    CvConnectedComp comp;
    CvBox2D box;
	CvRect rectWin;
	int i=0, j,  w, h, x, y,cx, cy, wid,hei;
//	long lWidth, lHeight, lDepth;

	m_pIPLOutputImage->imageData	= (char*)Input;

	w = m_pIPLOutputImage->width;
	h = m_pIPLOutputImage->height;

//	Initial(lWidth, lHeight, lDepth);
    rectWin.x=window[0];
    rectWin.y=window[1];
    rectWin.width=window[2];
    rectWin.height=window[3];
	

//	for (i=0; i <8; i++)
//	{
		*iter = cvCamShift(m_pIPLOutputImage, rectWin, cvTermCriteria( CV_TERMCRIT_EPS | CV_TERMCRIT_ITER, 10, 10 ), &comp, &box);
		ATLTRACE("CamShift loop # %d:  iterations: %d box:%g %g center:%g %g\n", i, *iter, box.size.height, box.size.width, box.center.x, box.center.y);
		ATLTRACE("\t ConnComp  x:%d y:%d  width:%d height:%d area:%g\n",comp.rect.x, comp.rect.y, comp.rect.width, comp.rect.height, comp.area);
		rectWin = comp.rect;
		x=comp.rect.x;
		y=comp.rect.y;
		wid=comp.rect.width;
		hei=comp.rect.height;
		cx=box.center.x;
		cy=box.center.y;
		center[0]=(float)cx/w;
		center[1]=(float)cy/h;

		for (i=0; i<5;i++)
		{
//			m_pIPLOutputImage->imageData[cx-3+i+(w*cy)] = (uchar) 255;
			for (j=0; j<5;j++)
			{
				m_pIPLOutputImage->imageData[cx-3+i+(w*(cy-3*j))] = (uchar) 255;
			}
		}

		
		for (j=x; j<x+wid ,j < w; j=j+3)
		{
			m_pIPLOutputImage->imageData[j+(w*y)] = (uchar) 255;
		}

		for (j=y; j<y+hei, j < h; j=j+3)
		{
			m_pIPLOutputImage->imageData[x+(w*j)] = (uchar) 255;
		}

		for (j=x; j<x+wid, j < w ; j=j+3)
		{
			m_pIPLOutputImage->imageData[j+(w*(y+hei))] = (uchar) 255;
		}

		for (j=y; j<y+hei, j < h; j=j+3)
		{
			m_pIPLOutputImage->imageData[(x+wid)+(w*j)] = (uchar) 255;
		}

//	}

	return S_OK;
}

STDMETHODIMP CICVLComponent::ReadHistFile(float * data, long * datasize)
{
	USES_CONVERSION;
	long lCount=0;
	long lInfo;
	char seps[]   = " ,\t\n";
	char *token;
	char *pcRet;

	CloseFile();
	OpenFile();
//	ReadNewLine(&lInfo);

	if(m_fp !=NULL ) //fscanf(m_fp ,"%s",szTemp)
		pcRet = fgets(szTemp,LARGE_CHAR,m_fp);

	lInfo = feof(m_fp) || ferror(m_fp);

	while(lInfo == 0)
	{
		token = strtok( szTemp, seps );
		if(token !=NULL)
		{
			data[lCount] = atof(token);
			lCount++;
		}

		while( token != NULL )
		{
			// Get next token:
			token = strtok( NULL, seps );
			if(token !=NULL)
			{
				data[lCount] = atof(token);
				lCount++;
			}
		}
//		ReadNewLine(&lInfo);
		pcRet = fgets(szTemp,LARGE_CHAR,m_fp);

		lInfo = feof(m_fp) || ferror(m_fp);

	}
	*datasize=lCount;
	return S_OK;
}

STDMETHODIMP CICVLComponent::CloseFile()
{
	if(m_fp!=NULL)
	{
		fclose(m_fp );
		m_fp=NULL;
	}

	return S_OK;
}

STDMETHODIMP CICVLComponent::OpenFile()
{
	USES_CONVERSION;
	if (m_fp != NULL)
		CloseFile();

	m_fp  = fopen(OLE2T(m_bstrHistFile), "rt");
	return S_OK;
}
