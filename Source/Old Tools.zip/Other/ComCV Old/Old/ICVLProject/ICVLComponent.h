// ICVLComponent.h : Declaration of the CICVLComponent

#ifndef __ICVLCOMPONENT_H_
#define __ICVLCOMPONENT_H_

#include "resource.h"       // main symbols
#include "ipl.h"
#include "CV.h"

#define N 2
#define LARGE_CHAR 40800
#define REAL_BIG 2600

/////////////////////////////////////////////////////////////////////////////
// CICVLComponent
class ATL_NO_VTABLE CICVLComponent : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CICVLComponent, &CLSID_ICVLComponent>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CICVLComponent>,
	public IDispatchImpl<IICVLComponent, &IID_IICVLComponent, &LIBID_ICVLPROJECTLib>,
	public CMechanismImpl<CICVLComponent>
{
public:
	CICVLComponent()
	{
		USES_CONVERSION;
		long i;

		// TODO: Initialize all variables
		for(i=0; i<N; i++)
		{
			m_pIPLInputImage [i] = NULL;
		}
	
		m_pIPLOutputImage = NULL;
		m_fp = NULL;
		m_bstrHistFile = "U:\\Irlusers\\tamarar\\Data\\hist\\skinhist.txt";

		
		
		
		// TODO: Call SetupMechanism(ops, flags)
		SetupMechanism(0,0);

		// TODO: Setup component links
		
	}

DECLARE_REGISTRY_RESOURCEID(IDR_ICVLCOMPONENT)

BEGIN_COM_MAP(CICVLComponent)
	COM_INTERFACE_ENTRY(IICVLComponent)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
	// IMA Interface entries
	COM_INTERFACE_ENTRY(IComponent)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY_IMPL(IPersistStorage)
	COM_INTERFACE_ENTRY(IMechanismActivate)
END_COM_MAP()
// support for outgoing interfaces, if necessary

BEGIN_CONNECTION_POINT_MAP(CICVLComponent)
END_CONNECTION_POINT_MAP()


	HRESULT FinalConstruct()
	{
		// if your component aggregates other COM objects,
		//  create them here.
	

		return S_OK;
	}

	void FinalRelease()
	{
		// if your component aggregates other COM objects,
		//  releasethem here.
	}


// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

public:
// Overridable IMA Component functionality:
//

	virtual ULONG	MechanismActivate(ULONG flags, ULONG operation);
	virtual HRESULT MechanismReset(ULONG flags);

	virtual HRESULT FinalComponentInitialization(ULONG ulFlags, IUnknown *pIUnkAManager);
	virtual HRESULT SaveComponentToStream(LPSTREAM pStm);
	virtual HRESULT InitComponentFromStream(LPSTREAM pStm);
	virtual ULONG	GetMaxStreamSize();


public:
	STDMETHOD(OpenFile)();
	STDMETHOD(CloseFile)();
	STDMETHOD(ReadHistFile)(float *data, long *datasize);
	STDMETHOD(CamShift)(long Input, int* window, int* iter, double* center);
	STDMETHOD(CalcBackProjectImage)(long Input, long Output);
	STDMETHOD(CreateHistogram)(long Input, int flag);
	STDMETHOD(Initialize)(long* InputInfo, long* OutputInfo);
	STDMETHOD(Threshold)(long Input, long Output, double Value);

	IplImage* m_pIPLInputImage[N];
	IplImage* m_pIPLOutputImage;
	CvHistogram* m_pCVHistogram;
	CComBSTR m_bstrHistFile;
	FILE * m_fp;
	char szTemp[LARGE_CHAR];
	
// %%INTERFACE: IICVLComponent

};

#endif //__ICVLCOMPONENT_H_
