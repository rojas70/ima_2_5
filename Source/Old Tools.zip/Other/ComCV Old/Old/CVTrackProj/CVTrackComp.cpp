// CVTrackComp.cpp : Implementation of CCVTrackComp
#include "stdafx.h"
#include "I:\Include\BasicIMA.h"
#include "I:\Include\coreobj.h"
#include "I:\Include\Component.h"
//#include "I:\Include\BasicComponents.h"
#include "CVTrackProj.h"
#include "CVTrackComp.h"
//#include "D:\Program Files\Intel\OpenCV\cv\_include\_cv.h"
//#include "D:\Program Files\Intel\OpenCV\cv\_include\_cvwrap.h"

/////////////////////////////////////////////////////////////////////////////
// CCVTrackComp

STDMETHODIMP CCVTrackComp::InterfaceSupportsErrorInfo(REFIID riid)
{
	static const IID* arr[] = 
	{
		&IID_ICVTrackComp,
	};
	for (int i=0;i<sizeof(arr)/sizeof(arr[0]);i++)
	{
		if (InlineIsEqualGUID(*arr[i],riid))
			return S_OK;
	}
	return S_FALSE;
}


//
// Name		- MechanismActivate
// Purpose	- "Do it" method for IMA mechanisms.

ULONG CCVTrackComp::MechanismActivate(ULONG flags, ULONG operation)
{
	// TODO: Implement the operations that this component supports.
	IImageRep* pImageIn = NULL;
	IImageRep* pImageOut = NULL;
	IICVLComponent* pICVL = NULL;
	IIntelIPL* pIPL = NULL;
	IVectorSignal* pIVSData = NULL;
	IVectorSignal* pIVSTrack = NULL;

	long	lWidth,lHeight,lDepth;
	long	lData1; //holds 3d color
	long	lData2; //holds 1d gray
	long	lData3d; //holds 3d color
	long	*lData1d; //holds 1d image
	long	*InputVect, *OutputVect;
	if (operation == 0)
	{
		if(m_pIUnkImageIn != NULL && m_pIUnkImageOut != NULL && m_pIUnkICVL != NULL && m_pIUnkIPL != NULL)
		{
			m_pIUnkImageIn->QueryInterface(IID_IImageRep,(void**)&pImageIn );
			m_pIUnkImageOut->QueryInterface(IID_IImageRep,(void**)&pImageOut );
			m_pIUnkICVL->QueryInterface(IID_IICVLComponent,(void**)&pICVL );
			m_pIUnkIPL->QueryInterface(IID_IIntelIPL,(void**)&pIPL );
		//get image dimensions
			if ( pImageIn != NULL && pImageOut != NULL &&  pICVL != NULL && pIPL != NULL)
			{
				pImageIn->Data (0, &lData1);
				pImageIn->get_Width(&lWidth);
				pImageIn->get_Height(&lHeight);
				pImageIn->get_Depth(&lDepth);
		//init ipl
				pIPL->Initial(lWidth, lHeight, lDepth);

				
				
				InputVect = new long [3];
				OutputVect = new long [3];
				InputVect[0] = lWidth;
				InputVect[1] = lHeight;
				InputVect[2] = 3;
				OutputVect[0] = lWidth;
				OutputVect[1] = lHeight;
				OutputVect[2] = 1;



		//init cvlib
				pICVL->Initialize(InputVect, OutputVect);
		//load skin histogram (flags)
				pICVL->CreateHistogram(lData2,0);

//				delete [] lData3d;
				delete [] InputVect;
				delete [] OutputVect;

				pImageIn->Release();
				pImageOut->Release();
				pIPL->Release();
				pICVL->Release();
			}

		}
	}

	if (operation == 1)
	{
		// get current frame
		//convert rgb2hsv
		// take H and back project
		// camshift
		// output point and box

		if(m_pIUnkImageIn != NULL && m_pIUnkImageOut != NULL && m_pIUnkICVL != NULL && m_pIUnkIPL != NULL)
		{
			m_pIUnkImageIn->QueryInterface(IID_IImageRep,(void**)&pImageIn );
			m_pIUnkImageOut->QueryInterface(IID_IImageRep,(void**)&pImageOut );
			m_pIUnkICVL->QueryInterface(IID_IICVLComponent,(void**)&pICVL );
			m_pIUnkIPL->QueryInterface(IID_IIntelIPL,(void**)&pIPL );
		//get image dimensions
			if ( pImageIn != NULL && pImageOut != NULL &&  pICVL != NULL && pIPL != NULL)
			{
			
				pImageIn->Data (0, &lData1);
				pImageOut->Data (0, &lData2);
				pImageIn->get_Width(&lWidth);
				pImageIn->get_Height(&lHeight);
				pImageIn->get_Depth(&lDepth);
		//init ipl
				pIPL->Initial(lWidth, lHeight, lDepth);
				
				
				
//				lData3d = new long[lWidth*lHeight*3];
				
				
/*				IPLImage TempIPLImage;
				lData3d = new long[lWidth*lHeight*3];
				TempIPLImage->Data =lData3d;
*/
//				IplImage*  planeH=cvCreateImage(cvSize(w,h),IPL_DEPTH_8U, 1);
//	  uchar* Himg=(uchar*) planeH->imageData;

/*				TempIPLImage = new IplImage;
				TempIPLImage->depth = lDepth;
				TempIPLImage->depth = lHeight;
				TempIPLImage->depth = lWidth;
				long lData3d = (long)TempIPLImage->imageData;
*/
				IplImage*  TempIPLImage=cvCreateImage(cvSize(lWidth,lHeight),IPL_DEPTH_8U, 3);
/* iplCreateImageHeader( channels, 0, depth, channels == 1 ? "GRAY" : "RGB",
channels==1 ?"GRAY":channels==3 ?"BGR":"BGRA", IPL_DATA_ORDER_PIXEL, IPL_ORIGIN_TL, 4, size.width, size.height,
0,0,0,0);

*/

/*			TempIPLImage = iplCreateImageHeader( 1, 0, lDepth,"RGB", "BGR", IPL_DATA_ORDER_PIXEL, IPL_ORIGIN_TL, 4, lWidth, lHeight,
0,0,0,0);
*/		
				lData3d = (long)TempIPLImage->imageData;		
				
				
				pIPL->RGBToHSV(lData1, lData3d);

				InputVect = new long [3];
				OutputVect = new long [3];
				InputVect[0] = lWidth;
				InputVect[1] = lHeight;
				InputVect[2] = 3;
				OutputVect[0] = lWidth;
				OutputVect[1] = lHeight;
				OutputVect[2] = 1;
		//init cvlib
//				pICVL->Initialize(InputVect, OutputVect);
		//load skin histogram (flags)
//				pICVL->CreateHistogram(lData2,0);
				pICVL->CalcBackProjectImage(lData3d,lData2);
				int search_win[4], iterationNumber;
				double center[2];
				search_win[0]=lWidth/4;
				search_win[1]=lHeight/4;
				search_win[2]=3*lWidth/4;
				search_win[3]=3*lHeight/4;

				pICVL->CamShift(lData2, search_win, &iterationNumber, center);
				
				if (m_pIUnkTrackVector != NULL)
				{
					m_pIUnkTrackVector->QueryInterface(IID_IVectorSignal,(void**)&pIVSTrack );
					if (pIVSTrack != NULL)
					{
						pIVSTrack->SetCurrentVector(2, center);
					}
				}

				int i,j,cx,cy;
				BYTE *pixels;
				
				cx = center[0]*lWidth;
				cy = center[1]*lHeight;

				pixels=(BYTE *) lData1;

				for (i=cx-11; (i<cx+11 && i<lWidth); i++)
				{
					pixels[(3*(i+(lWidth*cy-3)))] = (uchar) 255;
					pixels[(3*(i+(lWidth*cy-2)))] = (uchar) 255;
					pixels[(3*(i+(lWidth*cy-1)))] = (uchar) 255;
					pixels[(3*(i+(lWidth*cy)))] = (uchar) 255;
					pixels[(3*(i+(lWidth*cy+1)))] = (uchar) 255;
					pixels[(3*(i+(lWidth*cy+2)))] = (uchar) 255;
					pixels[(3*(i+(lWidth*cy+3)))] = (uchar) 255;
				}
				for (j=cy-11; (j<cy+11 && j<lHeight) ; j++)
				{
					pixels[(3*(cx-3+(lWidth*j)))] = (uchar) 255;
					pixels[(3*(cx-2+(lWidth*j)))] = (uchar) 255;
					pixels[(3*(cx-1+(lWidth*j)))] = (uchar) 255;
					pixels[(3*(cx+(lWidth*j)))] = (uchar) 255;
					pixels[(3*(cx+1+(lWidth*j)))] = (uchar) 255;
					pixels[(3*(cx+2+(lWidth*j)))] = (uchar) 255;
					pixels[(3*(cx+3+(lWidth*j)))] = (uchar) 255;
				}

				pImageIn->Update(NULL);	
				pImageOut->Update(NULL);	
//				delete [] lData3d;
				delete [] InputVect;
				delete [] OutputVect;

				pImageIn->Release();
				pImageOut->Release();
				pIPL->Release();
				pIVSTrack->Release();
				pICVL->Release();
			}
		}
	
	}
	return S_OK;
}


//
// Name		- MechanismReset
// Purpose	- Standard way for IMA components to 

HRESULT CCVTrackComp::MechanismReset(ULONG flags)
{

	return S_OK;
}


//
// Name		- FinalComponentInitialization
// Purpose	- Called to do allow the component to do any final setup.
// *NOTE: This may be called more than once after a component is inserted!

HRESULT CCVTrackComp::FinalComponentInitialization(ULONG ulFlags, IUnknown *pIUnkAManager)
{

	return S_OK;
}


//
// Name		- SaveComponentToStream
// Purpose	- Save the state of this component from storage.

HRESULT CCVTrackComp::SaveComponentToStream(LPSTREAM pStm)
{
	// TODO: Save persistent to pStm

	return S_OK;
}


//
// Name		- InitComponentFromStream
// Purpose	- Initialize the state of this component from storage.

HRESULT CCVTrackComp::InitComponentFromStream(LPSTREAM pStm)
{
	// TODO: Load persistent state from pStm

	return S_OK;
}


//
// Name		-	GetMaxStreamSize
// Purpose	-	Return the size of the stream necessary to save this object.

ULONG	CCVTrackComp::GetMaxStreamSize()
{
	// TODO: Return a count of the amount of memory bytes that you require for
	//		 storage.

	return S_OK;
}

STDMETHODIMP CCVTrackComp::get_CVL(BSTR * pVal)
{
	GetComponentLinkName(&m_pIUnkICVL,pVal);

	return S_OK;
}

STDMETHODIMP CCVTrackComp::put_CVL(BSTR newVal)
{
	UpdateComponentLinkName(&m_pIUnkICVL,newVal);

	return S_OK;
}

STDMETHODIMP CCVTrackComp::get_ImageIn(BSTR * pVal)
{
	GetComponentLinkName(&m_pIUnkImageIn,pVal);

	return S_OK;
}

STDMETHODIMP CCVTrackComp::put_ImageIn(BSTR newVal)
{
	UpdateComponentLinkName(&m_pIUnkImageIn,newVal);

	return S_OK;
}

STDMETHODIMP CCVTrackComp::get_ImageOut(BSTR * pVal)
{
	GetComponentLinkName(&m_pIUnkImageOut,pVal);

	return S_OK;
}

STDMETHODIMP CCVTrackComp::put_ImageOut(BSTR newVal)
{
	UpdateComponentLinkName(&m_pIUnkImageOut,newVal);

	return S_OK;
}

STDMETHODIMP CCVTrackComp::get_IPL(BSTR * pVal)
{
	GetComponentLinkName(&m_pIUnkIPL,pVal);

	return S_OK;
}

STDMETHODIMP CCVTrackComp::put_IPL(BSTR newVal)
{
	UpdateComponentLinkName(&m_pIUnkIPL,newVal);

	return S_OK;
}

STDMETHODIMP CCVTrackComp::get_DataVector(BSTR * pVal)
{
	GetComponentLinkName(&m_pIUnkDataVector,pVal);

	return S_OK;
}

STDMETHODIMP CCVTrackComp::put_DataVector(BSTR newVal)
{
	UpdateComponentLinkName(&m_pIUnkDataVector,newVal);

	return S_OK;
}

STDMETHODIMP CCVTrackComp::get_TrackPoint(BSTR * pVal)
{
	GetComponentLinkName(&m_pIUnkTrackVector,pVal);

	return S_OK;
}

STDMETHODIMP CCVTrackComp::put_TrackPoint(BSTR newVal)
{
	UpdateComponentLinkName(&m_pIUnkTrackVector,newVal);

	return S_OK;
}
