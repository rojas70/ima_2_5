// CVTrackComp.h : Declaration of the CCVTrackComp

#ifndef __CVTRACKCOMP_H_
#define __CVTRACKCOMP_H_

#include "I:\Include\ImageRepresentations.h"
#include "I:\Include\BasicComponents.h"
#include "I:\Src\Mechanisms\ICVLProject\ICVLProject.h"
#include "I:\Include\IPComponents.h"

#include "resource.h"       // main symbols
#include "ipl.h"
#include "cv.h"

/////////////////////////////////////////////////////////////////////////////
// CCVTrackComp
class ATL_NO_VTABLE CCVTrackComp : 
	public CComObjectRootEx<CComMultiThreadModel>,
	public CComCoClass<CCVTrackComp, &CLSID_CVTrackComp>,
	public ISupportErrorInfo,
	public IConnectionPointContainerImpl<CCVTrackComp>,
	public IDispatchImpl<ICVTrackComp, &IID_ICVTrackComp, &LIBID_CVTRACKPROJLib>,
	public CMechanismImpl<CCVTrackComp>
{
public:
	CCVTrackComp()
	{
		// TODO: Initialize all variables
		m_pIUnkImageIn = NULL;
		m_pIUnkImageOut = NULL;
		m_pIUnkICVL = NULL;
		m_pIUnkIPL = NULL;
		m_pIUnkDataVector = NULL;
		m_pIUnkTrackVector = NULL;

		// TODO: Call SetupMechanism(ops, flags)
		SetupMechanism( 3, 1 );

		// TODO: Setup component links
		SetupComponentLink(&IID_IImageRep,&m_pIUnkImageIn);
		SetupComponentLink(&IID_IImageRep,&m_pIUnkImageOut);
		SetupComponentLink(&IID_IVectorSignal,&m_pIUnkDataVector);
		SetupComponentLink(&IID_IVectorSignal,&m_pIUnkTrackVector);
		SetupComponentLink(&IID_IICVLComponent,&m_pIUnkICVL);
		SetupComponentLink(&IID_IIntelIPL,&m_pIUnkIPL);

	}

DECLARE_REGISTRY_RESOURCEID(IDR_CVTRACKCOMP)

BEGIN_COM_MAP(CCVTrackComp)
	COM_INTERFACE_ENTRY(ICVTrackComp)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
	COM_INTERFACE_ENTRY_IMPL(IConnectionPointContainer)
	// IMA Interface entries
	COM_INTERFACE_ENTRY(IComponent)
	COM_INTERFACE_ENTRY(IPersistStreamInit)
	COM_INTERFACE_ENTRY_IMPL(IPersistStorage)
	COM_INTERFACE_ENTRY(IMechanismActivate)
END_COM_MAP()
// support for outgoing interfaces, if necessary

BEGIN_CONNECTION_POINT_MAP(CCVTrackComp)
END_CONNECTION_POINT_MAP()


	HRESULT FinalConstruct()
	{
		// if your component aggregates other COM objects,
		//  create them here.
	

		return S_OK;
	}

	void FinalRelease()
	{
		// if your component aggregates other COM objects,
		//  releasethem here.
	}


// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

public:
// Overridable IMA Component functionality:
//

	virtual ULONG	MechanismActivate(ULONG flags, ULONG operation);
	virtual HRESULT MechanismReset(ULONG flags);

	virtual HRESULT FinalComponentInitialization(ULONG ulFlags, IUnknown *pIUnkAManager);
	virtual HRESULT SaveComponentToStream(LPSTREAM pStm);
	virtual HRESULT InitComponentFromStream(LPSTREAM pStm);
	virtual ULONG	GetMaxStreamSize();


public:
	IUnknown * m_pIUnkTrackVector;
	IUnknown * m_pIUnkDataVector;
	IUnknown * m_pIUnkImageOut;
	IUnknown * m_pIUnkImageIn;
	IUnknown * m_pIUnkICVL;
	IUnknown * m_pIUnkIPL;
	STDMETHOD(get_TrackPoint)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_TrackPoint)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_DataVector)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_DataVector)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_IPL)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_IPL)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_ImageOut)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_ImageOut)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_ImageIn)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_ImageIn)(/*[in]*/ BSTR newVal);
	STDMETHOD(get_CVL)(/*[out, retval]*/ BSTR *pVal);
	STDMETHOD(put_CVL)(/*[in]*/ BSTR newVal);

// %%INTERFACE: ICVTrackComp

};

#endif //__CVTRACKCOMP_H_
