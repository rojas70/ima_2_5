/* this file contains the actual definitions of */
/* the IIDs and CLSIDs */

/* link this file in with the server and any clients */


/* File created by MIDL compiler version 5.01.0164 */
/* at Thu Aug 16 10:56:05 2001
 */
/* Compiler settings for CVTrackProj.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32, ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
*/
//@@MIDL_FILE_HEADING(  )
#ifdef __cplusplus
extern "C"{
#endif 


#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

const IID IID_ICVTrackComp = {0x87E72468,0x3550,0x4244,{0x94,0x90,0xA9,0xA6,0x8D,0x37,0x85,0xA1}};


const IID LIBID_CVTRACKPROJLib = {0x211CF28D,0x779C,0x4323,{0xBC,0xF8,0xDE,0xC2,0x46,0xD9,0xD5,0x2C}};


const CLSID CLSID_CVTrackComp = {0x29CC7F7B,0x2455,0x43C0,{0xAE,0x18,0xC4,0xFB,0xC2,0x25,0x7E,0x90}};


#ifdef __cplusplus
}
#endif

