// DispXPpg.cpp : Implementation of the CDispXPropPage property page class.

#include "stdafx.h"
#include "DispX.h"
#include "DispXPpg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CDispXPropPage, COlePropertyPage)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CDispXPropPage, COlePropertyPage)
	//{{AFX_MSG_MAP(CDispXPropPage)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CDispXPropPage, "DISPX.DispXPropPage.1",
	0x5ef446a8, 0x4f45, 0x11d3, 0xbb, 0xd2, 0, 0xc0, 0x4f, 0x61, 0x3e, 0x8d)


/////////////////////////////////////////////////////////////////////////////
// CDispXPropPage::CDispXPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CDispXPropPage

BOOL CDispXPropPage::CDispXPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_DISPX_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}


/////////////////////////////////////////////////////////////////////////////
// CDispXPropPage::CDispXPropPage - Constructor

CDispXPropPage::CDispXPropPage() :
	COlePropertyPage(IDD, IDS_DISPX_PPG_CAPTION)
{
	//{{AFX_DATA_INIT(CDispXPropPage)
	// NOTE: ClassWizard will add member initialization here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_INIT
}


/////////////////////////////////////////////////////////////////////////////
// CDispXPropPage::DoDataExchange - Moves data between page and properties

void CDispXPropPage::DoDataExchange(CDataExchange* pDX)
{
	//{{AFX_DATA_MAP(CDispXPropPage)
	// NOTE: ClassWizard will add DDP, DDX, and DDV calls here
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA_MAP
	DDP_PostProcessing(pDX);
}


/////////////////////////////////////////////////////////////////////////////
// CDispXPropPage message handlers
