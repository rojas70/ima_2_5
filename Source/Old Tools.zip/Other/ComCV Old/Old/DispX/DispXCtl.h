#if !defined(AFX_DISPXCTL_H__5EF446B5_4F45_11D3_BBD2_00C04F613E8D__INCLUDED_)
#define AFX_DISPXCTL_H__5EF446B5_4F45_11D3_BBD2_00C04F613E8D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// DispXCtl.h : Declaration of the CDispXCtrl ActiveX Control class.

/////////////////////////////////////////////////////////////////////////////
// CDispXCtrl : See DispXCtl.cpp for implementation.

class CDispXCtrl : public COleControl
{
	DECLARE_DYNCREATE(CDispXCtrl)

// Constructor
public:
	CDispXCtrl();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDispXCtrl)
	public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();
	virtual DWORD GetControlFlags();
	//}}AFX_VIRTUAL

// Implementation
protected:
	~CDispXCtrl();

	DECLARE_OLECREATE_EX(CDispXCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CDispXCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CDispXCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CDispXCtrl)		// Type name and misc status

// Message maps
	//{{AFX_MSG(CDispXCtrl)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	//{{AFX_DISPATCH(CDispXCtrl)
	VARIANT m_data;
	afx_msg void OnDataChanged();
	afx_msg void Draw();
	//}}AFX_DISPATCH
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

// Event maps
	//{{AFX_EVENT(CDispXCtrl)
	//}}AFX_EVENT
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	BITMAPINFOHEADER bmiDraw;
	enum {
	//{{AFX_DISP_ID(CDispXCtrl)
	dispidData = 1L,
	dispidDraw = 2L,
	//}}AFX_DISP_ID
	};
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DISPXCTL_H__5EF446B5_4F45_11D3_BBD2_00C04F613E8D__INCLUDED)
