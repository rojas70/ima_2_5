// DispXCtl.cpp : Implementation of the CDispXCtrl ActiveX Control class.

#include "stdafx.h"
#include "DispX.h"
#include "DispXCtl.h"
#include "DispXPpg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CDispXCtrl, COleControl)


/////////////////////////////////////////////////////////////////////////////
// Message map

BEGIN_MESSAGE_MAP(CDispXCtrl, COleControl)
	//{{AFX_MSG_MAP(CDispXCtrl)
	// NOTE - ClassWizard will add and remove message map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG_MAP
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Dispatch map

BEGIN_DISPATCH_MAP(CDispXCtrl, COleControl)
	//{{AFX_DISPATCH_MAP(CDispXCtrl)
	DISP_PROPERTY_NOTIFY(CDispXCtrl, "Data", m_data, OnDataChanged, VT_VARIANT)
	DISP_FUNCTION(CDispXCtrl, "Draw", Draw, VT_EMPTY, VTS_NONE)
	//}}AFX_DISPATCH_MAP
	DISP_FUNCTION_ID(CDispXCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
END_DISPATCH_MAP()


/////////////////////////////////////////////////////////////////////////////
// Event map

BEGIN_EVENT_MAP(CDispXCtrl, COleControl)
	//{{AFX_EVENT_MAP(CDispXCtrl)
	// NOTE - ClassWizard will add and remove event map entries
	//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_EVENT_MAP
END_EVENT_MAP()


/////////////////////////////////////////////////////////////////////////////
// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CDispXCtrl, 1)
	PROPPAGEID(CDispXPropPage::guid)
END_PROPPAGEIDS(CDispXCtrl)


/////////////////////////////////////////////////////////////////////////////
// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CDispXCtrl, "DISPX.DispXCtrl.1",
	0x5ef446a7, 0x4f45, 0x11d3, 0xbb, 0xd2, 0, 0xc0, 0x4f, 0x61, 0x3e, 0x8d)


/////////////////////////////////////////////////////////////////////////////
// Type library ID and version

IMPLEMENT_OLETYPELIB(CDispXCtrl, _tlid, _wVerMajor, _wVerMinor)


/////////////////////////////////////////////////////////////////////////////
// Interface IDs

const IID BASED_CODE IID_DDispX =
		{ 0x5ef446a5, 0x4f45, 0x11d3, { 0xbb, 0xd2, 0, 0xc0, 0x4f, 0x61, 0x3e, 0x8d } };
const IID BASED_CODE IID_DDispXEvents =
		{ 0x5ef446a6, 0x4f45, 0x11d3, { 0xbb, 0xd2, 0, 0xc0, 0x4f, 0x61, 0x3e, 0x8d } };


/////////////////////////////////////////////////////////////////////////////
// Control type information

static const DWORD BASED_CODE _dwDispXOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CDispXCtrl, IDS_DISPX, _dwDispXOleMisc)


/////////////////////////////////////////////////////////////////////////////
// CDispXCtrl::CDispXCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CDispXCtrl

BOOL CDispXCtrl::CDispXCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_DISPX,
			IDB_DISPX,
			afxRegApartmentThreading,
			_dwDispXOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}


/////////////////////////////////////////////////////////////////////////////
// CDispXCtrl::CDispXCtrl - Constructor

CDispXCtrl::CDispXCtrl()
{
	InitializeIIDs(&IID_DDispX, &IID_DDispXEvents);

	VariantInit(&m_data);		// RO - Set variant to VT_EMPTY.

}


/////////////////////////////////////////////////////////////////////////////
// CDispXCtrl::~CDispXCtrl - Destructor

CDispXCtrl::~CDispXCtrl()
{
	// TODO: Cleanup your control's instance data here.
}


/////////////////////////////////////////////////////////////////////////////
// CDispXCtrl::OnDraw - Drawing function

void CDispXCtrl::OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{


	if (!IsOptimizedDraw())		{}				// Ignore this!
	
	if ((m_data.vt && VT_ARRAY) == FALSE)		// If the variant is empty, draw a white box.
	{ 
		pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
		return; 
	}

	// Blit the image.
	::StretchDIBits(	pdc->GetSafeHdc(), 
						0, 0, rcBounds.right, rcBounds.bottom,
						0, bmiDraw.biHeight, bmiDraw.biWidth, - bmiDraw.biHeight,
						(BYTE*) m_data.parray->pvData, 
						(LPBITMAPINFO) &bmiDraw, DIB_RGB_COLORS, SRCCOPY);						
}


/////////////////////////////////////////////////////////////////////////////
// CDispXCtrl::DoPropExchange - Persistence support

void CDispXCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.

}


/////////////////////////////////////////////////////////////////////////////
// CDispXCtrl::GetControlFlags -
// Flags to customize MFC's implementation of ActiveX controls.
//
// For information on using these flags, please see MFC technical note
// #nnn, "Optimizing an ActiveX Control".
DWORD CDispXCtrl::GetControlFlags()
{
	DWORD dwFlags = COleControl::GetControlFlags();

	// The control's output is not being clipped.
	// The control guarantees that it will not paint outside its
	// client rectangle.
	dwFlags &= ~clipPaintDC;

	// The control can optimize its OnDraw method, by not restoring
	// the original GDI objects in the device context.
	dwFlags |= canOptimizeDraw;
	return dwFlags;
}


/////////////////////////////////////////////////////////////////////////////
// CDispXCtrl::OnResetState - Reset control to default state

void CDispXCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}


/////////////////////////////////////////////////////////////////////////////
// CDispXCtrl::AboutBox - Display an "About" box to the user

void CDispXCtrl::AboutBox()
{
	CDialog dlgAbout(IDD_ABOUTBOX_DISPX);
	dlgAbout.DoModal();
}


/////////////////////////////////////////////////////////////////////////////
// CDispXCtrl message handlers

void CDispXCtrl::OnDataChanged() 
{
/*
	SAFEARRAY *SA;

	SA = m_Data.parray;

	typedef struct FARSTRUCT tagSAFEARRAY {
	unsigned short cDims; 		// Count of dimensions in this array.
	unsigned short fFeatures;	// Flags used by the SafeArray
								// routines documented below.
	unsigned long cbElements;	// Size of an element of the array.
								// Does not include size of
								// pointed-to data.
	unsigned long cLocks;		// Number of times the array has been 
								// locked without corresponding unlock.
	void HUGEP* pvData; 				// Pointer to the data.
	SAFEARRAYBOUND rgsabound[1];		// One bound for each dimension.
} SAFEARRAY;
*/
	// RO - Regenerate BMP struct each time data changes. (bmiDraw.width and bmi

	bmiDraw.biSize			= sizeof(BITMAPINFOHEADER);

	// Extract dimension size
	long uBound;
	HRESULT hresult;
	hresult = SafeArrayGetUBound(m_data.parray,1,&uBound);
	bmiDraw.biWidth = uBound/3;
	hresult = SafeArrayGetUBound(m_data.parray,2,&uBound);
	bmiDraw.biHeight = uBound;

	bmiDraw.biBitCount		= (WORD)3 * (WORD)8;
	bmiDraw.biPlanes		= 1;
	bmiDraw.biCompression	= BI_RGB;
	bmiDraw.biSizeImage		= 0;
	bmiDraw.biXPelsPerMeter = 0;
	bmiDraw.biYPelsPerMeter = 0;
	bmiDraw.biClrUsed		= 0;
	bmiDraw.biClrImportant	= 0;

	Refresh();

//	Call OnDraw() to show the image
	SetModifiedFlag();
}

void CDispXCtrl::Draw() 
{

}
