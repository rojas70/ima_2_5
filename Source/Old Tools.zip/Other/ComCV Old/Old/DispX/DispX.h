#if !defined(AFX_DISPX_H__5EF446AD_4F45_11D3_BBD2_00C04F613E8D__INCLUDED_)
#define AFX_DISPX_H__5EF446AD_4F45_11D3_BBD2_00C04F613E8D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// DispX.h : main header file for DISPX.DLL

#if !defined( __AFXCTL_H__ )
	#error include 'afxctl.h' before including this file
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CDispXApp : See DispX.cpp for implementation.

class CDispXApp : public COleControlModule
{
public:
	BOOL InitInstance();
	int ExitInstance();
};

extern const GUID CDECL _tlid;
extern const WORD _wVerMajor;
extern const WORD _wVerMinor;

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DISPX_H__5EF446AD_4F45_11D3_BBD2_00C04F613E8D__INCLUDED)
