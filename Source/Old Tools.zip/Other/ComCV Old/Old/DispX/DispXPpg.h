#if !defined(AFX_DISPXPPG_H__5EF446B7_4F45_11D3_BBD2_00C04F613E8D__INCLUDED_)
#define AFX_DISPXPPG_H__5EF446B7_4F45_11D3_BBD2_00C04F613E8D__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

// DispXPpg.h : Declaration of the CDispXPropPage property page class.

////////////////////////////////////////////////////////////////////////////
// CDispXPropPage : See DispXPpg.cpp.cpp for implementation.

class CDispXPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CDispXPropPage)
	DECLARE_OLECREATE_EX(CDispXPropPage)

// Constructor
public:
	CDispXPropPage();

// Dialog Data
	//{{AFX_DATA(CDispXPropPage)
	enum { IDD = IDD_PROPPAGE_DISPX };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	//{{AFX_MSG(CDispXPropPage)
		// NOTE - ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DISPXPPG_H__5EF446B7_4F45_11D3_BBD2_00C04F613E8D__INCLUDED)
