//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dlg_main.rc
//
#define IDD_DIALOG1                     101
#define IDD_GRAB                        101
#define IMAGENATION                     102
#define CYBER_PXR                       103
#define IDD_DIALOG2                     104
#define CYBER_PXC                       105
#define IDC_GRAB                        1000
#define IDC_START_RT                    1001
#define IDC_STOP_RT                     1002
#define IDC_OPEN                        1003
#define IDC_CLOSE                       1004
#define IDC_GAIN                        1007
#define IDC_OFFSET                      1008
#define ID_WRITE                        1009
#define ID_READ                         1010
#define IDC_SEQ                         1011
#define ID_SVIDEO                       1012
#define ID_MONO                         1013
#define ID_MONOCHROME                   1013
#define ID_COMPOSITE                    1014
#define ID_PAUSE                        1016
#define IDC_FILENAME                    1017
#define IDC_BLUR                        1018
#define IDC_DILATE                      1019
#define IDC_IOPEN                       1020
#define IDC_ERODE                       1021
#define IDC_NONE                        1022
#define IDC_FILTER                      1023
#define IDC_SUBTRACT                    1024
#define IDC_THRESHOLD_EN                1025
#define IDC_ROTATE                      1026
#define IDC_START                       1028
#define IDC_STOP                        1030
#define IDC_SAVE                        1032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        106
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1033
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
