#include "iframe.h"
#include "pxc.h"
#include "Cpxc_display.h"
#include "Cpxc_filerw.h"
#include <afxmt.h>

UINT DisplayThreadProc(LPVOID pParam);
enum TIMERmsg {PXC_TIME_RESET, PXC_TIME_DIFF};

/////////////////////////////////////////////////////////////////////////////
// pxcgrabber window

class pxcgrabber : public CObject
{

	CPXC_FILERW gpfile;

// Construction
public:
	pxcgrabber();

// Operations
public:
	BOOL InitializePXC();
	BOOL ResetPXC();
	void AppExit();
	BOOL SetupPXC();
	BOOL GrabImage();
	void SetComposite();
	void SetSVideo();
	void ReadFile();
	void WriteFile();
	BOOL GetAquire();
	void ShowFrame(CDC* pDC);
	double GetTime(UINT uMessage);
	int GetFPS(double dTime);

// Attributes
public:


private:

	// image size: width (iImageX), height (iImageY)
	int iGrabIdx;
	int qidGrab[2];



// Implementation
public:
	~pxcgrabber();

};
