/******************************************************************************
 * CPXC_FILERW.C
 *
 * Copyright (c) 2001 by Imagenation
 *
 * File Reading and Writing Routines
 * 
 * This source code is intended to be used for reading and writing files
 * for the PXC series frame garbber
 ******************************************************************************/
#include "stdafx.h"
#include "Cpxc_filerw.h"

/******************************************************************************
 * Name:         CPXC_FILERW -Constructor
 *-----------------------------------------------------------------------------
 * Description:  When the object is created, data members are initialized by 
 *               this constructor function.
 ******************************************************************************/
CPXC_FILERW::CPXC_FILERW()
{
	// Initialize all strings to 0 before using them
	memset(szReadFileName, 0, MAXPATH);
	memset(szReadFileTitle, 0, MAXPATH);
	memset(szReadFileDir, 0, MAXDIR);
	memset(szReadExt, 0, MAXEXT);

	// Clear the SFN structure before initializing it because
	// it contains more data than we are initializing
	memset(&rfn, 0, sizeof(rfn));

	// Initialize the Read File Name (RFN) structure
	rfn.lpstrTitle = "Read an Image from a File";
	rfn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
	rfn.lStructSize = sizeof(OPENFILENAME);
	rfn.hwndOwner = NULL;
	rfn.lpstrFilter = "BMP files (*.bmp)\0*.bmp\0";
	rfn.nMaxCustFilter = 0;
	rfn.nFilterIndex = 2l;
	rfn.nMaxFile = MAXPATH;
	rfn.nMaxFileTitle = MAXPATH;
	rfn.lpstrFile = szReadFileName;
	rfn.lpstrInitialDir = szReadFileDir;
	rfn.lpstrFileTitle = szReadFileTitle;
	rfn.lpstrDefExt = szReadExt;

	// Initialize all strings to 0 before using them
	memset(szSaveFileName, 0, MAXPATH);
	memset(szSaveFileTitle, 0, MAXPATH);
	memset(szSaveFileDir, 0, MAXDIR);
	memset(szSaveExt, 0, MAXEXT);

	// Clear the SFN structure before initializing it because
	// it contains more data than we are initializing
	memset(&sfn, 0, sizeof(sfn));

	// Initialize the Save File Name (SFN) structure
	sfn.lpstrTitle = "Save Image in File";
	sfn.Flags = OFN_OVERWRITEPROMPT | OFN_HIDEREADONLY;
	sfn.lStructSize = sizeof(OPENFILENAME);
	sfn.hwndOwner = NULL;
	sfn.lpstrFilter = "BMP files (*.bmp)\0*.bmp\0";
	sfn.nMaxCustFilter = 0;
	sfn.nFilterIndex = 2l;
	sfn.nMaxFile = MAXPATH;
	sfn.nMaxFileTitle = MAXPATH;
	sfn.lpstrFile = szSaveFileName;
	sfn.lpstrInitialDir = szSaveFileDir;
	sfn.lpstrFileTitle = szSaveFileTitle;
	sfn.lpstrDefExt = szSaveExt;
	 
}

/******************************************************************************
 * Name:  ~pxcgrabber -Destructor
 ******************************************************************************/
CPXC_FILERW::~CPXC_FILERW()
{

}

/******************************************************************************
 * Name: pxcReadFile
 ******************************************************************************/
void CPXC_FILERW::ReadFile(FRAMELIB	FrameLib, FRAME __PX_FAR *pFrame)
{
	static char *szReadError = \
"An error was encountered reading data from the file.\n\
The file header is probably corrupt.";

	// Call GetOpenFileName with the initialized RFN from above
	if(GetOpenFileName(&rfn))
	{
		iRet = FrameLib.ReadBMP(pFrame, rfn.lpstrFile);
		if(iRet != 0)
		{
			wsprintf(szTmp, "Read error: %d", iRet);
			::MessageBox(NULL,szTmp, szReadError, MB_OK);
		}
		else
		{
			lstrcpy(szReadFileDir, szReadFileName);
			j = lstrlen(szReadFileDir);
			for(i=j; i>0; --i)
			{
				if(szReadFileDir[i] != '\\')
				{
					szReadFileDir[i] = '\0';
				}
				else
				{
				if(szReadFileDir[i-1] != ':')
					szReadFileDir[i] = '\0';
				break;
				}
			}
			lstrcpy(szReadFileName, szReadFileTitle);
		}
	}
}

/******************************************************************************
 * Name: pxcWriteFile
 ******************************************************************************/
void CPXC_FILERW::WriteFile(FRAMELIB FrameLib, FRAME __PX_FAR *pFrame)
{

	static char *szWriteError = \
"An error was encountered writing data to the file.\n\
The file is incomplete and the data is invalid.";

	static char *szComplete = "The file was written successfully.";

	// Call GetSaveFileName with the initialized SFN from above
	if(GetSaveFileName(&sfn))
	{
		iRet = FrameLib.WriteBMP(pFrame, sfn.lpstrFile, 1);
		if(iRet != 0)
		{
			wsprintf(szTmp, "Write error: %d", iRet);
			::MessageBox(NULL,szTmp, szWriteError, MB_OK);
		}
		else
		{
			::MessageBox(NULL, szComplete, "Write File", MB_OK);
			lstrcpy(szSaveFileName, szSaveFileTitle);
			lstrcpy(szSaveFileDir, ofs.szPathName);
			j = lstrlen(szSaveFileDir);
			for(i=j; i>0; --i)
			{
				if(szSaveFileDir[i] != '\\')
				{
					szSaveFileDir[i] = '\0';
				}
				else
				{
					if(szSaveFileDir[i-1] != ':')
						szSaveFileDir[i] = '\0';
					break;
				}
			}
		}
	}
}
