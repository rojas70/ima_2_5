/******************************************************************************
 * CPXC_FILEW.H
 * 
 * Copyright (c) 2001 by Imagenation
 *
 * This header file belongs to the PXC_FILERW.C file. If your program uses
 * the Cpxc_filerw.c file for file I/O, you will need to include this header.
 ******************************************************************************/

#include "iframe.h"
#include "pxc.h"


class CPXC_FILERW : public CObject
{	

private:
	#define MAXPATH 128
	#define MAXDIR  66
	#define MAXEXT  5
	OPENFILENAME rfn;
	OPENFILENAME sfn;
	OFSTRUCT ofs;

	char	szTmp[201];
	int		i, j, iRet;

	char	szSaveFileName[MAXPATH];
	char	szSaveFileTitle[MAXPATH];
	char	szSaveFileDir[MAXDIR];
	char	szSaveExt[MAXEXT];

	char	szReadFileName[MAXPATH];
	char	szReadFileTitle[MAXPATH];
	char	szReadFileDir[MAXDIR];
	char	szReadExt[MAXEXT];

public:
	CPXC_FILERW();
	~CPXC_FILERW();
	void ReadFile(FRAMELIB	FrameLib, FRAME __PX_FAR *pFrame);
	void WriteFile(FRAMELIB	FrameLib, FRAME __PX_FAR *pFrame);
};
