// PXC_GRAB_MFCView.cpp : implementation of the CPXC_GRAB_MFCView class
//

#include "stdafx.h"
#include "MainFrm.h"
#include "PXC_GRAB_MFC.h"

#include "PXC_GRAB_MFCDoc.h"
#include "PXC_GRAB_MFCView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CEvent g_eventPause;
CEvent g_eventContinue;
CEvent g_eventGrab;
CEvent g_eventStop;



/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCView

IMPLEMENT_DYNCREATE(CPXC_GRAB_MFCView, CView)

BEGIN_MESSAGE_MAP(CPXC_GRAB_MFCView, CView)
	//{{AFX_MSG_MAP(CPXC_GRAB_MFCView)
	ON_COMMAND(ID_AQUIRE, OnAquire)
	ON_COMMAND(ID_STOP, OnStop)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_GRAB, OnGrab)
	ON_COMMAND(ID_COMPOSITE, OnComposite)
	ON_COMMAND(ID_SVIDEO, OnSvideo)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCView construction/destruction

CPXC_GRAB_MFCView::CPXC_GRAB_MFCView()
{

}

CPXC_GRAB_MFCView::~CPXC_GRAB_MFCView()
{

}

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCView OnDraw

void CPXC_GRAB_MFCView::OnInitialUpdate() 
{
	CView::OnInitialUpdate();
	
	//create thread and start it
	AfxBeginThread(DisplayThreadProc, GetSafeHwnd(),THREAD_PRIORITY_ABOVE_NORMAL );
	int m_nTimer = SetTimer(1,1000,NULL);
	ASSERT(m_nTimer !=0);
	grab.GetTime(PXC_TIME_RESET);
}

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCView OnDraw

void CPXC_GRAB_MFCView::OnDraw(CDC* pDC)
{	
	// display frame
	if(!grab.GetAquire())
		grab.ShowFrame(pDC);

}

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCView OnAquire

void CPXC_GRAB_MFCView::OnAquire()  
{
	if(grab.GetAquire())
	{
		MessageBox("Already acquiring an image", "PXC", MB_OK);
	}
	else
	{
		grab.GetTime(PXC_TIME_RESET);
		//create thread and start it
		AfxBeginThread(DisplayThreadProc, GetSafeHwnd(),THREAD_PRIORITY_ABOVE_NORMAL);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCView OnStop

void CPXC_GRAB_MFCView::OnStop() 
{
	if(grab.GetAquire())
	{
		// stop thread
		g_eventStop.SetEvent();
	}	
}

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCView OnStop
void CPXC_GRAB_MFCView::OnGrab() 
{	
	CDC * pDC;	

	if(grab.GetAquire())
	{
		MessageBox("Stop acquiring an image", "PXC", MB_OK);
	}
	else 
	{
		grab.GrabImage();
		pDC = GetDC();
		grab.ShowFrame(pDC);
		ReleaseDC(pDC);
	}
	
}

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCView OnFileOpen

void CPXC_GRAB_MFCView::OnFileOpen() 
{
	CDC * pDC;

	if(grab.GetAquire())
	{
		MessageBox("Stop acquiring an image", "PXC", MB_OK);
	}
	else 
	{
		grab.ReadFile();
		pDC = GetDC();
		grab.ShowFrame(pDC);
		ReleaseDC(pDC);
	}
	
}

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCView OnFileSave

void CPXC_GRAB_MFCView::OnFileSave() 
{
	if(grab.GetAquire())
	{
		MessageBox("Stop acquiring an image", "PXC", MB_OK);
	}
	else
	{
		// write frame to a BMP file 
		grab.WriteFile();
	}
	
}

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCView OnSvideo

void CPXC_GRAB_MFCView::OnSvideo() 
{
	// switch video format to S_Video
	grab.SetSVideo();
}

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCView OnComposite

void CPXC_GRAB_MFCView::OnComposite() 
{
	// switch video format to Composite;
	grab.SetComposite();
}

void CPXC_GRAB_MFCView::OnTimer(UINT nIDEvent) 
{
	int FPS;
	double dTime;
	char buffer[30];
	static double bTime;

	CMainFrame* pFrame = (CMainFrame*) AfxGetApp()->m_pMainWnd;
	CStatusBar* pStatus = &pFrame->m_wndStatusBar;
	
	dTime = grab.GetTime(PXC_TIME_DIFF);

	if(grab.GetAquire())
	{
		if(dTime > 0.0)
		{
			FPS = grab.GetFPS(dTime);
			wsprintf(buffer, (LPSTR)"FPS:%d ",FPS);
			pStatus->SetPaneText(1,buffer);
		}
	}
	else
	{
		wsprintf(buffer, (LPSTR)"FPS:%d ",0);
		pStatus->SetPaneText(1,buffer);
	}

	CView::OnTimer(nIDEvent);
}
/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCView diagnostics

#ifdef _DEBUG
void CPXC_GRAB_MFCView::AssertValid() const
{
	CView::AssertValid();
}

void CPXC_GRAB_MFCView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CPXC_GRAB_MFCDoc* CPXC_GRAB_MFCView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPXC_GRAB_MFCDoc)));
	return (CPXC_GRAB_MFCDoc*)m_pDocument;
}
#endif //_DEBUG

