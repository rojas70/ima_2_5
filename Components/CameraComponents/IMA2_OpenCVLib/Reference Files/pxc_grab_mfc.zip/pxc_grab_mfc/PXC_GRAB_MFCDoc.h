// PXC_GRAB_MFCDoc.h : interface of the CPXC_GRAB_MFCDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PXC_GRAB_MFCDOC_H__65091E0A_5F01_11D5_BE5B_00D0B7212B03__INCLUDED_)
#define AFX_PXC_GRAB_MFCDOC_H__65091E0A_5F01_11D5_BE5B_00D0B7212B03__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPXC_GRAB_MFCDoc : public CDocument
{
protected: // create from serialization only
	CPXC_GRAB_MFCDoc();
	DECLARE_DYNCREATE(CPXC_GRAB_MFCDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPXC_GRAB_MFCDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPXC_GRAB_MFCDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPXC_GRAB_MFCDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PXC_GRAB_MFCDOC_H__65091E0A_5F01_11D5_BE5B_00D0B7212B03__INCLUDED_)
