// PXC_GRAB_MFCDoc.cpp : implementation of the CPXC_GRAB_MFCDoc class
//

#include "stdafx.h"
#include "PXC_GRAB_MFC.h"

#include "PXC_GRAB_MFCDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCDoc

IMPLEMENT_DYNCREATE(CPXC_GRAB_MFCDoc, CDocument)

BEGIN_MESSAGE_MAP(CPXC_GRAB_MFCDoc, CDocument)
	//{{AFX_MSG_MAP(CPXC_GRAB_MFCDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCDoc construction/destruction

CPXC_GRAB_MFCDoc::CPXC_GRAB_MFCDoc()
{
	// TODO: add one-time construction code here

}

CPXC_GRAB_MFCDoc::~CPXC_GRAB_MFCDoc()
{
}

BOOL CPXC_GRAB_MFCDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCDoc serialization

void CPXC_GRAB_MFCDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCDoc diagnostics

#ifdef _DEBUG
void CPXC_GRAB_MFCDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CPXC_GRAB_MFCDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPXC_GRAB_MFCDoc commands
