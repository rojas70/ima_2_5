/******************************************************************************
 * CPXC_DISPLAY.H
 * 
 * Copyright (c) 2001 by Imagenation
 *
 * This header file belongs to the PXC_DISPLAY.C file. If your program uses
 * the Cpxc_display.c file for display, you will need to include this header.
 ******************************************************************************/

#include "iframe.h"
#include "pxc.h"

enum PALETTEmsg {PXC_PALETTE_CREATE, PXC_PALETTE_DELETE, PXC_PALETTE_REALIZE};

class CPXC_DISPLAY : public CObject
{	

private:
	// the static modifier keeps these variable names local to this file
	BYTE *gpBits;

	typedef struct {
		BITMAPINFOHEADER bmiHeader; 
		RGBQUAD          bmiColors[256]; 
	} XBITMAPINFO; 

	XBITMAPINFO bmi;

	

public:
    CPXC_DISPLAY();
	CPXC_DISPLAY(FRAMELIB	PXCFrameLib);
    ~CPXC_DISPLAY();
	void FreeDisplayBuffer(void);
	int CreateDisplayBuffer(int iWidth, int iHeight, int iPixelType);
	void GrayscalePalette(HDC hdc, UINT uMessage);
	void SetBitmapHead(int iWidth, int iHeight, int iPixelType);
	void ShowFrame(FRAMELIB	FrameLib, FRAME __PX_FAR *pFrame, HDC hdc, int iWidth, int iHeight, int iPixelType);
};
