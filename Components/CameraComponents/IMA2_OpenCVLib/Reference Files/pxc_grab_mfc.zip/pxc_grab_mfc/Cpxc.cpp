/******************************************************************************
 * Cpxc.cpp : implementation file
 *
 * Copyright (c) 2001 by Imagenation
 *
 * This sample code shows you how to grab and display frames in realtime using
 * a technique called double buffering. 
 *
 * Double Buffering Description:
 * We allocate two grab buffers and we alternate grabs to them.
 * While one buffer is being filled with video, the other one can be copied
 * to the VGA card for display. We use the QUEUED flag with each grab in
 * order to let the grab work in the background while our program is still
 * running and copying buffers.
 *
 * This method works quite well and will result in a realtime display if a 
 * buffer can be copied to the VGA faster than the next grab can take place, 
 * which is either 33 or 40 ms depending camera type. A color buffer at full
 * resolution is between .9 MB and 1.2 MB depending on camera. So whether or
 * not you can achieve a realtime display depends on your processor speed.
 *
 * In this sample you will learn how to do the following:
 *
 * 1. Create a simple control window.
 * 2. Create a video display window.
 * 3. Initialize the PXC frame grabber.
 * 4. Grab individual frames and display them in the video display window.
 * 5. Grab frames and display them in realtime in the video display window.
 *
 * In this sample we will create two objects one for reading and write images
 * to a file and one for display them. You will need the following files:
 *
 * 1. CPXC_DISPLAY.CPP -- video display common code
 * 2. CPXC_FILERW.CPP  -- file read/write common code
 *
 * To embed a Cpxc object in a veiw class (see PXC_GRAB_MFCView.h)
 * 
 * add the header file #include "Cpxc.h" to PXC_GRAB_MFCView.h 
 * then add following line of code to the view class:
 *           pxcgrabber grab;
 * 
 ******************************************************************************/

#include "stdafx.h"
#include "Cpxc.h"
#include <math.h>
#include <Mmsystem.h>


// set the DLL names
#define PXC_9X  "pxc_95.dll"
#define FRAME_NAME  "frame_32.dll"
#define PXC_NT    "pxc_nt.dll"

// frame grabber handle
long			hFG;
FRAME			*gpFrame[2];
FRAMELIB		FrameLib;
PXC				pxc;

// image size: width (iImageX), height (iImageY)
static	int iImageX, iImageY;
static	short PIXEL_TYPE;
static 	int iGrabType;
static	int PXC_Error;
static	BOOL bAcquire = FALSE;
int iFrameCount;

// Global event objects 
extern CEvent g_eventPause;
extern CEvent g_eventContinue;
extern CEvent g_eventStop;

/******************************************************************************
 * Name:         pxcgrabber -Constructor
 *-----------------------------------------------------------------------------
 * Description:  When the object is created, data members are initialized by 
 *               this constructor function.
 ******************************************************************************/
pxcgrabber::pxcgrabber()
{
	int i;
	
	PXC_Error = 0;
	iGrabIdx = 1;

	// this program can use either 24 bit color or 8 bit gray frames
    // change the value of PIXEL_TYPE to PBITS_RGB24 or PBITS_Y8
	PIXEL_TYPE = PBITS_RGB24;

	bAcquire = FALSE;
	for(i=0; i<2; ++i) 
	{
		gpFrame[i] = NULL;
		qidGrab[i] = 0;
	}
	SetupPXC();
}

/******************************************************************************
 * Name:         ~pxcgrabber -Destructor
 *-----------------------------------------------------------------------------
 * Description:  When the object is destroyed, This procedure performs the
 *               termination housekeeping.
 ******************************************************************************/
pxcgrabber::~pxcgrabber()
{
	bAcquire = FALSE;
	AppExit();
}

/******************************************************************************
 * Name:         InitializePXC
 *-----------------------------------------------------------------------------
 * Description:  This function contains code that is unique to initializing
 *               the PXC. There is another function that contains code for
 *               resetting the PXC.
 ******************************************************************************/
BOOL pxcgrabber::InitializePXC()
{
	// allocate any frame grabber
	hFG = pxc.AllocateFG(-1);
	if(!hFG)
	{
		return FALSE;
	}
	return TRUE;
}

/******************************************************************************
 * Name:         ResetPXC
 *-----------------------------------------------------------------------------
 * Description:  This function should contain initialization code that would
 *               be needed if the program or the PXC were reset, but not code
 *               that is used for first-time initialization. You should design
 *               this function so it can be called many times without creating
 *               problems.
 ******************************************************************************/
BOOL pxcgrabber::ResetPXC()
{
	int iVideoType;

	// reset the PXC to a default state
	pxc.Reset(hFG);

	// wait 2 1/2 seconds for CCIR detect
	Sleep(2500);

	iVideoType = pxc.VideoType(hFG);

	switch(iVideoType)
	{
	case 0:     /* no video */
	case 1:     /* NTSC */
		iGrabType = QUEUED;
		iImageX = 640;
		iImageY = 486;
		if(iVideoType == 0)
			return FALSE;
		break;
	case 2:     /* CCIR */
		iGrabType = QUEUED;
		iImageX = 768;
		iImageY = 576;
		break;
	}

	pxc.SetWidth(hFG,(short)iImageX);
	pxc.SetHeight(hFG,(short)iImageY);
	pxc.SetLeft(hFG,0);
	pxc.SetTop(hFG,0);
	pxc.SetXResolution(hFG,(short)iImageX);
	pxc.SetYResolution(hFG,(short)iImageY);

	return TRUE;
}

/******************************************************************************
 * Name:         SetupPXC
 *-----------------------------------------------------------------------------
 * Description:  this function open the PXC library and the PXC frame library,
 *               reset the PXC to known values, and  allocate frame buffers 
 ******************************************************************************/
BOOL pxcgrabber::SetupPXC() 
{
	short	sGrabbers;

	// try to open the PXC library and the PXC frame library
	// all of this code will have to change
	sGrabbers = imagenation_OpenLibrary(PXC_9X, &pxc, sizeof(pxc));
	if (sGrabbers == 0)
	{
		sGrabbers = imagenation_OpenLibrary(PXC_NT, &pxc, sizeof(pxc));
		if (sGrabbers == 0)
		{
			MessageBox(NULL,"Could not load pxc_95.dll or pxc_nt.dll", "PXC_GRAB_MFC", MB_OK);
			PXC_Error = 1;
			return FALSE;
		}
		
	}

	// now try to open the frame library
	if (!imagenation_OpenLibrary(FRAME_NAME, &FrameLib,sizeof(FrameLib)))
	{
		MessageBox(NULL,"Could not load frame_32.dll", "PXC_GRAB_MFC", MB_OK);
		imagenation_CloseLibrary(&pxc);
		PXC_Error = 2;
		return FALSE;
	}

	// try to initialize any PXC in the computer
	if(!InitializePXC())
	{
		MessageBox(NULL,"Unable to find a PXC board", "Board initialization failure",MB_ICONERROR | MB_OK);
		PXC_Error = 3;
		return FALSE;
	}

	// now reset the PXC to known values 
	if(!ResetPXC())
	{
		MessageBox(NULL,"Unknown video type or no video signal", "ResetPXC Failure", MB_ICONERROR | MB_OK);
		PXC_Error = 4;
		return FALSE;
	}

	// try to allocate a first frame buffer
	gpFrame[0] = pxc.AllocateBuffer((short)iImageX, (short)iImageY, PIXEL_TYPE);
	if(!gpFrame[0]) 
	{
		MessageBox(NULL,"Unable to allocate buffer on gpFrame[0]", "Frame allocation failure", MB_ICONERROR | MB_OK);
		PXC_Error = 5;
		return FALSE;
	}

    // try to allocate a second frame buffer
	gpFrame[1] = pxc.AllocateBuffer((short)iImageX, (short)iImageY, PIXEL_TYPE);
	if(!gpFrame[1]) 
	{
		MessageBox(NULL,"Unable to allocate buffer on gpFrame[1]", "Frame allocation failure", MB_ICONERROR | MB_OK);
		PXC_Error = 6;
		return FALSE;
	}
	
	return TRUE;
	
}

/******************************************************************************
 * Name:         AppExit
 *-----------------------------------------------------------------------------
 * Description:  This function contains common exit code.
 ******************************************************************************/
void pxcgrabber::AppExit()
{
	int i;

	// stop thread
	g_eventStop.SetEvent();

	if(hFG != 0)
	{
		// wait for all queued activity to stop before deleting the FG 
		pxc.WaitFinished(hFG, 0);
		pxc.FreeFG(hFG);
	}

	for(i=0; i<2; ++i) 
		if(gpFrame[i] != NULL)
		{
				FrameLib.FreeFrame(gpFrame[i]);
				gpFrame[i] = NULL;
		}

	imagenation_CloseLibrary(&pxc);
	imagenation_CloseLibrary(&FrameLib);
}

/******************************************************************************
 * Name:         GrabImage
 *-----------------------------------------------------------------------------
 * Description:  We use this function the grabs a signgle image into a frame.
 *
 ******************************************************************************/
BOOL pxcgrabber::GrabImage()
{
	if (!PXC_Error)
		qidGrab[iGrabIdx] = pxc.Grab(hFG, gpFrame[iGrabIdx], 0);
	else
		return FALSE;

	return TRUE;

}

/******************************************************************************
 * Name: ReadFile
 *-----------------------------------------------------------------------------
 * Description:  This function calls ReadFile from the pxc_filerw class.              
 ******************************************************************************/
void pxcgrabber::ReadFile()
{
	// read BMP file to a frame 
	if(!PXC_Error) 
		gpfile.ReadFile(FrameLib, gpFrame[iGrabIdx]);
}

/******************************************************************************
 * Name: WriteFile
 *-----------------------------------------------------------------------------
 * Description:  This function calls WriteFile from the pxc_filerw class.   
 ******************************************************************************/
void pxcgrabber::WriteFile()
{
	// write frame to a BMP file
	if(!PXC_Error) 
		gpfile.WriteFile(FrameLib, gpFrame[iGrabIdx]);
}

/******************************************************************************
 * Name: SetComposite
 *-----------------------------------------------------------------------------
 * Description:  This function set the camera input to 0 and the set video
 *               input for Composite. 
 ******************************************************************************/
void pxcgrabber::SetComposite()
{
	// pause the thread needed to synchronize event with thread
	g_eventPause.SetEvent();

	// Set the camera input to input 0
	pxc.SetCamera(hFG,0,0);

	// tell frame grabber that the video input is Monochrome or Composite
	pxc.SetChromaControl(hFG,NOTCH_FILTER|BW_DETECT);

	// continue with thread 
	g_eventContinue.SetEvent();

}

/******************************************************************************
 * Name: SetSVideo
 *-----------------------------------------------------------------------------
 * Description:  This function set the camera input to 1 and the set video 
 *               input for S_Video. 
 ******************************************************************************/
void pxcgrabber::SetSVideo()
{
	// pause the thread needed to synchronize event with thread
	g_eventPause.SetEvent();

	// Set the camera input to input 1
	// the PXC200 LC has s-video only on channel 1
	pxc.SetCamera(hFG,1,0);

	// tell frame grabber that the video input is an S-video signal
	pxc.SetChromaControl(hFG,SVIDEO);

	// continue with thread 
	g_eventContinue.SetEvent();
}

/******************************************************************************
 * Name: GetAquire()
 *-----------------------------------------------------------------------------
 * Description:  This function returns the value of the bAcquire flag. 
 *               bAcquire indicate if the thread is running. 
 ******************************************************************************/	
BOOL pxcgrabber::GetAquire()
{
	return bAcquire;
}

/******************************************************************************
 * Name: ShowFrame()
 *-----------------------------------------------------------------------------
 * Description:  This display the aquired image in a frame. It uses the  
 *               display class Cpxc_display.cpp
 ******************************************************************************/
void pxcgrabber::ShowFrame(CDC* pDC)
{
	CPXC_DISPLAY display;
	HDC hdc = pDC->GetSafeHdc( ) ;
	
	if (!PXC_Error)
	{
		// creates a display buffer. It will be deleted when this 
		// procdure exits by the display class destructor.
		display.CreateDisplayBuffer(iImageX, iImageY, PIXEL_TYPE);
		// display frame
		display.ShowFrame(FrameLib, gpFrame[iGrabIdx], hdc, iImageX, 
			iImageY, PIXEL_TYPE);			
	}

}

/******************************************************************************
 * Name:         GetTime
 *-----------------------------------------------------------------------------
 * Description:  This function is used to get a difference in seconds from 
 *               some beginning time. It is used to calculate frames per second.
 ******************************************************************************/
double pxcgrabber::GetTime(UINT uMessage)
{
	// Timer Data   
	static double bTime;
	double eTime, dTime;

	switch(uMessage) 
	{
	case PXC_TIME_DIFF:
		eTime = timeGetTime();	// get end time
		dTime = eTime - bTime;	// calculate difference
		break;

	case PXC_TIME_RESET:
		bTime = timeGetTime();	// reset begin time
		dTime = 0.0;
		break;
	}

	return dTime;
}

/******************************************************************************
 * Name:         GetFPS
 *-----------------------------------------------------------------------------
 * Description:   
 ******************************************************************************/
int pxcgrabber::GetFPS(double dTime)
{
	double dFrameCount, dFPS;
	double dFract, dInt;

	if(dTime <= 1.0)
		return 0;

	dFrameCount = (double)iFrameCount;
	dFPS = dFrameCount / (dTime / (double)CLOCKS_PER_SEC);
	dFract = modf(dFPS, &dInt);
	if(dFract >= 0.05)
		dInt += 1.0;

	return (int)dInt;


}

/******************************************************************************
 * Name:         DisplayThreadProc
 *-----------------------------------------------------------------------------
 * Description:  this  function contains the code for a worker thread to keep 
 *               the grabs and the displays going. To start this thread your
 *               your program will needs to make the following call: 
 *               
 *               AfxBeginThread(DisplayThreadProc, GetSafeHwnd(),
 *                              THREAD_PRIORITY_HIGHEST);
 *
 *               You will also need to add the following global event objects 
 *               to the view class (see PXC_GRAB_MFCView.cpp).
 *
 *               CEvent g_eventPause;
 *               CEvent g_eventContinue;
 *               CEvent g_eventStop;
 *
 *               This function uses 2 buffers. It sets up a queued grab to one
 *               buffer and then displays the other.
 *
 *               This function always works correctly if you always clear the
 *               queue handle after a grab has completed. When bAcquire is TRUE
 *               a grab is queued whenever the grab handle is clear. The order
 *               does not matter. When you enter this routine, you always switch
 *               the queue index and check whatever it points to. When you need
 *               to stop the display, you set bAcquire to FALSE and clear both
 *               grab handles qidGrab[0] and qidGrab[1]. When you call this
 *               function bAcquire is set TRUE again, the queuing will restart
 *               restart automatically.
 ******************************************************************************/

UINT DisplayThreadProc(LPVOID pParam)
{
	HDC hdc = GetDC((HWND) pParam); 
	CPXC_DISPLAY display;
	static int iGrabIdx = 1;
	static int qidGrab[2];
	iFrameCount = 0;

	bAcquire = TRUE;
	
	display.CreateDisplayBuffer(iImageX, iImageY, PIXEL_TYPE);	

	for(;;)
	{
		if(!PXC_Error)
		{
			// pause execution of thread 
			if(::WaitForSingleObject(g_eventPause.m_hObject,0)==WAIT_OBJECT_0)
				::WaitForSingleObject(g_eventContinue.m_hObject,INFINITE);

			if (GetKeyState(VK_LBUTTON) >= 0 && !PXC_Error)
			{
				// swap the index from 0 to 1 or vice versa
				iGrabIdx = (iGrabIdx == 1) ? 0 : 1;

				// if there is a valid queue handle, check the queue
				// for a completed grab.
				if(qidGrab[iGrabIdx]!= 0) 
				{
					// wait for the grab to finish 
					pxc.WaitFinished(hFG, qidGrab[iGrabIdx]);
					++iFrameCount;
					qidGrab[iGrabIdx] = 0;
				}

				// if qidGrab is clear, a grab needs to be queued
				if(qidGrab[iGrabIdx] == 0)
				{
					qidGrab[iGrabIdx] = pxc.Grab(hFG, gpFrame[iGrabIdx], (short)iGrabType);
				}
				// display frame
				display.ShowFrame(FrameLib, gpFrame[iGrabIdx], hdc, iImageX, iImageY, PIXEL_TYPE);
			}
		}
		// exit thread on event g_eventStop
		if(::WaitForSingleObject(g_eventStop.m_hObject,0)==WAIT_OBJECT_0)
			break;
	}
	bAcquire = FALSE;
    return 0; // ends the thread
}

