// PXC_GRAB_MFCView.h : interface of the CPXC_GRAB_MFCView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PXC_GRAB_MFCVIEW_H__65091E0C_5F01_11D5_BE5B_00D0B7212B03__INCLUDED_)
#define AFX_PXC_GRAB_MFCVIEW_H__65091E0C_5F01_11D5_BE5B_00D0B7212B03__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Cpxc.h"

class CPXC_GRAB_MFCView : public CView
{
pxcgrabber grab;

protected: // create from serialization only
	CPXC_GRAB_MFCView();
	DECLARE_DYNCREATE(CPXC_GRAB_MFCView)

// Attributes
public:
	CPXC_GRAB_MFCDoc* GetDocument();

// Operations
public:
	
private:


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPXC_GRAB_MFCView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual void OnInitialUpdate();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CPXC_GRAB_MFCView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif


protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPXC_GRAB_MFCView)
	afx_msg void OnAquire();
	afx_msg void OnStop();
	afx_msg void OnFileOpen();
	afx_msg void OnFileSave();
	afx_msg void OnGrab();
	afx_msg void OnComposite();
	afx_msg void OnSvideo();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in PXC_GRAB_MFCView.cpp
inline CPXC_GRAB_MFCDoc* CPXC_GRAB_MFCView::GetDocument()
   { return (CPXC_GRAB_MFCDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PXC_GRAB_MFCVIEW_H__65091E0C_5F01_11D5_BE5B_00D0B7212B03__INCLUDED_)
