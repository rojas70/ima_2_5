/******************************************************************************
 * PXC_IPL.C
 *
 * Copyright (c) 2002 by Imagenation
 *
 * This example shows some of the basic steps need to use the Intel Image 
 * Processing Library with a PXC200 Frame grabber. In this example we use the 
 * FrameFromPointer function to create a pxc compatible frame for the ipl 
 * image data buffer. This technique allows us to grab a image directly in to  
 * an ipl image data buffer with out the added step of having to copy it from 
 * another buffer first.
 *
 * In this example you can select one of the IPL function from a list and 
 * then adjust one of its key parameters with the scroll bar to see what 
 * happens.
 *
 * In this sample you will learn how to do the following:
 *
 * 1. Create a simple control window.
 * 2. Create a video display window.
 * 3. Initialize the PXc frame grabber.
 * 4. Create a pxc compatible frame for a ipl image.
 * 5. Grab frames and display them in the video display window.
 * 6. Use and control some simple IPL functions from the Intel Image Processing 
 *    Library.
 ******************************************************************************/

#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <math.h>
#include <ipl.h>
#include "pxc_display.h"
#include "resource.h"

FRAMELIB		FrameLib;
PXC				pxc;

// this program can use either 24 bit color or 8 bit gray frames
// the value of PIXEL_TYPE can be change to PBITS_RGB24 or PBITS_Y8
static short PIXEL_TYPE = PBITS_RGB24;

// set the DLL names
#define PXC_9X  "pxc_95.dll"
#define FRAME_NAME  "frame_32.dll"
#define PXC_NT    "pxc_nt.dll"

// frame grabber handle
static long		hFG;
static FRAME		*gpFrame = NULL;
static FRAME		*gpFrame2 = NULL;

//The variables are used by AppIdle() where the grabs are queued.
static BOOL bAcquire = FALSE;
static BOOL bRestartClock;

// iGrabType controls the queuing of the grab. 
int iGrabType;

// image size: width (iImageX), height (iImageY)
static int iImageX, iImageY;
// Window size: width (iWindowX), height (iWindowY)
static int iWindowX, iWindowY;

// window procs for the dialog and video display windows
LRESULT CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK VideoProc(HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam);

// functions to register and create video display window
void RegisterVideoWindow(HINSTANCE hInstance);
HWND CreateVideoWindow(HINSTANCE hInstance);


// these functions contain the knowledge of how to open and close the video
// display window. if you have variables that are coordinated with this
// window they can be set and cleared within these functions.
int OpenVideoWindow(void);
int CloseVideoWindow(void);
void SizeVideoWindow(void);
BOOL ResetBuffers(short PixelType);


//  displays the hardware/firmware revision
int DisplayRevision(long fgHandle);

// PXC control functions
long InitializePXC(void);
BOOL ResetPXC(void);

// application control functions
BOOL AppIdle(void);
void AppExit(void);

// these variables are static for one reason: to avoid name collisions with other
// modules.
static HINSTANCE hAppInst;
static HWND hDisplay = NULL;
static HWND hMainDlg = NULL;
static int iFrameCount;

// these variables are the class names for the two windows
static char szDLGClass[] = "PXC_IPL";
static char szVidClass[] = "VidWin";

// these two RECT structures contain the positions of the two windows
static RECT rectMain, rectVideo;

/*---------------------------< IPL data >------------------------------*/

// these variable are needed to keep IPL libary functions and operations
static char szSeqFile[250] = "PXC_IPL";
static int  iStart,iCount= 0;
static BOOL bThreshold =FALSE;

// max scroll number 
#define MaxCount 255
static int MaxRange = MaxCount;
static int MinRange = 3;
static int iScroll[8]={128,3,3,3,3,3,0,0};

static IplImage* img=NULL;
static IplImage* img2 =NULL;
static int IplType =0;

// PXC image processing functions
BOOL create_ipl_Image(int MaxX,int MaxY,int iPixelType );
void Process_Image(HDC hdc,int type );

/******************************************************************************
 * Name:         WinMain
 *-----------------------------------------------------------------------------
 * Description:  Main dialog window program and message loop
 ******************************************************************************/
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,
										PSTR szCmdLine, int iCmdShow)
{
	MSG		msg;
	short	sGrabbers;
    
	// save this instance of the program
	hAppInst = hInstance;

	// register the video display window class
	// it will be used to create a video display window later
	RegisterVideoWindow(hAppInst);

	// create the main window as a modeless dialog box
	hMainDlg = CreateDialog (hInstance, MAKEINTRESOURCE(IDD_GRAB),0, WndProc);

	// try to open the PXC library and the PXC frame library
	// all of this code will have to change
	sGrabbers = imagenation_OpenLibrary(PXC_9X, &pxc, sizeof(pxc));
	if (sGrabbers == 0)
	{
		sGrabbers = imagenation_OpenLibrary(PXC_NT, &pxc, sizeof(pxc));
		if (sGrabbers == 0)
		{
			MessageBox(0, "Could not load pxc_95.dll or pxc_nt.dll", szDLGClass, MB_OK);
			return FALSE;
		}
	}

	// now try to open the frame library
	if (!imagenation_OpenLibrary(FRAME_NAME, &FrameLib,sizeof(FrameLib)))
	{
		MessageBox(0, "Could not load frame_32.dll", szDLGClass, MB_OK);
		imagenation_CloseLibrary(&pxc);
		return FALSE;
	}

	// try to initialize any PXC in the computer
	if(!InitializePXC())
	{
		MessageBox(NULL, "Unable to find a PXC board", "Board initialization failure", 0);
		AppExit();
		return FALSE;
	}

	// now reset the PXC to known values 
	if(!ResetPXC())
	{
		MessageBox(NULL, "Unknown video type or no video signal", "ResetPXC Failure", 0);
		AppExit();
		return FALSE;
	}


	// create a pxc compatible frame for ipl image data 
	if(! create_ipl_Image(iImageX,iImageY,PIXEL_TYPE))
	{
		MessageBox(0, "Unable to create frame for ipl", "Frame Failure", 0);
		AppExit();
		return FALSE;
	}


	// set a gray scale palette to be used for display
	GrayscalePalette(NULL, PXC_PALETTE_CREATE);

	/*-------------------------------------------------------------------------
	watch for windows messages like mouse events, and otherwise call AppIdle
	to maintain a display of video.
	-------------------------------------------------------------------------*/
	for(;;) 
	{
		if(PeekMessage(&msg, NULL, 0, 0,PM_REMOVE)) 
		{
			if (msg.message == WM_QUIT)
				break;
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else 
		{
			if(AppIdle())
				WaitMessage();
		}
	}
    
    AppExit();
	return TRUE;
}

/******************************************************************************
 * Name:         AppIdle
 *-----------------------------------------------------------------------------
 * Description:  This idle function is called whenever the message queue
 *               is empty. We use this function to keep the grabs and the
 *               displays going.
 ******************************************************************************/
BOOL AppIdle(void)
{
	HDC hdc;

	if (IsIconic(hDisplay))
		return TRUE;

	if (GetKeyState(VK_LBUTTON) >= 0)
	{
		// if we are in the acquire mode, queue a new grab and display
		// whatever was in the previous grab.
		if(bAcquire) 
		{
			pxc.Grab(hFG, gpFrame, (short)iGrabType);
				
		}

		if(hDisplay)
		{
		hdc = GetDC(hDisplay);
		Process_Image(hdc,IplType);
		ReleaseDC(hDisplay, hdc);
		}
		return FALSE;
	}
	else 
	{
		return TRUE;      // background app; nothing to do.
	}
}

/******************************************************************************
 * Name:         WndProc
 *-----------------------------------------------------------------------------
 * Description:  Window procedure for main dialog box
 ******************************************************************************/
LRESULT CALLBACK WndProc (HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	HDC hDC;

	int  iseq=0;

	switch (iMsg)
	{
	case WM_INITDIALOG:
		
		// If you want to do something to the window before it displays,
		// do it in this message trap.

		// set initial state of control buttons
		CheckRadioButton(hWnd, IDC_OPEN, IDC_CLOSE, IDC_CLOSE);
		CheckRadioButton(hWnd, ID_SVIDEO, ID_COMPOSITE, ID_COMPOSITE);
		CheckRadioButton(hWnd, IDC_NONE, IDC_NONE, IDC_NONE);

		// set the sequence file name
		SetDlgItemText(hWnd, IDC_FILENAME, szSeqFile);
		
		//set range and initial position of scroll bar
		SetScrollRange (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, 3, MaxRange, FALSE) ;
		SetScrollPos   (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, iScroll[0], FALSE) ;
		return TRUE;

	case WM_HSCROLL :
		//iCtrlID = GetWindowLong((HWND) lParam, GWL_ID); // ID of control
		
		switch (LOWORD (wParam))
		{
		case SB_PAGERIGHT :   //click on bar right of scrollbox step right 15
			iScroll[IplType] += 15 ;
			break ;
		
		case SB_LINERIGHT:            // Scrolls left by 2 units.
			iScroll[IplType] = min (MaxRange, iScroll[IplType] + 1) ;
			break ;
		
		case SB_PAGELEFT :	  //click on bar left of scrollbox step left 15
			iScroll[IplType] -= 15 ;
			break ;
		
		case SB_LINELEFT :	  // Scrolls Right by 2 units.
			iScroll[IplType] = max (MinRange, iScroll[IplType] - 1) ;
			break ;
		
		case SB_LEFT : 
			iScroll[IplType] = MinRange ;   // limit left
			break ;
		
		case SB_RIGHT :
			iScroll[IplType] = MaxRange ; // limit right
			break ;
		
		case SB_THUMBPOSITION : //user dragging scrollbox update when mouse release
		
		case SB_THUMBTRACK :    //user dragging scrollbox update repeatedly until mouse released
			iScroll[IplType] = HIWORD (wParam) ; // set to position of scrollbox
			break ;

		default :
			return FALSE ;
		}


		if(iScroll[IplType] < MinRange) iScroll[IplType] = MinRange;

		// set the new position for the selected the scroll bar  
		SetScrollPos  (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, iScroll[IplType],TRUE) ;
		iCount=iScroll[IplType];
		
		if(!bAcquire && hDisplay)
		{		
				hDC = GetDC(hDisplay);
				Process_Image(hDC,IplType );
				ReleaseDC(hDisplay, hDC);
		}
		
		return TRUE;

	case WM_COMMAND:
		switch (LOWORD (wParam))
		{
		case IDC_OPEN:
			OpenVideoWindow();
			break;
		
		case IDC_CLOSE:
			PostMessage(hDisplay, WM_CLOSE, wParam, lParam);
			break;
		
		case IDC_START_RT:
			bAcquire = TRUE;
			bRestartClock = TRUE;
			break;
		
		case IDC_STOP_RT:
			bAcquire = FALSE;
			break;
		
		case ID_COMPOSITE:
			// Set the camera input to input 0
			pxc.SetCamera(hFG,0,0);

			// tell frame grabber that the video input is Monochrome or Composite
			pxc.SetChromaControl(hFG,NOTCH_FILTER|BW_DETECT);

			// resize buffers and set the value of pixel type to PBITS_RGB24
			ResetBuffers(PBITS_RGB24);
			break;

        case ID_SVIDEO:
			// Set the camera input to input 1
			// the PXC200 LC has s-video only on channel 1
			pxc.SetCamera(hFG,1,0);

			// tell frame grabber that the video input is an S-video signal
			pxc.SetChromaControl(hFG,SVIDEO);

			// resize buffers and set the value of pixel type to PBITS_RGB24
			ResetBuffers(PBITS_RGB24);
			break;
		
		case ID_MONOCHROME:
			// Set the camera input to input 0
			pxc.SetCamera(hFG,0,0);

			// tell frame grabber that the video input is Monochrome or Composite
			pxc.SetChromaControl(hFG,NOTCH_FILTER|BW_DETECT);

			// resize buffers and set the value of pixel type to PBITS_Y8
			ResetBuffers(PBITS_Y8);
			break;

	    case IDC_BLUR:
			//set range and initial position of scroll bar
			IplType = 1;
            MaxRange = 100; 
			MinRange = 3;
			SetScrollRange (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, 	MinRange, MaxRange, TRUE) ;
			SetScrollPos   (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, iScroll[IplType], TRUE) ;
			break;
	   
		case IDC_DILATE:
			//set range and initial position of scroll bar
			IplType =2;
			MinRange=3;
            MaxRange = 100; 
			SetScrollRange (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, 	MinRange, MaxRange, TRUE) ;
			SetScrollPos   (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, iScroll[IplType], TRUE) ;
			break;

		case IDC_ERODE:
			//set range and initial position of scroll bar
			IplType =3;
			MinRange = 3;
            MaxRange = 50; 
			SetScrollRange (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, 	MinRange, MaxRange, TRUE) ;
			SetScrollPos   (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, iScroll[IplType], TRUE) ;

			break;

	    case IDC_IOPEN:
			//set range and initial position of scroll bar
			IplType =4;
			MinRange =3;
            MaxRange = 50; 
			SetScrollRange (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, 	MinRange, MaxRange, TRUE) ;
			SetScrollPos   (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, iScroll[IplType], TRUE) ;
			break;
			    
		case IDC_FILTER:
			//set range and initial position of scroll bar
			IplType =5;
			MinRange =3;
            MaxRange = 25; 
			SetScrollRange (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, 	MinRange, MaxRange, TRUE) ;
			SetScrollPos   (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, iScroll[IplType], TRUE) ;
			break;

		case IDC_SUBTRACT:
			//set range and initial position of scroll bar
		   	IplType =6;
			MinRange = 0;
            MaxRange = 250; 
			SetScrollRange (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, 	MinRange, MaxRange, FALSE) ;
			SetScrollPos   (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, iScroll[IplType], TRUE) ;
			break;

	   case IDC_NONE:
			//set range and initial position of scroll bar
		   	IplType =0;
            MaxRange = 255; 
			MinRange =0;
			SetScrollRange (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, 	MinRange, MaxRange, TRUE) ;
			SetScrollPos   (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, iScroll[IplType], TRUE) ;
			break;

	    case IDC_ROTATE:
			//set range and initial position of scroll bar
		   	IplType =7;
			MinRange =0;
            MaxRange = 360; 
			SetScrollRange (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, 	MinRange, MaxRange, TRUE) ;
			SetScrollPos   (GetDlgItem (hWnd, IDC_OFFSET), SB_CTL, iScroll[IplType], TRUE) ;
			break;

	   case IDC_THRESHOLD_EN:
		   // enable or disable Thresholding
		    if(bThreshold)
				bThreshold = FALSE;
			else
				bThreshold = TRUE;
		    break;

		}
		return TRUE;
	
	case WM_CLOSE:
		DestroyWindow(hWnd);
		return TRUE;
	
	case WM_DESTROY:
		PostQuitMessage (0);
		return TRUE;
	}
	return FALSE;
}

/******************************************************************************
 * Name:         VideoProc
 *-----------------------------------------------------------------------------
 * Description:  Window procedure for the video display window(s). You can use
 *               this procedure for multiple display windows.
 ******************************************************************************/
LONG WINAPI VideoProc(HWND hWnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	PAINTSTRUCT ps;
	HDC hDC;

	switch (iMsg)
	{
	case WM_CREATE:
		// get the default main window size
		GetClientRect(hMainDlg, (LPRECT)&rectMain);

		// set video window size and position
		SetWindowPos(hWnd, NULL, rectMain.right+(GetSystemMetrics(SM_CXFRAME)*2),
			rectMain.top , iWindowX, iWindowY, 0);
		return 0;
	
	case WM_PAINT:
		// repaint video window 
		hDC = BeginPaint(hWnd, &ps);
		ShowFrame(gpFrame, hDC, iImageX, iImageY, PIXEL_TYPE);
		EndPaint(hWnd, &ps);	
		return 0;

	case WM_DESTROY:
		CloseVideoWindow();
		return 0;
	}
	return(DefWindowProc(hWnd, iMsg, wParam, lParam));
}

/******************************************************************************
 * Name:         AppExit
 *-----------------------------------------------------------------------------
 * Description:  This function contains common exit code.
 ******************************************************************************/
void AppExit(void)
{	
	if(hFG != 0)
	{
		// wait for all queued activity to stop before deleting the FG 
		pxc.WaitFinished(hFG, 0);
		pxc.FreeFG(hFG);
	}

	// free frame
	if(gpFrame != NULL)
		FrameLib.FreeFrame(gpFrame);
	// free frame
	if(gpFrame2 != NULL)
		FrameLib.FreeFrame(gpFrame2);

	// free IPL images
	if(img)
		iplDeallocate( img, IPL_IMAGE_ALL );
	if(img)
		iplDeallocate( img2, IPL_IMAGE_ALL );

	GrayscalePalette(NULL, PXC_PALETTE_DELETE);

	imagenation_CloseLibrary(&pxc);
	imagenation_CloseLibrary(&FrameLib);
}

/******************************************************************************
 * Name: RegisterVideoWindow
 ******************************************************************************/
void RegisterVideoWindow(HINSTANCE hInstance)
{
	WNDCLASS  wc;

	memset(&wc,0,sizeof(wc));         // clear stack variable

	// register the control window class

	wc.style         = CS_VREDRAW | CS_HREDRAW;
	wc.lpfnWndProc   = VideoProc;
	wc.cbClsExtra    = 0;
	wc.cbWndExtra    = 0;
	wc.hInstance     = hInstance;
	wc.hIcon         = LoadIcon(hInstance, MAKEINTRESOURCE(CYBER_PXC));
	wc.hCursor       = NULL;
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
	wc.lpszMenuName  = NULL;
	wc.lpszClassName = szVidClass;

	RegisterClass (&wc);
}

/******************************************************************************
 * Name: CreateVideoWindow
 ******************************************************************************/
HWND CreateVideoWindow(HINSTANCE hInstance)
{
HWND hWnd;

  hWnd = CreateWindow (szVidClass,   // window class name
        NULL,
        WS_OVERLAPPEDWINDOW,         // window style
        CW_USEDEFAULT,               // initial x position
        CW_USEDEFAULT,               // initial y position
        CW_USEDEFAULT,               // initial x size
        CW_USEDEFAULT,               // initial y size
        NULL,                        // parent window handle
        NULL,                        // window menu handle
        hInstance,                   // program instance handle
        NULL);                       // creation parameters

  return hWnd;
}

/******************************************************************************
 * Name:         InitializePXC
 *-----------------------------------------------------------------------------
 * Description:  This function contains code that is unique to initializing
 *               the PXC. There is another function that contains code for
 *               resetting the PXC.
 ******************************************************************************/
long InitializePXC(void)
{
	// allocate any frame grabber
	hFG = pxc.AllocateFG(-1);
	if(!hFG)
	{
		return FALSE;
	}
	return TRUE;
 
}

/******************************************************************************
 * Name:         ResetPXC
 *-----------------------------------------------------------------------------
 * Description:  This function should contain initialization code that would
 *               be needed if the program or the PXC were reset, but not code
 *               that is used for first-time initialization. You should design
 *               this function so it can be called many times without creating
 *               problems.
 *               
 *               This function shows how to setup to grab a single field. In 
 *               this function you should look at the values of iImageX  and  
 *               iImageY. iImageX is set to half the expected pixel width to 
 *               make the display look good. iImageY is set to the actual  
 *               expected field length. When iImageY is used in the call to  
 *               SetYResolution it is multiplied by 2 to double the image  
 *               height for the library function:
 *                          pxc.SetYResolution(hFG,(short)(iImageY*2)); 
 ******************************************************************************/
BOOL ResetPXC(void)
{
int iVideoType;

	// reset the PXC to a default state
	pxc.Reset(hFG);

	// wait 2 1/2 seconds for CCIR detect
	Sleep(2500);

	iVideoType = pxc.VideoType(hFG);

	switch(iVideoType)
	{
	case 0:     /* no video */
	case 1:     /* NTSC */
		iGrabType = 0;
		iImageX = 640;
		iImageY = 486;
		if(iVideoType == 0)
			return FALSE;
		break;
	case 2:     /* CCIR */
		iGrabType = 0;
		iImageX = 768;
		iImageY = 576;
		break;
	}

	pxc.SetWidth(hFG,(short)iImageX);
	pxc.SetHeight(hFG,(short)(iImageY));
	pxc.SetLeft(hFG,0);
	pxc.SetTop(hFG,0);
	pxc.SetXResolution(hFG,(short)iImageX);
	pxc.SetYResolution(hFG,(short)(iImageY));
 

	// Size video Window.
    SizeVideoWindow();

	return TRUE;
}

/******************************************************************************
 * Name:         SizeVideoWindow
 *-----------------------------------------------------------------------------
 * Description:  This function will resize create a video window that can
 *               fit on the screen.
 ******************************************************************************/
void SizeVideoWindow(void)
{ 
	float AspectRatio;
	int FrameSizeX, FullScreenSizeX;

	AspectRatio = (float)iImageY/iImageX;
	iWindowY = iImageY;
	iWindowX = iImageX;
	
	// get the default window size
	GetClientRect(hMainDlg, (LPRECT)&rectMain);
	// if dwImageX to large then resize to fit screen
	if (GetSystemMetrics(SM_CXFULLSCREEN) < (int)(iImageX+rectMain.right))
	{
		FrameSizeX = GetSystemMetrics(SM_CXFRAME)*4;
		FullScreenSizeX = GetSystemMetrics(SM_CXFULLSCREEN);
		iWindowX = FullScreenSizeX - rectMain.right - FrameSizeX;
		// resize dwWindowY to match AspectRatio
		iWindowY= (int)(iWindowX*AspectRatio);
	}
	// get the initial window size
	iWindowX = GetSystemMetrics(SM_CXFRAME)*2+iWindowX;
	iWindowY = GetSystemMetrics(SM_CXFRAME)*2+GetSystemMetrics(SM_CYCAPTION)+iWindowY;
}


/******************************************************************************
 * Name:         OpenVideoWindow
 *-----------------------------------------------------------------------------
 * Description:  This function creates the window where the video is displayed
 *               and sets all necessary variables accordingly.
 ******************************************************************************/
int OpenVideoWindow(void)
{
	// ungray the windows that pertain to the control of the video window
	EnableWindow(GetDlgItem (hMainDlg, IDC_START_RT), TRUE);
	EnableWindow(GetDlgItem (hMainDlg, IDC_STOP_RT), TRUE);
	EnableWindow(GetDlgItem (hMainDlg, IDC_GRAB), TRUE);

	// and set their default values
	CheckRadioButton(hMainDlg, IDC_OPEN, IDC_CLOSE, IDC_OPEN);
	CheckRadioButton(hMainDlg, IDC_START_RT, IDC_STOP_RT, IDC_STOP_RT);

	// open the video display window if it is not already open
	if(!hDisplay)
	{
		hDisplay = CreateVideoWindow(hAppInst);
		if(!CreateDisplayBuffer(iImageX, iImageY, PIXEL_TYPE)) 
		{
			MessageBox(0, "Unable to allocate Display buffer", 
			"Display Buffer allocation failure", MB_TASKMODAL | MB_TOPMOST);
			return FALSE;
		}
		ShowWindow(hDisplay, SW_SHOW);
	}

	//  displays the hardware/firmware revision
	if(!DisplayRevision(hFG));
		return FALSE;

	return TRUE;
}

/******************************************************************************
 * Name:         CloseVideoWindow
 *-----------------------------------------------------------------------------
 * Description:  Close the video display window and clear its handle so
 *               other functions know it is closed. Also delete is 
 *               associated buffer.
 ******************************************************************************/
int CloseVideoWindow(void)
{
	// turn off window control buttons
	EnableWindow(GetDlgItem (hMainDlg, IDC_START_RT), FALSE);
	EnableWindow(GetDlgItem (hMainDlg, IDC_STOP_RT), FALSE);
	EnableWindow(GetDlgItem (hMainDlg, IDC_GRAB), FALSE);

	// check the close button
	CheckRadioButton(hMainDlg, IDC_OPEN, IDC_CLOSE, IDC_CLOSE);

	// stop AppIdle from trying to display
	bAcquire = FALSE;
	// set hDisplay to null to show that the window is closed
	hDisplay = NULL;
 	// free the video windows buffer
	FreeDisplayBuffer();
	return TRUE;
}

/******************************************************************************
 * Name:         DisplayRevision 
 *-----------------------------------------------------------------------------
 * Description: The Read and displays the hardware/firmware revision of the 
 *              grabber and the driver in the display window title bar. 
 ******************************************************************************/
int DisplayRevision(long fgHandle)
{
	int	iHardwareRev;
	char szTitleBar[100];

	// get the hardware/firmware revision number
	iHardwareRev = pxc.ReadRevision(hFG);

	// check to see if valid revision number was returned
	if(iHardwareRev == 0)
		return FALSE;

	// show hardware revision in title bar of display window
	wsprintf(szTitleBar, "PXC - Hardware Rev:%X", iHardwareRev);
	SetWindowText(hDisplay, szTitleBar);

	return TRUE;
}

/*****************************************************************************
 * Name:         ResetBuffers 
 *-----------------------------------------------------------------------------
 * Description:  resize the frame buffers and display buffer to match 
 *               the pixel type                    
 *****************************************************************************/
BOOL ResetBuffers( short PixelType)
{	
	// set the value of pixel type 
	PIXEL_TYPE = PixelType;
	
	// wait for all queued activity to stop before deleting the frames 
	pxc.WaitFinished(hFG, 0);
 
	if(gpFrame != NULL)
		FrameLib.FreeFrame(gpFrame);
	if(gpFrame2 != NULL)
		FrameLib.FreeFrame(gpFrame2);
	if(img)
		iplDeallocate( img, IPL_IMAGE_ALL );
	if(img2)
		iplDeallocate( img2, IPL_IMAGE_ALL );
		
	/*------ allocate a frame buffers ------*/
	
	// create a pxc compatible frame from ipl image data 
	if(! create_ipl_Image(iImageX,iImageY,PIXEL_TYPE))
	{
		MessageBox(0, "Unable to create frame for ipl", "Frame Failure", 0);
		AppExit();
		return FALSE;
	}
	

	if(hDisplay)
	{
		// free the video windows buffer
		FreeDisplayBuffer();
		if(!CreateDisplayBuffer(iImageX, iImageY, PixelType)) 
		{
			MessageBox(0, "Unable to allocate Display buffer", 
				"Display Buffer allocation failure", MB_TASKMODAL | MB_TOPMOST);
			return FALSE;
		}
	}
	return TRUE;
}



/*****************************************************************************
 * Name: Process_Image
 *-----------------------------------------------------------------------------
 * Description:  Image processing procedure
 * 
 *****************************************************************************/

void Process_Image(HDC hdc,int type ) 
{

    static int iValue = 3;
 
	switch (type)
	{

	case 1:
        // Blur image
        iplBlur( img, img2, iScroll[IplType],iScroll[IplType], iScroll[IplType]/2,iScroll[IplType]/2 );
		if(bThreshold)
			iplThreshold( img2, img2, iScroll[0] );
		ShowFrame(gpFrame2, hdc, iImageX, iImageY, PIXEL_TYPE);
		break;
	
	case 2:	
		// Dilate image
	    iplDilate( img, img2, iScroll[IplType] );
		if(bThreshold)
			iplThreshold( img2, img2, iScroll[0] );
		ShowFrame(gpFrame2, hdc, iImageX, iImageY, PIXEL_TYPE);
		break;

	case 3:	
		if(bThreshold)
			iplThreshold( img, img, iScroll[0] );
		// Erode image
		iplErode( img, img2, iScroll[IplType]); 
		ShowFrame(gpFrame2, hdc, iImageX, iImageY, PIXEL_TYPE);
		break;

	case 4:
		if(bThreshold)
			iplThreshold( img, img, iScroll[0] );
		// Open image
	    iplOpen( img, img2, iScroll[IplType]);
		ShowFrame(gpFrame2, hdc, iImageX, iImageY, PIXEL_TYPE);
		break;

	case 5:	
		if(bThreshold)
			iplThreshold( img, img, iScroll[0] );
		// Try to remove the noise, w/Median
        iplMedianFilter( img, img2, iScroll[IplType],iScroll[IplType], iScroll[IplType]/2,iScroll[IplType]/2 );
		ShowFrame(gpFrame2, hdc, iImageX, iImageY, PIXEL_TYPE);
		break;
		
	case 6:	
		if(bThreshold)
			iplThreshold( img, img, iScroll[0] );
		// subtract scroll value from pixel value
		iplSubtractS(img, img2,iScroll[IplType], FALSE);
		ShowFrame(gpFrame2, hdc, iImageX, iImageY, PIXEL_TYPE);
		break;

	case 7:	
		if(bThreshold)
			iplThreshold( img, img, iScroll[0] );
		// subtract scroll value from pixel value
		iplSubtractS(img2, img2,255, FALSE); // clear destination image
		iplRotateCenter( img, img2,iScroll[IplType], iImageX/2, iImageY/2, IPL_INTER_LINEAR);
		ShowFrame(gpFrame2, hdc, iImageX, iImageY, PIXEL_TYPE);
		break;


	default:
		if(bThreshold)
			iplThreshold( img, img, iScroll[0] );
		ShowFrame(gpFrame, hdc, iImageX, iImageY, PIXEL_TYPE);
		break;
	} 

	
}

/*****************************************************************************
 * Name: create_ipl_Image
 *-----------------------------------------------------------------------------
 * Description:  create a pxc compatible frame for ipl image data 
 * 
 *****************************************************************************/

BOOL create_ipl_Image(int MaxX,int MaxY,int iPixelType ) 
{
    
	if(iPixelType == PBITS_Y8) // for gray scale
		img = iplCreateImageHeader( 
		  1,                            // 1 channel
		  0,                            // no alpha channel
		  IPL_DEPTH_8U,                 // data type is ushort
		  "GRAY",                       // color model
		  "GRAY",                       // channel sequence
		  IPL_DATA_ORDER_PIXEL,         // channel arrangement
		  IPL_ORIGIN_TL,                // top left orientation
		  IPL_ALIGN_DWORD,              // 4 bytes align
		  MaxX,MaxY,                    // image width and height
		  NULL, NULL,                   // no ROI, no mask ROI
		  NULL, NULL);                  // image ID, not tiled
	else // for color 24bit RGB
		img = iplCreateImageHeader( 
		  3,                            // 1 channel
		  0,                            // no alpha channel
		  IPL_DEPTH_8U,                 // data type is ushort
		  "RGB",                       // color model
		  "RGB",                       // channel sequence
		  IPL_DATA_ORDER_PIXEL,         // channel arrangement
		  IPL_ORIGIN_TL,                // top left orientation
		  IPL_ALIGN_DWORD,              // 4 bytes align
		  MaxX,MaxY,                    // image width and height
		  NULL, NULL,                   // no ROI, no mask ROI
		  NULL, NULL);                  // image ID, not tiled

   /// allocate image data without filling
   iplAllocateImage( img, 0, 0 ); 

   // make a clone
   img2 = iplCloneImage( img );

   /// create a frame from pointer to image clone buffer
   if( img2->imageData ) 
   {
	   // allocate a frame buffer using a pointer to the image data
	   gpFrame2 = FrameLib.FrameFromPointer(img2->imageData,(short)MaxX, (short)MaxY, (short)iPixelType);

	   if(!gpFrame2)
	   {
			MessageBox(0, "Allocate Buffer Failed", "Frame2 Failure", 0);
			return FALSE;
	   }
   }
   else 
	   return FALSE;
  
   /// create a frame from pointer to image buffer
   if( img->imageData ) 
   {
	  // allocate a frame buffer using a pointer to the image data
	  gpFrame = FrameLib.FrameFromPointer(img->imageData,(short)MaxX, (short)MaxY, (short)iPixelType);

	  if(!gpFrame)
	  {
		MessageBox(0, "Allocate Buffer Failed", "Frame Failure", 0);
		return FALSE;
	  }
   }
   else 
	   return FALSE;

   
   return TRUE;

}