#ifndef COMMON_H
#define COMMON_H

#include "cv.h"
#include "highgui.h"

#define W 320
#define H 240
#define D 3

#define X 0
#define Y 1
#define Z 2

#define RTD 180.0/3.14159
#define DTR 3.14159/180.0

enum EType {
	COLOR,
	EDGE,
	SHAPE
};

enum ECam {
	LEFT,
	RIGHT,
	STEREO
};

struct SObject {
	EType type;
	ECam cam;
	int size;
	double azimuth;
	double elevation;
	double distance;
	double pos[3];

	double primaryX;
	double primaryY;
};

#endif //COMMON_H
