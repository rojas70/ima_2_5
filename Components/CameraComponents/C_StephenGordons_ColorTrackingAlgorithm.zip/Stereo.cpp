#include "Stereo.h"

using namespace std;

CStereo::CStereo()
{
	base = 0.28;

	leftpan = 0;
	rightpan = 0;
	lefttilt = 0;
	righttilt = 0;
}

CStereo::~CStereo()
{
}

bool CStereo::DeterminePosition(SObject o1, SObject o2, SObject& obj)
{
	double ratio = (double)o1.size / (double)o2.size;
	SObject oL, oR;
	if(o1.cam == LEFT)
	{
		oL = o1;
		oR = o2;
	}
	else
	{
		oL = o2;
		oR = o1;
	}

	if(ratio > 0.66 && ratio < 1.5 && ((double)o1.size/W*H > 0.015))
	{
		obj.size = (oL.size + oR.size)/2;
		obj.cam = STEREO;
		obj.type = oL.type;

		double ang1 = leftpan + 90.0 + oL.azimuth;
		double ang2 = 180.0 - (rightpan + 90.0 + oR.azimuth);
		double ang3 = 180.0 - ang1 - ang2;
		double L2 = sin(ang1*DTR) * base / sin(ang3*DTR);
		double L1 = sin(ang2*DTR) * base / sin(ang3*DTR);
		double y = L2*sin(ang2*DTR);
		double x = 0.5 * base - L2 * cos(ang2*DTR);
		double angz1 = righttilt + 90.0 + oL.elevation;
		double zhyp = L1/sin(angz1*DTR);
		double z = -1 * zhyp * cos(angz1*DTR);
		
		double tempx = x - 0.5 * base;
		//pt_out
		double tempxy = pow(tempx*tempx + y*y, 0.5);
		//pt_out

		tempx = x - (-0.5 * base);
		//pt_out
		tempxy = pow(tempx*tempx + y*y, 0.5);
		//pt_out

		double beta = atan2(z, y)/DTR;
		obj.elevation = 90 - beta;
		double tempyz = pow(y*y + z*z, 0.5);
		obj.azimuth = atan2(-1*x, y)/DTR;
		obj.distance = pow(x*x + y*y + z*z, 0.5);
		obj.pos[X] = x;
		obj.pos[Y] = y;
		obj.pos[Z] = z;

		return true;
	}
	return false;
}

void CStereo::SetPanTilt(double *pt)
{
	rightpan = pt[0];
	righttilt = pt[1];
	leftpan = pt[2];
	lefttilt = pt[3];
}
