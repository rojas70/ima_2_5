#include "Img.h"

using namespace std;

CImageFunc::CImageFunc()
{
	const int element_shape = CV_SHAPE_ELLIPSE;
	int posD = 1;
	int posE = 2;
	elementD = cvCreateStructuringElementEx(posD*2+1, posD*2+1, posD, posD, element_shape, 0);
	elementE = cvCreateStructuringElementEx(posE*2+1, posE*2+1, posE, posE, element_shape, 0);
}

CImageFunc::~CImageFunc()
{
}

void CImageFunc::LoadColor(string color)
{
	char file[100] = {"/home/stephen/NEW_HEAD/OBJECT_DETECT/COLORS/"};
	char ifile[100] = {"/home/stephen/NEW_HEAD/OBJECT_DETECT/COLORS/"};
	strcat(file, color.data());
	strcat(file, ".txt");
	strcat(ifile, color.data());
	strcat(ifile, ".jpg");

	ifstream input(file);
	cout << ifile << endl;
	SColor clr;
	clr.name = color;

	input >> clr.vmin;
	input >> clr.vmax;
	input >> clr.smin;

	IplImage* src = 0;
	src = cvLoadImage(ifile, 1);
	clr.image = cvCreateImage(cvGetSize(src), 8, D);
	cvCvtColor(src, clr.image, CV_RGB2HSV);


	int hdims = 16;
	float hranges_arr[] = {0, 180};
	float *hranges = hranges_arr;
	int vmin = 10;
	int smin = 30;
	clr.hist = cvCreateHist(1, &hdims, CV_HIST_ARRAY, &hranges, 1);

	IplImage* hue = 0;
	IplImage* mask = 0;

	hue = cvCreateImage(cvGetSize(clr.image), 8, 1);
	mask = cvCreateImage(cvGetSize(clr.image), 8, 1);
	float max_val = 0.f;

	cvInRangeS(clr.image, cvScalar(0, smin, MIN(vmin, 256), 0), cvScalar(180, 256, MAX(vmin, 256), 0), mask);
	cvSplit(clr.image, hue, 0, 0, 0);

	cvCalcHist(&hue, clr.hist, 0, mask);
	cvCalcHist(&hue, clr.hist, 0, mask);

	cvGetMinMaxHistValue(clr.hist, 0, &max_val, 0, 0);

	cvConvertScale(clr.hist->bins, clr.hist->bins, max_val ? 255. / max_val : 0., 0);

	clr.histimg = cvCreateImage(cvSize(320, 200), 8, D);
	cvZero(clr.histimg);

	int bin_w = clr.histimg->width/hdims;

	for(int i=0;i<hdims;i++)
	{
		int val = cvRound(cvGetReal1D(clr.hist->bins, i)*clr.histimg->height/255);
		CvScalar colr = hsv2rgb(i*180.f/hdims);
		cvRectangle(clr.histimg, cvPoint(i*bin_w, clr.histimg->height), cvPoint((i+1)*bin_w, clr.histimg->height - val), colr, -1, 8, 0);
	}

	clr.window = cvRect(W/2, H/2, 30, 30);
	
	cvReleaseImage(&src);
	cvReleaseImage(&hue);
	cvReleaseImage(&mask);

	CvSize imgSize;
	imgSize.width = W;
	imgSize.height = H;
	clr.hsv = cvCreateImage(imgSize, 8, D);
	clr.hue = cvCreateImage(imgSize, 8, 1);
	clr.mask = cvCreateImage(imgSize, 8, 1);
	clr.backproject = cvCreateImage(imgSize, 8, 1);

	m_Colors.push_back(clr);
}

int CImageFunc::FindColor(IplImage* img, string color, SObject& obj, bool exchange, char* str)
{
	SColor clr;
	int index = 0;
	for(int i=0;i<m_Colors.size();i++)
	{
		if(!m_Colors.at(i).name.compare(color))
		{
			clr = m_Colors.at(i);
			index = i;
			break;
		}
	}

	cvCvtColor(img, clr.hsv, CV_RGB2HSV);
	int _vmin = clr.vmin;
	int _vmax = clr.vmax;
	int _smin = clr.smin;
	cvInRangeS(clr.hsv, cvScalar(0, _smin, MIN(_vmin, _vmax), 0), cvScalar(180, 256, MAX(_vmin, _vmax), 0), clr.mask);
	cvSplit(clr.hsv, clr.hue, 0, 0, 0);
	cvCalcBackProject(&clr.hue, clr.backproject, clr.hist);
	cvAnd(clr.backproject, clr.mask, clr.backproject, 0);

	cvErode(clr.backproject, clr.backproject, elementE, 1);
	cvDilate(clr.backproject, clr.backproject, elementD, 1);
	
	Check(clr.window);
	cvCamShift(clr.backproject, clr.window, cvTermCriteria(CV_TERMCRIT_EPS | CV_TERMCRIT_ITER, 10, 1),
		&clr.track_comp, &clr.track_box);
	clr.window = clr.track_comp.rect;

	double xcount = 0;
	double ycount = 0;
	double num = 0;

	if(clr.track_box.size.width < 10)
	{
	  for(int c=0;c<W;c++)
	  {
	  	for(int r=0;r<H;r++)
	  	{
	  		double temp = (double)(clr.backproject->imageData[r*W+c]);
	  		if(fabs(temp) > 0)
				{
	  			xcount = xcount + (double)c;
	  			ycount = ycount + (double)r;
					num++;
	  			//clr.backproject->imageData[r*W+c] = (unsigned char)255;
				}
	  		else
	  		{
	  			//clr.backproject->imageData[r*W+c] = (unsigned char)0;
	  		}
	  	}
		}
		if(num != 0)
		{
			xcount = xcount/num;
		  ycount = ycount/num;
			clr.window.x = (int)xcount;
			clr.window.y = (int)ycount;
			clr.window.width = 10;
			clr.window.height = 10;
		}
	}

	if(exchange)
		cvCvtColor(clr.backproject, img, CV_GRAY2BGR);

	if(!img->origin)
		clr.track_box.angle = -clr.track_box.angle;
	cvEllipseBox(img, clr.track_box, CV_RGB(255,0,0), 3, CV_AA, 0);

	obj.type = COLOR;
	cvSetImageROI(clr.backproject, clr.window);
	obj.size = cvCountNonZero(clr.backproject);
	cvResetImageROI(clr.backproject);

	if(obj.size > 0)
	{
		double sideW = 292.49;
		double sideH = 304.48;

		double xplace = W/2 - clr.track_box.center.x;
		double yplace = H/2 - clr.track_box.center.y;
		CvBox2D tb = clr.track_box;
		tb.size.width = 0;
		tb.size.height = 0;
	  //cvEllipseBox(img, tb, CV_RGB(0,0,255), 3, CV_AA, 0);

		obj.azimuth = atan2(xplace, sideW) * RTD;
		obj.elevation = atan2(yplace, sideH) * RTD;
	}
	else
	{
		obj.azimuth = 0;
		obj.elevation = 0;
	}

	m_Colors.at(index) = clr;

	return (obj.size);
}

void CImageFunc::Check(CvRect& window)
{
	double x = (double)window.x;
	double y = (double)window.y;
	double width = (double)window.width;
	double height = (double)window.height;

	bool error = false;
	if(x + width >= W || x - width <= 0)
	{
		window.width--;
		error = true;
	}
	if(y + height >= H || y - height <= 0)
	{
		window.height--;
		error = true;
	}
	if(window.height < 2)
	{
		window.height = 2;
		if(window.y > 120)
			window.y--;
		else
			window.y++;
	}
	if(window.width < 2)
	{
		window.width = 2;
		if(window.x > 160)
			window.x--;
		else
			window.x++;
	}
	if(error)
		Check(window);

	//cout << window.x << " " << window.y << " " << window.width << " " << window.height << endl;
}

//convert image to hsv (for object detection)
CvScalar CImageFunc::hsv2rgb(float hue)
{
	int rgb[3], p, sector;
	static const int sector_data[][3] = 
			{{0,2,1}, {1,2,0}, {1,0,2}, {2,0,1}, {2,1,0}, {0,1,2}};
	hue *= 0.033333333333333333333333333333333f;
	sector = cvFloor(hue);
	p = cvRound(255*(hue - sector));
	p ^= sector & 1 ? 255 : 0;

	rgb[sector_data[sector][0]] = 255;
	rgb[sector_data[sector][1]] = 0;
	rgb[sector_data[sector][2]] = p;

	return cvScalar(rgb[2], rgb[1], rgb[0], 0);
}
