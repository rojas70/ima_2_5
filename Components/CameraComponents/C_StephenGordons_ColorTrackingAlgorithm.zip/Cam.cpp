#include "Cam.h"

using namespace std;

Camera::Camera()
{
	w = W;
	h = H;
	m_spca = false;
}

Camera::~Camera()
{
  //fd = open(dev, O_RDWR | O_SYNC);
	cout << "CLOSING : " << fd << endl;
	close(fd);
}

int Camera::IncreaseBrightness()
{
	struct video_picture grab_pict;
	struct video_picture gp;
	
	ioctl(fd, VIDIOCGPICT, &gp);
	grab_pict = gp;
	grab_pict.brightness = grab_pict.brightness + 500;

	if(ioctl(fd, VIDIOCSPICT, &grab_pict) < 0)
		cout << "Error setting pict" << endl;
  
	return 1;
}

int Camera::DecreaseBrightness()
{
	struct video_picture grab_pict;
	struct video_picture gp;
	
	ioctl(fd, VIDIOCGPICT, &gp);
	grab_pict = gp;
	grab_pict.brightness = grab_pict.brightness - 500;

	if(ioctl(fd, VIDIOCSPICT, &grab_pict) < 0)
		cout << "Error setting pict" << endl;
  
	return 1;
}

int Camera::OpenCamera(char* dev)
{
  fd = open(dev, O_RDWR | O_SYNC);

	if(fd < 0)
	{
		cout << "Did not open device " << dev << endl;
		return -1;
	}

	if(m_spca)
	{
		struct video_window vwin;
		struct video_picture vpict, vpict2;
		ioctl(fd, VIDIOCGWIN, &vwin);
		ioctl(fd, VIDIOCGPICT, &vpict);
		ioctl(fd, VIDIOCSPICT, &vpict);
		if(vwin.width != W)
		{
			vwin.width = W;
			vwin.height = H;
			ioctl(fd, VIDIOCSWIN, &vwin);
			ioctl(fd, VIDIOCGWIN, &vwin);
			if(vwin.width != W)
				cout << "COULD NOT SET W & H" << endl;
		}
	}
	else
	{
	  struct video_picture grab_pict1;
	  grab_pict1.depth = 16;
  	grab_pict1.palette = VIDEO_PALETTE_YUV422;

  	if(ioctl(fd, VIDIOCSPICT, &grab_pict1) < 0)
  		cout << "Error setting pict1" << endl;

  	//Tvtime...
  	struct v4l2_format imgformat;
  	imgformat.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
  	memset(&(imgformat.fmt.pix), 0, sizeof(struct v4l2_pix_format));
  	imgformat.fmt.pix.width = w;
  	imgformat.fmt.pix.height = h;
  	imgformat.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
  	imgformat.fmt.pix.field = V4L2_FIELD_INTERLACED;
  
  	if(ioctl(fd, VIDIOC_S_FMT, &imgformat) < 0)
  		cout << "Error setting format" << endl;
  
    sleep(1);	
  
  	struct video_picture grab_pict2;
  	struct video_picture gp;
  	
  	ioctl(fd, VIDIOCGPICT, &gp);
  	grab_pict2.depth = 24;
  	grab_pict2.palette = VIDEO_PALETTE_RGB24;
  	//if(dev == 1)
  	if(fd == 1)
  		grab_pict2.brightness = 18000;//20000;
  	else
  		grab_pict2.brightness = 32112;//18000;
  	//grab_pict2.brightness = gp.brightness;//32112;
  	grab_pict2.hue = 32768;
  	grab_pict2.colour = 30000;//32768;
  	grab_pict2.contrast = 32000;//34078;
  	grab_pict2.whiteness = 0;
  
  	if(ioctl(fd, VIDIOCSPICT, &grab_pict2) < 0)
  		cout << "Error setting pict2" << endl;
  }
	return fd;
}

int Camera::OpenCamera(char* dev, int b)
{
  fd = open(dev, O_RDWR | O_SYNC);

	if(fd < 0)
	{
		cout << "Did not open device " << dev << endl;
		return -1;
	}

	//struct video_picture grab_pict1;
	//grab_pict1.depth = 16;
	//grab_pict1.palette = VIDEO_PALETTE_YUV422;

	//if(ioctl(fd, VIDIOCSPICT, &grab_pict1) < 0)
	//	cout << "Error setting pict1" << endl;
	if(m_spca)
	{
		struct video_window vwin;
		struct video_picture vpict, vpict2;
		ioctl(fd, VIDIOCGWIN, &vwin);
		ioctl(fd, VIDIOCGPICT, &vpict);
		ioctl(fd, VIDIOCSPICT, &vpict);
		if(vwin.width != W)
		{
			vwin.width = W;
			vwin.height = H;
			ioctl(fd, VIDIOCSWIN, &vwin);
			ioctl(fd, VIDIOCGWIN, &vwin);
			if(vwin.width != W)
				cout << "COULD NOT SET W & H" << endl;
		}
	}
	else
	{

  	//Tvtime...
  	struct v4l2_format imgformat;
  	imgformat.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
  	memset(&(imgformat.fmt.pix), 0, sizeof(struct v4l2_pix_format));
  	imgformat.fmt.pix.width = w;
  	imgformat.fmt.pix.height = h;
  	imgformat.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
  	imgformat.fmt.pix.field = V4L2_FIELD_INTERLACED;
  
  	if(ioctl(fd, VIDIOC_S_FMT, &imgformat) < 0)
  		cout << "Error setting format" << endl;
  	

    //sleep(1);	

  	struct video_picture grab_pict2;
  	struct video_picture gp;
	
  	ioctl(fd, VIDIOCGPICT, &gp);
  	grab_pict2.depth = 24;
  	grab_pict2.palette = VIDEO_PALETTE_RGB24;
  
  	grab_pict2.brightness = b;

  	grab_pict2.hue = 32768;
  	grab_pict2.colour = 30000;//32768;
  	grab_pict2.contrast = 32000;//34078;
  	grab_pict2.whiteness = 0;

  	if(ioctl(fd, VIDIOCSPICT, &grab_pict2) < 0)
  		cout << "Error setting pict2" << endl;
	}
  
	return fd;
}

int Camera::OpenCamera(int dev)
{
	char device[25];
	if(dev == 0)
	{
		cout << "Opening video0" << endl;
		strcpy(device,"/dev/video0");
		return OpenCamera(device);
	}
	else if(dev == 1)
	{
		cout << "Opening video1" << endl;
		strcpy(device, "/dev/video1");
		return OpenCamera(device);
	}
	else if(dev == 2)
	{
		cout << "Opening video2" << endl;
		strcpy(device, "/dev/video2");
		return OpenCamera(device);
	}
	else if(dev == 3)
	{
		cout << "Opening video3" << endl;
		strcpy(device, "/dev/video3");
		return OpenCamera(device);
	}
	else
	{
		cout << "What device again?" << endl;
		return -1;
	}
	return 0;
}


int Camera::ReadCam(unsigned char buf[W*H*D])
{
	int len = read(fd, buf, W*H*D);

	return len;
}

int Camera::CloseCam()
{
  return close(fd);
}
