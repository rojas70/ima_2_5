#include "cv.h"
#include "highgui.h"
#include "Cam.h"
#include "Img.h"
#include "Stereo.h"
#include "variables_registry.h"

#include <iostream>
#include <pthread.h>

IplImage* frameL = 0;
IplImage* frameR = 0;

bool m_Stereo = false;
bool m_UPbL = false;
bool m_UPbR = false;
bool m_DOWNbL = false;
bool m_DOWNbR = false;
bool m_backProject = false;

int m_ShowImage = -1;
int m_ImageSize = 0;

bool STOP = false;

char host[100] = {"localhost"};
int port = 30000;
variables_registry vr(host, port, false);

using namespace std;

void ReadCams()
{
  Camera camL, camR;
	char camfileL[50] = {"/dev/video0"};
	char camfileR[50] = {"/dev/video1"};

	//camL.OpenCamera(1); //Left Eye
	//camR.OpenCamera(0); //Right Eye
	//camR.m_spca = true;
	//camL.m_spca = true;
	camL.OpenCamera(camfileL, 32000); //Left Eye
	camR.OpenCamera(camfileR, 32000); //Right Eye

	unsigned char bufL[W*H*D];
	unsigned char bufR[W*H*D];

	for(;;)
	{
		if(STOP)
			break;
		if(m_UPbL)
		{
			camL.IncreaseBrightness();
			m_UPbL = false;
		}
		if(m_UPbR)
		{
			camR.IncreaseBrightness();
			m_UPbR = false;
		}
		if(m_DOWNbL)
		{
			camL.DecreaseBrightness();
			m_DOWNbL = false;
		}
		if(m_DOWNbR)
		{
			camR.DecreaseBrightness();
			m_DOWNbR = false;
		}
		int lenL = camL.ReadCam(bufL);
		int lenR = camR.ReadCam(bufR);

		if(lenL < 0)
			cout << "Error reading " << camfileL << endl;
		if(lenR < 0)
			cout << "Error reading " << camfileR << endl;
		if(lenL < 0 && lenR < 0)
			break;

		cvSetImageData(frameL, bufL, W*D);
		cvSetImageData(frameR, bufR, W*D);
	}
	return;
}

void OutputVariables()
{
	vector<string> vars;
	vector<string> vals;
	cout << "VARIABLES : " << endl;
	if(vr.getvars(vars, vals) > 0)
	{
		for(int i=0;i<vars.size();i++)
			cout << "  " << vars.at(i) << " " << vals.at(i) << endl;
	}
}

void SetFocus(char* c1, char* c2)
{
	char* focus[] = {c1, c2};
	vr.set_focus(focus);
}

bool Switch(int w)
{
	if(w == 27)
		return true;
	switch(w)
	{
		case 'i':
			m_UPbR = true;
			break;
		case 'k':
			m_DOWNbR = true;
			break;
		case 'e':
			m_UPbL = true;
			break;
		case 'd':
			m_DOWNbL = true;
			break;
		case 'p':
			OutputVariables();
			break;
		case 'b':
			SetFocus("OBJECT", "purple");
			break;
		case 'f':
			SetFocus("OBJECT", "pink");
			break;
		case 'h':
			SetFocus("PRESET", "HOME");
			break;
		case 't':
			SetFocus("PRESET", "TABLE");
			break;
		case 's':
			if(m_backProject)
				m_backProject = false;
			else
				m_backProject = true;
			break;
		case 'a':
			m_ShowImage++;
			if(m_ShowImage >= m_ImageSize)
				m_ShowImage = -1;
		default:
			break;
	}
	return false;
}

int main(int argc, char* argv[])
{
	IplImage* imageL = 0;
	IplImage* imageR = 0;
	IplImage* showImageL = 0;
	IplImage* showImageR = 0;

	CvSize imgSize;
	imgSize.width = 320;
	imgSize.height = 240;

	frameL = cvCreateImage(imgSize, 8, D);
	frameR = cvCreateImage(imgSize, 8, D);

	imageL = cvCreateImage(imgSize, 8, D);
	imageR = cvCreateImage(imgSize, 8, D);

	showImageL = cvCreateImage(imgSize, 8, D);
	showImageR = cvCreateImage(imgSize, 8, D);

	pthread_t video_t;
	pthread_create(&video_t, NULL, (void *(*) (void *)) ReadCams, NULL);

	sleep(2);

	cvNamedWindow("Left", 1);
	cvNamedWindow("Right", 1);

	vector<string> search_objects;
	search_objects.push_back("purple");
	search_objects.push_back("red");
	search_objects.push_back("green");
	search_objects.push_back("blue");
	search_objects.push_back("car");
	search_objects.push_back("yellow");
	//search_objects.push_back("pink");
	m_ImageSize = search_objects.size();

	CStereo stereo;
	CImageFunc imgF_L;
	CImageFunc imgF_R;

	for(int i=0;i<search_objects.size();i++)
	{
	  imgF_L.LoadColor(search_objects.at(i).data());
	  imgF_R.LoadColor(search_objects.at(i).data());
	}

	double pt[4] = {0, 0, 0, 0};
	vr.set_head(pt);
	
	SetFocus("PRESET", "TABLE");
	char previous_focus[50] = {"TABLE"};
	char focus[2][50];

	for(;;)
	{
		//Get Focus
		vr.get_focus(focus);
		if(strcmp(focus[1], previous_focus))
			sleep(1);
		strcpy(previous_focus, focus[1]);

		//Get Position
		vr.get_head(pt);
		stereo.SetPanTilt(pt);

		cvCopy(frameL, imageL, 0);
		cvCopy(frameR, imageR, 0);

		for(int i=0;i<search_objects.size();i++)
		{
		  SObject objL, objR;
		  objL.cam = LEFT;
		  objR.cam = RIGHT;
			if(m_ShowImage == i)
				m_backProject = true;
			else
				m_backProject = false;

		  int nL = imgF_L.FindColor(imageL, search_objects.at(i).data(), objL, m_backProject, "LEFT");
		  int nR = imgF_R.FindColor(imageR, search_objects.at(i).data(), objR, m_backProject, "RIGHT");

			if(m_ShowImage == i)
			{
				cvCopy(imageL, showImageL, 0);
				cvCopy(imageR, showImageR, 0);
			}

		  SObject objS;
		  if(stereo.DeterminePosition(objL, objR, objS))
	      vr.set_percept((char*)search_objects.at(i).data(), objS.pos);
			else
				vr.delete_percept((char*)search_objects.at(i).data());
		}

		if(m_ShowImage > 0)
		{
			cvShowImage("Left", imageL);
		  cvShowImage("Right", imageR);
		}
		else
		{
			cvShowImage("Left", imageL);
		  cvShowImage("Right", imageR);
		}

		int w = cvWaitKey(10);
		if(Switch(w))
			break;
	}
	STOP = true;
	sleep(2);

	return 1;
}
