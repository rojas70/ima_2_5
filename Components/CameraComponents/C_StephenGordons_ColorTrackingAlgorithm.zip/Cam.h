#ifndef CAMERA_CLASS_H
#define CAMERA_CLASS_H

#include "common.h"

#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/videodev.h>
#include <iostream>

class Camera
{
public:
	Camera();
	~Camera();
	int OpenCamera(int dev);
	int OpenCamera(char* dev);
	int OpenCamera(char* dev, int b);
	int ReadCam(unsigned char buf[W*H*D]);
	int CloseCam();

	int IncreaseBrightness();
	int DecreaseBrightness();
	int fd;
	int w;
	int h;

	bool m_spca;
};
#endif //CAMERA_CLASS_H
