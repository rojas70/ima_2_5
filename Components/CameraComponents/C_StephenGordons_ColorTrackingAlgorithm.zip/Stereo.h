#ifndef STEREO_H
#define STEREO_H

#include "common.h"

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <cmath>
#include <cstring>

class CStereo 
{
public:
	CStereo();
	virtual ~CStereo();

	bool DeterminePosition(SObject o1, SObject o2, SObject& obj);
	void SetPanTilt(double *pt);
	
	double base;

	double leftpan;
	double rightpan;
	double lefttilt;
	double righttilt;
};
#endif //STEREO_H
