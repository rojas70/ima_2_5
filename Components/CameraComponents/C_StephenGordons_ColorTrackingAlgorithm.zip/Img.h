#ifndef IMG_H
#define IMG_H

#include "common.h"

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <cmath>
#include <ctime>
#include <vector>

using namespace std;

struct SColor {
	string name;
	int vmin;
	int vmax;
	int smin;
	IplImage* histimg;
	IplImage* image;
	IplImage* hsv;
	IplImage* mask;
	IplImage* hue;
	IplImage* backproject;
	CvRect window;
	CvBox2D track_box;
	CvConnectedComp track_comp;
	CvHistogram *hist;
};

class CImageFunc 
{
public:
	CImageFunc();
	virtual ~CImageFunc();

	void LoadColor(string color);
	int FindColor(IplImage* img, string color, SObject& obj, bool exchange, char* str);

private:
  CvScalar hsv2rgb(float hue);
	void Check(CvRect& window);
	std::vector<SColor> m_Colors;

	IplConvKernel *elementE, *elementD;
	CvHistogram *m_hist;
};
#endif //IMG_H
