//
//	FILENAME: Default.h
//
//	AUTHOR: Joe Christopher
//
//	DATE: 10 November 1997
//

#ifndef __IMG_CONSTANTS
#define __IMG_CONSTANTS

const long	WIDTH = 640;
const long HEIGHT = 480;
const long DEPTH = 4;
const long LEFT = 0;
const long TOP = 0;
const long SKIPX = 2;
const long SKIPY = 2;
const short CHANNEL = 0;

#endif