#include "Headers\stdafx.h"
#include <windows.h>
#include <windef.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <stdarg.h>
#include <math.h>
#include <IOSTREAM>
#include <sstream>
#include "Headers\winmotenc.h"
#include "Headers\Control.h"
#include "Headers\NNMuscleClass.h"
#include "Headers\MahirKinematics.h"
#include "Headers\PID.h"
#include "Headers\commport.h"
#include "Headers\GripControl.h"

using namespace std;

#define npoints 5
double leftValvesOutputs[12]={0};
double leftValvesInputs[12]={0};
double InitialleftValvesOutputs[12];
long leftEncoders[6]={0};
double leftAngles[6]={0};

double rightValvesOutputs[12]={0};
double rightValvesInputs[12]={0};
double InitialrightValvesOutputs[12];
long rightEncoders[6]={0};
double rightAngles[6]={0};

float desiredangleR[6] ={0.0},desiredangleL[6] ={0.0},desiredtrajectoryL[npoints][6]={0},desiredtrajectoryR[npoints][6]={0};
float prevThetasR[6]={0.0}, prevThetasL[6]={0.0};
int totalstep = 50,sampletime=60;

CNNMuscles LeftNNMusclesAngle0F(1,0,1);CNNMuscles LeftNNMusclesAngle0B(1,0,-1);
CNNMuscles LeftNNMusclesAngle1F(1,1,1);CNNMuscles LeftNNMusclesAngle1B(1,1,-1);
CNNMuscles LeftNNMusclesAngle2F(1,2,1);CNNMuscles LeftNNMusclesAngle2B(1,2,-1);
CNNMuscles LeftNNMusclesAngle3F(1,3,1);CNNMuscles LeftNNMusclesAngle3B(1,3,-1);
CNNMuscles LeftNNMusclesAngle4F(1,4,1);CNNMuscles LeftNNMusclesAngle4B(1,4,-1);
CNNMuscles LeftNNMusclesAngle5F(1,5,1);CNNMuscles LeftNNMusclesAngle5B(1,5,-1);

CNNMuscles RightNNMusclesAngle0F(0,0,1);CNNMuscles RightNNMusclesAngle0B(0,0,-1);
CNNMuscles RightNNMusclesAngle1F(0,1,1);CNNMuscles RightNNMusclesAngle1B(0,1,-1);
CNNMuscles RightNNMusclesAngle2F(0,2,1);CNNMuscles RightNNMusclesAngle2B(0,2,-1);
CNNMuscles RightNNMusclesAngle3F(0,3,1);CNNMuscles RightNNMusclesAngle3B(0,3,-1);
CNNMuscles RightNNMusclesAngle4F(0,4,1);CNNMuscles RightNNMusclesAngle4B(0,4,-1);
CNNMuscles RightNNMusclesAngle5F(0,5,1);CNNMuscles RightNNMusclesAngle5B(0,5,-1);

void LeftNN();void RightNN();
void LeftPID();void RightPID();
void GetPoints(int *,int *);

void main()
{
	double *desPos = (double*)malloc(3*sizeof(double));
	double *prevThetas = (double*)malloc(6*sizeof(double));
	double *thetas = (double*)malloc(6*sizeof(double));
	int usecontrol = 1, useleft =1, useright =1, useLPID =1,useRPID =1, useleftgripper=0,userightgripper=1;
	int count=1,i,j;

	//GripControl gripper;
	// Left Arm Objects
	LeftNNMusclesAngle0F.Allocator();LeftNNMusclesAngle0B.Allocator();
	LeftNNMusclesAngle1F.Allocator();LeftNNMusclesAngle1B.Allocator();
	LeftNNMusclesAngle2F.Allocator();LeftNNMusclesAngle2B.Allocator();
	LeftNNMusclesAngle3F.Allocator();LeftNNMusclesAngle3B.Allocator();
	LeftNNMusclesAngle4F.Allocator();LeftNNMusclesAngle4B.Allocator();
	LeftNNMusclesAngle5F.Allocator();LeftNNMusclesAngle5B.Allocator();

	RightNNMusclesAngle0F.Allocator();RightNNMusclesAngle0B.Allocator();
	RightNNMusclesAngle1F.Allocator();RightNNMusclesAngle1B.Allocator();
	RightNNMusclesAngle2F.Allocator();RightNNMusclesAngle2B.Allocator();
	RightNNMusclesAngle3F.Allocator();RightNNMusclesAngle3B.Allocator();
	RightNNMusclesAngle4F.Allocator();RightNNMusclesAngle4B.Allocator();
	RightNNMusclesAngle5F.Allocator();RightNNMusclesAngle5B.Allocator();

	if (usecontrol)	InitializeCards();
	if (usecontrol && useleft && useright) {InitializeAllValves();Sleep(500);}
	if (usecontrol && useleft && !useright) {InitializeLeftValves();/*if (useleftgripper) gripper.SimpleOpen()*/;Sleep(500);}
	if (usecontrol && useright && !useleft){ InitializeRightValves();if (userightgripper) OpenRightGripper();Sleep(500);}	

	GetPoints(&useleft,&useright);
	
	Sleep(3000);
	
	// Data File Initialization
	FILE *outputdata;
	if((outputdata = fopen(".\\MatlabWork\\MatlabWork.txt","w")) == NULL)
		printf("Can't Open File MatlabWork.txt\n");

	// Homing & Reset Encoders Left
	// if (usecontrol){Sleep(100);/*gripper.SimpleOpen()*/;Sleep(500);}
	if (usecontrol && useleft)  {ResetLeftEncoders();ReadLeftEncoders();RealLeftAngles();}
	if (usecontrol && useright) {ResetRightEncoders();ReadRightEncoders();RealRightAngles();}

	// Assigning the Previous Angles
	if (usecontrol && useleft)
		for(i=1;i<=6;i++)
			prevThetasL[i] = leftAngles[i];

	if (usecontrol && useright)
		for(i=1;i<=6;i++)
			prevThetasR[i] = rightAngles[i];
	
	printf("Control Loop Starts Neural Part!!\n");
	// Neural Networks
	for (i=0;i<npoints;i++)
	{
		for (j=0;j<5;j++)
			desiredangleL[j] = desiredtrajectoryL[i][j];	
		for (j=0;j<5;j++)
			desiredangleR[j] = desiredtrajectoryR[i][j];	
		if (usecontrol && useleft) LeftNN();
		if (i==2 && usecontrol && useleft && useLPID) {LeftPID(); /*if (useleftgripper) gripper.GrabSomething()*/;Sleep(500);}
		if (usecontrol && useright) RightNN();
		if (i==2 && usecontrol && useright && useRPID) {RightPID(); /*if (useleftgripper) gripper.GrabSomething()*/;Sleep(500);} ;
		//if (i==1 && usecontrol && useright && useRPID) {RightPID(); if (userightgripper) CloseRightGripper();Sleep(500);}
	}
				
	Sleep(300);
	/*
	if (usecontrol && (useleft || useright))
		while(!kbhit())
			{
				ReadLeftEncoders();RealLeftAngles();
				if (useleft && useLPID ) LeftPID(); 
				if (useright && useRPID) RightPID();
				Sleep(20);
			}
		*/
	// Closing the Controls
	if (usecontrol)	{CloseValves();Sleep(500);vitalQuit();Sleep(500);}
	fclose(outputdata);
}

void GetPoints(int *left,int *right)
{
	FILE *PFileL,*PFileR;
	float bufferleft[npoints*6+1]={0},bufferright[npoints*6+1]={0};
	int countL=0,i,j,countR=0;

	if((PFileL = fopen("Z://LeftTrajectory.txt","r")) == NULL)
			printf("LeftTrajectory can't open\n");
	
	if((PFileR = fopen("Z://RightTrajectory.txt","r")) == NULL)
			printf("RightTrajectory can't open\n");

	while(!feof(PFileL))
	{
		fscanf(PFileL ,"%f ",&bufferleft[countL]);
		if (bufferleft[countL]==-1000) {*left=0; break;}
		countL++;
	}
	Sleep(100);

	while(!feof(PFileR))
	{
		fscanf(PFileR ,"%f ",&bufferright[countR]);
		if (bufferright[countR]==-1000) {*right=0; break;}
		countR++;
	}

	for(j=0;j<npoints;j++)
		for (int i=0;i<6;i++)
			desiredtrajectoryL[j][i] = bufferleft[j*6+i];
	
	for(j=0;j<npoints;j++)
		for (int i=0;i<6;i++)
			desiredtrajectoryR[j][i] = bufferright[j*6+i];
/*
	for(j=0;j<npoints;j++)
	{
		for ( i=0;i<6;i++)
			printf("%f ",desiredtrajectoryL[j][i]);
		printf("\n");
	}
	fclose(PFileL);fclose(PFileR);
*/
}

void LeftPID()
{
		double LPID0_output=0.0,LPID1_output=0.0,LPID2_output=0.0,LPID3_output=0.0,LPID4_output=0.0,LPID5_output=0.0;
		int count =20;

		while(!kbhit() && count<50)
		{
			ReadLeftEncoders();RealLeftAngles();

			LPID0_output = leftPID0(&desiredangleL[0]);
			LPID1_output = leftPID1(&desiredangleL[1]);
			LPID2_output = leftPID2(&desiredangleL[2]);
			LPID3_output = leftPID3(&desiredangleL[3]);			
			LPID4_output = leftPID4(&desiredangleL[4]);		
			LPID5_output = leftPID5(&desiredangleL[5]);
			
			leftValvesOutputs[0] = leftValvesOutputs[0]-LPID0_output;
			leftValvesOutputs[1] = leftValvesOutputs[1]+LPID0_output;
				
			leftValvesOutputs[2] = leftValvesOutputs[2]+LPID1_output;
			leftValvesOutputs[3] = leftValvesOutputs[3]-LPID1_output;

			leftValvesOutputs[4] = leftValvesOutputs[4]+LPID2_output;
			leftValvesOutputs[5] = leftValvesOutputs[5]-LPID2_output;
			leftValvesOutputs[6] = leftValvesOutputs[6]-LPID2_output;
			leftValvesOutputs[7] = leftValvesOutputs[7]+LPID2_output;

			leftValvesOutputs[4] = leftValvesOutputs[4]+LPID3_output;
			leftValvesOutputs[5] = leftValvesOutputs[5]+LPID3_output;
			leftValvesOutputs[6] = leftValvesOutputs[6]-LPID3_output;
			leftValvesOutputs[7] = leftValvesOutputs[7]-LPID3_output;

			leftValvesOutputs[8] = leftValvesOutputs[8]+LPID4_output;
			leftValvesOutputs[9] = leftValvesOutputs[9]-LPID4_output;
			leftValvesOutputs[10] = leftValvesOutputs[10]+LPID4_output;
			leftValvesOutputs[11] = leftValvesOutputs[11]-LPID4_output;

			leftValvesOutputs[8] = leftValvesOutputs[8]-LPID5_output;
			leftValvesOutputs[9] = leftValvesOutputs[9]-LPID5_output;
			leftValvesOutputs[10] = leftValvesOutputs[10]+LPID5_output;
			leftValvesOutputs[11] = leftValvesOutputs[11]+LPID5_output;

			SetLeftArmPressures();Sleep(20);count++;
		}
}

void RightPID()
{
	double RPID0_output=0.0,RPID1_output=0.0,RPID2_output=0.0,RPID3_output=0.0,RPID4_output=0.0,RPID5_output=0.0;
	int count=20;

	while(!kbhit() && count<50)
	{
		ReadRightEncoders();RealRightAngles();

		RPID0_output = rightPID0(&desiredangleR[0]);
		RPID1_output = rightPID1(&desiredangleR[1]);
		RPID2_output = rightPID2(&desiredangleR[2]);
		RPID3_output = rightPID3(&desiredangleR[3]);			
		RPID4_output = rightPID4(&desiredangleR[4]);		
		RPID5_output = rightPID5(&desiredangleR[5]);
		
		rightValvesOutputs[0] = rightValvesOutputs[0]-RPID0_output;
		rightValvesOutputs[1] = rightValvesOutputs[1]+RPID0_output;
			
		rightValvesOutputs[2] = rightValvesOutputs[2]+RPID1_output;
		rightValvesOutputs[3] = rightValvesOutputs[3]-RPID1_output;

		rightValvesOutputs[4] = rightValvesOutputs[4]+RPID2_output;
		rightValvesOutputs[5] = rightValvesOutputs[5]-RPID2_output;
		rightValvesOutputs[6] = rightValvesOutputs[6]-RPID2_output;
		rightValvesOutputs[7] = rightValvesOutputs[7]+RPID2_output;

		rightValvesOutputs[4] = rightValvesOutputs[4]+RPID3_output;
		rightValvesOutputs[5] = rightValvesOutputs[5]+RPID3_output;
		rightValvesOutputs[6] = rightValvesOutputs[6]-RPID3_output;
		rightValvesOutputs[7] = rightValvesOutputs[7]-RPID3_output;

		rightValvesOutputs[8] = rightValvesOutputs[8]+RPID4_output;
		rightValvesOutputs[9] = rightValvesOutputs[9]-RPID4_output;
		rightValvesOutputs[10] = rightValvesOutputs[10]+RPID4_output;
		rightValvesOutputs[11] = rightValvesOutputs[11]-RPID4_output;

		rightValvesOutputs[8] = rightValvesOutputs[8]-RPID5_output;
		rightValvesOutputs[9] = rightValvesOutputs[9]-RPID5_output;
		rightValvesOutputs[10] = rightValvesOutputs[10]+RPID5_output;
		rightValvesOutputs[11] = rightValvesOutputs[11]+RPID5_output;

		SetRightArmPressures();Sleep(20);count++;
	}
}

void LeftNN()
{
	float incrementalVoltage0 = 0.0, incrementalVoltage1 = 0.0,incrementalVoltage2 = 0.0,incrementalVoltage3 = 0.0,incrementalVoltage4 = 0.0, incrementalVoltage5 = 0.0;
	double incL0=0,incL1=0,incL2=0,incL3=0,incL4=0,incL5=0;
	int count=1;

	// Precise Sampling Time Initialization		
	LARGE_INTEGER ticksPerSecond,start_ticks, end_ticks, cputime,tick;
	if (!QueryPerformanceFrequency(&ticksPerSecond))
		if (!QueryPerformanceCounter(&tick) ) 
			printf("no go counter not installed");

	incL0 = (desiredangleL[0] - prevThetasL[0])/ totalstep	;
	incL1 = (desiredangleL[1] - prevThetasL[1])/ totalstep	;
	incL2 = (desiredangleL[2] - prevThetasL[2])/ totalstep	;
	incL3 = (desiredangleL[3] - prevThetasL[3])/ totalstep	;
	incL4 = (desiredangleL[4] - prevThetasL[4])/ totalstep	;
	incL5 = (desiredangleL[5] - prevThetasL[5])/ totalstep	;

	while(count<=totalstep && !kbhit())
	{
		QueryPerformanceCounter(&start_ticks);

		desiredangleL[0] =prevThetasL[0] + count * incL0;
		desiredangleL[1] =prevThetasL[1] + count * incL1;
		desiredangleL[2] =prevThetasL[2] + count * incL2;
		desiredangleL[3] =prevThetasL[3] + count * incL3;
		desiredangleL[4] =prevThetasL[4] + count * incL4;
		desiredangleL[5] =prevThetasL[5] + count * incL5;
		
		// Left Arm
		//ANGLE 0
		if( prevThetasL[0] > desiredangleL[0] )
			LeftNNMusclesAngle0B.Process(&desiredangleL[0],&incrementalVoltage0);
		else if( prevThetasL[0] < desiredangleL[0] )
			LeftNNMusclesAngle0F.Process(&desiredangleL[0],&incrementalVoltage0);
		leftValvesOutputs[0] = InitialleftValvesOutputs[0] - incrementalVoltage0;
		leftValvesOutputs[1] = InitialleftValvesOutputs[1] + incrementalVoltage0;
		
		//ANGLE 1
		if( prevThetasL[1] < desiredangleL[1] )
			LeftNNMusclesAngle1F.Process(&desiredangleL[1],&incrementalVoltage1);
		else if( prevThetasL[1] > desiredangleL[1] )
			LeftNNMusclesAngle1B.Process(&desiredangleL[1],&incrementalVoltage1);
		leftValvesOutputs[2] = InitialleftValvesOutputs[2]+incrementalVoltage1;
		leftValvesOutputs[3] = InitialleftValvesOutputs[3]-incrementalVoltage1;

		//ANGLE 2
		if( prevThetasL[2] > desiredangleL[2] )
				LeftNNMusclesAngle2B.Process(&desiredangleL[2],&incrementalVoltage2);
		else if( prevThetasL[2] < desiredangleL[2] )
				LeftNNMusclesAngle2F.Process(&desiredangleL[2],&incrementalVoltage2);
		//ANGLE 3
		if( prevThetasL[3] > desiredangleL[3] )
				LeftNNMusclesAngle3B.Process(&desiredangleL[3],&incrementalVoltage3);
		else if( prevThetasL[3] < desiredangleL[3] )
				LeftNNMusclesAngle3F.Process(&desiredangleL[3],&incrementalVoltage3);
		leftValvesOutputs[4] = InitialleftValvesOutputs[4] + incrementalVoltage2 - incrementalVoltage3;
		leftValvesOutputs[5] = InitialleftValvesOutputs[5] - incrementalVoltage2 - incrementalVoltage3;			
		leftValvesOutputs[6] = InitialleftValvesOutputs[6] - incrementalVoltage2 + incrementalVoltage3;
		leftValvesOutputs[7] = InitialleftValvesOutputs[7] + incrementalVoltage2 + incrementalVoltage3;

		//ANGLE 4
		if( prevThetasL[4] >  desiredangleL[4] )
			LeftNNMusclesAngle4B.Process(& desiredangleL[4],&incrementalVoltage4);
		else if( prevThetasL[4] <  desiredangleL[4] )
			LeftNNMusclesAngle4F.Process(& desiredangleL[4],&incrementalVoltage4);
		//ANGLE  5
		if( prevThetasL[5] > desiredangleL[5] )
			LeftNNMusclesAngle5B.Process(&desiredangleL[5],&incrementalVoltage5);
		else if( prevThetasL[5] < desiredangleL[5] )
			LeftNNMusclesAngle5F.Process(&desiredangleL[5],&incrementalVoltage5);
		leftValvesOutputs[8] = InitialleftValvesOutputs[8] - incrementalVoltage4 - incrementalVoltage5 ;
		leftValvesOutputs[9] = InitialleftValvesOutputs[9] + incrementalVoltage4 + incrementalVoltage5;
		leftValvesOutputs[10]= InitialleftValvesOutputs[10] - incrementalVoltage4 + incrementalVoltage5;
		leftValvesOutputs[11]= InitialleftValvesOutputs[11] + incrementalVoltage4 - incrementalVoltage5;

		SetLeftArmPressures();

		QueryPerformanceCounter(&end_ticks); //printf("time pass:%f\n",(float)(end_ticks.QuadPart-start_ticks.QuadPart)/ticksPerSecond.QuadPart*1000);		
		while(((float)(end_ticks.QuadPart-start_ticks.QuadPart)/ticksPerSecond.QuadPart*1000) < (float) sampletime)
			QueryPerformanceCounter(&end_ticks); cputime.QuadPart = end_ticks.QuadPart- start_ticks.QuadPart;	
		count++;
	}
	Sleep(200);
	// Reading the Angles
	ReadLeftEncoders();RealLeftAngles();

	// Assigning the Previous Angles
	for(int i=0;i<6;i++)
		prevThetasL[i] = leftAngles[i];
}

void RightNN()
{
	float incrementalVoltage0 = 0.0, incrementalVoltage1 = 0.0,incrementalVoltage2 = 0.0,incrementalVoltage3 = 0.0,incrementalVoltage4 = 0.0, incrementalVoltage5 = 0.0;
	double incR0=0,incR1=0,incR2=0,incR3=0,incR4=0,incR5=0;
	int count=1;

	// Precise Sampling Time Initialization		
	LARGE_INTEGER ticksPerSecond,start_ticks, end_ticks, cputime,tick;
	if (!QueryPerformanceFrequency(&ticksPerSecond))
		if (!QueryPerformanceCounter(&tick) ) 
			printf("no go counter not installed");

	incR0 = (desiredangleR[0] - prevThetasR[0])/ totalstep	;
	incR1 = (desiredangleR[1] - prevThetasR[1])/ totalstep	;
	incR2 = (desiredangleR[2] - prevThetasR[2])/ totalstep	;
	incR3 = (desiredangleR[3] - prevThetasR[3])/ totalstep	;
	incR4 = (desiredangleR[4] - prevThetasR[4])/ totalstep	;
	incR5 = (desiredangleR[5] - prevThetasR[5])/ totalstep	;

	// Right Arm 
	while(count<=totalstep && !kbhit())
	{
		QueryPerformanceCounter(&start_ticks);
		
		desiredangleR[0] =prevThetasR[0] + count * incR0;
		desiredangleR[1] =prevThetasR[1] + count * incR1;
		desiredangleR[2] =prevThetasR[2] + count * incR2;
		desiredangleR[3] =prevThetasR[3] + count * incR3;
		desiredangleR[4] =prevThetasR[4] + count * incR4;
		desiredangleR[5] =prevThetasR[5] + count * incR5;

		//ANGLE 0
		if( prevThetasR[0] > desiredangleR[0] )
			RightNNMusclesAngle0B.Process(&desiredangleR[0],&incrementalVoltage0);
		else if( prevThetasR[0] < desiredangleR[0])
			RightNNMusclesAngle0F.Process(&desiredangleR[0],&incrementalVoltage0);
		rightValvesOutputs[0] = InitialrightValvesOutputs[0] - incrementalVoltage0;
		rightValvesOutputs[1] = InitialrightValvesOutputs[1] + incrementalVoltage0;

		//ANGLE 1
		if( prevThetasR[1] < desiredangleR[1] )
			RightNNMusclesAngle1F.Process(&desiredangleR[1],&incrementalVoltage1);
		else if( prevThetasR[1] > desiredangleR[1])
			RightNNMusclesAngle1B.Process(&desiredangleR[1],&incrementalVoltage1);
		rightValvesOutputs[2] = InitialrightValvesOutputs[2]+incrementalVoltage1;
		rightValvesOutputs[3] = InitialrightValvesOutputs[3]-incrementalVoltage1;

		//ANGLE 2
		if( prevThetasR[2] > desiredangleR[2] )
			RightNNMusclesAngle2B.Process(&desiredangleR[2],&incrementalVoltage2);
		else if( prevThetasR[2] < desiredangleR[2] )
			RightNNMusclesAngle2F.Process(&desiredangleR[2],&incrementalVoltage2);
		//ANGLE 3
		if( prevThetasR[3] > desiredangleR[3])
			RightNNMusclesAngle3B.Process(&desiredangleR[3],&incrementalVoltage3);
		else if( prevThetasR[3] < desiredangleR[3])
			RightNNMusclesAngle3F.Process(&desiredangleR[3],&incrementalVoltage3);
		rightValvesOutputs[4] = InitialrightValvesOutputs[4] + incrementalVoltage2 - incrementalVoltage3;
		rightValvesOutputs[5] = InitialrightValvesOutputs[5] - incrementalVoltage2 - incrementalVoltage3;			
		rightValvesOutputs[6] = InitialrightValvesOutputs[6] - incrementalVoltage2 + incrementalVoltage3;
		rightValvesOutputs[7] = InitialrightValvesOutputs[7] + incrementalVoltage2 + incrementalVoltage3;

		//ANGLE 4
		if( prevThetasR[4] > desiredangleR[4] )
			RightNNMusclesAngle4B.Process(&desiredangleR[4],&incrementalVoltage4);
		else if( prevThetasR[4] < desiredangleR[4] )
			RightNNMusclesAngle4F.Process(&desiredangleR[4],&incrementalVoltage4);
		//ANGLE  5
		if( prevThetasR[5] > desiredangleR[5] )
			RightNNMusclesAngle5B.Process(&desiredangleR[5],&incrementalVoltage5);
		else if( prevThetasR[5] < desiredangleR[5] )
			RightNNMusclesAngle5F.Process(&desiredangleR[5],&incrementalVoltage5);
		rightValvesOutputs[8] = InitialrightValvesOutputs[8] - incrementalVoltage4 - incrementalVoltage5 ;
		rightValvesOutputs[9] = InitialrightValvesOutputs[9] + incrementalVoltage4 + incrementalVoltage5;
		rightValvesOutputs[10]= InitialrightValvesOutputs[10] - incrementalVoltage4 + incrementalVoltage5;
		rightValvesOutputs[11]= InitialrightValvesOutputs[11] + incrementalVoltage4 - incrementalVoltage5;

		SetRightArmPressures();

		QueryPerformanceCounter(&end_ticks); //printf("time pass:%f\n",(float)(end_ticks.QuadPart-start_ticks.QuadPart)/ticksPerSecond.QuadPart*1000);		
		while(((float)(end_ticks.QuadPart-start_ticks.QuadPart)/ticksPerSecond.QuadPart*1000) < (float) sampletime)
			QueryPerformanceCounter(&end_ticks); cputime.QuadPart = end_ticks.QuadPart- start_ticks.QuadPart;	
		count++;
	}
	
	// Reading the Angles
	ReadRightEncoders();RealRightAngles();

	// Assigning the Previous Angles
	for(int i=0;i<6;i++)
		prevThetasR[i] = rightAngles[i];
}
