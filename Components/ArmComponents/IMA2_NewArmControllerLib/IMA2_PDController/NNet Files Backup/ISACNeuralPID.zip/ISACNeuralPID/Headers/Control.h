#ifndef _Control_h
#define _Control_h

#include "stdafx.h"
#include <windows.h>
#include <windef.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <math.h>
#include <IOSTREAM>
#include "winmotenc.h"

extern double leftValvesOutputs[12];
extern double InitialleftValvesOutputs[12];
extern double leftValvesInputs[12];
extern long leftEncoders[6];
extern double leftAngles[6];

extern double rightValvesOutputs[12];
extern double InitialrightValvesOutputs[12];
extern double rightValvesInputs[12];
extern long rightEncoders[6];
extern double rightAngles[6];

void InitializeAllValves()
{
	printf("Initializing Both Arm!!\n");
	double bufferVoltage=0.1;
	int i=0,j=0,k=0;

	leftValvesOutputs[0]=2.3;
	leftValvesOutputs[1]=1.7;
	leftValvesOutputs[2]=2.0;
	leftValvesOutputs[3]=2.0;
	leftValvesOutputs[4] =0.0;
	leftValvesOutputs[5] =2.2;
	leftValvesOutputs[6] =2.4;
	leftValvesOutputs[7] =0.0;
	leftValvesOutputs[8]  =2.3;
	leftValvesOutputs[9]  =1.7;
	leftValvesOutputs[10] =1.7;
	leftValvesOutputs[11] =2.3;

	rightValvesOutputs[0]=2.1;
	rightValvesOutputs[1]=1.9;
	rightValvesOutputs[2]=2.2;
	rightValvesOutputs[3]=1.8;
	rightValvesOutputs[4] =0.0;
	rightValvesOutputs[5] =2.2;
	rightValvesOutputs[6] =2.1;
	rightValvesOutputs[7] =0.0;
	rightValvesOutputs[8]  =2.0;
	rightValvesOutputs[9]  =2.0;
	rightValvesOutputs[10] =2.0;
	rightValvesOutputs[11] =2.0;

	for(i=0;i<25;i++) // 25x100 ms = 2.5 sec makes the muscles blow up
	{
		vitalSelectBoard(0);
		if(bufferVoltage <= leftValvesOutputs[1] + 0.05)
				vitalDacWrite(1, bufferVoltage);
		if(bufferVoltage <= leftValvesOutputs[2] + 0.05)
				vitalDacWrite(2, bufferVoltage);
		bufferVoltage +=0.1; // Increasing the ref voltage slowly not to harm 
		Sleep(100); // Wait 100 ms at each step	
		vitalSelectBoard(1);
		if(bufferVoltage <= rightValvesOutputs[0] + 0.05)
				vitalDacWrite(4, bufferVoltage);
		if(bufferVoltage <= rightValvesOutputs[2] + 0.05)
				vitalDacWrite(6, bufferVoltage);
		bufferVoltage +=0.1; // Increasing the ref voltage slowly not to harm 
		Sleep(100); // Wait 100 ms at each step		
	}
	Sleep(200);
	bufferVoltage =0.1;
	for(i=0;i<25;i++) // 25x100 ms = 2.5 sec makes the muscles blow up
	{	
		vitalSelectBoard(0);
		for(j=0;j<8;j++) // giving reference to each channel of board 0
		{	
			if(j==0)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j, bufferVoltage);}
			//if (j==1)
			//	if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
			//		vitalDacWrite(j, bufferVoltage);}
			//if (j==2)
			//	if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
			//		vitalDacWrite(j, bufferVoltage);}
			if (j==3)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j, bufferVoltage);}
			if (j==4)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j, bufferVoltage);}
			if (j==5)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j, bufferVoltage);}
			if (j==6)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j, bufferVoltage);}
			if (j==7)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j, bufferVoltage);}
		}
		vitalSelectBoard(1);
		for(j=8;j<12;j++) // giving reference to each channel of board 0
		{	
			if (j==8)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j-8, bufferVoltage);}
			if (j==9)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j-8, bufferVoltage);}
			if (j==10)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j-8, bufferVoltage);}
			if (j==11)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j-8, bufferVoltage);}
		}
		// Right Arm
		vitalSelectBoard(1);
		for(j=0;j<4;j++) // giving reference to each channel of board 0
		{	
			//if (j==0)
			//	if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
			//		vitalDacWrite(j+4, bufferVoltage);}
			if (j==1)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j+4, bufferVoltage);}
			//if (j==2)
			//	if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
			//		vitalDacWrite(j+4, bufferVoltage);}
			if (j==3)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j+4, bufferVoltage);}
		}
		vitalSelectBoard(2);
		for(j=4;j<12;j++) // giving reference to each channel of board 0
		{	
			if(j==4)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==5)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==6)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==7)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==8)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==9)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==10)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==11)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
		}
		bufferVoltage +=0.1; // Increasing the ref voltage slowly not to harm 
		Sleep(100); // Wait 100 ms at each step		
	}

	for(int s=0;s<12;s++)
	{
		InitialleftValvesOutputs[s] = leftValvesOutputs[s];
		InitialrightValvesOutputs[s] = rightValvesOutputs[s];
	}

}

void InitializeLeftValves()
{
	printf("Initializing Left Arm!!\n");
	double bufferVoltage=0.1;
	int i=0,j=0,k=0;

	leftValvesOutputs[0]=2.3;
	leftValvesOutputs[1]=1.7;
	leftValvesOutputs[2]=2.0;
	leftValvesOutputs[3]=2.0;
	leftValvesOutputs[4] =0.0;
	leftValvesOutputs[5] =2.2;
	leftValvesOutputs[6] =2.4;
	leftValvesOutputs[7] =0.0;
	leftValvesOutputs[8]  =2.3;
	leftValvesOutputs[9]  =1.7;
	leftValvesOutputs[10] =1.7;
	leftValvesOutputs[11] =2.3;

	for(i=0;i<25;i++) // 25x100 ms = 2.5 sec makes the muscles blow up
	{
		vitalSelectBoard(0);
		if(bufferVoltage <= leftValvesOutputs[1] + 0.05)
				vitalDacWrite(1, bufferVoltage);
		if(bufferVoltage <= leftValvesOutputs[2] + 0.05)
				vitalDacWrite(2, bufferVoltage);
		bufferVoltage +=0.1; // Increasing the ref voltage slowly not to harm 
		Sleep(100); // Wait 100 ms at each step		
	}
	Sleep(200);
	bufferVoltage=0.1;

	for(i=0;i<25;i++) // 25x100 ms = 2.5 sec makes the muscles blow up
	{	
		vitalSelectBoard(0);
		for(j=0;j<8;j++) // giving reference to each channel of board 0
		{	
			if(j==0)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j, bufferVoltage);}
			//if (j==1)
			//	if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
			//		vitalDacWrite(j, bufferVoltage);}
			//if (j==2)
			//	if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
			//		vitalDacWrite(j, bufferVoltage);}
			if (j==3)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j, bufferVoltage);}
			if (j==4)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j, bufferVoltage);}
			if (j==5)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j, bufferVoltage);}
			if (j==6)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j, bufferVoltage);}
			if (j==7)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j, bufferVoltage);}
		}
		vitalSelectBoard(1);
		for(j=8;j<12;j++) // giving reference to each channel of board 0
		{	
			if (j==8)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j-8, bufferVoltage);}
			if (j==9)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j-8, bufferVoltage);}
			if (j==10)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j-8, bufferVoltage);}
			if (j==11)
				if(bufferVoltage <= leftValvesOutputs[j] + 0.05){
					vitalDacWrite(j-8, bufferVoltage);}
		}
		bufferVoltage +=0.1; // Increasing the ref voltage slowly not to harm 
		Sleep(100); // Wait 100 ms at each step		
	}
	for(int s=0;s<12;s++)
		InitialleftValvesOutputs[s] = leftValvesOutputs[s];

	vitalSelectBoard(0);
}

void InitializeRightValves()
{
	printf("Initializing Right Arm!!\n");
	double bufferVoltage=0.1;
	int i=0,j=0,k=0;

	rightValvesOutputs[0]=2.1;//2.2
	rightValvesOutputs[1]=1.9;//1.8
	rightValvesOutputs[2]=2.2;
	rightValvesOutputs[3]=1.8;
	rightValvesOutputs[4] =0.0;
	rightValvesOutputs[5] =2.2;//2.1
	rightValvesOutputs[6] =2.1;//1.9
	rightValvesOutputs[7] =0.0;
	rightValvesOutputs[8]  =2.0;
	rightValvesOutputs[9]  =2.0;
	rightValvesOutputs[10] =2.0;
	rightValvesOutputs[11] =2.0;

	for(i=0;i<25;i++) // 25x100 ms = 2.5 sec makes the muscles blow up
	{
		vitalSelectBoard(1);
		if(bufferVoltage <= rightValvesOutputs[0] + 0.05)
				vitalDacWrite(4, bufferVoltage);
		if(bufferVoltage <= rightValvesOutputs[2] + 0.05)
				vitalDacWrite(6, bufferVoltage);
		bufferVoltage +=0.1; // Increasing the ref voltage slowly not to harm 
		Sleep(100); // Wait 100 ms at each step		
	}
	Sleep(200);
	bufferVoltage=0.1;	
	for(i=0;i<25;i++) // 25x100 ms = 2.5 sec makes the muscles blow up
	{	
		vitalSelectBoard(1);
		for(j=0;j<4;j++) // giving reference to each channel of board 0
		{	
			//if (j==0)
			//	if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
			//		vitalDacWrite(j+4, bufferVoltage);}
			if (j==1)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j+4, bufferVoltage);}
			//if (j==2)
			//	if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
			//		vitalDacWrite(j+4, bufferVoltage);}
			if (j==3)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j+4, bufferVoltage);}
		}
		vitalSelectBoard(2);
		for(j=4;j<12;j++) // giving reference to each channel of board 0
		{	
			if(j==4)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==5)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==6)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==7)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==8)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==9)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==10)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
			if (j==11)
				if(bufferVoltage <= rightValvesOutputs[j] + 0.05){
					vitalDacWrite(j-4, bufferVoltage);}
		}

		bufferVoltage +=0.1; // Increasing the ref voltage slowly not to harm 
		Sleep(100); // Wait 100 ms at each step		
	}
	for(int s=0;s<12;s++)
		InitialrightValvesOutputs[s] = rightValvesOutputs[s];

	vitalSelectBoard(1);
}

void SetLeftArmPressures()
{
	int channel=0;

	vitalSelectBoard(0);
	for(channel=0;channel<8;channel++) // giving reference to each channel of board 0
	{
		if (leftValvesOutputs[channel] < 0.0 ){
			//
			printf("negative pressure!\n");
			leftValvesOutputs[channel] = 0.0;
		}
		if (leftValvesOutputs[channel] > 3.6 )
		{
			leftValvesOutputs[channel] = 3.6;
			printf("Too Maiac Pressure!!\n");
		}
		vitalDacWrite( channel, leftValvesOutputs[channel] );
	}
	vitalSelectBoard(1);
	for(channel=0;channel<4;channel++) // giving reference to first 4 channel of board 1
	{
		if (leftValvesOutputs[channel+8] < 0.0 ){
			//printf("negative pressure!\n");
			leftValvesOutputs[channel+8] = 0.0;
		}
		if (leftValvesOutputs[channel+8] > 3.6 )
		{
			leftValvesOutputs[channel+8] = 3.6;
			printf("Too Maiac Pressure!!\n");
		}

		vitalDacWrite( channel, leftValvesOutputs[channel+8] );
	}
}

void SetRightArmPressures()
{
	int channel=0;

	vitalSelectBoard(1);
	for(channel=4;channel<8;channel++) // giving reference to each channel of board 0
	{
		if (rightValvesOutputs[channel-4] < 0.0 ){
			//printf("negative pressure!\n");
			rightValvesOutputs[channel-4] = 0.0;
		}
		if (rightValvesOutputs[channel-4] > 3.6 )
		{
			rightValvesOutputs[channel-4] = 3.6;
			printf("Too Maiac Pressure!!\n");
		}
		vitalDacWrite( channel, rightValvesOutputs[channel-4] );
	}
	vitalSelectBoard(2);
	for(channel=0;channel<8;channel++) // giving reference to first 4 channel of board 1
	{
		if (rightValvesOutputs[channel+4] < 0.0 ){
			//printf("negative pressure!\n");
			rightValvesOutputs[channel+4] = 0.0;
		}
		if (rightValvesOutputs[channel+4] > 3.6 )
		{
			rightValvesOutputs[channel+4] = 3.6;
			printf("Too Maiac Pressure!!\n");
		}
		if ( channel!=0 && channel!=3) // Not using the triceps
			vitalDacWrite( channel, rightValvesOutputs[channel+4] );
	}
}

void CloseValves()
{
	double bufferVoltage=0.1;
	int i=0,j=0,k=0;

	printf("Closing Valves!!\n");

	for(i=0;i<36;i++) // 36x100 ms = 3.6 sec makes the muscles blow up
	{		
		// For the Left Arm
		vitalSelectBoard(0);
		for(j=0;j<8;j++) // giving reference to each channel of board 0
		{
			if( leftValvesOutputs[j]-bufferVoltage >0 )
				vitalDacWrite( j, leftValvesOutputs[j]-bufferVoltage);
		}
		vitalSelectBoard(1);
		for(j=0;j<4;j++) // giving reference to first 4 channel of board 1
		{
			if( leftValvesOutputs[j+8]-bufferVoltage >0 )
				vitalDacWrite( j, leftValvesOutputs[j+8]-bufferVoltage);	
		}
		// For the Right Arm
		for(j=4;j<8;j++) // giving reference to first 4 channel of board 1
		{
			if( rightValvesOutputs[j-4]-bufferVoltage >0 )
				vitalDacWrite( j, rightValvesOutputs[j-4]-bufferVoltage );
		}
		vitalSelectBoard(2);
		for(j=0;j<8;j++) // giving reference to first 4 channel of board 1
		{
			if( rightValvesOutputs[j+4]-bufferVoltage >0 )
				vitalDacWrite( j, rightValvesOutputs[j+4]-bufferVoltage );
		}
		Sleep(200); // Wait 100 ms at each step
		bufferVoltage += 0.1;
	}
}

void ReadLeftEncoders()
{
	//Read Encoder Values
	vitalSelectBoard(0);
	for(int channel=0;channel<4;channel++)
		vitalEncoderRead(channel, &leftEncoders[channel]);
	vitalSelectBoard(1);
	for(channel=0;channel<2;channel++)
		vitalEncoderRead(channel, &leftEncoders[channel+4]);

	leftEncoders[2]*=-1;
	leftEncoders[5]*=-1;

	//printf("Enc1: %d Enc2: %d Enc3: %d Enc4: %d Enc5: %d Enc6: %d\n",leftEncoders[0],leftEncoders[1],leftEncoders[2],leftEncoders[3],leftEncoders[4],leftEncoders[5]);
}

void ReadRightEncoders()
{
	//Read Encoder Values
	vitalSelectBoard(1);
	//!!!First two encoders are flipped!!! (The readings show that)
	vitalEncoderRead(2, &rightEncoders[1]);
	vitalEncoderRead(3, &rightEncoders[0]);

	vitalSelectBoard(2);
	// This part is changed in Sean master
	//for(int channel=0;channel<4;channel++)
	//	vitalEncoderRead(channel, &rightEncoders[channel+2]);
	vitalEncoderRead(0, &rightEncoders[2]);
	vitalEncoderRead(1, &rightEncoders[3]);
	vitalEncoderRead(2, &rightEncoders[4]);
	vitalEncoderRead(3, &rightEncoders[5]);

	rightEncoders[1]*=-1;
	rightEncoders[2]*=-1;

	printf("Enc1: %d Enc2: %d Enc3: %d Enc4: %d Enc5: %d Enc6: %d\n",rightEncoders[0],rightEncoders[1],rightEncoders[2],rightEncoders[3],rightEncoders[4],rightEncoders[5]);
}

void ResetLeftEncoders()
{
	vitalSelectBoard(0);
	for(int channel=0;channel<4;channel++)
		vitalResetCounter(channel);
	vitalSelectBoard(1);
	for(channel=0;channel<2;channel++)
		vitalResetCounter(channel);
}

void ResetRightEncoders()
{
	vitalSelectBoard(1);
	for(int channel=2;channel<4;channel++)
		vitalResetCounter(channel);
	vitalSelectBoard(2);
	for(channel=0;channel<4;channel++)
		vitalResetCounter(channel);
}

void RealLeftAngles()
{
	//Encoder Parameters =  -5092 5092 -4244 4244 636.6 -636.6
	leftAngles[0] =  (double) leftEncoders[0] / -5092.0 /6.28 * 360;
	leftAngles[1] =  (double) -1*leftEncoders[1] / 5092.0 /6.28 * 360 + 90;
	leftAngles[2] =  ((double) leftEncoders[3] / -4244.0 /2 /6.28 * 360 - (double) leftEncoders[2] / 4244 /2 /6.28 * 360) -180 ;
	leftAngles[3] =  ((double) -leftEncoders[3] / - 4244.0 /6.28 * 360 - (double) leftEncoders[2] /  4244 /6.28 * 360 ) ;
	leftAngles[4] =  ((double) -leftEncoders[4] / 636.6 /2 /6.28 * 360 - (double) leftEncoders[5] / 636.6 /2 /6.28 * 360);
	leftAngles[5] =  ((double) leftEncoders[4] / - 636.6 /6.28 * 360 + (double) leftEncoders[5] / 636.6 /6.28 * 360);

	printf("ang0: %.2f ang1: %.2f ang2: %.2f ang3: %.2f ang4: %.2f ang5: %.2f\n",leftAngles[0],leftAngles[1],leftAngles[2],leftAngles[3],leftAngles[4],leftAngles[5]);
}

void RealRightAngles()
{
	//Encoder Parameters =  -5092 5092 -4244 4244 636.6 -636.6
	rightAngles[0] =  (double) rightEncoders[0] / -5092.0 /6.28 * 360;
	rightAngles[1] =  (double) -1*rightEncoders[1] / 5092.0 /6.28 * 360 + 90;
	rightAngles[2] =  ((double) -rightEncoders[3] / -4244.0 /2 /6.28 * 360 + (double) rightEncoders[2] / 4244 /2 /6.28 * 360) -180 ;
	rightAngles[3] =  ((double) -rightEncoders[3] / - 4244.0 /6.28 * 360 - (double) rightEncoders[2] /  4244 /6.28 * 360 ) ;
	rightAngles[5]=  ((double) -rightEncoders[4] / 636.6 /2 /6.28 * 360 - (double) rightEncoders[5] / 636.6 /2 /6.28 * 360);
	// Opposite of Left Arm 4-5 changed and 4 multiplied by -1
	rightAngles[4]=  ((double) rightEncoders[4] / - 636.6 /6.28 * 360 + (double) rightEncoders[5] / 636.6 /6.28 * 360);

	printf("ang0: %.2f ang1: %.2f ang2: %.2f ang3: %.2f ang4: %.2f ang5: %.2f\n",rightAngles[0],rightAngles[1],rightAngles[2],rightAngles[3],rightAngles[4],rightAngles[5]);
}

void ReadLeftPressure()
{
	double leftPressures[4]={0};

	//Filtering
	for(int i=0;i<5;i++)
	{
		if( i == 0 ){
			vitalSelectBoard(0);
			vitalReadAnalogInputs( 0, leftPressures);
			for(int channel=0; channel<4;channel++)
				leftValvesInputs[channel]= leftPressures[channel];

			vitalReadAnalogInputs( 1, leftPressures);
			for(channel=4;channel<8;channel++)
				leftValvesInputs[channel]= leftPressures[channel-4];

			vitalSelectBoard(1);
			vitalReadAnalogInputs( 0, leftPressures);
			for(channel=8;channel<12;channel++)
				leftValvesInputs[channel]= leftPressures[channel-8];

			Sleep(1);
		}else{
			vitalSelectBoard(0);
			vitalReadAnalogInputs( 0, leftPressures);
			for(int channel=0; channel<4;channel++)
				leftValvesInputs[channel]+= leftPressures[channel];

			vitalReadAnalogInputs( 1, leftPressures);
			for(channel=4;channel<8;channel++)
				leftValvesInputs[channel]+= leftPressures[channel-4];

			vitalSelectBoard(1);
			vitalReadAnalogInputs( 0, leftPressures);
			for(channel=8;channel<12;channel++)
				leftValvesInputs[channel]+= leftPressures[channel-8];

			Sleep(1);
		}
	}

	for(i=0;i<12;i++)
		leftValvesInputs[i]/=5;

	// there is a problem with the 10th muscle
	leftValvesInputs[9]-=100;

	vitalSelectBoard(0);

}

void InitializeCards()
{
	printf("Initializing Cards!!\n");
	int numb =0;
	//Initializing the Cards
	if( numb=vitalInit() )
		printf("%d board(s) detected\n",numb);
	else
		printf( "Error initializing WinMotenc library\n" );
}

void CloseRightGripper()
{
	vitalSelectBoard(2);
	vitalDacWrite(0,2);Sleep(100);
}

void OpenRightGripper()
{
	vitalSelectBoard(2);
	vitalDacWrite(0,0);Sleep(100);
}

#endif