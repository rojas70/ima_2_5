#ifndef _PID_h
#define _PID_h

extern double leftAngles[6],rightAngles[6];

double leftPID0(float *desiredAngle0)
{
	double anglenow, angleerror;
	double P=0.00045;

	anglenow = leftAngles[0];		
		
	angleerror =  *desiredAngle0 - anglenow;		

	return P*angleerror;

}

double leftPID1(float *desiredAngle1)
{
	double anglenow, angleerror;
	double P=0.0013/2;

	anglenow = leftAngles[1];		
		
	angleerror =  *desiredAngle1 - anglenow;		

	return P*angleerror;

}

double leftPID2(float *desiredAngle2)
{
	double anglenow, angleerror;
	double P=0.0015/2;

	anglenow = leftAngles[2];		
		
	angleerror =  *desiredAngle2 - anglenow;		

	return P*angleerror;

}

double leftPID3(float *desiredAngle3)
{
	double anglenow, angleerror;
	double P=0.0015;

	anglenow = leftAngles[3];		
		
	angleerror =  *desiredAngle3 - anglenow;		

	return P*angleerror;

}

double leftPID4(float *desiredAngle4)
{
	double anglenow, angleerror;
	double P=0.0015/2;

	anglenow = leftAngles[4];		
		
	angleerror =  *desiredAngle4 - anglenow;		

	return P*angleerror;

}

double leftPID5(float *desiredAngle5)
{
	double anglenow, angleerror;
	double P=0.0015;

	anglenow = leftAngles[5];		
		
	angleerror =  *desiredAngle5 - anglenow;		

	return P*angleerror;

}
// RightPIDs
double rightPID0(float *desiredAngle0)
{
	double anglenow, angleerror;
	double P=0.00045;

	anglenow = rightAngles[0];		
		
	angleerror =  *desiredAngle0 - anglenow;		

	return P*angleerror;

}

double rightPID1(float *desiredAngle1)
{
	double anglenow, angleerror;
	double P=0.0013/2;

	anglenow = rightAngles[1];		
		
	angleerror =  *desiredAngle1 - anglenow;		

	return P*angleerror;

}

double rightPID2(float *desiredAngle2)
{
	double anglenow, angleerror;
	double P=0.0015/2;

	anglenow = rightAngles[2];		
		
	angleerror =  *desiredAngle2 - anglenow;		

	return P*angleerror;

}

double rightPID3(float *desiredAngle3)
{
	double anglenow, angleerror;
	double P=-0.0015;

	anglenow = rightAngles[3];		
		
	angleerror =  *desiredAngle3 - anglenow;		

	return P*angleerror;

}

double rightPID4(float *desiredAngle4)
{
	double anglenow, angleerror;
	double P=0.0015/2;

	anglenow = rightAngles[4];		
		
	angleerror =  *desiredAngle4 - anglenow;		

	return P*angleerror;

}

double rightPID5(float *desiredAngle5)
{
	double anglenow, angleerror;
	double P=0.0015/2;

	anglenow = rightAngles[5];		
		
	angleerror =  *desiredAngle5 - anglenow;		

	return P*angleerror;

}

#endif