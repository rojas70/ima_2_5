#include "stdafx.h"
#include <windows.h>
#include <windef.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <stdarg.h>	
#include "time.h"
#include <IOSTREAM>
#include "winmotenc.h"

using namespace std;

double LeftValvesOutputs[12]={0},RightValvesOutputs[12]={0};
double LeftValvesInputs[12]={0},RightValvesInputs[12]={0};

void initializecards();
void initializeleftvalves();
void closevalves();

int main()
{
	int count=0,numb=0;
	float v0=1.0,v1=1.0;
	double buffervoltage1=0.0,buffervoltage2=0.0,buffervoltage3,buffervoltage4,buffervoltage5,buffervoltage6;

	initializecards();
	initializeleftvalves();

	// Precise Sampling Time Initialization		
	LARGE_INTEGER ticksPerSecond,start_ticks, end_ticks, cputime,tick;
	if (!QueryPerformanceFrequency(&ticksPerSecond))
	if (!QueryPerformanceCounter(&tick) ) printf("no go counter not installed");

	// Using only the first board
	//vitalSelectBoard(0);

	Sleep(3000);

	buffervoltage1 = 2;buffervoltage2 = 2;
	buffervoltage3 = 2;buffervoltage5 = 2;
	buffervoltage4 = 2;buffervoltage6 = 2;
	double buffervoltage7 = 2,buffervoltage8 = 2;

	vitalSelectBoard(0);

	//Control loop
	while(count<10)
	{
		QueryPerformanceCounter(&start_ticks);

		// Update the voltage output refrences
		vitalDacWrite( 0, buffervoltage1 );

		// Read the pressures

		//Read Encoders

		// Find error

		// Calculate the new voltage output reference
	
		//...Control will be here....
		/*
		// Anaolog Outputs Check the Values if they are > 3 Volts give 3V.
		if (count>0 && count<50)
		{
			//buffervoltage1+=0.02;buffervoltage2-=0.02;buffervoltage3+=0.02;buffervoltage4-=0.02;
			buffervoltage5-=0.02;buffervoltage6+=0.02;
			buffervoltage7+=0.02;buffervoltage8-=0.02;
		    vitalDacWrite( 0, buffervoltage1 );
			vitalDacWrite( 1, buffervoltage2 );
			vitalDacWrite( 2, buffervoltage3 );
			vitalDacWrite( 3, buffervoltage4 );
			vitalDacWrite( 4, buffervoltage5 );
			vitalDacWrite( 5, buffervoltage6 );
			vitalDacWrite( 6, buffervoltage7 );
			vitalDacWrite( 7, buffervoltage8 );
		}
		if (count>50 && count<150)
		{
			buffervoltage1-=0.02;buffervoltage2+=0.02;buffervoltage3-=0.02;buffervoltage4+=0.02;
			buffervoltage5+=0.01;buffervoltage6-=0.01;
			buffervoltage7-=0.01;buffervoltage8+=0.01;
		    vitalDacWrite( 0, buffervoltage1 );
			vitalDacWrite( 1, buffervoltage2 );
			vitalDacWrite( 2, buffervoltage3 );
			vitalDacWrite( 3, buffervoltage4 );
			vitalDacWrite( 4, buffervoltage5 );
			vitalDacWrite( 5, buffervoltage6 );
			vitalDacWrite( 6, buffervoltage7 );
			vitalDacWrite( 7, buffervoltage8 );
		}
		if (count>150 && count<250)
		{
			buffervoltage1+=0.02;buffervoltage2-=0.02;buffervoltage3+=0.02;buffervoltage4-=0.02;
			buffervoltage5-=0.01;buffervoltage6+=0.01;
			buffervoltage7+=0.01;buffervoltage8-=0.01;
		    vitalDacWrite( 0, buffervoltage1 );
			vitalDacWrite( 1, buffervoltage2 );
			vitalDacWrite( 2, buffervoltage3 );
			vitalDacWrite( 3, buffervoltage4 );
			vitalDacWrite( 4, buffervoltage5 );
			vitalDacWrite( 5, buffervoltage6 );
			vitalDacWrite( 6, buffervoltage7 );
			vitalDacWrite( 7, buffervoltage8 );
		}
		if (count>250 && count<300)
		{
			buffervoltage5+=0.02;buffervoltage6-=0.02;
			buffervoltage7-=0.02;buffervoltage8+=0.02;
			vitalDacWrite( 4, buffervoltage5 );
			vitalDacWrite( 5, buffervoltage6 );
			vitalDacWrite( 6, buffervoltage7 );
			vitalDacWrite( 7, buffervoltage8 );
		}
		if (count == 50 || count == 100 ||count == 150 || count == 200 || count == 250)
				Sleep(500);

	*/

		// Sleep 20 ms.   
		QueryPerformanceCounter(&end_ticks); printf("timepass:%f\n",(float)(end_ticks.QuadPart-start_ticks.QuadPart)/ticksPerSecond.QuadPart*1000);
		
		while(((float)(end_ticks.QuadPart-start_ticks.QuadPart)/ticksPerSecond.QuadPart*1000) < (float) 20)
		QueryPerformanceCounter(&end_ticks); cputime.QuadPart = end_ticks.QuadPart- start_ticks.QuadPart;	

		count++;
	}
	
	QueryPerformanceCounter(&end_ticks); printf("total:%f\n",(float)(end_ticks.QuadPart-start_ticks.QuadPart)/ticksPerSecond.QuadPart*1000);

	closevalves();
	Sleep(1000);

	//clean up on exit
	vitalQuit();

	// wait for 1 seconds

	return 0;
}

void initializecards()
{
	int numb =0;
	//Initializing the Cards
	if( numb=vitalInit() )
		printf("%d board(s) detected\n",numb);
	else
		printf( "Error initializing WinMotenc library\n" );
}

void initializeleftvalves()
{
	double buffervoltage=0.1;
	int i=0,j=0,k=0;

	for(i=0;i<20;i++) // 20x100 ms = 2 sn makes the muscles blow up
	{
		vitalSelectBoard(0);
		for(j=0;j<8;j++) // giving reference to each channel of board 0
			vitalDacWrite( j, buffervoltage );
		vitalSelectBoard(1);
		for(j=0;j<4;j++) // giving reference to first 4 channel of board 1
			vitalDacWrite( j, buffervoltage );
		buffervoltage +=0.1; // Increasing the ref voltage slowly not to harm 
		Sleep(100); // Wait 100 ms at each step
	}
	for(k=0;k<12;k++)
			LeftValvesOutputs[k]=2.0;
}

void closevalves()
{
	int i=0,j=0,k=0;

	for(i=0;i<30;i++) // 30x100 ms = 3 sn makes the muscles blow down
	{
		for(k=0;k<12;k++)
			LeftValvesOutputs[k]-=0.1;
		vitalSelectBoard(0);
		for(j=0;j<8;j++) // giving reference to each channel of board 0
			vitalDacWrite( j, LeftValvesOutputs[j] );
		vitalSelectBoard(1);
		for(j=0;j<8;j++) // giving reference to first 4 channel of board 1
			vitalDacWrite( j, LeftValvesOutputs[j+8] );
		vitalSelectBoard(2);
		for(j=0;j<8;j++) // giving reference to first 4 channel of board 1
			vitalDacWrite( j, 0 );
		Sleep(150); // Wait 100 ms at each step
	}
}




