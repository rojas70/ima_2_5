//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: graspitGUI.h,v 1.7 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines a graspit user interface class that contains subpieces of the UI.
*/

#ifndef GRASPITGUI_HXX
class MainWindow;
class IVmgr;

//! This is the main user interface class that is responsible for creating and destroying the MainWindow and IVmgr.
/*!
  This class also processes command line arguments and holds pointers to both
  the MainWindow and IVmgr.  There is one global instance of this class, which
  allows access to these two main pieces of the UI.  This class also has
  methods for both the entry and exit to the interactive program loop.
*/
class GraspItGUI
{
  //! A pointer to the MainWindow.
  MainWindow *mainWindow;

  //! A pointer to the IVmgr.
  IVmgr *ivmgr;

  //! TRUE if this class has been initialized.
  static bool initialized;

  //! Holds result of UI initialization.
  static int initResult;
  
 protected:
  int processArgs(int argc, char **argv);

 public:
  GraspItGUI(int argc,char **argv);
  ~GraspItGUI();

  /*! Returns whether the UI pieces were successfully initialized. */
  bool initOK() const {return !initResult;}

  /*! Returns a pointer to the MainWindow. */
  MainWindow *getMainWindow() const {return mainWindow;}

  /*! Returns a pointer to the IVmgr. */
  IVmgr *getIVmgr() const {return ivmgr;}
  
  void startMainLoop();
  void exitMainLoop();
};

extern GraspItGUI *graspItGUI;

#define GRASPITGUI_HXX
#endif
