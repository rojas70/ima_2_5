//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: robonaut.h,v 1.6 2004/02/12 21:35:07 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines the special %Robonaut robot class
 */

#ifndef ROBONAUT_H

#include "robot.h"

//! A special hand because collisions must be turned off between the palm and the second link of the thumb
/*! A special hand because collisions must be turned off between the palm and the second link of the thumb.  This is done by overriding the load method.
 */
class Robonaut : public Hand {

 public:

  /*! Empty constructor (placeholder) */
  Robonaut(World *w,const char *name) : Hand(w,name) {}
  
 /*! Performs the normal robot load routine then turns off collisions between
     the palm and the second link of the thumb.
 */
  virtual int load(QString filename);

};

#define ROBONAUT_H
#endif
