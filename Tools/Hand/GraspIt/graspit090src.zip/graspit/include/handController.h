//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: handController.h,v 1.3 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################


void HandController(Hand *hand,Grasp *grasp,double timeInterval);
