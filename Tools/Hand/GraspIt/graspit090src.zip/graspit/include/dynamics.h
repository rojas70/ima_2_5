//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: dynamics.h,v 1.8 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Prototypes for moveBodies and iterateDynamics
 */

class DynamicBody;
class Contact;
class Robot;

#define ERP 0.2

int
moveBodies(int numBodies,std::vector<DynamicBody *> bodyVec,double h);

int
iterateDynamics(std::vector<Robot *> robotVec,
		std::vector<DynamicBody *> bodyVec,double h,
		bool useContactEps);


