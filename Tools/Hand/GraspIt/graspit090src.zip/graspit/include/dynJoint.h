//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: dynJoint.h,v 1.6 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################

/*! \file
\brief Defines the DynJoint classes. 
*/
#ifndef _DYNJOINT_H_

#include <vector>
#include "matvec3D.h"

class Joint;
class DynamicBody;

//! The parent class for each of the joint modules used in the dynamics.
/*!
  For each pair of links with one or more joints between them, a dynJoint must
  also be defined.  The dynJoint has 2 functions.  First it must build up
  the dynamic constraints imposed by the particular joint type, and it must
  compute the new joint angles after a dynamic step has been taken.
*/
class DynJoint {
 protected:
  
  //! The link preceding this joint in the kinematic chain, could be NULL if joint is connected to the world space.
  DynamicBody *prevLink;

  //! The link succeeding this joint in the kinematic chain
  DynamicBody *nextLink;

  //! The position and orientation of the end frame of the preceding link
  transf prevFrame;
    
  //! The position and orientation of the end frame of the succeeding link
  transf nextFrame;

 public:

  /*! 
     Initializes the class with pointers and transfroms of the two links
     connected to this joint.
  */
  DynJoint(DynamicBody *pLink,DynamicBody *nLink,const transf &pFrame,
	const transf &nFrame):
    prevLink(pLink),nextLink(nLink),prevFrame(pFrame),nextFrame(nFrame) {}

  /*! Returns a pointer to the preceding link */
  DynamicBody *getPrevLink() const {return prevLink;}

  /*! Returns a pointer to the succeeding link */
  DynamicBody *getNextLink() const {return nextLink;}

  /*! Returns the number of constrained DOF's for this joint. */
  virtual int getNumConstraints()=0;

  /*! Returns the current error for each of the constraints. */
  virtual double *getConstraintError()=0;

  /*!
    Creates the dynamic constraints for this joint.  \a Nu is the joint
    constraint matrix, \a eps is the constraint error.
  */
  virtual void 
    buildConstraints(double *Nu,double *eps,int numBodies,
		     const std::vector<int> &islandIndices,int &ncn)=0;

  /*! 
    Update the joint values from the current position of the connected links.
  */
  virtual void updateValues() = 0;
};

//! A fixed joint constrains all translations and rotations.
/*!
  A fixed joint completely constrains the relative motion between the two
  connected links.  Or if the prevLink is NULL, it fixes the position of
  the nextLink to its current location in the world.
*/
class FixedDynJoint : public DynJoint {
  double constraintError[6];

 public:

  /*! 
     Initializes the class with pointers and transfroms of the two links
     connected to this joint.
  */
  FixedDynJoint(DynamicBody *pLink,DynamicBody *nLink,
		const transf &pFrame=transf::IDENTITY,
		const transf &nFrame=transf::IDENTITY) :
    DynJoint(pLink,nLink,pFrame,nFrame) {}
  
  virtual int getNumConstraints() {return 6;}

  double *getConstraintError() {return constraintError;}

  virtual void 
    buildConstraints(double *Nu,double *eps,int numBodies,
		     const std::vector<int> &islandIndices,int &ncn);
   virtual void updateValues();
};

//! A revolute joint constrains all 3 translations and 2 rotations.
/*!
  It only allows relative rotation about a single axis.
*/
class RevoluteDynJoint : public DynJoint {
  
  //! Keeps track of the current error in the constraints
  double constraintError[5];

  //! A pointer to the associated joint in the kinematic chain
  Joint *joint;

 public:

  /*! 
     Initializes the class with pointers and transfroms of the two links
     connected to this joint.  It also requires a pointer to the joint
     in the kinematic chain that this dynJoint is associated with.
  */
  RevoluteDynJoint(Joint *j,DynamicBody *pLink,DynamicBody *nLink,
		  const transf &pFrame=transf::IDENTITY,
		  const transf &nFrame=transf::IDENTITY) :
    DynJoint(pLink,nLink,pFrame,nFrame),joint(j) {}
  
  virtual int getNumConstraints() {return 5;}
  double *getConstraintError() {return constraintError;}

  virtual void 
    buildConstraints(double *Nu,double *eps,int numBodies,
		     const std::vector<int> &islandIndices,int &ncn);
   virtual void updateValues();
};


//! A universal joint constrains all 3 translations and 1 rotation.
/*!
  A universal joint consits of two co-located revolute joints with
  perpendicular axes.  It constrains the relative translational motion
  between the two connected links as well as relative rotations about an axis
  perpendicular to the two joint axes. 
*/
class UniversalDynJoint : public DynJoint {

  //! Revolute joint connected to the end of the prevLink
  Joint *joint1;

  //! Revolute joint connected to the start of the nextLink
  Joint *joint2;

  //! Keeps track of the current error in the constraints
  double constraintError[4];

 public:

  /*! 
     Initializes the class with pointers and transfroms of the two links
     connected to this joint.  It also requires a pointer to the 2 joints
     in the kinematic chain that this dynJoint is associated with.
  */
  UniversalDynJoint(Joint *j1,Joint *j2,DynamicBody *pLink,DynamicBody *nLink,
		    const transf &pFrame=transf::IDENTITY,
		    const transf &nFrame=transf::IDENTITY) :
    DynJoint(pLink,nLink,pFrame,nFrame),joint1(j1),joint2(j2) {}

  virtual int getNumConstraints() {return 4;}
  double *getConstraintError() {return constraintError;}

  virtual void 
    buildConstraints(double *Nu,double *eps,int numBodies,
		     const std::vector<int> &islandIndices,int &ncn);

  virtual void updateValues();
};

//! A ball joint constrains all 3 translations.
/*!
  A ball joint consits of three co-located revolute joints with
  perpendicular axes.  It constrains the relative translational motion
  between the two connected links but not of the rotational motions.
*/
class BallDynJoint : public DynJoint {
  //! Revolute joint connected to the end of the prevLink
  Joint *joint1;

  //! Revolute joint connected to joint1 and joint2
  Joint *joint2;

  //! Revolute joint connected to the start of the nextLink
  Joint *joint3;

  //! Keeps track of the current error in the constraints
  double constraintError[3];

 public:
  /*! 
     Initializes the class with pointers and transfroms of the two links
     connected to this joint.  It also requires a pointer to the 3 joints
     in the kinematic chain that this dynJoint is associated with.
  */
  BallDynJoint(Joint *j1,Joint *j2,Joint *j3,DynamicBody *pLink,DynamicBody *nLink,
		    const transf &pFrame=transf::IDENTITY,
		    const transf &nFrame=transf::IDENTITY) :
    DynJoint(pLink,nLink,pFrame,nFrame),joint1(j1),joint2(j2),joint3(j3) {}

  virtual int getNumConstraints() {return 3;}
  double *getConstraintError() {return constraintError;}

  virtual void 
    buildConstraints(double *Nu,double *eps,int numBodies,
		     const std::vector<int> &islandIndices,int &ncn);

  virtual void updateValues();
};

#define _DYNJOINT_H_
#endif
