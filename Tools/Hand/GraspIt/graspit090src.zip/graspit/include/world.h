//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: world.h,v 1.20 2004/02/15 15:14:32 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines the simulation world that controls interactions between the world elements
 */
#ifndef WORLD_HXX

#include <list>
#include <vector>
#include <utility>
#include <qstring.h>
#include <qobject.h>

#include "material.h"
#include "matvec3D.h"

#include <Inventor/SoType.h>

class Hand;
class Robot;
class Body;
class Link;
class GraspableBody;
class WorldElement;
class ivcollide;

class SoGroup;
class SoSeparator;
class SoIdleSensor;
class SoSensor;

typedef std::pair<Body *,Body *> BodyPair;
typedef std::vector<BodyPair> ColReportT ;

enum {BODY_TYPE_STATIC,BODY_TYPE_DYNAMIC,BODY_TYPE_GRASPABLE,BODY_TYPE_LINK};

//! The simulation world holds the world elements and handles their static and dynamic interactions
/*! A world object keeps track of all of the world elements (bodies and robots)
    contained within it.  It allows collisions to be turned on or off,
    completely, for a single body, or just between a pair of bodies.  It has
    several parameters that effect body interactions such as the table of
    coefficient of friction tables.  The world also contains methods advance
    the dynamic simulation of body motions within the world.  The state of
    a world may be written out to a simple text file which may be reloaded
    later.
 */
class World : public QObject {
  Q_OBJECT ;

protected:
  //! Keeps track of the current simulation time.
  double worldTime;

  //! A vector of pointers to ALL of the bodies in the world
  std::vector<Body *> bodyVec;

  //! A vector of pointer to ALL of the bodies in the world indexed by the body ID
  std::vector<Body *> bodyIdVec;

  //! A vector of pointers to the graspable bodies in the world
  std::vector<GraspableBody *> GBVec;

  //! A vector of pointers to the robots defined within this world
  std::vector<Robot *> robotVec;        

  //! A vector of pointers to the hands defined within this world
  std::vector<Hand *> handVec;

  //! The highest body ID used within the world
  int maxId;
  
  //! The number of bodies currently in this world
  int numBodies;

  //! The number of graspable bodies currently in this world
  int numGB;

  //! The number of robots currently in this world
  int numRobots;

  //! The number of hands currently in this world
  int numHands;

  //! The number of currently selected elements
  int numSelectedElements;

  //! The number of currently selected body elements
  int numSelectedBodyElements;

  //! The number of currently selected body elements
  int numSelectedRobotElements;

  //!
  int numSelectedBodies;

  //! Keeps track of whether the world has been modified since the last save
  bool modified;

  //! Keeps track of which hand is currently the focus of menu commands
  Hand *currentHand;

  //! A list of pointers to the currently selected worldElements
  std::list<WorldElement *> selectedElementList;

  //! A vector of pointers to the currently selected bodies
  std::vector<Body *> selectedBodyVec;
  
  //! A flag to determine if collions checking is on or off
  bool allCollisionsOFF;

  //! A pointer to the collision detection instance
  ivcollide *ivc;

  //! A pointer to the root of the world's Inventor scene graph
  SoSeparator *IVRoot;

  //! The number of materials defined within this world
  int numMaterials;
  
  //! A vector of strings, one for each material name
  std::vector<QString> materialNames;

  //! A numMaterials x numMaterials array of static coefficient of friction values
  double **cofTable;

  //! A numMaterials x numMaterials array of kinetic coefficient of friction values
  double **kcofTable;

  //! A flag to determine whether dynamics is currently being used or not
  bool dynamicsOn;

  //! A pointer to the Inventor idle sensor that is used when dynamics is on
  SoIdleSensor *idleSensor;

  //! The length of the default dynamics time step
  double dynamicsTimeStep;  

  /*! This routine reads the user preferences for the world settings.  Under
      Windows this information is read from the registry, under linux it
      is read from a file.
  */
  void readSettings();

  /*! This routine saves the user preferences for the world settings.  Under
      Windows this information is saved in the registry, under linux it
      is saved to a file.
  */
  void saveSettings();

  /*! This is a static callback routine for the idle sensor.  It simply calls
    the internalStepDyn
amics routine for the world passed in the user data
    pointer.
  */
  static void dynamicsCB(void *data,SoSensor *sensor);

  
  void internalStepDynamics();

  friend class Body;
  friend class DynamicBody;
  friend class MainWindow;

signals:
  /*! Signal that a dynamic step has been completed */
  void dynamicStepTaken();

  /*! Signal a dynamics error has occured with an error string */
  void dynamicsError(const char *errMsg);

  /*! Signal that selections have changed */
  void selectionsChanged();

  /*! Signal that the number of world elements has changed */
  void numElementsChanged();

  /*! Signal that a hand was removed from the world */
  void handRemoved();

  /*! Signal that all grasps have been updated */
  void graspsUpdated();

public:
  
  /*! public constructor */
  World(QObject *parent=0,const char *name=0);

  /*! 
    Saves the current user settings in the registry, deletes the friction
    tables, destroys every worldElement, and deletes the world scene graph.
  */
  ~World();
  
  /*! Returns the number of bodies in this world */
  int getNumBodies() const {return numBodies;}

  /*! Returns the number of graspable bodies in this world */
  int getNumGB() const {return numGB;}

  /*! Returns the number of robots in this world */
  int getNumRobots() const {return numRobots;}

  /*! Returns the number of hands in this world */
  int getNumHands() const {return numHands;}

  /*! Returns the number of materials defined in this world */
  int getNumMaterials() const {return numMaterials;}

  /*! Returns the material index of the material named by matName */
  int getMaterialIdx(const QString &matName) const; 

  /*! Returns the name of the material with index i */
  QString getMaterialName(int i) const {return materialNames[i];}

  /*! Returns the number of selected body elements */
  int getNumSelectedBodyElements() const {return numSelectedBodyElements;}
  
  /*! Returns the number of selected robot elements */
  int getNumSelectedRobotElements() const {return numSelectedRobotElements;}

  /*! Returns the number of selected world elements */
  int getNumSelectedElements() const {return numSelectedElements;}

  /*! Returns the number of selected bodies */
  int getNumSelectedBodies() const {return numSelectedBodies;}

  /*! Returns a pointer to the i-th selected body in the world */
  Body *getSelectedBody(int i) const {return selectedBodyVec[i];}

  /*! Returns the static coefficient of friction between materials with
    indicies mat1 and mat2 */
  double getCOF(int mat1,int mat2) {return cofTable[mat1][mat2];}

  /*! Returns the kinetic coefficient of friction between materials with
    indicies mat1 and mat2 */
  double getKCOF(int mat1,int mat2) {return kcofTable[mat1][mat2];}

  /*! Returns the current simulation time for this world */
  double getWorldTime() const {return worldTime;}

  /*! Returns the default timestep for this world */
  double getTimeStep() const {return dynamicsTimeStep;}
  
  /*! Returns whether this world has been modified since the last save. */
  bool wasModified() const {return modified;}

  /*! Returns the root of the Inventor scene graph for this world */
  SoSeparator *getIVRoot() const {return IVRoot;}

  /*! Returns a pointer to the i-th body defined in this world */
  Body *getBody(int i) const {return bodyVec[i];}

  /*! Returns a pointer to the body with an ID equal to i */
  Body *getBodyById(int i) const {return bodyIdVec[i];}

  /*! Returns a pointer to the i-th graapable body defined in this world */
  GraspableBody *getGB(int i) const {return GBVec[i];}

  /*! Returns a pointer to the i-th hand defined in this world */
  Hand *getHand(int i) const {return handVec[i];}

  /*! Returns a pointer to the i-th robot defined in this world */
  Robot *getRobot(int i) const {return robotVec[i];}

  /*! Returns whether the world element pointed to by e is currently selected
      or not
  */
  bool isSelected(WorldElement *e) const;

  /*! Returns a list of pointers to the currently selected world elements */
  const std::list<WorldElement *>& getSelectedElementList() const {return selectedElementList;}

  /*! Returns a pointer to the hand that is the focus of menu commands etc. */
  Hand *getCurrentHand() const { return currentHand;}

  /*! Returns whether dynamics are currently running or not. */
  bool dynamicsAreOn() const {return dynamicsOn;}

  /*! Sets all world settings to their original default values. */
  void setDefaults();

  /*! Sets the world modified flag.  This should be done whenever a change has
      been made to the world since the last save.
  */
  void setModified() {modified = true;}

  /*! Loads the saved world from the file in filename. It loads each of
      the bodies and robots in the world, and sets each of their positions and
      restores connections between robots.
  */
  int load(const QString &filename);

  /*! Save the current state of the world to a file.  It saves the filename of
      each body and robot as well as their current position.  It also saves the
      connections between robots.  It does not save the current dynamic state
      of the bodies.
  */
  int save(const QString &filename);
  
  /*! Creates a new body of type bodyType, which should be either "Body" or
      "GraspableBody".  Then calls the load routine of that body to read the
      geometry file given by filename. The body's Inventor scene graph is added
      to the world scene graph, and the body is added to the world's body
      vectors.
   */
  Body *importBody(QString bodyType,QString filename);

  /*! Links are loaded in during the robot load method, but are added to the
      world with this routine, which adds the link to the world body vectors.
  */
  void addLink(Link *newLink);

  /*! This routine is called when the user selects a new hand from the drop
      down menu.  This new hand becomes the focus of future menu commands.
  */
  void setCurrentHand(Hand *hand) {currentHand = hand;}

  /*! Opens the robot configuration file named with filename, and reads the
      first non-comment line to determine what type of robot to create
      (generic robot, hand, puma560, barrett, etc.).  It creates that robot,
      and then calls it load method with the same filename.  After the load
      is complete it adds the robot to the world robot vector and hand vector
      if necessary.  It also turns off collision detection between each pair of
      connected links in the robot.
   */
  Robot *importRobot(QString filename);

  /*! Removes the robot pointed to by robot from the world by deleting pointers
      to it in the world robot vector and hand vector if necessary.  Then it
      deletes the robot.
  */
  void removeRobot(Robot *robot);

  /*! Creates a new dynamic body from the data in the body pointed to by b.
      A mass must be provided, and then it can compute the mass matrix by
      assuming a uniform mass distribution.  The original body is deleted,
      and replaced with the new body.
   */
  DynamicBody *makeBodyDynamic(const Body *b, double mass);

  /*! Deselects all currently selected world elements. */
  void deselectAll();

  /*! Adds the worldElement pointed to by e to the list of selected elements.
      If the element is a body it is also added to the selectedBody vector.
      If the element is a robot, every link in the robot is added to the
      selectedBody vector.
  */
  void selectElement(WorldElement *e);

  /*! Removes the worldElement pointed to by e from the list of selected
      elements.  If the element is a body it is also removed from the
      selectedBody vector.  If the element is a robot, every link in the robot
      is removed from the selectedBody vector.      
   */
  void deselectElement(WorldElement *e);

  /*! Removes the element pointed to by e from the world body, robot, hand,
      and GB vectors as necessary.  If it is a body, it removes the body from
      the collision detection system.  If it is a graspable body and there
      is a grasp that references it, it associates the grasp with the first
      GB or NULL if none are left.  It removes the element's Inventor scene
      graph from the world graph, and finally deletes the element.
   */
  void destroyElement(WorldElement *e);
  
  /*! Turns the collision detection system on or off */
  void toggleCollisions(bool off);

  /*! There are 2 main cases:  If e2 is NULL, then this activates collision
      checking for the element e1.  If e2 is not NULL, then it activates
      collision checking between elements e1 and e2.  If an element is a robot,
      then this is performed for every body in the robot.  So if e1 and e2 are
      both robots, this would activate collisions for every possible pair
      of bodies between the two robots.
  */
  void turnOnCollisions(WorldElement *e1,WorldElement *e2=NULL);

  /*! There are 2 main cases:  If e2 is NULL, then this deactivates collision
      checking for the element e1.  If e2 is not NULL, then it deactivates
      collision checking between elements e1 and e2.  If an element is a robot,
      then this is performed for every body in the robot.  So if e1 and e2 are
      both robots, this would deactivate collisions for every possible pair
      of bodies between the two robots.
  */
  void turnOffCollisions(WorldElement *e1,WorldElement *e2=NULL);

  /*! There are 3 possible cases.  If e1 and e2 are both NULL, then this
      returns whether the collision detection system is on or off.  If e1
      is not NULL, it checks whether collisions are off for the element
      pointed to by e1.  If both are not NULL, then it checks whether
      collisions have been decativated between the pair of elements.
  */
  bool collisionsAreOff(WorldElement *e1=NULL, WorldElement *e2=NULL);

  /*! Queries the collision detection system and returns a report of which
      pairs of bodies have interpenetrated eachother.
  */
  int getCollisionReport(ColReportT &colReport);

  /*! Returns the minimum distance in mm between the two bodies */
  double getDist(Body *b1,Body *b2);

  /*! Finds every contact occurring between the pairs of bodies listed
      in the colReport.  A contact occurs when bodies are separated by a
      distance less than the contact threshold.  This routine uses the
      collision detection system to find the points of contact between
      each body and at each one creates a pair of contact objects which are
      added to the individual bodies.
  */
  void findContacts(const ColReportT &colReport);

  /*! Finds all contacts occurring on body b.  A pair of contact objects
      is created for each contact and are added to the individual bodies
      that are in contact.
  */
  void findContacts(Body *b);

  /*! Finds all the contacts occuring in the world. A pair of contact objects
      is created for each contact and are added to the individual bodies
      that are in contact.
  */
  void findAllContacts();

  /*! This will update the grasp for any hand that has had contacts change
      on it since its grasp was last updated.
   */
  void updateGrasps();

  /*! Starts the dynamic simulation for this world.  Currently we
      have this routine fix the base robot of every collection of robots
      so that it does not fall under gravity.  We also set the desired pose
      of each robot to be it's current state so that the controllers try
      to maintain the current positions until the user requests something
      different.
   */
  void turnOnDynamics();

  /*! Stops the dynamic simulation process. */
  void turnOffDynamics();

  /*! Moves all dynamic bodies by an amount equal to their velocity times the
      length of the current timestep.  If any collisions are encountered or
      a joint limit is passed, a binary search on the timestep length is
      performed until the first colliding bodies are within the contact
      threshold distance of eachother, or the joint value is within a very
      small range of its limit. Then it looks for and adds any contacts.
      The actual amount of time that the bodies were moved is returned.
  */
  double moveDynamicBodies(double timeStep);

  /*! Breaks the collection of dynamic bodies up into islands of connected
      bodies.  Two dynamic bodies are connected if they share a contact or
      a joint.  Then for each island, this calls the iterate dynamics routine
      to build and solve the LCP to find the velocities of all the bodies
      in the next iteration.
   */
  int computeNewVelocities(double timeStep);

  /*! Calls upon each dynamic body to save its current dynamic state to the
      top of its stack of states.  This can be used by a user to
      bookmark a particular state during the simulation.
  */
  void pushDynamicState();

  /*! Restores the most recent dynamic state of each dynamic body by popping
      the state of each body's local stack.  This can be used by a user to
      return to a previously bookmarked dynamic state.
  */
  void popDynamicState();

};

#define WORLD_HXX
#endif


