//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: joint.h,v 1.8 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines the classes: DHTransform, DOF, RevoluteJoint, and PrismaticJoint.
 */
#ifndef JOINT_H

#include <list>
#include <vector>

#include "mytools.h"
#include "matvec3D.h"
// #include "robot.h"

class Joint;
class KinematicChain;
class DynJoint;
class Robot;

class SoTransform;

enum JointT {REVOLUTE,PRISMATIC};

//! Converts 4 parameter Denavit-Hartenberg notation to a 4x4 transform.
/*! 
  Stores the 4 Denavit-Hartenberg parameters that define a transform between
  the joints of a robot.  Each joint has its axis aligned with the z-axis of
  the joint frame.  The four values are theta, d, a, and alpha.  Theta is
  the rotation about the z-axis of the current joint frame (this value is
  variable for revolute joints).  D is the translation along the z-axis of
  the joint frame (this value is variable for prismatic joints).  A is the
  transaltion along the x-axis of the joint frame, and alpha is the rotation
  about the x-axis.  
 */
class DHTransform {

  //! Translation vector along the z-axis
  vec3 dtrans;

  //! Translation vector along the x-axis
  vec3 atrans;

  //! Precomputed value of transform 4 times transform 3
  transf tr4TimesTr3;

  //! Translation transform of d along z-axis
  transf tr2;

  //! Rotation transform of theta about z-axis
  transf tr1;

  //! Final transform
  transf tran;

  //! Rotation about z-axis in radians
  double theta;

  //! Translation along z-axis in mm
  double d;

  //! Translation along x-axis in mm
  double a;

  //! Rotation about x-axis in radians
  double alpha;

public:
  DHTransform(double thval=0.0,double dval=0.0,double aval=0.0,
	      double alval=0.0);

  /*! Returns the current d value. */
  double getD() const {return d;}

  /*! Returns the current theta value. */
  double getTheta() const {return theta;}

  /*! Returns the current value of this transform. */
  const transf& getTran() const {return tran;}
  
  /*!
    Returns the value of this transform if \a thetaVal is substituted for
    theta and \a dval is substituted for d. It does not change any values
    within the DHTransform.
  */
  transf getTran(double thetaVal,double dVal) const
    {
      return tr4TimesTr3 * translate_transf(vec3(0,0,dVal)) * 
	rotate_transf(thetaVal,vec3(0,0,1));
    }

  void setD(double q);
  void setTheta(double q);
};


//! A single degree of freedom in a robot
/*!
  A degree of freedom is a single coordinate of relative motion between two
  bodies.  This can be linear or rotary motion.  It has a value, limits on
  that value, a velocity, and a generalized force acting on it
  (can be thought of as a motor force).  A trajectory of
  desired values can be set for the DOF and an included PD controller will
  choose motor forces during each time step of the dynamics to try and reach
  the desired value.  
*/
class DOF {
  friend class Robot;

 protected:
  //! The robot that this DOF is a part of
  Robot *owner;

  //! The number of this DOF within the robot definition
  int dofNum;

  //! The current value of this DOF
  double q;
  
  //! Tha maximum allowable value
  double maxq;

  //! The minimum allowable value
  double minq;

  //! The desired value
  double desiredq;

  //! The current trajectory set point
  double setPoint;

  double desiredVelocity;
  double defaultVelocity;
  double actualVelocity;
  double maxAccel;  // should be based on maxEffort

  //! The current force acting on this DOF
  double force;

  double desiredForce;

  //! The maximum force this DOF can exert
  double maxForce;

  //! The sum of external forces acting on the this DOF
  double extForce;

  //! Derivative gain used for PD controller
  double Kv;

  //! Proportional gain used for PD controller
  double Kp;

  //! The difference between the current value and the setPoint
  double error;

  //! The difference between the current value and the setPoint in the last timestep
  double lastError;

  //! A vector of set points
  std::vector<double> trajectory;

  //! Index of the current set point within the trajectory vector
  int currTrajPt;

  //! List of robot joints that are connected to this DOF
  std::list<Joint *> jointList;

  //  friend Robot::SetDOFVal(int dofNum,double val);
  //  friend Robot::SetDOFVals(double *dofVals);

  virtual int setVal(double q1);

public:

  /*! Initializes everything to zero. */
  DOF() : owner(NULL), q(0.0),desiredq(0.0),
    desiredVelocity(0.0),defaultVelocity(0.0),actualVelocity(0.0),
    maxAccel(10.0),
    force(0.0),desiredForce(0.0),maxForce(0.0),extForce(0.0),
    Kv(0.0),Kp(0.0),error(0.0),lastError(0.0),currTrajPt(0) {}

  /*! Stub destructor */
  virtual ~DOF() {}

  void initDOF(Robot *myRobot,const std::list<Joint *>& jList);

  /*! Returns the number of this DOF within the robot definition. */
  int getDOFNum() const {return dofNum;}

  /*! Returns the maximum allowable value. */
  double getMax() const { return maxq;}

  /*! Returns the minimum allowable value. */
  double getMin() const { return minq;}

  /*! Returns the current value. */
  double getVal() const {return q;}

  /*! Returns the desired velocity. */
  double getDesiredVelocity() const {return desiredVelocity;}

  /*! Returns the default velocity. */
  double getDefaultVelocity() const {return defaultVelocity;}
  double getActualVelocity() const {return actualVelocity;}
  double getMaxAccel() const {return maxAccel;}

  /*! Returns the current force acting on the DOF. */
  double getForce() const {return force;}
 
  double getDesiredForce() const {return force;}

  /*! Returns the maximum force that can be applied by this DOF (think torque limit). */
  double getMaxForce() const {return maxForce;}
  double getExtForce() const {return extForce;}
  double getDesiredPos() const {return desiredq;}

  /*! Returns the current trajectory set point. */
  double getSetPoint() const {return setPoint;}

  void setDesiredPos(double p) {desiredq = MIN(maxq,MAX(minq,p));}
  void setDesiredVelocity(double v) {desiredVelocity = v;}
  void setDefaultVelocity(double v) {defaultVelocity = v;}
  void setDesiredForce(double f) {desiredForce = f;}

  void setForce(double f);
  void updateSetPoint();
  void setTrajectory(double *traj,int numPts);
  void addToTrajectory(double *traj,int numPts);

  void PDPositionController(double timeStep);
  
  // these two shouldn't be public
  void setActualVelocity(double v) {actualVelocity = v;}
  void setExtForce(double f) {extForce = f;}

  void turnOnPower() {desiredVelocity = defaultVelocity;}
  void turnOffPower() {desiredVelocity = 0.0;}
};

//! Abstract base class for a single axis robot joint.
/*!
  A robot joint allows either translation or rotation on a single axis.
  It is part of a kinematic chain, which is a serial set of links and joints.
  Multiple joints can be defined between two links.  The value of the joint is
  linearly related to a robot DOF value, and has its own minimum and maximum
  values.  The joint also computes its friction value during dynamic simulation
  using viscous and Coulomb friction values defined in the robot configuration
  file.  
*/
class Joint {
protected:
  //! Index of the robot DOF this joint is connected to
  int DOFnum;

  //! A pointer to the kinematic chain that this joint is a part of
  KinematicChain *owner;

  //! \c TRUE if an Inventor dragger is currently attached to this joint
  bool draggerAttached;

  //! The current value of the joint computed by inverse kinematic during dynamics
  double dynamicsVal;

  //! The current velocity of the joint (first order approximation)
  double velocity;

  //! Joint limit
  double minVal,maxVal;

  //! Linear multiplier of DOF value.  JointVal = k * (DOFVal) + c
  double k;  

  //! Joint offset 
  double c;  

  //! The coefficient of viscous friction
  double f1;

  //! Coulomb friction value (constant offset)
  double f0;

  //! Current joint axis expressed in world coordinates
  vec3 worldAxis;

  //! The DHTransform from this joint frame to the next
  DHTransform *DH;

  //! A pointer to the associated Inventor transform used for joint draggers
  SoTransform *IVTran;

  /*! This sets the joint value and is only called through DOF::setVal. */
  virtual int setVal(double q)=0;

  /*! This applies a force to the joint and is only called through DOF::setForce */
  virtual void applyForce(double f)=0;

  friend int DOF::setVal(double);
  friend void DOF::setForce(double);

public:
  //! [Temporary] this points to the DynJoint that contains this joint
  DynJoint *dynJoint;

  /*! Initializes all values and pointers to zero.  Joint should set up
  with initJoint.  */
  Joint() : DOFnum(0),owner(NULL),draggerAttached(false),
    dynamicsVal(0.0),
    velocity(0.0),minVal(0.0),maxVal(0.0),k(1.0),c(0.0),f1(0.0),f0(0.0),DH(NULL),
    IVTran(NULL),dynJoint(NULL) {}

  virtual ~Joint();

  /*!
    Set up the joint using values from a string read from the robot
    configuration file.
  */
  virtual int initJoint(const char *info,KinematicChain *myChain,
			const Robot *myRobot) =0;

  /*! Returns the current joint value. */
  virtual double getVal() const =0;

  /*! Return type of this joint, either REVOLUE or PRISMATIC. */
  virtual JointT getType() const =0;

  /*! Returns the transform to the next joint frame the results from
      substituting \a jointVal for the current joint value. */
  virtual transf getTran(double jointVal) const =0;

  /*! Returns the current joint transform as computed from IK during dynamic
      simulation. */
  virtual transf getDynamicsTran() const =0;

  /*! Returns the index of the robot DOF this joint is connected to. */
  int getDOFNum() const {return DOFnum;}

  /*! Returns the linear multiplier relating this joint value to the DOF value.
   */
  double getRatio() const {return k;}

  /*! Returns the constant joint offset value.  */
  double getOffset() const {return c;}

  /*! Returns the minimum joint limit */
  double getMin() const {return minVal;}

  /*! Returns the maximum joint limit. */
  double getMax() const {return maxVal;}

  /*! Returns the current velocity of this joint (computed during dynamics).*/
  double getVelocity() const {return velocity;}

  /*! Returns the magnitude of friction acting on this joint.  This uses
     both viscous friction, which is proportional to the joint velocity,
     and Coulomb friction, which is constant. */
  double getFriction() const {
    return -f1 * velocity + (velocity<0 ? f0 : (velocity>0 ? -f0 : 0.0));
  }

  /*! Returns the current joint value as computed from the IK during dyanmic
    simulation. */
  double getDynamicsVal() const {return dynamicsVal;}

  /*! Returns the current value of the DHTransform associated with this joint.
   */
  transf const& getTran() const {return DH->getTran();}

  /*! Returns the current direction of the joint axis in world coordinates. */
  vec3 const& getWorldAxis() const {return worldAxis;}

  /*! Returns a pointer to the DHTransform associated with this joint. */
  DHTransform *getDH() const {return DH;}
 
  /*! Returns a pointer to the Inventor transform associated with this joint
    that is used in the joint dragger sub graph.
  */
  SoTransform *getIVTran() const {return IVTran;}

  /*! Sets the current joint velocity (computed during dynamics). */
  void setVelocity(double v) {velocity = v;}

  /*! Sets the current value of the joint (computed during dynamics). */
  void setDynamicsVal(double v) {dynamicsVal = v;}

  /*! Sets the current orientation of the joint axis in world coordinates. */
  void setWorldAxis(const vec3 &wa) {worldAxis = normalise(wa);}

  /*! Updates \a draggerAttached when a dragger is added or removed from this
    joint. */
  void setDraggerAttached(bool b) {draggerAttached = b;}
};


//! A type of joint that translates along the z-axis of the joint frame.
/*!
  A specific type of joint used for linear motion.
*/
class PrismaticJoint : public Joint {
  virtual int setVal(double q);
  virtual void applyForce(double f);

public:

  /*! Stub */
  PrismaticJoint() : Joint() {}

  virtual int initJoint(const char *info,KinematicChain *myChain,
			    const Robot *myRobot);

  /*! Returns the current value of this joint. */
  virtual double getVal() const {return DH->getD() - c;}

  /*! Returns the type of this joint: PRISMATIC. */
  virtual JointT getType() const {return PRISMATIC;}

  transf getTran(double jointVal) const {
    return DH->getTran(DH->getTheta(),jointVal + c);
  }

  transf getDynamicsTran() const {
    return DH->getTran(DH->getTheta(),dynamicsVal);
  }

};

//! A type of joint that rotates about the z-axis of the joint frame.
/*!
  A specific type of joint used for rotary motion.
*/
class RevoluteJoint : public Joint {
  virtual int setVal(double q);
  virtual void applyForce(double f);

public:

  /*! Stub */
  RevoluteJoint() : Joint() {}

  virtual int initJoint(const char *info,KinematicChain *myChain,
			    const Robot *myRobot);

  /*! Returns the current value of this joint. */
  virtual double getVal() const {return DH->getTheta() - c;}

  /*! Returns the type of this joint: REVOLUTE. */
  virtual JointT getType() const {return REVOLUTE;}


  transf getTran(double jointVal) const {
    return DH->getTran(jointVal + c,DH->getD());
  }
  transf getDynamicsTran() const {
    return DH->getTran(dynamicsVal,DH->getD());
  }

};

#define JOINT_H
#endif
