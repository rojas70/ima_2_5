//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: quality.h,v 1.7 2004/02/12 21:35:07 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines the base QualityMeasure class and specific qm classes.
 */
#ifndef QUALITY_H

#include <qstring.h>
#include <string.h>
#include <list>

class Grasp;         // defined in grasp.h
class GWS;           // defined in gws.h
class QComboBox;
class QualityMeasure;
class QHBox;
class QLineEdit;
class QWidget;
class Grasp;

//! A collection of pointers to exchange data with the qm dialog box
/*!
  A collection of pointers to exchange data with the qm dialog box.
*/
struct qmDlgDataT {
  //! The current grasp
  Grasp *grasp;

  //! A pointer to the settings area widget of the dlg box (qm must populate)
  QWidget *settingsArea;

  //! A pointer to the qm Type selection box in the dlg box
  QComboBox *qmTypeComboBox;

  //! The pointer to the name field in the dlg box
  QLineEdit *qmName;

  //! The string quality measure type
  const char *qmType;

  //! The current quality measure
  QualityMeasure *currQM;

  //! Pointer to another stucture containing data for this specific type of QM
  void *paramPtr;
};


//! Abstract base class for quality measures
/*!
  A quality measure is associated with a particular grasp.  Each individual
  type of quality measure must be able to build a parameters area for the
  quality measure dialog box.  It also must be able to produce a scalar real
  value that evaluates its grasp in someway.
*/
class QualityMeasure {
  //! The user chosen name of this qm instance
  QString name;

 protected:
  //! A pointer to the grasp this qm is associated with
  Grasp *grasp;

  //! The current value of the qm
  double val;

 public:
  QualityMeasure(qmDlgDataT *data);
  virtual ~QualityMeasure();

  /*! Returns the type of this quality measure expressed as a string */
  virtual const char *getType() const =0;
  
  /*! Returns the user chosen name of this qm instance */
  virtual QString getName() {return name;}

  /*! Returns the quality of the grasp associated with this qm */
  virtual double evaluate() =0
;
      
  static void buildParamArea(qmDlgDataT *qmData);
  static QualityMeasure *createInstance(qmDlgDataT *qmData);
  static const char *TYPE_LIST[];

};

//! The epsilon quality measure
/*!
  The epsilon quality measure measures the size of the largest Task Wrench
  Space (TWS_ that can fit within the unit Grasp Wrench Space (GWS).  In the
  case of the ball TWS, the measure because simply the euclidean distance from
  the wrench space origin to the closest point on the  hull bouandary.  This
  is a worst case grasp quality measure.  The parameters for this quality
  measure are:
     The GWS type
     The TWS type
*/
class QualEpsilon : public QualityMeasure {
  //! A pointer to the GWS that this qm should use for its calculation
  GWS *gws;

  //! The string identifying this qm type
  static const char *type;

 public:
  QualEpsilon(qmDlgDataT *data);
  ~QualEpsilon();

  /*! Returns the type of this quality measure expressed as a string */
  const char *getType() const {return type;}

  double evaluate();

  static void buildParamArea(qmDlgDataT *qmData);

  /*! Returns the type of this class expressed as a string. */
  static const char *getClassType() {return type;}
};

//! The volume quality measure
/*!
  The volume quality measure measures the volume of the unit Grasp Wrench
  Space (GWS). This is an average case grasp quality measure.  The parameter
  for this quality measure is:
     The GWS type
*/
class QualVolume : public QualityMeasure {
  //! A pointer to the GWS that this qm should use for its calculation
  GWS *gws;

  //! The string identifying this qm type
  static const char *type;

 public:
  QualVolume(qmDlgDataT *data);
  ~QualVolume();
  
  /*! Returns the type of this quality measure expressed as a string */
  const char *getType() const {return type;}

  double evaluate();

  static void buildParamArea(qmDlgDataT *qmData);

  /*! Returns the type of this class expressed as a string. */
  static const char *getClassType() {return type;}
};

/*
class QualWeighted : public QualityMeasure {
  QualityMeausre *qm1,*qm2;
  double weight1,weight2;

 public:
  QualWeighted(Grasp *g, char *n, QualityMeasure *q1, QualityMeasure *q2,
	       double w1, double w2);
  double evalute() {return weight1*qm1->evaluate() + weight2*qm2->evaluate();}

};

*/
#define QUALITY_H
#endif
