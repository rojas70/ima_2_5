//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: mytools.h,v 1.8 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################

/*! \file
  \brief Various useful macros and functions for dealing with errors and other common operations.
*/

#ifndef _MY_TOOLS_HXX_
#define _MY_TOOLS_HXX_

#include <qmessagebox.h>
#include <qpixmap.h>

#define SUCCESS 0
#define FAILURE -1

void show_errors(int, char* = NULL);

#ifndef MAX
#define MAX(A,B)	((A) > (B) ? (A) : (B))
#endif

#ifndef MIN
#define MIN(A,B)	((A) < (B) ? (A) : (B))
#endif

#ifndef ROUND
#define ROUND(A)        ((A) >= 0 ? (int)((A)+.5) : -(int)(.5-(A)))
#endif

//! Puts up a QT warning box with the given message
#define QTWARNING(MSG_) \
   QMessageBox::warning(NULL,"GraspIt!",MSG_,QMessageBox::Ok, \
                        QMessageBox::NoButton,QMessageBox::NoButton)

QPixmap load_pixmap(const QString &name);

//useful macros for standardizing error printing
#define pr_error(EXPR_)                         \
{                                               \
    fprintf(stderr,">>!>> ");                   \
    fprintf(stderr,EXPR_);                      \
    fprintf(stderr,"\n");                       \
}

// EXPR_ must be of the form: (stderr,"..%...%...%...",args)
#define pr_errArgs(EXPR_)                       \
{                                               \
    fprintf(stderr,">>!>> ");                   \
    fprintf EXPR_;                              \
    fprintf(stderr,"\n");                       \
}

/*!
  Extracts a name from a filename by stripping off any directory path
  preceeding the filename, and discarding any file extension.  \a maxsize
  is the maximum size of the returned name.
*/
inline void
extractName(const char *filename,char *name,int maxSize)
{
  const char *p;
  char *p2;

  //extract just the filename for a longer path
  p=filename+strlen(filename)-1;
  while (p != filename && *p != '/') p--;
  if (*p == '/') p++;
  strncpy(name,p,maxSize);
 
  // discard the ending
  p2 = name;
  while (*p2 != '\0' && *p2 != '.') p2++;
  *p2 = '\0';
}

#endif
