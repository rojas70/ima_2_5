//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: contact.h,v 1.9 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines the contact class
 */
#ifndef CONTACT_HXX

//Inventor includes
#include <Inventor/nodes/SoSeparator.h>
#include <list>
#include "PQP.h"
#include "matvec3D.h"

class Body;

#define DISPLAY_CONE_SCALE 20.0
#define FORCE_SCALE 4.0
#define MAX_FRICTION_EDGES 100
  

//! Friction type: Frictionless, Point contact with friction, Soft finger contact with elliptic approximation, Soft finger contact with linearized elliptic approximation
enum frictionT {FL,PCWF,SFCE,SFCL};

//!  A wrench is a 6-vector containing 2 3-vectors for the force and torque components
struct Wrench {
  vec3 force;
  vec3 torque;
};

//! A point contact between 2 bodies
/*!
  Contacts always come in pairs.  When two bodies touch, a contact is defined
  for each of them.  They have the same (or very close to the same) global
  positions, opposite inward pointing normals, and share the same coefficients
  of friction.  These contacts are considered PCWF (point contacts with
  friction), but soft finger contacts could be handled relatively easily.
 */
class Contact {
  //! Pointer to the body this contact is on
  Body *body1;
    
  //! Pointer to the other body involved in this contact
  Body *body2;

  //! Points to the other contact in this pair
  Contact *mate;

  //! Coefficient of static friction
  double cof;

  //! Coefficient of kinetic friction
  double kcof;

  //! Currently this is either frictionless or point contact with friction but could include soft finger contacts later.
  frictionT frictionType;

  //! Contact dimension (num basisvecs): 1 for FL, 3 for PCWF, 4 for SFCE, 4 for SFCL
  int contactDim;

  //! LMI dimension: 1 for FL, 3 for PCWF, 4 for SFCE, 7 for SFCL
  int lmiDim;

  //! coordinates of the contact with respect to body 1
  position loc;

  //! contact normal with respect to body 1 base frame
  vec3 normal; 

  //! Pose of the contact frame with respect to the body1 frame. 
  transf frame;
 
  //! Pose of body 1 in world space at time of contact
  transf body1Tran;

  //! Pose of body 2 in world space at time of contact
  transf body2Tran;

  //! Root Inventor node stores arrow geometry representing current contact force
  SoSeparator *contactForcePointers;

  //!  A 6 x contactDim matrix containing the wrenches due to the normal, tangentX and tangentY forces at each contact point (column-major format)
  double *basisVecs;

  //! The maximum normal force for this contact point due to hand torque limits
  double normalForceLimit; 

  //! A contactDim vector containing the optimal values to multiply with basisVecs. This will produce the contact forces necessary to generate the needed object wrench
  double *optimalCoeffs;    

  //! Holds the current dynamic force acting at this contact
  double dynamicForce[6];

public:
  //! Array of wrenches bounding the friction cone
  Wrench *wrench;

  /*! Initializes an empty contact (not really used) */
  Contact() : body1(NULL),body2(NULL),mate(NULL),cof(0.0),
    contactForcePointers(NULL),wrench(NULL) {}

  Contact(Body *b1,Body *b2,const double pos[3],const double norm[3]);
  ~Contact();

  
  /*! Returns a pointer to the other half of this contact pair. */
  Contact *getMate() const {return mate;}

  /*! Returns a pointer to body this contact is on. */
  Body *getBody1() const {return body1;}

  /*! Returns a pointer to the other body invovled in this contact. */
  Body *getBody2() const {return body2;}

  /*! Returns the pose of body1 when this contact was formed. */
  transf getBody1Tran() const {return body1Tran;}

  /*! Returns the pose of body2 when this contact was formed. */
  transf getBody2Tran() const {return body2Tran;}

  /*! Currently returns the normal coefficient of friction, but with soft
    contact finger models this will change. */
  double getTorsionalCof() const {return cof;} // temporary

  /*! Returns the type of friction modeled at this contact. */
  frictionT getFrictionType() const {return frictionType;}

  /*! Returns the contact dimension (number of basis wrenches). */
  int getContactDim() const {return contactDim;}
  
  /*! Returns the dimension of the LMI block for this contact. (used in GFO) */
  int getLmiDim() const {return lmiDim;}

  /*! Returns a pointer to the matrix holding the basis vectors for this
    contact.  (Stored in column-major format).
  */
  double *getBasisVecs() const {return basisVecs;}

  /*! Returns pose of the contact frame relative to the base frame of body1. */
  transf getContactFrame() {return frame;}

  /*! Returns the maximum normal force that can be applied at this contact
      due to torque limtis in the hand.  */
  double getNormalForceLimit() const {return normalForceLimit;}

  /*! Returns the optimal contact force for this contact (result from GFO). */
  double *getContactForce() const {return optimalCoeffs;}

  /*! Returns the current dynamic force acting at this contact. */
  double *getDynamicContactForce() {return dynamicForce;}

  /*! Returns the Inventor root of the pointer geometry for this contact */
  SoSeparator *getContactForcePointers() const {return contactForcePointers;}

  /*! Determines whether this contact will prevent motion of body 1 as
    expressed in local body 1 coordinates */
  bool preventsMotion(const transf& motion) const;

  /*! Connects the mate contact to this one */
  void setMate(Contact *m) {mate = m;}

  /*! Sets the normal force limit based on hand torque limits as computed
    during grasp force optimization.  (Not used) */
  void setNormalForceLimit(double nfl) {normalForceLimit = nfl;}

  /*! Sets the dynamic force acting at this contact during the
    current time step.  Used when drawing contact forces.  */
  void setDynamicContactForce(double f[6])
    {memcpy(dynamicForce,f,6*sizeof(double));}


  double getCof() const;
  void updateCof();
  void setContactForce(double *optmx);
  double getConstraintError();
  void computeWrenches();

  //! Number of force vectors used in each friction cone approximation
  static int numFCVectors;

  //! Maximum separation distance (in mm) between two bodies that are considered to be in contact
  static const double THRESHOLD;

  //! 6 x numFrictionEdges matrix of friction cone boundary wrenches used in dynmaics
  static double frictionEdges[6*MAX_FRICTION_EDGES];

  //! number of fricition edges bounding friction cones
  static int numFrictionEdges;

  static int setUpFrictionEdges(int numLatitudes,int numDirs[], double phi[],
				double eccen[]);

};

void addContacts(Body *body1, Body *body2,ContactSetT contactSet);
void addContacts(Body *body1, Body *body2,ContactSetT contactSet,
	    std::list<Contact *> &cl1, std::list<Contact *> &cl2);


#define CONTACT_HXX
#endif
