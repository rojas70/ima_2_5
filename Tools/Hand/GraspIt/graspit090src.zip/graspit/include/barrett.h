//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: barrett.h,v 1.10 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines the %Barrett hand class, a specialized hand subclass
 */
#ifndef BARRETT_H

#include "joint.h"
#include "robot.h"

class Barrett;

//! The Barrett hand has a special DOF that allows the passively coupled joint to breakaway
/*! The Barrett hand has a special feature that allows the passively coupled
    outer joint of each finger to continue to close if the inner link is
    stopped by a contact.  As the finger opens again the joint becomes
    recoupled when it reaches the point when the breakaway first occurred.
    This only works when dynamics is off.  We just need to add some code to
    check a torque threshold to determine when breakaway occurs during
    dynamic simulation.
*/
class BarrettDOF : public DOF {
  friend class Barrett;

  //! Holds the original joint list while this DOF is in breakaway
  std::list<Joint *> tempList;

  //! Keeps track of the DOF value at which the breakaway occurred
  double reconnectAt;

  /*! Checks the new DOF value.  If it is less than the reconnectAt and the
      DOF is in breakaway, it reconnects the inner joint to the DOF. */
  int setVal(double q1);

 public:
  /*! Copies the data from the generic DOF into the new Barrett DOF */
  BarrettDOF(const DOF &oldDOF);

  /*! Empty destructor (placeholder)*/
  virtual ~BarrettDOF() {}

  /*! Returns whether the DOF is in breakaway mode or not. */
  bool inBreakAway() const {return !tempList.empty();}

  /*! Returns the value at which the inner joint will reconnect to the DOF */
  double getReconnectAt() const {return reconnectAt;}

  /*! Saves the current joint list to templist and removes the first joint
      from the original list, thus disconnecting it from the DOF.
  */
  void breakAway();

  /*! Restores the original joint list, thus reconnecting the inner joint to
      the DOF.
  */
  void reconnect();
};

//! A special hand with a clutch mechanism in each finger that allows the outer joint to continue to close after the inner link is stopped.
class Barrett : public Hand {

 public:
  /*! Empty constructor (placeholder) */
  Barrett(World *w,const char *name) : Hand(w,name) {}

  /*! Performs the usual robot load, but replaces 3 of the DOF's with 
    BarretDOF's */
  int load(QString filename);

  /*! This overrides the original fwdKinematics so that the correct
      values are used when one or more fingers have broken away. */
  void fwdKinematics(double* dofVals,std::vector<transf>& trVec,int chainNum);

  /*! Calls the moveDOFTo in the robot class, but if any of the inner links
      are stopped by a contact, this will call the breakaway routine of the
      associate BarrettDOF.
  */
  ColReportT moveDOFTo(double *desiredDOFVals,double *stepSize,
		       bool renderIt = false,
		       std::vector<Link *> *stoppedLinks = NULL);

  //  void autoGrasp(bool renderIt,double speedFactor);  // not used right now

  /*! Since the hand posture may be saved while one or more joints have broken
      away, it must read in ALL joint values.
  */
  QTextStream& readDOFVals(QTextStream &is);

  /*! Since the hand posture may be saved while one or more joints have broken
      away, it must write out ALL joint values.
  */
  QTextStream& writeDOFVals(QTextStream &os);
};

#define BARRETT__H
#endif
