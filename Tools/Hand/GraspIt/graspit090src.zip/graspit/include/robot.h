//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: robot.h,v 1.17 2004/02/12 21:35:07 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines the robot class hierarchy.
 */

#ifndef ROBOT_H

#include <vector>
#include <qtextstream.h>
#include <qstring.h>
#include "mytools.h"
#include "material.h"
#include "joint.h"
#include "worldElement.h"
#include "body.h"

class Body;
class DynamicBody;
class Robot;
class Hand;
class Grasp;


typedef std::pair<Body *,Body *> BodyPair;
typedef std::vector<BodyPair> ColReportT;

//! A serial chain of links connected by joints
/*! A kinematicChain is a serial chain of links connected by joints.  In a
    robot hand each finger is a kinematic chain.  A chain can also have any
    number of robots attached to its end.  For example, a robot hand can be
    connected to the end of an arm's kinematic chain.  Each chain has a base
    transform that relates the start of the chain to the base frame of the
    robot.  Given values for the joint positions, this class solves the
    forward kinematics for each link in the chain.
*/
class KinematicChain {
  //! Pointer to the robot that this chain is a part of
  Robot *owner;
  
  //! Indicates which chain this is within the robot definition
  int chainNum;

  //! The number of degrees of freedom in the chain
  int numDOF;

  //! The number of joints in the chain
  int numJoints;

  //! The number of links in the chain
  int numLinks;
  
  //! A vector of the indicies of the robot DOF's included in this chain
  std::vector<int> dofNumVec;

  //! A vector of pointers to the joints in the chain
  std::vector<Joint *> jointVec;

  //! A vector of pointers to the links in the chain
  std::vector<Link *> linkVec;

  //! An array where each element corresponds to a link in the chain and the value is the index of the last joint affecting the pose of that link
  int *lastJoint;

  //! A vector of link transforms relative to the robot base
  std::vector<transf> linkTranVec;

  //! The base transform of the chain relative to the robot base
  transf tran;

  //! The current end transform of the chain relative to the robot base
  transf endTran;

  //! A pointer to the root of the chain's Inventor scene graph
  SoSeparator *IVRoot;

  //! A pointer to the Inventor transform corresponding to the base transform of the chain
  SoTransform *IVTran;

  //! Indicates whether any of the joints in the chain have moved since the last update of the kinematics
  bool jointsMoved;

  //! A vector of child robots connected to the last link of the chain
  std::vector<Robot *> children;

  //! The offset transforms relating the base frame of each child robot to the end transform of the chain
  std::vector<transf> childOffsetTran;

  //! The number of child robots connected to the chain
  int numChildren;  

  friend int Joint::setVal(double);
  friend int PrismaticJoint::setVal(double);
  friend int RevoluteJoint::setVal(double);


 public:
  /*! The constructor is called from a robot's load method, and requires a
      a pointer to the robot owning this chain, and the index of which chain
      this is within the robot.
  */
  KinematicChain(Robot *r,int chainNumber) : owner(r),chainNum(chainNumber),
    numJoints(0),numLinks(0),lastJoint(NULL),
    IVRoot(NULL),numChildren(0) {}

  ~KinematicChain();
  
  /*! Returns the number of degrees of freedom in the chain */
  int getNumDOF() const {return numDOF;}

  /*! Returns the number of joints in the chain */
  int getNumJoints() const {return numJoints;}

  /*! Returns the number of links in the chain */
  int getNumLinks() const {return numLinks;}

  /*! Returns the index of the robot DOF corresponding to the i-th DOF of this
    chain.  This function may be not be necessary and may be eliminated.*/
  int getDOFNum(int i) const {return dofNumVec[i];}
  
  /*! Returns a pointer to the i-th joint in the chain */
  Joint *getJoint(int i) const {return jointVec[i];}

  /*! Returns a pointer to the i-th link in the chain */
  Link *getLink(int i) const {return linkVec[i];}

  /*! Returns the index of the last joint in the chain that affects the pose
   of link i*/
  int getLastJoint(int i) const {return lastJoint[i];}

  /*! Returns a pointer to the root of the chain's Inventor scene graph */
  SoSeparator *getIVRoot() const {return IVRoot;}

  /*! Returns a pointer to the Inventor transform corresponding to the base
      transform of the chain */
  SoTransform *getIVTran() const {return IVTran;}

  /*! Returns the base transform of the chain relative to the robot base */
  transf const &getTran() const {return tran;}

  /*! Returns the value of the flag indicating whether the joints have been
    moved since the last time the link poses have been updated
  */
  bool jointsHaveMoved() const {return jointsMoved;}

  /*! Returns the number of robots attached to the end of the chain */
  int getNumAttachedRobots() const {return numChildren;}

  /*! Returns the i-th robot attached to the end of the chain */
  Robot *getAttachedRobot(int i) const {return children[i];}

  /*! Returns the offset transform between the end of the chain and the base
      of the i-th attached robot
  */
  transf const &getAttachedRobotOffset(int i) const{return childOffsetTran[i];}

  int initChain(QTextStream &stream,QString &linkDir);
  transf const &getDesiredEndTran() const;
  void attachRobot(Robot *r,const transf &offsetTr);
  void detachRobot(Robot *r);
  void fwdKinematics(double *jointVals,std::vector<transf> &newLinkTranVec)
    const;
  void updateLinkPoses();

  //  void buildJointConstraints();

};

//! Base class for all robots which are collections of links connected by moveable joints
/*! A robot is collection of link bodies orgainized around a base link.
   Connected to the base link may be 1 or more kinematic chains of links and
   joints.  When a robot is attached to another robot an additional mount
   piece that connects to the base of the child robot may also be defined.
   The structure of a robot is defined in a text configuration file
   [see user documentation] that is parsed by the load method. 
   \p
   Each robot has a collection of DOF's (degrees of freedom) that are
   linked to the individual joints of a kinematic chain.  This allows multiple
   joints to be connected to a single DOF, as in the case of passively coupled
   joints.  The values of the DOF's can be set directly, or when dynamics are
   off, they can be moved from their current position to the new position so
   that if a collision is detected along the way, the movement will stop.
   \p
   If dynamics are on, then new desired DOF positions are set with a call
   to setDesiredDOFVals, and a number of intermediate set points are generated
   for each joint that will ensure a smooth velocity and acceleration profile.
   Built in PD joint controllers use gains specified in the robot configuration
   file to apply approriate forces to each joint to correct error between the
   current joint position and the current set point.
   If a linear cartesian moves are desired, a trajectory generator can smoothly
   interpolate between the desired poses by creating a number of intermediate
   poses.  The inverse kinematics for each of these positions is computed and
   and the resulting joint positions are used as set points for the PD
   controllers.   
*/
class Robot : public WorldElement {
  Q_OBJECT

 private:
  //! Points to a parent robot that this robot is attached to
  Robot *parent;

  //! Records which chain of the parent robot this robot is attached to
  int parentChainNum;

  //! The inverse of the offset transform from parent chain end to this robot's base
  transf tranToParentEnd;

  //! A pointer to an optional mount piece link
  Link *mountPiece;

  
  //  float draggerScale;
  
 protected:

  //! The number of kinematic chains (or fingers) this robot has
  int numChains;

  //! The number of degrees of freedom this robot has
  int numDOF;

  //! A vector of pointers to this robot's kinematic chains
  std::vector<KinematicChain *> chainVec;

  //! A vector of pointers to this robot's DOF's
  std::vector<DOF *> dofVec;

  //! The scale for the Inventor dragger of each DOF
  std::vector<float> dofDraggerScale;

  //! A pointer to the base link (or palm) of the robot
  Link *base;

  //! The currently desired pose of the robot
  transf desiredTran;

  //! The simulation time of when the next change of DOF setpoints should occur
  double dofUpdateTime;

  //! The default translational velocity (mm/sec) to use when generating cartesian trajectories
  double defaultTranslVel;

  //! The default rotational velocity (rad/sec) to use when generating cartesian trajectories
  double defaultRotVel;

  virtual bool simpleContactsPreventMotion(const transf& motion) const;

  /*! This is an internal method called by setTran.  It sets the transform
      of the base link, the mount piece (if it exists), and tells the each
      kinematic chain to update the link poses, which also updates the pose
      of each attached robot.
  */
  virtual void simpleSetTran(transf const& tr) {
    base->setTran(tr);
    if (mountPiece) mountPiece->setTran(tr);
    for (int f=0;f<numChains;f++) chainVec[f]->updateLinkPoses();
  }

  friend void KinematicChain::updateLinkPoses();
  friend void KinematicChain::attachRobot(Robot *r,const transf &offsetTr);

 public:

  /*! This constructor simply initializes an empty robot within world w.  The
    load method must be called to read a configuration file and give structure
    to the robot.
  */
  Robot(World *w,const char *name) : WorldElement(w,name) {
    parent=NULL; parentChainNum = -1;
    mountPiece=NULL;
    numChains = numDOF = 0;
    base = NULL;
    dofUpdateTime=0.0;
  }

  virtual ~Robot();

  /*! Given a chain or tree of connected robots, this will return a pointer to
      the root or base robot.
  */
  Robot *getBaseRobot()
    {if (parent) return parent->getBaseRobot(); return this;}

  /*! Returns a pointer to the parent robot (the robot whose chain this robot
      is connected to).
  */
  Robot *getParent() {return parent;}

  /*! Returns the index of the chain that this robot is connected to.
   */
  int getParentChainNum() {return parentChainNum;}

  /*! Returns the transform from the base of this robot to end frame of the
      parent's kinematic chain that this robot is connected to.
   */
  const transf &getTranToParentEnd() {return tranToParentEnd;}

  /*! Returns the number of degrees of freedom for this robot. */
  int getNumDOF() const {return numDOF;}

  /*! Returns a pointer to the i-th DOF.  */
  DOF *getDOF(int i) const {return dofVec[i];}

  /*! Returns the scale of the i-th DOF dragger.*/
  float getDOFDraggerScale(int i) const {return dofDraggerScale[i];}

  /*! Returns the number of kinematic chains in this robot.*/
  int getNumChains() const {return numChains;}

  /*! Returns a pointer to the cnumber of kinematic chains in this robot */
  KinematicChain *getChain(int i) const {return chainVec[i];}

  /*! Return a pointer to the base link of this robot */
  Link *getBase() const {return base;}

  /*! Returns a point to the mountpiece link (NULL if none exists) */
  Link *getMountPiece() const {return mountPiece;}

  /*! Return the transform which describes the world pose of the robot base
      frame with respect to the world coordinate system.
  */
  transf const &getTran() const {return base->getTran();}

  /*! Returns the current desired pose for the robot.  This is set to the final
      pose of a trajectory when the trajectory generator computes one.
   */
  transf const &getDesiredTran() const {return desiredTran;}

  /*! Returns the default translational velocity (mm/sec) for the robot.*/
  double getDefaultTranslVel() const {return defaultTranslVel;}

  /*! Returns the default rotational velocity (rad/sec) for the robot.*/
  double getDefaultRotVel() const  {return defaultRotVel;}

  /*! Sets the default translational velocity (mm/sec) for the robot.*/
  void setDefaultTranslVel(double v) {defaultTranslVel = v;}

  /*! Sets the default rotational velocity (rad/sec) for the robot.*/
  void setDefaultRotVel(double v) {defaultRotVel = v;}

  /*! Returns the current values of all of the DOF's of the robot.
      dofVals should point to a double array with a length at least equal to
      the number of DOF's of this robot.
  */
  void getDOFVals(double *dofVals) const {
    for (int d=0;d<numDOF;d++) dofVals[d]=dofVec[d]->getVal();
  }

  /*! Sets the given DOF to the given value and updates the link poses.
      Collisions are not checked.
  */
  void setDOFVal(int dofNum,double val) {
    dofVec[dofNum]->setVal(val);
    for (int f=0;f<numChains;f++)
      if (chainVec[f]->jointsHaveMoved()) chainVec[f]->updateLinkPoses();
  }

  /*! Sets the values of the DOF's of this robot to the values in the
      array dofVals.  Then it updates the link poses, but collisions are not
      checked.
  */
  void setDOFVals(double *dofVals) {
    for (int d=0;d<numDOF;d++) dofVec[d]->setVal(dofVals[d]);
    for (int f=0;f<numChains;f++)
      if (chainVec[f]->jointsHaveMoved()) chainVec[f]->updateLinkPoses();
  }

  void getAllLinks(std::vector<DynamicBody *> &allLinkVec);
  void getAllAttachedRobots(std::vector<Robot *> &robotVec);
  virtual int load(QString filename);
  void attachRobot(Robot *r,int chainNum,const transf &offsetTr);
  void detachRobot(Robot *r);
  Link *importMountPiece(QString filename);
  virtual void fwdKinematics(double *dofVals,std::vector<transf>& trVec,int chainNum=0);
  virtual int invKinematics(const transf& endTran,double* dofVals,
			    int chainNum=0); 
  virtual bool contactsPreventMotion(const transf& motion) const;
  virtual int setTran(transf const& tr);
  void setChainEndTrajectory(std::vector<transf>& traj,int chainNum=0);
  void generateCartesianTrajectory(const transf &startTr, const transf &endTr,
				   std::vector<transf> &traj,
				   double startVel, double endVel=0.0,
				   double timeNeeded=-1.0);
  void setDesiredDOFVals(double *dofVals);
  virtual ColReportT moveDOFTo(double *dofVals,double *stepSize,
			       bool renderIt=false,
			       std::vector<Link *> *stoppedLinks = NULL);
  void updateJointValues();
  void applyMotorForces();
  void applyJointFriction();
  virtual void DOFController(double timeStep);
  virtual void buildDOFConstraints(const std::vector<int> &islandIndices,
			     int numBodies,
			     double* Nu,double *eps,
			     double* H, double *g,
			     double h,int &ncn,int &hcn);
  virtual QTextStream &readDOFVals(QTextStream &is);
  virtual QTextStream &writeDOFVals(QTextStream &os);
};

//! A hand is a special type of robot that can have a grasp associated with it.
/*! A hand is a special type of a more generic robot.  Generally it consists of
    a palm as the base link and one or more fingers, which are kinematic
    chains.  One instance of a grasp is associated with each hand, and it is
    usually analyzed each time contacts between the hand and the object to be
    grasped change.  The hand class also provides an autograsp method which 
    closes the fingers at fixed rates until further motion is prevented by
    contacts.
*/
class Hand : public Robot {
  Q_OBJECT

 private:

 protected:
  //! A pointer to the grasp associated with this hand
  Grasp *grasp;

 public:
  Hand(World *w,const char *name);
  virtual ~Hand();

  /*! Returns the number of fingers in the hand.  Fingers are just another name
    for kinematic chains, so this is just a convenience function */
  int getNumFingers() const {return numChains;}

  /*! Returns a pointer to the i-th kinematic chain. */
  KinematicChain *getFinger(int i) const {return chainVec[i];}

  /*! Returns a pointer to the base link of the hand. */
  Link *getPalm() const {return base;}

  /*! Returns a pointer to the associated grasp object. */
  Grasp *getGrasp() const {return grasp;}

  virtual void autoGrasp(bool renderIt,double speedFactor=1.0);
  virtual void DOFController(double timeStep);
  
};

#define ROBOT_H
#endif

