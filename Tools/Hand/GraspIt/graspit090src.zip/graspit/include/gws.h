//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: gws.h,v 1.6 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines the abstract Grasp Wrench Space class and specific GWS classes
 */
#ifndef GWS_H

#include <vector>
#include <set>
#include "matvec3D.h"
#include "contact.h"

class Grasp;
struct coordT;

//! An abstract base class for 6D grasp wrench spaces
/*!
  Specific grasp wrench spaces should be defined as subclasses of this
  class.
*/
class GWS {

 public:

  //! A pointer to the associated grasp
  Grasp *grasp;
  
  //! number of 6D hyperplanes bounding this GWS
  int numHyperPlanes;

  //! 7 x numHyperPlanes matrix of plane coefficients
  double **hyperPlanes;
  
  //! Surface area of 6D hull (returned by qhull)
  double hullArea;
  
  //! Volume of 6D hull (returned by qhull)
  double hullVolume;

  //! If GWS contains the origin, the grasp has force closure
  bool forceClosure;

  //! Number of reference to this GWS.  When it is 0, GWS may be deleted
  int refCount;

  /*! Initializes grasp to \a g.  Zeros hyperplanes and refCount. */
  GWS(Grasp *g) : grasp(g),numHyperPlanes(0),hyperPlanes(NULL),refCount(0) {}

  virtual ~GWS();

  /*! Returns a pointer to the grasp associated with this GWS */
  Grasp *getGrasp() const {return grasp;}

  /*! Adds one reference to this GWS */
  void ref() {refCount++;}

  /*! Removes one reference to this GWS */
  void unref() {refCount--;}

  /*! Returns the current number of references to this GWS */
  int getRefCount() {return refCount;}

  /*! Returns whether this grasp has force closure. */
  bool isForceClosure() {return forceClosure;}

  /*! Returns a string that is the name of the type of GWS. */
  virtual const char *getType() =0;

  /*! Builds the GWS from the contact wrenches. */
  virtual int build() =0;

  virtual int projectTo3D(double *projCoords,std::set<int> fixedCoordSet,
			  std::vector<position> &hullCoords,
			  std::vector<int> &hullIndices);

  //! Array of strings of possible GWS types
  static const char *TYPE_LIST[];

  static GWS *createInstance(const char *type,Grasp *g);


};

//! A class to build an L1 GWS
/*!
  A unit grasp wrench space constructed using the L1 norm of the
  grasp vector (i.e. The sum magnitude of all contact normal forces is 1).
*/
class L1GWS : public GWS {

  //! Name of this type of GWS
  static const char *type;

 public:

  /*! Stub */
  L1GWS(Grasp *g) : GWS(g) {}

  //  virtual ~L1GWS() {}

  int build();

  /*! Returns the name of this type of GWS */
  static const char *getClassType() {return type;}

  /*! Returns the name of this type of GWS */
  virtual const char *getType() {return type;}
};

//! A class to build an L-Infinity GWS
/*!
  A unit grasp wrench space constructed using the L-Infinity norm of the
  grasp vector (i.e. The maximum magnitude of any contact normal force is 1).
*/
class LInfGWS : public GWS {

  //! Name of this type of GWS
  static const char *type;

 public:

  /*! Stub */
  LInfGWS(Grasp *g) : GWS(g) {}
  //  virtual ~LInfGWS() {}

  int build();

  /*! Returns the name of this type of GWS */
  static const char *getClassType() {return type;}

  /*! Returns the name of this type of GWS */
  virtual const char *getType() {return type;}
};

void minkowskiSum(Grasp *g,int c,int &wrenchNum,coordT *wrenchArray,
		  Wrench currSum);


#define GWS_H
#endif
