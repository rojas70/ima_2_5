//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: worldElement.h,v 1.13 2004/02/12 21:35:07 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines the world element base class that is used for all robots and bodies.
 */
#ifndef WORLD_ELEMENT_H
#include "matvec3D.h"
#include <vector>
#include <Inventor/SoType.h>
#include <qstring.h>
#include <qobject.h>

class World;
class SoSeparator;
class Body;

typedef std::pair<Body *,Body *> BodyPair;
typedef std::vector<BodyPair> ColReportT ;

//! The base class for all physical elements within the world.
/*!  A world element is either an individual body or a robot which is comprised
     of a collection of articulated bodies.  It serves as the common base class
     for these two types of elements.
*/
class WorldElement : public QObject{
  Q_OBJECT  ;

 //! This flag indicates whether any contacts have formed or been broken
 // on the robot or body since the last time this flag was reset.
 bool contactsChangedFlag;

 protected:
  //! A pointer to the world that this element is a part of
  World *myWorld;

  //! A pointer to the root of this element's Inventor scene graph
  SoSeparator *IVRoot;
 
  //! Holds the file name associated with this element.  For bodies this is the geometry file, for robots its the configuration file.
  QString myFilename;

  //! Holds the name of this element
  QString myName;

  WorldElement(World *w,const char *name);
  WorldElement(const WorldElement &e);

 public:
  virtual ~WorldElement();

  /*! Returns the world the element is a part of */
  World *getWorld() const {return myWorld;}

  /*! Returns a pointer to the root of this element's Inventor scene graph */
  SoSeparator *getIVRoot() const {return IVRoot;}

  /*! Returns the filename associated with this element */
  QString getFilename() const {return myFilename;}

  /*! Returns the name of this element */
  QString getName() const {return myName;}

  /*! Returns the current pose of this element relative to the world frame.
      This is a purely abstract function that is reimplemented in the robot
      and body classes */
  virtual const transf& getTran() const =0;

  /*! Checks whether contacts on the element will prevent the element from 
      making the motion described by the transform motion.  This is a purely
      abstract function that is reimplemented in the robot and body classes */
  virtual bool contactsPreventMotion(const transf& motion) const =0;

  /*! Returns the state of the contactsChanged flag. */
  bool contactsChanged() const {return contactsChangedFlag;}

  /*! This function is called whenever a contact is formed or broken on a body
      or any body that is part of a robot.
  */
  virtual void setContactsChanged() {contactsChangedFlag=true;}

  /*! This function is called after a grasp has been analyzed. */
  virtual void resetContactsChanged() {contactsChangedFlag=false;}

  /*! Sets the current pose of the element with respect to the world frame.
      This is a purely abstract function that is reimplemented in the robot and
      body classes.
  */
  virtual int setTran(transf const& newTr)=0;
  
  virtual ColReportT moveTo(transf &tr,double translStepSize,double rotStepSize);

  static WorldElement *createInstance(const QString &className,
				      World *parent,const char *name);
};

#define WORLD_ELEMENT_H
#endif
