//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: grasp.h,v 1.11 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines the grasp class, which analyzes grasps
 */
#ifndef GRASP_HXX
#include <list>
#include <vector>
#include <set>
#include <qobject.h>

#include "matvec3D.h"


//Inventor includes
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/Qt/viewers/SoQtExaminerViewer.h>
class SoTransform;
class SoCoordinate3;
class SoIndexedFaceSet;


class Hand;
class GraspableBody;
class Contact;
class GWS;
class QualityMeasure;
class QMDlg;
class GWSprojection;

#define MAX_FEAS_LOOPS	100  // max iteration steps in a feasibility phase
#define MAX_OPTM_LOOPS  100  // max iteration steps in a optimization phase

extern bool saveSetup;
extern int saveCounter;

//! A grasp occurs between a hand and an object and has quality measures associated with it.  It also has methods to optimize grasping forces.

/*! Each hand object has a grasp associated with it, and the grasp occurs
    between the hand and a graspableBody.  When contacts change between the
    two, the grasp is updated, meaning each grasp wrench space associated with
    the grasp is rebuilt, as well as any grasp wrench space projections.  All
    grasp quality measures are also re-evaluated.  The grasp class also
    contains several methods that are used for grasp force optimization.
    These use a linear matrix inequality technique and are adapted from code
    written by Li Han and Jeff Trinkle.  More information regarding their
    algorithm can be found in: L. Han, J. Trinkle, and Z. Li, "Grasp Analysis
    as Linear Matrix Inequality Problems," \e IEEE \e Transactions \e on
    \e Robotics \e and \e Automation, Vol. 16, No. 6, pp. 663--674, December,
    2000.
*/
class Grasp : public QObject{
  Q_OBJECT

  //! A pointer to the hand that owns this grasp object
  Hand *hand;

  //! A pointer to the object that is the focus of this grasp
  GraspableBody *object;

  //! \c TRUE if the grasp has been updated since the last time the contacts changed
  bool valid;

  //! A list of pointers to the associated grasp wrench spaces
  std::list<GWS *> gwsList;

  //! A list of pointers to the associated quality measures
  std::list<QualityMeasure *> qmList;

  //! A list of pointer to the associated grasp wrench space projections
  std::list<GWSprojection *> projectionList;

  //! Number of quality meausre in the list
  int numQM;

  //! A vector of pointers to the contacts on the object where it touches the hand 
  std::vector<Contact *> contactVec;

  //! Number of grasp contacts
  int numContacts;

  //! Used when saving output from grasp force optimization analysis
  int graspCounter;

  //! Minimum grasp wrench that can be applied given contact forces that sum to 1
  double minWrench[6];  

  /***** Additions from Li Han's code to do grasp force optimization *********/
  //! Number of basis wrenches for grasp map (3 * numContacts for PCWF)
  int numWrenches; 

  //! A \a (6 * numWrenches) matrix containing basis wrenches for each contact vertex (stored in column-major format)
  double *graspMap; 

  //! Dimension of the null space of the grasp map
  int nullDim;

  //! The null space of the grasp map; (column-major)
  double *nullSpace;

  //! vector of size \a (numWrenches+1), the optimal grasp contact forces, computed from optmz0 and the objective value.
  double *optmx0;   

  //! vector of size \a numDOF storing the optimal torque for each DOF
  double *optTorques; 

  //! Min norm solution to \f$\mbox{GraspMap} * x = F_{ext}\f$
  double *minNormSln;

  //! The number of degrees of freedom of the hand
  int numDOF;

  //! The grasp jacobian
  double *Jacobian;

  //! temporary: should come from hand object
  double *externalTorques; 
  
  //! These variables are used by maxdet package.  Refer to maxdet manual for their explainations.
  int L, K, GPkRow, *F_blkszs,*G_blkszs;                 

  //! These variables are used by maxdet package.  Refer to maxdet manual for their explainations.
  double *F, *G, *Z, *W, *c, constOffset;

  //! Termination criteria used in maxdet algorithm. Refer to maxdet manual.
  double gamma, abstol, reltol; 

  //! If it is 1, then terminate the force feasibility phase whenever the objective value becomes negative, i.e. find one valid grasp force. Otherwise, use the regular maxdet termination.
  int negativeFlag;

  //! Is the grasp force optimization feasible?
  int feasible;

  //! On entry, the maximum number of total Newton iteraions, and on exit, the real number of Newton Iterations in the feasible phase.
  int feasNTiters;

  //! Vector of size \a m, the \a z value corrsponding to the initial feasible grasp forces computed in force feasibility phase.
  double *initz0;

  //! The counterpart to feasNTiters
  int optmNTiters;

  //! Vector of size \a m, the \a z value corresponding to optimal grasp forces, computed in force optimization phase.
  double *optmz0;

  //! Vector of size \a (m+3), \a optmz0, as well as the corresponding objective value, duality gap, and number of optimization iteration steps.
  double *extendOptmz0;

  //! array of dimension \a (m+3)*Number_of_Iterations_at_the_Feasibility_Phase, the history (iterative values) of z, objective value, duality gap and iteration number in force feasibility phase at each simulation step.
  double *feasZHistory; 

 // array of dimension \a (m+3)*Number_of_Iterations_at_the_Optimization_Phase, the counterpart to feasZHistory in the optimization phase.
  double *optmZHistory;

  //! array of dimension \a (m+3)*(Number_of_Iterations_at_Optimization_Phase+1), optmZHistory, + 1: the initial feasible grasp force, its objective value, duality gap and number of iterations 
  double *extendOptmZHistory; 

 //! array of dimension \a (NumWrenches+1)*Number_of_Iterations_at_the_Feasibility_Phase, the history of grasp forces x and objective value in the force feasibility phase at the last simulation step.
  double *feasXHistory;

 //! array of dimension \a (NumWrenches+1)*(Number_of_Iterations_at_the_Optimization_Phase+1), the counterpart to feasXHistory in the optimization phase at the last step.
  double *optmXHistory;

  //! Output file pointer for saving the results of a GFO analysis
  FILE *pRstFile;

  void minimalNorm();
  void computeNullSpace();
  

  // friction LMI helper functions
  void lmiFL(double *lmi,int rowInit, int colInit, int totalRow);
  void lmiPCWF(double cof, double *lmi,int rowInit, int colInit, int totalRow);
  void lmiSFCE(double cof, double cof_t,double *lmi,int rowInit, int colInit,
	       int totalRow);

  void lmiSFCL(double cof, double cof_t,double *lmi,int rowInit, int colInit,
	       int totalRow);

  double *lmiTorqueLimits();
  void lmiFL();
  void lmiPWCF();
  void lmiSFCE();
  void lmiSFCL();
  double *lmiFrictionCones();

  double *weightVec();
  void feasibilityAnalysis();
  void optm_EffortBarrier();
  void computeObjectives();
  double *xzHistoryTransfrom(double *zHistory,int numIters);


  /**************************************************************************/
  bool checkRelativeMotion(const transf& motion,bool handMoving);
  double *getLinkJacobian(int f, int l);

  friend class QMDlg;

signals:
  void graspUpdated();

public:
  Grasp(Hand *h);
;
  ~Grasp();

  /*! Returns whether the grasp has been updated since the last time grasp
    contacts have changed. */
  bool                    isValid() const {return valid;}

  /*! Returns whether the grasp force optimization problem is feasible. */
  bool                    isFeasible() const {return feasible;}

  /*! Returns the number of quality measures defined for this grasp. */
  int                     getNumQM() const {return numQM;}

  /*! Return a pointer to the object that is the focus of this grasp. */
  GraspableBody *         getObject() const {return object;}

  /*! Return the number of grasp contacts. */
  int                     getNumContacts() const {return numContacts;}

  /*! Return a pointer to the i-th grasp contact on the object. */
  Contact *               getContact(int i) const {return contactVec[i];}

  /*! Return a pointer to the grasp jacobian matrix. */
  double *                getJacobian() const {return Jacobian;}

  /*! Return the optimal DOF forces (the results of GFO). */
  double *                getOptDOFEfforts() const {return optTorques;}

  void                    getMinWrench(double *w) const
  {
    if (w) memcpy(w,minWrench,6*sizeof(double));
  }

  void                    setMinWrench(double *w)
  {
    if (w) memcpy(minWrench,w,6*sizeof(double));
  }

  /*! Sets graspableBody \a g to be the new focus of the grasp and updates the
    grasp. */
  void                    setObject(GraspableBody *g) {object = g; update();}


  bool checkLinkMotion();
  bool checkHandMotion();

  void collectContacts();
  void buildGraspMap();
  void buildJacobian();
  void computeContactForceLimits();
  int  findOptimalGraspForce();

  void update();


  GWS *addGWS(const char *type);
  void removeGWS(GWS *gws);
  void addQM(QualityMeasure *qm);
  void replaceQM(int which,QualityMeasure *qm);
  QualityMeasure *getQM(int which);
  void removeQM(int which);
  
  void addProjection(GWSprojection *gp);
  void removeProjection(GWSprojection *gp);
  static void destroyProjection(void * user, SoQtComponent * component);
  static double GFO_WEIGHT_FACTOR;

};

#define GRASP_HXX
#endif





