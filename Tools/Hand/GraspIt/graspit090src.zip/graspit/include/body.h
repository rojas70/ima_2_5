//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: body.h,v 1.21 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines the body class hierarchy.
 */
#ifndef BODY_HXX

#include "worldElement.h"
#include "contact.h"
#include "PQP.h"
#include <list>
#include <vector>
#include <qtextstream.h>
#include <qstring.h>

class SoCoordinate3;
class SoGroup;
class SoIndexedFaceSet;
class SoMaterial;
class SoScale;
class SoSeparator;
class SoSwitch;
class SoTranslation;
class SoTransform;

class Contact;
struct PQPContactPt;

class Robot;
class DynJoint;
class World;

//! A triangular body face used in computing mass properties.
/*!
  For use with Mirtich's mass property code
*/
typedef struct {
  double norm[3];
  double w;
  double *verts[3];
} FACE;

//! A generic simulation body.
/*! A generic body is defined by its geometry, its material, and a transform.
    Body instances are considered obstacles--they can form contacts with other
    objects but are not part of of the dynamics system.
*/
class Body : public WorldElement {
  Q_OBJECT

protected:
  //! The surface material of the body specified as an index to the world material list
  int material; 

  //! The body's world position (translations are in mm)
  transf Tran;  

  //! The id returned by the collision detection system.
  int id;  

  //! The number of contacts on the body
  int numContacts;

  //! The current contacts on the body
  std::list<Contact *> contactList; 

  //! This flag determines whether the body's friction cones should be shown
  bool showFC;

  //! A pointer to the root node of the geometry loaded from the model file
  SoGroup *IVGeomRoot; 

  //! A pointer to the Inventor transform for the body
  SoTransform *IVTran;  

  //! A pointer to the material node that controls this body's transparency
  SoMaterial *IVMat;

  //! A pointer to the root of the friction cones on this body
  SoSeparator *IVCones;

  //! Inventor material for all friction cones
  static SoMaterial *coneMat;

  //! Inventor material for the z axis within a friction cone
  static SoMaterial *zaxisMat;

  //! Parameter to control the height of friction cones
  static const float CONE_HEIGHT;

  //! Keeps track of how many bodies are defined.  At 0, static friction cone properties are deleted.
  static int instanceCount;

  Body (const Body &b);
  virtual void drawFrictionCone(Contact *c);

  /////////////////////////////// PUBLIC /////////////////////////////////
public:
  Body(World *w,const char *name=0);
  virtual ~Body();

  /*! Individual bodies belong to themselves.  The link definition overrides
    this and returns the robot.
  */
  virtual WorldElement *getOwner() {return (WorldElement *)this;}

  /*! Function determines whether instance is dynamic (overridden in
    DynamicBody)
  */
  virtual bool isDynamic() const {return false;}

  /*! Returns the current material of the body. 
   * \sa setMaterial()
   */
  int getMaterial() const {return material;}

  /*! Returns the Inventor material for the body. */
  SoMaterial *getIVMat() const {return IVMat;}

  /*! Returns the collision detection id of the body. */
  int getId() const {return id;}

  /*! Returns a pointer to the root of the Inventor geometry that was loaded.
   */
  SoGroup *getIVGeomRoot() const {return IVGeomRoot;}

  /*! Returns a pointer to the Inventor transform node for the body. */
  SoTransform *getIVTran() const {return IVTran;}

  /*! Returns a pointer to the root of the Inventor subtree containing the 
    friction cones.
  */
  SoSeparator *getIVCones() const {return IVCones;}

  /*! Returns the current pose of the body. */
  transf const& getTran() const {return Tran;}

  /*! Returns the number of contacts on the body. */
  int getNumContacts() const {return numContacts;}

  /*! Returns a copy of the body's contact list. */
  std::list<Contact *>getContacts() const {return contactList;}

  /*! Returns the value of the flag determining whether friction cones are
    shown on this body
  */
  bool frictionConesShown() const {return showFC;}

  float getTransparency() const;

  virtual bool contactsPreventMotion(const transf& motion) const;
  virtual int load(const QString &filename);
  void setMaterial(int mat);
  void setTransparency(float t);
  void showFrictionCones(bool on);
  virtual void addContact(Contact *c);
  virtual void removeContact(Contact *c);
  virtual void breakContacts();
  virtual void redrawFrictionCones();
  virtual int setTran(transf const& newTr);

  friend QTextStream& operator<<(QTextStream &os, const Body &b);

};

//! The superclass for all bodies that take part in the dynamics.
/*! A dynamic body adds mass parameters to the generic body description.
    It also includes the state variables q and v, which encode the position
    and velocity of the body at the current time step of the dynamics.
*/
class DynamicBody : public Body {
  Q_OBJECT

  //! Is this body affected by dynamics?
  bool useDynamics;

  //! projection integrals used in mass properties computations
  double P1, Pa, Pb, Paa, Pab, Pbb, Paaa, Paab, Pabb, Pbbb;

  //! face integrals used in mass properties computations
  double Fa, Fb, Fc, Faa, Fbb, Fcc, Faaa, Fbbb, Fccc, Faab, Fbbc, Fcca;

 protected:
  //! Center of gravity position (in millimeters)
  position CoG;

  //! Center of gravity position assumming uniform density
  position defaultCoG;

  //! Maximum radius of the body from the center of gravity (in millimeters)
  double maxRadius;

  //! The maximum radius from the default center of gravity
  double defaultMaxRadius;

  //! Mass of the body (in grams)
  double mass;

  //! Is this body fixed in the world frame?
  bool fixed;

  //! World pose a fixed body should maintain
  transf fixedTran;

  //! Points to the dynamic joint connecting this body to its parent
  DynJoint *dynJoint;

  //! Corners of the box bounding the possible world positions of the object
  vec3 bbox_max, bbox_min;

  //! Flag determining whether axes should be shown (origin at COG)
  bool showAx;

  //! Flag determining whether dynamic contact forces for this body should be drawn
  bool showDynCF;

  //! Inventor root of the axes in the body subtree
  SoSwitch *IVAxes;

  //! Inventor root of the worst case disturbance wrench indicator
  SoSeparator *IVWorstCase;

  //! Inventor transform from body frame to center of gravity
  SoTranslation *axesTranToCOG;

  //! Inventor scale for axes so that they extend outside the body
  SoScale *axesScale;

  // parameters for dynamics
  double a[6];       // in mm/sec^2
  double v[6];       // in mm/sec
  double q[7];       // in mm
  std::list<double *> qStack;
  std::list<double *> vStack;
  double markedV[6];
  double markedQ[7];
  double startq[7];
  double I[9];
  
  //! holds uniform density mass properties (scaled for unity mass)
  double defaultI[9];

  bool dynamicsComputedFlag;

  double j[6];  // impulse

  double externalWrench[6];
  double extWrenchAcc[6];

  void compProjectionIntegrals(FACE &f,int A,int B);
  void compFaceIntegrals(FACE &f,int A,int B,int C);

  void init();

public:
  DynamicBody(World *w, const char *name=0);
  DynamicBody(const Body &b, double m);
  virtual ~DynamicBody();

  /*! Returns the center of gravity position. */
  position const& getCoG() const {return CoG;}

  /*! Returns the max radius of the body. */
  double getMaxRadius() const {return maxRadius;}

  /*! Returns the mass of the body (in grams).
   * \sa setMass()
   */
  double getMass() const {return mass;}

  double *getExtWrench() {return externalWrench;}

  /*! Returns a pointer to the body's 3x3 inertia tensor (stored as an array).
   */
  const double *getInertia() const {return I;} 

  /*! Returns a pointer to the body's 6x1 velocity vector. */
  const double *getVelocity() {return v;}

  /*! Returns a pointer to the body's 6x1 acceleration vector (simple first
    order approximation).
   */
  const double *getAccel() {return a;}

  // is this really needed?
  const double *getImpulse() {return j;}

  /*! Returns a pointer to the body's 7x1 position vector [3x1 translation , 
     4x1 quaternion]
   */
  const double *getPos() {return q;} 

  /*! The returns a pointer to the Inventor subgraph containing the worst case
    indicator */
  SoSeparator *getIVWorstCase() const {return IVWorstCase;}

  /*! Returns whether the body is fixed within the world
   */
  bool isFixed() const {return fixed;}

  /*! Returns whether this body is affected by dynamics
    \sa setUseDynamics()
   */
  bool isDynamic() const {return useDynamics;}

  /*! Returns the world pose a fixed body should maintain */
  const transf& getFixedTran() const {return fixedTran;}

  /*! Returns the dynamic joint connecting this body to its parent or NULL
   * if there is none
   */
  virtual DynJoint *getDynJoint() {return dynJoint;}

  /*! Returns whether axes are drawn for this body */
  bool axesShown() const {return showAx;}

  /*! Returns whether dynamic contact forces should be drawn for this body */
  bool dynContactForcesShown() const {return showDynCF;}

  /*! Sets whether this body should be affected by dynamics.  Rather than
      creating a new static body when a body is set to be static, we just set
      this flag to false.  That way if the body is made dynamic again, many\
      parameters won't have to be recomputed.
  */
  void setUseDynamics(bool dyn) {useDynamics = dyn;}

  /*! Returns whether the dynamics have been computed for this body during
    the current dynamics iteration.
    \sa setDynamicsFlag()
    \sa resetDynamicsFlag()
  */
  bool dynamicsComputed() const {return dynamicsComputedFlag;}  

  /*! At the end of the dynamics iteration, this is used to reset the
    dynamicsComputed flag
   */
  void resetDynamicsFlag() {dynamicsComputedFlag = false;}
  
  /*! This is called to set the dynamicsComputed flag after the motions for
    this body have been computed during the current iteration of the dynamics.
   */
  void setDynamicsFlag() {dynamicsComputedFlag = true;}

  /*! Sets whether axes should be drawn for this body */
  void showAxes(bool on);

  /*! Sets whether dynamic contact forces should be drawn for this body */
  void showDynContactForces(bool on);

  /*! Sets the current 7x1 position vector */
  bool setPos(double *new_q);

  /*! Sets the current 6x1 velocity vector [vx vy vz vrx vry vrz] */
  void setVelocity(double *new_v)  {memcpy(v,new_v,6*sizeof(double));}

  /*! Sets the current 6x1 acceleration vector */
  void setAccel(double *new_a)  {memcpy(a,new_a,6*sizeof(double));}

  /*! Sets the world boundaries for this body.  This is so a body can't fall
     forever.
  */
  void setBounds(vec3 minBounds,vec3 maxBounds)
    {bbox_min = minBounds; bbox_max = maxBounds;}
  
  /*! Sets the body's mass in grams to m.
    \sa getMass()
   */
  void setMass(double m) {mass = m;}

  /*! Returns the value of the external wrench accumulator. */
  double *getExtWrenchAcc() {return extWrenchAcc;}

  /*! Sets the value of the external wrench accumulator to \a w. */
  void setExtWrench(double *w) {memcpy(externalWrench,w,6*sizeof(double));}

  virtual int load(const QString &filename);
  void computeMassProp(double **vlist,int numFaces);
  void resetExtWrench();
  void addExtWrench(double *extW);
  void addTorque(vec3 torque);
  void addRelTorque(vec3 torque);
  void addForce(vec3 force);
  void addForceAtPos(vec3 force,position pos);
  void addForceAtRelPos(vec3 force,position pos);
  void fix();
  virtual void setDynJoint(DynJoint *dj);
  void unfix();
  void pushState();
  void popState();
  void markState();
  void returnToMarkedState();
  virtual int setTran(transf const& newTr);
  virtual void breakContacts() {Body::breakContacts();}
  void setMassProp(const position& newCoG,double *newI);


  /*! Holds a default mass in case a body file doesn't specify one.
   *  The other mass properties can be computed assuming uniform density
   */
  static double defaultMass;
};

//! Used for bodies that are part of a robot.
/*! A link is a dynamic body that notifies its owner robot when contacts have
    changed.
*/
class Link : public DynamicBody {
  Q_OBJECT

  friend class Robot;
  friend class KinematicChain;

 protected:

  //! A pointer to the robot that this link is a part of
  Robot *owner;

  //! Identifies what part of the robot this link is
  int chainNum,linkNum;

 public:
  Link(Robot *r,int c, int l,World *w,const char *name=0);
  virtual ~Link();

  /*! Returns a pointer to the robot owning this link. */
  virtual WorldElement *getOwner() {return (WorldElement *)owner;}

  /*! Returns which chain this link is a part of. */
  int getChainNum() const {return chainNum;}

  /*! Returns which link in the chain this link is. */
  int getLinkNum() const {return linkNum;}
  
  virtual void setContactsChanged();

  //temporary
  void setFixedTran(const transf &tr) {fixedTran = tr;}
  
};

//! Used for dynamic bodies that are not part of a robot.
/*! A Graspable body is partially transparent by default and shows the
    locations of any contacts on its surface.
*/
class GraspableBody : public DynamicBody {
  Q_OBJECT

  //! A pointer to the Inventor root of the shape primitives for this body
  SoSeparator *IVGeomPrimitives;

 public:
  GraspableBody(World *w, const char *name=0);
  virtual ~GraspableBody();

  /*! If the body has shape primitives defined (i.e. they were found when the
    body was loaded), this returns a pointer to the Inventor root node of
    that tree.  Otherwise, it returns NULL. */
  SoSeparator *getIVGeomPrimitives() const {return IVGeomPrimitives;}

  virtual int load(const QString &filename);

  friend QTextStream& operator<<(QTextStream &os, const GraspableBody &gb);

};


#define BODY_HXX
#endif


