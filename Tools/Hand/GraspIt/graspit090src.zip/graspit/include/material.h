//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: material.h,v 1.4 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################

#ifndef MATERIAL_HXX

enum materialT {frictionless, glass, metal, wood,plastic, rubber, invalid};

#define NUM_MATERIAL 7

extern double Cof[NUM_MATERIAL][NUM_MATERIAL];
extern double KineticCof[NUM_MATERIAL][NUM_MATERIAL];
extern char *matNameList[NUM_MATERIAL];

void initCof();
materialT readMaterial(const char *matStr);
void getMaterialStr(materialT mat,char *str);
const char *getMaterialStr(materialT mat);

#define MATERIAL_HXX
#endif

