//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author:  Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: ivmgr.h,v 1.12 2004/02/12 21:35:06 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Defines the IVmgr class which handles 3D user interaction.
 */
#ifndef IVMGR_HXX
#include <Inventor/SbBasic.h>
#include <Inventor/SbLinear.h>
#include <list>
#include <vector>
#include <qstring.h>
#include <qwidget.h>
#include "material.h"

class ivcollide;
struct VCReportType;
class SbVec3f;

class QWidget;
class SoQtExaminerViewer;
class SoBlinker;
class SoCenterballDragger;
class SoHandleBoxDragger;
class SoTranslate1Dragger;
class SoRotateDiscDragger;
class SoDragger;
class SoMaterial;
class SoPath;
class SoPickedPoint;
class SoScale;
class SoSelection;
class SoSeparator;
class SoText2;
class SoTransform;
class SoEventCallback;
class SoSensor;
class SoNodeSensor;
class SoQtRenderArea;
class World;
class WorldElement;
class Robot;
class KinematicChain;
class DOF;
class GraspableBody;
class Body;
class Finger;
class Grasp;
class GWS;
class GWSprojection;
class QualityMeasure;
struct DraggerInfo;

class position;


#define HANDS_DIR "../../hands/"
#define OBJECTS_DIR "../../objects/"
#define MAX_POLYTOPES 15
#define MAX_COLLISIONS 5

typedef double col_Mat4[4][4];

/*
typedef struct {
  int numCols;
  VCReportType *colReport;
} CBdataT;
*/

enum ToolType {TRANSLATE_TOOL,ROTATE_TOOL,SELECT_TOOL};

//! Handles 3D interactions with the world
/*!
  There is one instance of the Inventor Manager within the application.  It
  handles all 3D user interaction with the main world.  An examiner viewer
  provides the user with a way to manipulate a virtual camera to view the
  simulation world.  The user can also use the mouse to select bodies, or
  create draggers that allow manipulation of elements within the world.
  This class also handles the display of contact forces and some other
  indicators, and can render and save an image of the current scene.
 */
class IVmgr : public QWidget {
  Q_OBJECT

  //  friend void addQualityMeasureDlg(Widget w,XtPointer clientData,
  //				   XtPointer callData);
  //  friend void addQualityMeasure(Widget w,XtPointer clientData,
  //				XtPointer callData);

 private:
  //! Global ivmgr pointer for use with static callback routines.  There is only one ivmgr.    
  static IVmgr *ivmgr;

  //! Points to the main world associated with this iteraction manager
  World *world;

  //! File pointer used to read or record camera positions when making a movie
  FILE *camerafp;

  //! Base filename fir recording an image sequence 
  const char *imgSeqStr;

  //! Current frame counter used in recording an image sequence
  int imgSeqCounter;

  /*  CBdataT CBdata;

  SoPath *draggerPath;
  SoScale *draggerScale;
  SoTransform *lastTran;
  SbVec3f lastCent;
  */

  //! Current interaction tool selected (translate, rotate, or select)
  ToolType currTool;

  //! A flag indicating whether the control key is down during a mouse click
  SbBool CtrlDown;

  //! A flag indicating whether the shift key is down during a mouse click
  SbBool ShiftDown;


  //  SoSeparator *IVContactRoot;
  SoSeparator *pointers;
  /*  SoSeparator *forcePointer;
  SoSeparator *torquePointer;
  SoTransform *tpTran;
  SoTransform *fpTran;
  SoSeparator *axes;
  SoSeparator *hullaxes;
  SoSeparator *objectWrenchSep;
  */

  //! An array of pointers to blinker nodes that correspond to individual contact force indicators
  SoBlinker ** contactForceBlinkerVec;

  //! A pointer to the examiner viewer which inventor component facilitating user interaction
  SoQtExaminerViewer *myViewer;

  //! Pointer to the root of the entire Inventor scene graph
  SoSeparator *sceneRoot;

  //! Pointer to the sub-tree of selectable Inventor objects
  SoSelection *selectionRoot;

  //! Pointer to the sub-tree of 
  SoSeparator *draggerRoot;

  //! Pointer to sub-tree containing wireframe versions of bodies when they are selected
  SoSeparator *wireFrameRoot;

  //! Pointer to an empty separator
  SoSeparator *junk;

  //! Pointer to the material node controlling the color of dynamic force indicatores
  SoMaterial *dynForceMat;


  //  int saveCounter;

  void setupPointers();
  void transRot(DraggerInfo *dInfo);
  void revoluteJointChanged(DraggerInfo *dInfo);  
  void prismaticJointChanged(DraggerInfo *dInfo);
  void makeCenterball(WorldElement *selectedElement,Body *surroundMe);
  void makeHandleBox(WorldElement *selectedElement,Body *surroundMe);
  void makeJointDraggers(Robot *robot,KinematicChain *chain);
  void drawWireFrame(SoSeparator *elementRoot);
  SoPath *pickFilter(const SoPickedPoint *pick);
  void handleSelection(SoPath* p);
  void handleDeselection(SoPath* p);  
  void deleteSelections();
  void setCtrlDown(SbBool status) {CtrlDown = status;}
  void setShiftDown(SbBool status) {ShiftDown = status;}
  void spaceBar();
  void keyPressed(SoEventCallback *eventCB);

  //! static callback routine for when a body dragger is moved
  static void transRotCB(void *dInfo,SoDragger *dragger);

  //! static callback routine for when a disc dragger is moved
  static void revoluteJointChangedCB(void *dInfo,SoDragger *dragger);
  
  //! static callback routine for when an arrow dragger is moved
  static void prismaticJointChangedCB(void *dInfo,SoDragger *dragger);

  //! static callback routine for mouse events
  static void shiftOrCtrlDownCB(void *,SoEventCallback *eventCB);

  //! static callback routine for keyboard events
  static void keyPressedCB(void *,SoEventCallback *eventCB);

  //! static callback routine for selections
  static void selectionCB(void *,SoPath *p);

  //! static callback routine for deselections
  static void deselectionCB(void *,SoPath *p);

  //! static callback routine for pick events (before selections or deselections)
  static SoPath *pickFilterCB(void *,const SoPickedPoint *pick);

public slots:
  void drawDynamicForces();
  void drawWorstCaseWrenches();
  void saveNextImage();
  void saveCameraPos();
  void restoreCameraPos();

public:
  IVmgr(QWidget *parent=0,const char *name=0,WFlags f=0);
  ~IVmgr();

  /*! 
    Returns a pointer to the main World that the user interacts with through
    this manager.
   */
  World *getWorld() const {return world;}

  /*!
    Returns a pointer to the Inventor examiner viewer.
  */
  SoQtExaminerViewer *getViewer() const {return myViewer;}  

  /*!
    Returns the Inventor sub-tree that holds the pointer shapes (arrow and
    torque pointer) read in during start up.
  */
  SoSeparator *getPointers() const {return pointers;}

  void setTool(ToolType newTool);
  void emptyWorld();
  void hilightObjContact(int contactNum);
  void unhilightObjContact(int contactNum);

  void saveImageSequence(const char *fileStr);
  int saveCameraPositions(const char *filename);
  int useSavedCameraPositions(const char *filename);

  void saveImage(QString filename);
  void beginMainLoop();

};

#define IVMGR_HXX
#endif
