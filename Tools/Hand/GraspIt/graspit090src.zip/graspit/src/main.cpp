//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: main.cpp,v 1.19 2004/02/12 20:59:24 amiller Exp $
//
//######################################################################

/*! \mainpage GraspIt! Developer Documentation
  \image html logo.jpg

  These pages document the GraspIt! source code. Please remember this is
  research code. There are still plenty of pieces of code that are unfinished
  and several bugs that need to be fixed.

  This documentation does not cover other packages included in the GraspIt!
  distribution. In many cases the original code for these packages has been
  modified and needs further documentation.  The most important modification
  is the contact determination system added to PQP.  However, due to
  limitations in using PQP to determine contacts, we hope to be replacing this
  with our own software in the future.

  More information and original source code for the packages included with
  GraspIt! can be found in the following places:

  - <b>VCOLLIDE:</b> <A HREF="http://www.cs.unc.edu/~geom/V_COLLIDE">www.cs.unc.edu/~geom/V_COLLIDE</A>
  - <b>PQP:</b> <A HREF="http://www.cs.unc.edu/~geom/SSV">www.cs.unc.edu/~geom/SSV</A>
  - <b>ivcollide:</b> website no longer available.  Author e-mail: <A HREF="mailto:manowitz@alum.mit.edu">manowitz@alum.mit.edu</A>
  - <b>qhull:</b> <A HREF="http://www.qhull.org">www.qhull.org</A>
  - <b>maxdet:</b> <A HREF="http://www.stanford.edu/~boyd/MAXDET.html>www.stanford.edu/~boyd/MAXDET.html</A>

  
 */

/*! \file
  \brief Program execution starts here.  Server is started, main window is built, and the interactive loop is started.
 */

#include <iostream>
#include <graspitApp.h>
#include "graspitGUI.h"
#include "graspitServer.h"
#include "mainWindow.h"

#ifdef Q_WS_WIN
#include <windows.h>
#include <wincon.h>
#endif

//#define GRASPITDBG

int main(int argc, char **argv)
{
#ifdef GRASPITDBG
#ifdef Q_WS_WIN
  AllocConsole(); 
  freopen("conin$", "r", stdin); 
  freopen("conout$", "w", stdout); 
  freopen("conout$", "w", stderr); 
  //ios::sync_with_stdio();
#endif
#endif

  GraspItApp app(argc, argv);
 
  app.showSplash();
  QApplication::setOverrideCursor( Qt::waitCursor );

  GraspItGUI gui(argc,argv);
  GraspItServer server(4765);
 
  app.setMainWidget(gui.getMainWindow());
  QObject::connect(qApp, SIGNAL(lastWindowClosed()), qApp, SLOT(quit()));

  app.closeSplash();
  QApplication::restoreOverrideCursor();

  gui.startMainLoop();
  return 0;
}
