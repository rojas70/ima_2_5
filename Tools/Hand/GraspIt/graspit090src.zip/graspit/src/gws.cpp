//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: gws.cpp,v 1.11 2004/02/12 21:35:27 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Implements the abstract Grasp Wrench Space class and specific GWS classes.
 */

#include <math.h>
#include <string.h>
#include "gws.h"
#include "grasp.h"
#include "mytools.h"
#include "body.h"

extern "C" {
#include "qhull_a.h"
}

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

#define IVTOL 1e-5

const char *GWS::TYPE_LIST[] = {"L1 Norm","LInfinity Norm",NULL};
const char *L1GWS::type = "L1 Norm";
const char *LInfGWS::type = "LInfinity Norm";

typedef double *doublePtr;

/*!
  Deletes all the GWS hyperplanes.
*/
GWS::~GWS()
{
#ifdef GRASPITDBG
  std::cout << "deleting GWS" << std::endl;
#endif

  if (hyperPlanes) {
    for (int i=0;i<numHyperPlanes;i++)
      delete [] hyperPlanes[i];
    delete [] hyperPlanes;
  }
}

/*!
  Creates a GWS whose type string matches \a desiredType.
*/
GWS *
GWS::createInstance(const char *desiredType,Grasp *g)
{
  if (!strcmp(desiredType,L1GWS::getClassType()))
    return new L1GWS(g);

  if (!strcmp(desiredType,LInfGWS::getClassType()))
    return new LInfGWS(g);

  return NULL;
}


/*!
 This uses the \a projCoords and \a fixedCoordSet (which identifies the indices
 of the fixed coordinates) to project the 6D hyperplanes
 of the Grasp Wrench Space into 3D. The \a projCoords is an array of 6 values,
 but only 3 are used.  It then calls qhull to perform a
 halfspace intersection to get the vertices of the 3D volume.  These
 vertices are stored in \a hullCoords, and indices of the individual faces
 that make up the volume are stored in \a hullIndices (an Indexed Face Set).
*/
int
GWS::projectTo3D(double *projCoords,std::set<int> fixedCoordSet,
		   std::vector<position> &hullCoords,
		   std::vector<int> &hullIndices)
{
  int i,j,k,validPlanes,numCoords,numInLoop;
  double **planes;
  int freeCoord[3],fixedCoord[3];

  // qhull variables
  boolT ismalloc;
  int curlong,totlong,exitcode;
  char options[200];  
  facetT *facet;

  if (numHyperPlanes == 0) return SUCCESS;

  planes = (double **) malloc(numHyperPlanes * sizeof(double *));
  if (!planes) {
#ifdef GRASPITDBG
    pr_error("GWS::ProjectTo3D,Out of memory allocating planes array");
    printf("NumHyperplanes: %d\n",numHyperPlanes);
#endif
    return FAILURE;
  }

  validPlanes = 0;

  // determine which dimensions are free and which are fixed
  // the set keeps things ordered
  for (i=0,j=0,k=0;i<6;i++)
    if (fixedCoordSet.find(i) == fixedCoordSet.end())
      freeCoord[k++] = i;
    else
      fixedCoord[j++] = i;

  //
  // project the hyperplanes to three dimensional planes
  //
  for (i=0;i<numHyperPlanes;i++) {
    double len;    

    len=sqrt(hyperPlanes[i][freeCoord[0]]*hyperPlanes[i][freeCoord[0]] +
	     hyperPlanes[i][freeCoord[1]]*hyperPlanes[i][freeCoord[1]] +
	     hyperPlanes[i][freeCoord[2]]*hyperPlanes[i][freeCoord[2]]);

    if (len>1e-11) {
      planes[validPlanes] = (double *) malloc(4 * sizeof(double));
      if (!planes[validPlanes]) {
	pr_error("Out of memory allocating planes array");
	return FAILURE;
      }
      planes[validPlanes][0] = hyperPlanes[i][freeCoord[0]]/len;
      planes[validPlanes][1] = hyperPlanes[i][freeCoord[1]]/len;
      planes[validPlanes][2] = hyperPlanes[i][freeCoord[2]]/len;
      planes[validPlanes][3] = 
	(hyperPlanes[i][6] + 
	 hyperPlanes[i][fixedCoord[0]]*projCoords[fixedCoord[0]] +
	 hyperPlanes[i][fixedCoord[1]]*projCoords[fixedCoord[1]] +
	 hyperPlanes[i][fixedCoord[2]]*projCoords[fixedCoord[2]])/len;
      
      if (planes[validPlanes][3]>0) printf("positive offset!!!!\n");
      validPlanes++;
    }
  }
  
#ifdef GRASPITDBG
  if (validPlanes<numHyperPlanes)
    printf("ignored %d hyperplanes which did not intersect this 3-space\n",
	   numHyperPlanes-validPlanes);
#endif

  //
  // call qhull to do the halfspace intersection
  //
  coordT *array = new coordT[validPlanes*3];
  coordT *p = &array[0];
  
  boolT zerodiv;
  coordT *point, *normp, *coordp, **pointp, *feasiblep;
  vertexT *vertex, **vertexp;

#ifdef GRASPITDBG
  printf("Calling qhull to perform a 3D halfspace intersection of %d planes...\n",validPlanes);
#endif

  ismalloc = False; 	// True if qh_freeqhull should 'free(array)'

  // I want to get rid of this but qh_init needs some sort of file pointer
  // for stdout and stderr
  FILE *qhfp = fopen("logfile","w");

  if (!qhfp) {
	fprintf(stderr,"Could not open qhull logfile!\n");
	qh_init_A(NULL, stdout, stderr, 0, NULL);
  }
  else
   qh_init_A(NULL, qhfp, qhfp, 0, NULL);

  if ((exitcode = setjmp(qh errexit))) {
    delete [] array;
	qh NOerrexit= True;
	qh_freeqhull(!qh_ALL);
	qh_memfreeshort (&curlong, &totlong);
	if (curlong || totlong)  	/* optional */
	   fprintf (stderr, "qhull internal warning (main): did not free %d bytes of long memory (%d pieces)\n",
		 totlong, curlong);
    for (i=0;i<validPlanes;i++)
      free(planes[i]);
    free(planes);
	if (qhfp) fclose(qhfp);
    return FAILURE; //exit(exitcode);
  }
  sprintf(options, "qhull -H0,0,0 Pp");
  qh_initflags(options);
  qh_setfeasible(3);
  if (!(qh feasible_point)) printf("why is qh_qh NULL?\n");
  for(i=0;i<validPlanes;i++) {
    qh_sethalfspace (3, p, &p, planes[i],&(planes[i][3]), qh feasible_point);
  }

  qh_init_B(&array[0], validPlanes, 3, ismalloc);
  qh_qhull();
  qh_check_output();
  if (qhfp) fclose(qhfp);

  //
  // Collect the vertices of the volume
  //
  hullCoords.clear();
  numCoords = qh num_facets;
  hullCoords.reserve(numCoords);
  int *indices = new int[numCoords];

  double scale = grasp->getObject()->getMaxRadius(); // Hmm, is this right?

  point= (pointT*)qh_memalloc (qh normal_size);

  FORALLfacets {
    coordp = point;
    if (facet->offset > 0)
      goto LABELprintinfinite;

    normp= facet->normal;
    feasiblep= qh feasible_point;
    if (facet->offset < -qh MINdenom) {
      for (k= qh hull_dim; k--; )
        *(coordp++)= (*(normp++) / - facet->offset) + *(feasiblep++);
    }else {
      for (k= qh hull_dim; k--; ) {
        *(coordp++)= qh_divzero (*(normp++), facet->offset, qh MINdenom_1,
                                 &zerodiv) + *(feasiblep++);
        if (zerodiv) {
          goto LABELprintinfinite;
        }
      }
    }    
    hullCoords.push_back(position(point[0]*scale,point[1]*scale,
				  point[2]*scale));
    continue;
    LABELprintinfinite:
    hullCoords.push_back(position(qh_INFINITE,qh_INFINITE,qh_INFINITE));
    fprintf(stderr,"intersection at infinity!\n");
  }
  qh_memfree (point, qh normal_size);


  //
  // use adjacency information to build faces of the volume
  //
  double dot;
  vec3 testNormal;

  int numfacets, numsimplicial, numridges, totneighbors, numneighbors,
    numcoplanars;
  setT *vertices, *vertex_points, *coplanar_points;
  int numpoints= qh num_points + qh_setsize (qh other_points);
  int vertex_i, vertex_n;
  facetT *neighbor, **neighborp;
 
  qh_countfacets (qh facet_list, NULL, !qh_ALL, &numfacets, &numsimplicial, 
      &totneighbors, &numridges, &numcoplanars);  /* sets facet->visitid */

  qh_vertexneighbors();
  vertices= qh_facetvertices (qh facet_list, NULL, !qh_ALL);
  vertex_points= qh_settemp (numpoints);
  coplanar_points= qh_settemp (numpoints);
  qh_setzero (vertex_points, 0, numpoints);
  qh_setzero (coplanar_points, 0, numpoints);
  FOREACHvertex_(vertices)
    qh_point_add (vertex_points, vertex->point, vertex);
  FORALLfacet_(qh facet_list) {
    FOREACHpoint_(facet->coplanarset)
      qh_point_add (coplanar_points, point, facet);
  }

  FOREACHvertex_i_(vertex_points) {
    if (vertex) { 
      numneighbors= qh_setsize (vertex->neighbors);

      numInLoop = numneighbors;
      qh_order_vertexneighbors (vertex);
      j=0;
      FOREACHneighbor_(vertex) {
	if (!neighbor->visitid) {
	  fprintf(stderr,"Uh oh! neighbor->visitId==0, -neighbor->id: %d\n",
		  -neighbor->id);
	  numInLoop--;
	}
	else
	  indices[j] = neighbor->visitid - 1;

	if (j>0 && 
	    ((hullCoords[indices[j]]-hullCoords[indices[j-1]]).len() < IVTOL||
	    (hullCoords[indices[j]]-hullCoords[indices[0]]).len() < IVTOL))
	  numInLoop--;	
	else j++;
      }

    }
    else if ((facet= SETelemt_(coplanar_points, vertex_i, facetT)))
      numInLoop=1;
    else {
      numInLoop=0;
      continue;
    }

    if (numInLoop<3) {
#ifdef GRASPDEBUG
      printf("too few vertices to make a face. Ignoring ...\n");
#endif
      continue;
    }

    // check if the current orientation of the face matches the plane's normal
    testNormal = (hullCoords[indices[1]] - hullCoords[indices[0]]) *
      (hullCoords[indices[j-1]] - hullCoords[indices[0]]);

    if ((dot = testNormal % vec3(planes[vertex_i][0],planes[vertex_i][1],
				 planes[vertex_i][2])) > 0.0) {
      for (j=0;j<numInLoop;j++)
	hullIndices.push_back(indices[j]);
      hullIndices.push_back(-1);
    }
    else {
      // reverse the vertex ordering
      for (j=numInLoop-1;j>=0;j--)
	hullIndices.push_back(indices[j]);
      hullIndices.push_back(-1);
    }
  }

  qh_settempfree (&coplanar_points);
  qh_settempfree (&vertex_points);
  qh_settempfree (&vertices);

  qh NOerrexit= True;
  qh_freeqhull(!qh_ALL);
  qh_memfreeshort (&curlong, &totlong);
  if (curlong || totlong)  	/* optional */
     fprintf (stderr, "qhull internal warning (main): did not free %d bytes of long memory (%d pieces)\n",
        totlong, curlong);


  for (i=0;i<validPlanes;i++)
    free(planes[i]);
  free(planes);

  delete [] indices;
  delete [] array;

  return SUCCESS;
}



/*!
  Builds an L1 GWS by simply taking the union of all the contact wrenches,
  and using these as the input for the convex hull operation
  (performed by qhull). The output of qhull is the list of equations of the
  hyperplanes that bound the hull as well as the hull area and hull volume.
  These are all saved within the GWS.
  Returns FAILURE or SUCCESS.
*/
int
L1GWS::build()
{
  double minOffset;
  int i,w,wrenchCount,minIndex;
 
  // qhull variables
  boolT ismalloc;
  int curlong, totlong, exitcode;
  char options[200];  
  facetT *facet;
  //  unsigned long dmark = dmalloc_mark();

#ifdef GRASPITDBG
  std::cout << " in gws build" << std::endl;
#endif 

  if (hyperPlanes) {
    for (int i=0;i<numHyperPlanes;i++)
      delete [] hyperPlanes[i];
    delete [] hyperPlanes;
    hyperPlanes=NULL;
  }
  numHyperPlanes = 0;
  hullArea = hullVolume = 0.0;

  if (!grasp->getNumContacts()) {
    forceClosure = false;
    return SUCCESS;
  }

  wrenchCount = grasp->getNumContacts()*Contact::numFCVectors;
  coordT *array = new coordT[wrenchCount*6];
  if (!array) std::cerr << "array is NULL!! in L1GWS::Build(). wrenchCount: " << 
		wrenchCount << std::endl;
  coordT *p = &array[0];

  for (i=0;i<grasp->getNumContacts();i++) {    
    for (w=0;w<Contact::numFCVectors;w++) {
      *p++ = grasp->getContact(i)->getMate()->wrench[w].force.x();
      *p++ = grasp->getContact(i)->getMate()->wrench[w].force.y();
      *p++ = grasp->getContact(i)->getMate()->wrench[w].force.z();
      *p++ = grasp->getContact(i)->getMate()->wrench[w].torque.x();
      *p++ = grasp->getContact(i)->getMate()->wrench[w].torque.y();
      *p++ = grasp->getContact(i)->getMate()->wrench[w].torque.z();
    }
  }

#ifdef GRASPITDBG
  printf("Calling Qhull on %d 6D wrenches...\n",wrenchCount);
#endif

  ismalloc = False; 	// True if qh_freeqhull should 'free(array)'

  FILE *qhfp = fopen("logfile","w");
  if (!qhfp) {
	fprintf(stderr,"Could not open qhull logfile!\n");
	qh_init_A(NULL, stdout, stderr, 0, NULL);
  }
  else
   qh_init_A(NULL, qhfp, qhfp, 0, NULL);

  if ((exitcode = setjmp(qh errexit))) {
#ifdef GRASPITDBG
    printf("QUALITY: NON FORCE CLOSURE GRASP\n");
#endif
    forceClosure = false;
	delete [] array;
	qh NOerrexit= True;
	qh_freeqhull(!qh_ALL);
	qh_memfreeshort (&curlong, &totlong);
	if (curlong || totlong)  	/* optional */
	   fprintf (stderr, "qhull internal warning (main): did not free %d bytes of long memory (%d pieces)\n",
		  totlong, curlong);
	if (qhfp) fclose(qhfp);
    return FAILURE;
  }
  sprintf(options, "qhull Pp n Qx C-0.0001");
  qh_initflags(options);
  qh_init_B(&array[0], wrenchCount, 6, ismalloc);
  qh_qhull();
  qh_check_output();
  qh_getarea(qh facet_list);
  if (qhfp) fclose(qhfp);

  hullArea = qh totarea;
  hullVolume = qh totvol;
  numHyperPlanes = qh num_facets;

  hyperPlanes = new doublePtr[numHyperPlanes];
  if (!hyperPlanes) {
    pr_error("Out of memory allocating hyperPlanes array");
    return FAILURE;
  }
  for (i=0;i<numHyperPlanes;i++) {
    hyperPlanes[i] = new double[7];
    if (!hyperPlanes[i]) {
      pr_error("Out of memory allocating hyperPlanes array");
      return FAILURE;
    }
  }

  minOffset = -1.0;
  int posOffsets=0;
  i=0;

  FORALLfacets {
    hyperPlanes[i][0] = facet->normal[0];
    hyperPlanes[i][1] = facet->normal[1];
    hyperPlanes[i][2] = facet->normal[2];
    hyperPlanes[i][3] = facet->normal[3];
    hyperPlanes[i][4] = facet->normal[4];
    hyperPlanes[i][5] = facet->normal[5];
    hyperPlanes[i][6] = facet->offset;
    if (hyperPlanes[i][6] > 0) posOffsets++;
    if (minOffset == -1.0 || -hyperPlanes[i][6]<minOffset) {
	minOffset = -hyperPlanes[i][6];
	minIndex = i;
    }
    i++;
  }
  grasp->setMinWrench(hyperPlanes[minIndex]);

  qh NOerrexit= True;
  qh_freeqhull(!qh_ALL);
  qh_memfreeshort (&curlong, &totlong);
  if (curlong || totlong)  	/* optional */
     fprintf (stderr, "qhull internal warning (main): did not free %d bytes of long memory (%d pieces)\n",
        totlong, curlong);


  //  qh_memfreeshort(&curlong, &totlong);

  //  dcopy(6,hyperPlanes[minIndex],1,minWrench,1);

  if (posOffsets>0) {
#ifdef GRASPITDBG
    printf("QUALITY: NON FORCE CLOSURE GRASP\n");
#endif
    forceClosure = false;
  }
  else {
#ifdef GRASPITDBG
    printf("QUALITY: %le\n",minOffset);
    printf("HULL AREA: %le\n",hullArea);
    printf("HULL VOLUME: %le\n",hullVolume);
#endif
    forceClosure = true;
  }

  delete [] array;
  //  dmalloc_log_changed(dmark,1,0,0);
  return SUCCESS;
}

/*! 
  This computes the minkowski sum of the wrenches from a set of contacts.
  The result is a m^n set of wrenches where m is the number of boundary
  wrenches on each contact and n is the number of contacts.
*/
void
minkowskiSum(Grasp *g,int c,int &wrenchNum,coordT *wrenchArray,Wrench prevSum)
{
  static Wrench sum;

  if (c == g->getNumContacts()) {
    wrenchArray[wrenchNum*6]   = prevSum.force.x();
    wrenchArray[wrenchNum*6+1] = prevSum.force.y();
    wrenchArray[wrenchNum*6+2] = prevSum.force.z();
    wrenchArray[wrenchNum*6+3] = prevSum.torque.x();
    wrenchArray[wrenchNum*6+4] = prevSum.torque.y();
    wrenchArray[wrenchNum*6+5] = prevSum.torque.z();
    wrenchNum++;
    return;
  }
  // Perform a sum that doesn't include any contribution from this contact
  minkowskiSum(g,c+1,wrenchNum,wrenchArray,prevSum);

  for (int w=0;w<Contact::numFCVectors;w++) {
    sum.force =
      prevSum.force + g->getContact(c)->getMate()->wrench[w].force;
    sum.torque = 
      prevSum.torque + g->getContact(c)->getMate()->wrench[w].torque;

    // perform a sum that includes this contact wrench
    minkowskiSum(g,c+1,wrenchNum,wrenchArray,sum);

  }
}

/*!
  Builds an L Infinity GWS by finding the minkowski sum of the set of contact
  wrenches, and using these as the input for the convex hull operation.
  (performed by qhull). The output of qhull is the list of equations of the
  hyperplanes that bound the hull as well as the hull area and hull volume.
  These are all saved within the GWS.
  Returns FAILURE or SUCCESS.
*/
int
LInfGWS::build()
{
  double minOffset;
  int i,wrenchCount,minIndex;

  //qhull variables
  boolT ismalloc;
  int curlong, totlong, exitcode;
  char options[200];
  facetT *facet;

  if (hyperPlanes) {
    for (int i=0;i<numHyperPlanes;i++)
      delete [] hyperPlanes[i];
    delete [] hyperPlanes;
    hyperPlanes = NULL;
  }
  numHyperPlanes = 0;
  hullArea = hullVolume = 0.0;

  if (!grasp->getNumContacts()) {
    forceClosure = false;
    return SUCCESS;
  }

  double numWrenchTest = pow(Contact::numFCVectors+1,
			     grasp->getNumContacts());
  if (numWrenchTest > INT_MAX/6.0) {  //what is a reasonable threshold ?
#ifdef GRASPITDBG
    printf("Too many contacts to compute the Minkowski sum!\n");
#endif
    return FAILURE;
  }
  wrenchCount = (int) numWrenchTest;

  coordT *array = new coordT[wrenchCount*6];
  if (!array) std::cerr << "Could not allocate wrench array in ComputeLInfHull. wrenchCount: " << wrenchCount << std::endl;

  Wrench initSum;
  initSum.force = vec3::ZERO;
  initSum.torque = vec3::ZERO;
  int wrenchNum = 0;

  minkowskiSum(grasp,0,wrenchNum,array,initSum);

#ifdef GRASPITDBG
  printf("Calling Qhull on %d 6D wrenches...\n",wrenchCount);
#endif

  ismalloc = False; 	// True if qh_freeqhull should 'free(array)'
  FILE *qhfp = fopen("logfile","w");
  if (!qhfp) {
	fprintf(stderr,"Could not open qhull logfile!\n");
	qh_init_A(NULL, stdout, stderr, 0, NULL);
  }
  else
   qh_init_A(NULL, qhfp, qhfp, 0, NULL);

  if ((exitcode = setjmp(qh errexit))) {
	forceClosure = false;
	delete [] array;
	qh NOerrexit= True;
	qh_freeqhull(!qh_ALL);
	qh_memfreeshort (&curlong, &totlong);
	if (curlong || totlong)  	/* optional */
     fprintf (stderr, "qhull internal warning (main): did not free %d bytes of long memory (%d pieces)\n",
        totlong, curlong);

	if (qhfp) fclose(qhfp);
    return FAILURE;
  }
  sprintf(options, "qhull Pp n Qx C-0.0001");
  qh_initflags(options);
  qh_init_B(&array[0], wrenchCount, 6, ismalloc);
  qh_qhull();
  qh_check_output();
  qh_getarea(qh facet_list);
  if (qhfp) fclose(qhfp);

  hullArea = qh totarea;
  hullVolume = qh totvol;
  numHyperPlanes = qh num_facets;

  hyperPlanes = (double **) malloc( numHyperPlanes * sizeof(double *));
  if (!hyperPlanes) {
    pr_error("Out of memory allocating hyperPlanes array");
    return FAILURE;
  }
  for (i=0;i<numHyperPlanes;i++) {
    hyperPlanes[i] = (double *) malloc(7 * sizeof(double));
    if (!hyperPlanes[i]) {
      pr_error("Out of memory allocating hyperPlanes array");
      return FAILURE;
    }
  }

  minOffset = -1.0;
  int posOffsets=0;
  i=0;
  FORALLfacets {
    hyperPlanes[i][0] = facet->normal[0];
    hyperPlanes[i][1] = facet->normal[1];
    hyperPlanes[i][2] = facet->normal[2];
    hyperPlanes[i][3] = facet->normal[3];
    hyperPlanes[i][4] = facet->normal[4];
    hyperPlanes[i][5] = facet->normal[5];
    hyperPlanes[i][6] = facet->offset;
    if (hyperPlanes[i][6] > 0) posOffsets++;
    if (i==0 || -hyperPlanes[i][6]<minOffset) {
	minOffset = -(hyperPlanes[i][6]);
	minIndex = i;
    }
    i++;
  }

  qh NOerrexit = True;
  qh_freeqhull(!qh_ALL);
  qh_memfreeshort (&curlong, &totlong);
  if (curlong || totlong)  	/* optional */
     fprintf (stderr, "qhull internal warning (main): did not free %d bytes of long memory (%d pieces)\n",
        totlong, curlong);

  //  qh_memfreeshort(&curlong, &totlong);

  //  dcopy(6,hyperPlanes[minIndex],1,minWrench,1);

  if (posOffsets>0) {
#ifdef GRASPITDBG
    printf("QUALITY: UNSTABLE GRASP\n");
#endif
    forceClosure = false;
  }
  else {
#ifdef GRASPITDBG
    printf("QUALITY: %le\n",minOffset);
    printf("HULL AREA: %le\n",hullArea);
    printf("HULL VOLUME: %le\n",hullVolume);
#endif

    forceClosure = true;
  }

  delete [] array;
  return SUCCESS;
}

