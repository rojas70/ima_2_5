//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: worldElement.cpp,v 1.15 2004/02/12 21:35:27 amiller Exp $
//
//######################################################################


/*! \file 
  \brief Implements the world element base class
 */
#include "worldElement.h"
#include "world.h"
#include "mytools.h"
#include "robot.h"
#include "robonaut.h"
#include "barrett.h"
#include "puma560.h"
#include "body.h"
#include "contact.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

//#define GRASPITDBG

/*!
  Protected constructor should only be called by subclasses.
  It initializes an empty worldElement.
*/
WorldElement::WorldElement(World *w,const char *name) : QObject((QObject *)w,name)
{
  myWorld=w; IVRoot=NULL;
  if (!name) myName = "unnamed";
  else myName = name;
  contactsChangedFlag=false;
}


/*!
  Protected copy constructor (should not be called by user)
*/
WorldElement::WorldElement(const WorldElement &e) : QObject((QObject *)e.myWorld,e.name())
{
  myWorld = e.myWorld;
  myName = e.myName;
  IVRoot = e.IVRoot;
  contactsChangedFlag = e.contactsChangedFlag;
}


/*!
  Protected destructor should only be called by subclasses
  Currently this is simply a stub.
*/
WorldElement::~WorldElement()
{

}


/*! 
  Moves the element from its current pose to the new pose specified by \a tr.
  This motion is performed in several steps such that the translation
  between each step does not exceed \a translStepSize and the angle of
  rotation does not exceed \a rotStepSize (expressed in radians).  The
  intermediate poses are determined using linear interpolation for the
  translation and spherical linear interpolation for the rotation.  If
  a collision is encountered during the motion, the point of first contact
  is determined and the element is left in that position.  This function
  returns the collision report of the first encountered collision or an
  empty report if no collisions were encountered and the move was
  completed.
*/
ColReportT
WorldElement::moveTo(transf &newTran,double translStepSize,
		     double rotStepSize)
{
  bool moveFinished = false;
  transf origTran,lastTran,nextTran,motion;
  Quaternion nextRotation;
  vec3 nextTranslation;
  double percentComplete,moveIncrement,translationLength;
  double angle;
  vec3 axis;
  int i,numCols;
  double t,deltat,minDist;
  bool done,moveOK;
  
  ColReportT colReport,result;

  origTran = getTran();

  do{
    moveOK = true;
  translationLength = (newTran.translation() - origTran.translation()).len();
  nextRotation = newTran.rotation() * origTran.rotation().inverse();
  nextRotation.ToAngleAxis(angle,axis);
  
  moveIncrement = 1.0;
  if (translationLength != 0.0)
	moveIncrement = MIN(moveIncrement, translStepSize / translationLength);
  if (angle != 0.0)
	moveIncrement = MIN(moveIncrement, rotStepSize / angle);
  

  // check contacts  
  nextTranslation = (1.0-moveIncrement)*origTran.translation() +
    moveIncrement*newTran.translation();
  nextRotation = Quaternion::Slerp(moveIncrement,origTran.rotation(),
				   newTran.rotation());
  nextTran = transf(nextRotation,nextTranslation);
  motion = nextTran * getTran().inverse();  

  if (contactsPreventMotion(motion)) {
#ifdef GRASPITDBG
    printf("contacts prevent motion\n");
#endif
    return colReport;
  }

  percentComplete = 0.0;
  while (!moveFinished) {
    percentComplete += moveIncrement;
    if (percentComplete >= 1.0) {
      percentComplete = 1.0;
      moveFinished = true;
    }
    lastTran = getTran();

    nextTranslation = (1.0-percentComplete)*origTran.translation() +
      percentComplete*newTran.translation();
    nextRotation = Quaternion::Slerp(percentComplete,origTran.rotation(),
				     newTran.rotation());
	
    nextTran = transf(nextRotation,nextTranslation);
  
    if (setTran(nextTran) == FAILURE) {
#ifdef GRASPITDBG
      printf("Move failed\n");
#endif
      break;
    }
    numCols = myWorld->getCollisionReport(colReport);
    if (numCols) moveFinished = true;
  }

  if (!numCols) return colReport;

#ifdef GRASPITDBG
  printf("%d collision(s) found!\n",numCols);
  for (i=0;i<numCols;i++) {
    printf("%s collided with %s\n",
	   colReport[i].first->getName().latin1(),
	   colReport[i].second->getName().latin1());
  }
#endif
  
  newTran = nextTran;
  t = 0.5;
  deltat = 0.5;
  done = false;
  
  while (!done && deltat > 1.0e-20) {
    deltat /= 2.0;
    
    nextTranslation = (1.0-t)*lastTran.translation() +
      t*newTran.translation();
    nextRotation = Quaternion::Slerp(t,lastTran.rotation(),
				     newTran.rotation());
    nextTran = transf(nextRotation,nextTranslation);
#ifdef GRASPITDBG
    printf("moving to time : %e\n",t);
#endif
    if (setTran(nextTran) == FAILURE) break;
    
    minDist = myWorld->getDist(colReport[0].first,colReport[0].second);
    for (i=1;i<numCols;i++)
      minDist = MIN(minDist,myWorld->getDist(colReport[i].first,
					     colReport[i].second));
#ifdef GRASPITDBG
    printf("minDist: %le\n",minDist);
#endif
    if (minDist > 0) {
      if (minDist < Contact::THRESHOLD * 0.5)
	break;
      t += deltat;
    }
    else
      t -= deltat;
  }
#ifdef GRASPITDBG
  if (deltat < 1.0e-20) printf("deltat failsafe hit\n");
  printf("deltat: %le\n",deltat);
#endif

  //determine which of the bodies that collided are now touching and add contacts
  for (i=0;i<numCols;i++)
    if (myWorld->getDist(colReport[i].first,colReport[i].second) < Contact::THRESHOLD)
      result.push_back(colReport[i]);

  //Check that we are not now in collision.  We may have missed one if the
  //step size was to big.  If that's the case, we'll repeat the move with
  //a smaller step size

  numCols = myWorld->getCollisionReport(colReport);
  if (numCols) {
    moveOK = false;
    setTran(origTran);
    result.clear();
#ifdef GRASPITDBG
    printf("moveTo: missed a collision, reducing step size and trying again.\n");
#endif
    translStepSize /= 10.0;
    rotStepSize /= 10.0;
    if ((fabs(translStepSize) > 0 && fabs(translStepSize< 1e-20)) || 
	(fabs(rotStepSize) > 0 && fabs(rotStepSize < 1e-20))) {
#ifdef GRASPITDBG
	printf("moveTo: stepsize < 1e-20 and still could not perform the move\n");
#endif
	moveOK = true; // give up
    }

  }
  } while (!moveOK);
  myWorld->findContacts(result);

  return result;
}


/*!
  This is a static helper function which will create and return an
  instance of the named subclass.  This is useful when reading in the
  world configuration file and populating the world.
*/
WorldElement *
WorldElement::createInstance(const QString &className,
			     World *parent,const char *name)
{
  if (className == "Body")
    return new Body(parent,name);
  else if (className == "GraspableBody")
    return new GraspableBody(parent,name);
  else if (className == "Robot")
    return new Robot(parent,name);
  else if (className == "Puma560")
    return new Puma560(parent,name);
  else if (className == "Hand")
    return new Hand(parent,name);
  else if (className == "Barrett")
    return new Barrett(parent,name);
  else if (className == "Robonaut")
    return new Robonaut(parent,name);
  else return NULL;
}
