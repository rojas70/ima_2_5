//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: robot.cpp,v 1.22 2004/02/12 21:35:27 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Implements the robot class hierarchy
 */
#include <iomanip>
#include <qfile.h>
#include "mytools.h"
#include "matvecIO.h"
#include "robot.h"
#include "dynJoint.h"
#include "world.h"
#include "grasp.h"
#include "graspitGUI.h"
#include "ivmgr.h"
#include "dynamics.h"


#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

//#define GRASPITDBG
#define BADCONFIG                                                   \
{                                                                   \
  QTWARNING("There was a problem reading the configuration file."); \
  file.close();                                                     \
  return FAILURE;                                                   \
}

#define AUTO_GRASP_TIME_STEP 0.01

/*!
  The destructor deletes each of the joints in this chain, and asks the
  world to delete each of the links in the chain.  It also detaches any
  connected robots.
*/
KinematicChain::~KinematicChain()
{
  int i;
  IVTran->unref();

  delete [] lastJoint;

  for (i=0;i<numJoints;i++)
    if (jointVec[i]) delete jointVec[i];

    for (i=0;i<numLinks;i++)
      if (linkVec[i]) owner->getWorld()->destroyElement(linkVec[i]);
	

  // go in reverse order becase these operations will delete elements from
  // the children vector
  for (i=numChildren-1;i>=0;i--)
    owner->detachRobot(children[i]);
}

/*!
  Sets up the chain given a stream from a currently open robot
  configuration file.  It reads the number of joints and the number of links
  and allocates space for those vectors, then it reads in the base transform
  of the chain.  Next, it reads a line for each joint and creates a
  prismatic or revolute joint which are initialized with the kinematic data
  in that line. \a linkDir should be the path to the directory where the link
  body files are kept.
*/ 
int
KinematicChain::initChain(QTextStream &stream,QString &linkDir)
{
  int d,j,l;
  QString line,linkFilename;
  bool ok;
  Link *prevLink;

  while((line=stream.readLine()) && (line.isEmpty() || line[0]=='#'));
  if (!line) return FAILURE;

  numJoints = line.toInt(&ok);
  if (!ok || numJoints < 1) return FAILURE;

  while((line=stream.readLine()) && (line.isEmpty() || line[0]=='#'));
  if (!line) return FAILURE;

  numLinks = line.toInt(&ok);
  if (!ok || numLinks < 1) return FAILURE;

  jointVec.reserve(numJoints);
  for (j=0;j<numJoints;j++)
    jointVec.push_back(NULL);

  linkVec.reserve(numLinks);  
  linkTranVec.reserve(numLinks);  
  for (l=0;l<numLinks;l++) {
    linkVec.push_back(NULL);
    linkTranVec.push_back(transf::IDENTITY);
  }
  
  lastJoint = new int[numLinks];

  IVRoot = new SoSeparator;
  IVTran = new SoTransform;
  IVTran->ref();

  /* read in the finger transformation */
  readTransRotFromQTextStream(stream,tran);
  tran.toSoTransform(IVTran);
    
  printf(" Creating joints ");fflush(stdout);
  numDOF = 0;

  for (j=0;j<numJoints;j++){
    while((line=stream.readLine()) && (line.isEmpty() || line[0]=='#'));
    if (!line) return FAILURE;

    printf("%d ",j);fflush(stdout);
    if (line[0]=='d') jointVec[j] = new RevoluteJoint;
    else jointVec[j] = new PrismaticJoint;
    if (jointVec[j]->initJoint(line.latin1(),this,owner) == FAILURE) return FAILURE;
    for (d=0;d<numDOF;d++)
      if (dofNumVec[d] == jointVec[j]->getDOFNum()) break;
    if (d==numDOF) {dofNumVec.push_back(jointVec[j]->getDOFNum());numDOF++;}
  }

  printf(", Creating links ");

	prevLink = owner->getBase();
  for (l=0;l<numLinks;l++){
	QString jointType;
    while((line=stream.readLine()) && (line.isEmpty() || line[0]=='#'));
    if (!line) return FAILURE;
	jointType = line.stripWhiteSpace();

#ifdef GRASPITDBG
	std::cout << "Joint Type: "<<jointType.latin1()<<std::endl;
#endif
    
	while((line=stream.readLine()) && (line.isEmpty() || line[0]=='#'));
    if (!line) return FAILURE;
    
    printf("%d ",l);fflush(stdout);
    linkFilename = line.section(' ',0,0);
    lastJoint[l] = line.section(' ',1,1).toInt(&ok);
    if (!ok || lastJoint[l] < 0 || lastJoint[l] >= numJoints) return FAILURE;

    QString linkName = 
      QString(owner->name())+QString("_chain%1_link%2").arg(chainNum).arg(l);

    linkVec[l] = 
      new Link(owner,chainNum,l,owner->getWorld(),linkName.latin1());

    if (linkVec[l] == NULL) return FAILURE;
    if (linkVec[l]->load(linkDir + linkFilename)==FAILURE) {
      delete linkVec[l]; linkVec[l] = NULL;
      return FAILURE;
    }
    if (jointType == "Ball") {
      linkVec[l]->setDynJoint(new BallDynJoint(jointVec[lastJoint[l]-2],
						    jointVec[lastJoint[l]-1],jointVec[lastJoint[l]],
						    prevLink,linkVec[l],
					            (l==0 ? tran : transf::IDENTITY),
						    jointVec[lastJoint[l]]->getTran().inverse()));
      jointVec[lastJoint[l]-2]->dynJoint = linkVec[l]->getDynJoint();
      jointVec[lastJoint[l]-1]->dynJoint = linkVec[l]->getDynJoint();
      jointVec[lastJoint[l]]->dynJoint = linkVec[l]->getDynJoint();
    }
    if (jointType == "Universal") {
      linkVec[l]->setDynJoint(new UniversalDynJoint(jointVec[lastJoint[l]-1],
						    jointVec[lastJoint[l]],
						    prevLink,
						    linkVec[l],(l==0 ? tran : transf::IDENTITY),
						    jointVec[lastJoint[l]]->getTran().inverse()));
      jointVec[lastJoint[l]-1]->dynJoint = linkVec[l]->getDynJoint();
      jointVec[lastJoint[l]]->dynJoint = linkVec[l]->getDynJoint();
    }
    else if (jointType == "Revolute") {
      if (l==0)
        linkVec[l]->setDynJoint(new RevoluteDynJoint(jointVec[lastJoint[l]],
						     prevLink,linkVec[l],tran));
      else 
	linkVec[l]->setDynJoint(new RevoluteDynJoint(jointVec[lastJoint[l]],
						     prevLink,linkVec[l]));
      jointVec[lastJoint[l]]->dynJoint = linkVec[l]->getDynJoint();
    }
    else if (jointType == "Prismatic") {
      if (l==0)
	linkVec[l]->setDynJoint(new RevoluteDynJoint(jointVec[lastJoint[l]],
						     prevLink,linkVec[l],tran));
      else
	linkVec[l]->setDynJoint(new RevoluteDynJoint(jointVec[lastJoint[l]],
						     prevLink,linkVec[l]));
      jointVec[lastJoint[l]]->dynJoint = linkVec[l]->getDynJoint();
    }
    
    //    owner->getWorld()->addLink(linkVec[l]);
    IVRoot->addChild(linkVec[l]->getIVRoot());
    prevLink = linkVec[l];
  }

  printf("\n");

  jointsMoved = true;
  updateLinkPoses();

  owner->getIVRoot()->addChild(IVRoot);

  return SUCCESS;
}


/*!
  Given a pointer to another robot and an offset transform of the base
  frame of the robot with respect to the end transform of the link of
  this chain.
*/
void
KinematicChain::attachRobot(Robot *r,const transf &offsetTr)
{
  children.push_back(r);
  childOffsetTran.push_back(offsetTr);
  numChildren++;

  if (r->getMountPiece())
    r->getMountPiece()->
      setDynJoint(new FixedDynJoint(linkVec[numLinks-1],r->getMountPiece(), offsetTr));
  else
    r->getBase()->
      setDynJoint(new FixedDynJoint(linkVec[numLinks-1],r->getBase(), offsetTr));
}

/*!
  This separates the robot pointed to by r from this kinematic chain,
  allowing them to move independently.
*/
void
KinematicChain::detachRobot(Robot *r)
{
  int i,j;
  std::vector<transf>::iterator tp;
  std::vector<Robot *>::iterator rp;

  for (i=0,rp=children.begin();rp!=children.end();i++,rp++)
    if (*rp==r) {children.erase(rp); break;}

  for (j=0,tp=childOffsetTran.begin();tp!=childOffsetTran.end();j++,tp++)
    if (j==i) {childOffsetTran.erase(tp); break;}

  numChildren--;
}


/*!
  This performs the forward kinematics for each link in the chain
  given the current joint values, and then sets each link transform.
  This update is recursively propagated to all attached robots.
*/
void
KinematicChain::updateLinkPoses()
{
  transf total,startTran;
  int l=0,j;

  if (jointsMoved) {
    for (j=0;j<numJoints;j++) {
      total = jointVec[j]->getTran() * total;
    
      if (l<numLinks && lastJoint[l]==j) {
	linkTranVec[l] = total;
	l++;
      }
    }
    jointsMoved = false;
  }

  startTran = tran * owner->getTran();
  endTran = linkTranVec[numLinks-1]*startTran;

  for (l=0;l<numLinks;l++)
    linkVec[l]->setTran(linkTranVec[l]*startTran);

  for (j=0;j<numChildren;j++) {
    children[j]->simpleSetTran(childOffsetTran[j]*endTran);
  }
}


/*!
  Given a array of joint values for each joint in the chain, this method
  will compute the transforms for each link in the chain with respect to
  world coordinates.  It does not affect the chain itself.
*/
void
KinematicChain::fwdKinematics(double *jointVals,
			      std::vector<transf> &newLinkTranVec) const
{
  transf total = tran * owner->getTran();
  int l=0;

  for (int j=0;j<numJoints;j++) {    
    total = jointVec[j]->getTran(jointVals[j]) * total;
    
    if (l<numLinks && lastJoint[l]==j) {
      newLinkTranVec[l] = total;
      l++;
    }
  }
#if 0
  std::cout << "fwd kine end tran "<< newLinkTranVec[numLinks-1] << std::endl;
  std::cout << "fwd kine rot "<< newLinkTranVec[numLinks-1].affine() << std::endl;
#endif
}


/*!
  Calls the forward kinematics with the current desired joint 
  positions and returns the pose of the end frame of the chain in world
  coordinates
*/
const transf &
KinematicChain::getDesiredEndTran() const
{
  //double jointVals[numJoints];
  double *jointVals = new double[numJoints];
  std::vector<transf> linkTranVec(numLinks);

  for (int j=0;j<numJoints;j++) {
    jointVals[j] = owner->getDOF(jointVec[j]->getDOFNum())->getSetPoint() *
      jointVec[j]->getRatio();
  }
  fwdKinematics(jointVals,linkTranVec);
  delete [] jointVals;
  return linkTranVec[numLinks-1];
}

//////////////////////////////////////////////////////////////////////////////
//                              Robot Methods
////////////////////////////////////////////////////////////////////////////// 


/*!
  Removes the base and mountpiece from the world, and deletes the
  kinematic chains and DOFs.  If this robot is connected to a parent
  robot, it detaches itself.
*/
Robot::~Robot()
{
  int i;
  for (i=0;i<numChains;i++)
    if (chainVec[i]) delete chainVec[i];

  for (i=0;i<numDOF;i++)
    if (dofVec[i]) delete dofVec[i];
  
  if (base) myWorld->destroyElement(base);  
  if (mountPiece) myWorld->destroyElement(mountPiece);

  if (parent) parent->detachRobot(this);

  std::cerr << "Deleting robot: " << name() <<std::endl;
}


/*!
  Given the filename of a robot configuration file this parses that file.
  It loads all the necessary link bodies, sets up the degrees of freedom,
  and the overall structure of the robot.
*/
int
Robot::load(QString filename)
{
  QFile file(filename);
  QString ivdir;
  int f,d,j;
  double defaultVel,maxForce;
  double Kp,Kv;
  bool ok;

  myFilename = filename.section('/',-1).section('.',0,0);
  if (name(0) == 0) {
    myName = filename.section('/',-1).section('.',0,0);
    setName(myName.latin1());
  }


  if (!file.open(IO_ReadOnly)) {
    std::cerr << "could not open robot configuration file\n";
    return FAILURE;
  }

  QTextStream stream( &file );
  QString line;
  
  // temporary
  defaultTranslVel = 50;
  defaultRotVel = M_PI/4.0;

  // read and ignore the classType 
  while((line=stream.readLine()) && (line.isEmpty() || line[0]=='#'));
  if (!line) BADCONFIG;

  IVRoot = new SoSeparator;

  while((line=stream.readLine()) && (line.isEmpty() || line[0]=='#'));
  if (!line) BADCONFIG;

  ivdir = filename.section('/',0,-2,QString::SectionIncludeTrailingSep)
	+ "iv/";

  printf("Creating base...\n");  

  base = new Link(this,-1,-1,myWorld,(QString(name())+"Base").latin1());
  if (base == NULL) BADCONFIG;
  if (base->load(ivdir+line.section(' ',0,0))==FAILURE) {
    delete base; base = NULL;
    BADCONFIG;
  }
  //  base->setDynJoint(new FixedDynJoint(NULL,base));

  //  myWorld->addLink(base);
  IVRoot->addChild(base->getIVRoot());

  while((line=stream.readLine()) && (line.isEmpty() || line[0]=='#'));
  if (!line) BADCONFIG;

  numDOF = line.toInt(&ok);
  if (!ok || numDOF < 1) BADCONFIG;
  printf("Setting up %d degrees of freedom...\n",numDOF);
  dofVec.reserve(numDOF);
  dofDraggerScale.reserve(numDOF);

  //initially set to null in case of problems reading dofs
  for (f=0;f<numDOF;f++)
    dofVec.push_back(NULL);

  for (f=0;f<numDOF;f++) {
    while((line=stream.readLine()) && (line.isEmpty() || line[0]=='#'));
    if (!line) BADCONFIG;
    QTextStream strStream(&line,IO_ReadOnly);
    strStream >> defaultVel >> maxForce >> Kp >> Kv >> dofDraggerScale[f];
    dofVec[f] = new DOF;
    dofVec[f]->dofNum = f;
    dofVec[f]->defaultVelocity = defaultVel;
    dofVec[f]->maxForce = maxForce;
    dofVec[f]->Kp = Kp;
    dofVec[f]->Kv = Kv;
  }

  while((line=stream.readLine()) && (line.isEmpty() || line[0]=='#'));
  if (!line) BADCONFIG;

  numChains = line.toInt(&ok);
  if (!ok || numChains < 1) BADCONFIG; 
    printf("Creating %d kinematic chains (fingers)...\n",numChains);
  chainVec.reserve(numChains);
  for (f=0;f<numChains;f++)
    chainVec.push_back(NULL);
      
  for (f=0;f<numChains;f++) {
    printf("Chain %d: ",f);
    chainVec[f] = new KinematicChain(this,f);
    if (chainVec[f]->initChain(stream,ivdir)==FAILURE) BADCONFIG;
    //    for (l=0;l<chainVec[f]->getNumLinks();l++) {
    //      chainVec[f]->getLink(l)->chainNum = f;
    //      chainVec[f]->getLink(l)->linkNum = l;
    // }
  }
  file.close();

  std::list<Joint *>jointList;

  for (d=0;d<numDOF;d++) {
    jointList.clear();
    for (f=0;f<numChains;f++)
      for (j=0;j<chainVec[f]->getNumJoints();j++)
	if (chainVec[f]->getJoint(j)->getDOFNum() == d)
	  jointList.push_back(chainVec[f]->getJoint(j));
    dofVec[d]->initDOF(this,jointList);
  }

  base->setTran(transf::IDENTITY);
  base->setDynJoint(new FixedDynJoint(NULL,getBase(),getTran()));
  return SUCCESS;
}


/*!
  Given the body filename of a mountpiece, this will load it into the
  world and connect it to the base of this robot.
*/
Link *
Robot::importMountPiece(QString filename)
{
  QString mountName = QString(name())+"_mount";
  mountPiece = new Link(this,-1,-1,myWorld,mountName.latin1());
  if (mountPiece->load(filename)==FAILURE){
    delete mountPiece; mountPiece = NULL; return NULL;
  }
  IVRoot->addChild(mountPiece->getIVRoot());
  mountPiece->setTran(base->getTran());
 
  base->setDynJoint(new FixedDynJoint(mountPiece,base));
  return mountPiece;
}


/*!
  Returns a vector of all links associated with this robot including
  all links in all chains, the base, and the mountpiece.
*/
void
Robot::getAllLinks(std::vector<DynamicBody *> &allLinkVec)
{
  int c,l,i;
  if (base) allLinkVec.push_back(base);
  if (mountPiece) allLinkVec.push_back(mountPiece);

  for (c=0;c<numChains;c++)
    for (l=0;l<chainVec[c]->getNumLinks();l++)
      allLinkVec.push_back(chainVec[c]->getLink(l));
  for (c=0;c<numChains;c++)
    for (i=0;i<chainVec[c]->getNumAttachedRobots();i++)
	  chainVec[c]->getAttachedRobot(i)->getAllLinks(allLinkVec);
}

/*!
  Returns a pointer to this robot and recursively, all child robots
  connected to this one
*/
void
Robot::getAllAttachedRobots(std::vector<Robot *> &robotVec)
{
  robotVec.push_back(this);

  for (int c=0;c<numChains;c++)
    for (int i=0;i<chainVec[c]->getNumAttachedRobots();i++)
	chainVec[c]->getAttachedRobot(i)->getAllAttachedRobots(robotVec);
}


/*!
  Given a pointer to a robot, the number of the chain on this robot to
  connect the new robot to, and the offset transform between the chain end
  and the base of the new robot, this will attach the new robot to this
  robot's chain end.
*/
void
Robot::attachRobot(Robot *r,int chainNum,const transf &offsetTr)
{
  r->parent = this;
  r->parentChainNum = chainNum;
  r->tranToParentEnd = offsetTr.inverse();
  chainVec[chainNum]->attachRobot(r,offsetTr);
}


/*!
  The detaches the robot pointed to by \a r from this robot so that they may
  move independently.
*/
void
Robot::detachRobot(Robot *r)
{
  std::cerr << "Detaching Robot " << r->getName() << " from " << getName() << std::endl;
  r->parent = NULL;
  chainVec[r->parentChainNum]->detachRobot(r);
}


/*!
  Given an array of DOF values equal in length to the number of DOFs in
  this robot, and the chain number for which the  kinematics should be
  computed, this will return a vector of transforms corresponding to
  the pose of each link in the chain.
*/
void
Robot::fwdKinematics(double* dofVals,std::vector<transf>& trVec,int chainNum)
{
  int numJoints = chainVec[chainNum]->getNumJoints();
  double *jointVals = new double[numJoints];
  Joint *joint;

  for (int j=0;j<numJoints;j++) {
    joint = chainVec[chainNum]->getJoint(j);
    jointVals[j] = dofVals[joint->getDOFNum()] * joint->getRatio();
  }

  chainVec[chainNum]->fwdKinematics(jointVals,trVec);
  delete [] jointVals;
}


/*!
  Unfortunately this is not complete.  Given a transform for the end pose
  of a particular kinematic chain, this will compute the DOF values
  corresponding to that pose.  It will use an iterative approximation
  technique, but I haven't had time to code this.  This routine is
  overriden for the Puma560 which has an analytical solution.
*/
int
Robot::invKinematics(const transf&,double* dofVals, int chainNum)
{
  // deals with compiler warnings
  dofVals = NULL;
  chainNum = 0;

  /*  const int iterLimit = 1000;
  int i,count = 0;
  double norm;
  KinematicChain *chain=chainVec[chainNum];
  std::vector<transf> trVec(chain->getNumLinks());

  //  for (i=0;i<chain->getNumDOF();i++)
  //    dofVals[chain->getDOFNum(i)] = 0.0;

  norm = 1.0;
  while (norm > MACHINE_ZERO) {
    fwdKinematics(dofVals,trVec,chainNum);
    norm = 0.0;
    //
    //    d = [	t1(1:3,4);
    //		0.5*[t1(3,2)-t1(2,3); t1(1,3)-t1(3,1); t1(2,1)-t1(1,2)]];
  }
  */
  return FAILURE;
}


/*!
  This is an internal method called by contactsPreventMotion.  Given a
  motion transform for an entire robot that is defined with respect to the
  base frame of the robot, it recursively checks all of the
  kinematic chains of the robot and any robots connected to them to
  determine if any contacts will prevent the motion.
*/
bool
Robot::simpleContactsPreventMotion(const transf& motion) const
{
  int i,j;
  transf linkMotion;
  transf baseToLink;

  for (i=0;i<numChains;i++) {

    for (j=0;j<chainVec[i]->getNumLinks();j++)
      if (chainVec[i]->getLink(j)->getNumContacts()) {
	baseToLink =
	  chainVec[i]->getLink(j)->getTran() * base->getTran().inverse();
	linkMotion = baseToLink * motion * baseToLink.inverse();
	if (chainVec[i]->getLink(j)->contactsPreventMotion(linkMotion))
	  return true;
      }

    // recursively check the motion for any robots attached to this chain
    for (j=0;j<chainVec[i]->getNumAttachedRobots();j++) {
      baseToLink = chainVec[i]->getAttachedRobot(j)->getBase()->getTran() *
	base->getTran().inverse();
	linkMotion = baseToLink * motion * baseToLink.inverse();
      if (chainVec[i]->getAttachedRobot(j)->
	  simpleContactsPreventMotion(linkMotion))
	return true;
    }
  }

  return false;

}


/*!
  Examines all of the contacts on every link of this robot, and each
  child robot connected to this one, to determine if the desired motion
  can be performed.  It also performs the inverse kinematics of the
  parent robot to see if any of those link motions will be prevented by
  contacts on those links.  The motion is expressed with respect to the
  base frame of the robot.  This is only used when dynamics are off.
*/
bool
Robot::contactsPreventMotion(const transf& motion) const
{
  int l;
  transf linkMotion;

  // check if we can move the base link
  if (base->contactsPreventMotion(motion)) return true;
  if (mountPiece && mountPiece->contactsPreventMotion(motion)) return true;


  // check if we can move all the kinematic chains and the robots connected
  // to them
  if (simpleContactsPreventMotion(motion)) return true;


  // if this robot is connected to another before it, try to do inv kinematics
  // and check if contacts on any of those links will prevent this motion
  if (parent) {
    transf newTran = tranToParentEnd*motion*base->getTran()*
      parent->getBase()->getTran().inverse();
    KinematicChain *chain = parent->getChain(parentChainNum);
    std::vector<transf> parentTrVec(chain->getNumLinks());    
    double *dofVals = new double[parent->getNumDOF()];

    if (parent->invKinematics(newTran,dofVals,parentChainNum)==FAILURE){
#ifdef GRASPITDBG	  
      printf("kinematics of parent robot prevent motion\n");
#endif
	  delete [] dofVals;
      return true;
    }
    
    parent->fwdKinematics(dofVals,parentTrVec,parentChainNum);
    delete [] dofVals;

    for (l=0;l<chain->getNumLinks();l++) {      
      if (chain->getLink(l)->getNumContacts()) {
	linkMotion = parentTrVec[l] * chain->getLink(l)->getTran().inverse();
	if (chain->getLink(l)->contactsPreventMotion(linkMotion)) {
#ifdef GRASPITDBG	  
	  printf("contacts on parent link %d prevent motion\n",l);
#endif
	  return true;
	}
      }
    } 
  }
  return false;
}


/*!
  This attempt to set the pose of the robot base to tr.  It does not check
  for collisions, but it will check the inverse kinematics of a parent
  robot (if it exists) to determine whether the move is valid.  If it is
  valid the DOF's of the parent are set, and this robot and all of its
  children are moved.
*/
int
Robot::setTran(const transf& tr)
{

  if (parent) {
    double *dofVals = new double[parent->getNumDOF()];
    transf parentBaseToEnd =
      tranToParentEnd*tr*parent->getBase()->getTran().inverse();

    if (parent->invKinematics(parentBaseToEnd,dofVals,parentChainNum)==FAILURE) {
	  delete [] dofVals;
      return FAILURE;
    }

#ifdef GRASPITDBG
    printf("Setting DOF vals: ");
    for (int i=0;i<parent->getNumDOF();i++)
      printf("%lf ",dofVals[i]);
    printf("\n");
#endif

    parent->setDOFVals(dofVals);
	delete [] dofVals;
  }
  else {
    simpleSetTran(tr);  
  }
  
  return SUCCESS;
}


/*!
  Attempts to move the DOF's from their current value to the new values
  provided in the \a desiredDOFVals array.  Collisions are checked and will
  halt the motion after the first contact is found.  If the stepsize for a DOF
  is too large it is possible that links may miss collisions with small
  objects.  After a collision is detected the links that collided are
  returned in the \a stoppedLinks vector.  If \a renderIt is \c TRUE then
  the intermediate steps will be rendered.
*/
ColReportT
Robot::moveDOFTo(double *desiredDOFVals,double *stepSize,bool renderIt,
		 std::vector<Link *> *stoppedLinks)
{  
  double *prevDOFVals = new double[numDOF];
  double *currDOFVals = new double[numDOF];
  double *newDOFVals = new double[numDOF];
  double *origDOFVals = new double[numDOF];

  int lastLink;
  bool done;
  int i,d,l,r,numCols;
  int itercount=0;
  double t,deltat,minDist;
  ColReportT colReport,result;
  transf motion;
  bool moveOK;

  getDOFVals(origDOFVals);

  do {
    moveOK = true;
  if (stoppedLinks) stoppedLinks->clear();

  // check contacts
  getDOFVals(currDOFVals);

  for (d=0;d<numDOF;d++) {
    newDOFVals[d] = currDOFVals[d] + stepSize[d];
    if (stepSize[d] > 0 && newDOFVals[d] > desiredDOFVals[d])
      newDOFVals[d] = desiredDOFVals[d];
    else if (stepSize[d] < 0 && newDOFVals[d] < desiredDOFVals[d])
      newDOFVals[d] = desiredDOFVals[d];
  }
  for (i=0;i<numChains;i++) {    
    std::vector<transf> linkTrVec(chainVec[i]->getNumLinks());    
    fwdKinematics(newDOFVals,linkTrVec,i);

    for (r=0;r<chainVec[i]->getNumAttachedRobots();r++) {
      lastLink = chainVec[i]->getNumLinks()-1;
      motion = chainVec[i]->getAttachedRobotOffset(r) * linkTrVec[lastLink] *
	chainVec[i]->getAttachedRobot(r)->getTran().inverse();

      if (chainVec[i]->getAttachedRobot(r)->simpleContactsPreventMotion(motion)) {
#ifdef GRASPITDBG
	  printf("contacts on attached robot prevent motion\n");
#endif	  
	if (stoppedLinks) stoppedLinks->push_back(chainVec[i]->getLink(lastLink));
	else {
	  delete [] origDOFVals;
	  delete [] prevDOFVals; delete [] currDOFVals; delete [] newDOFVals;
	  return colReport;
	}
      }
    }


    for (l=0;l<chainVec[i]->getNumLinks();l++) {      
      if (chainVec[i]->getLink(l)->getNumContacts()) {
	motion = linkTrVec[l] * chainVec[i]->getLink(l)->getTran().inverse();
#if 0
	std::cout << "new" << linkTrVec[l]<<"old"<<chainVec[i]->getLink(l)->getTran()<<std::endl;
	std::cout << "motion" << motion<<std::endl;
#endif
	

	if (chainVec[i]->getLink(l)->contactsPreventMotion(motion)) {
#ifdef GRASPITDBG
	  printf("contacts on link %d prevents motion\n",l);
#endif	  
	  if (stoppedLinks) stoppedLinks->push_back(chainVec[i]->getLink(l));
	  else {
	    delete [] origDOFVals;
	    delete [] prevDOFVals; delete [] currDOFVals; delete [] newDOFVals;
	    return colReport;
	  }
	}
      }
    }
  }
      
  if (stoppedLinks && !stoppedLinks->empty()) {
    delete [] origDOFVals;
    delete [] prevDOFVals; delete [] currDOFVals; delete [] newDOFVals;
    return colReport;
  }

  do {
    done = true;
	itercount++;
    getDOFVals(currDOFVals);
    for (d=0;d<numDOF;d++) {
      newDOFVals[d] = currDOFVals[d] + stepSize[d];
      if (stepSize[d] > 0 && newDOFVals[d] > desiredDOFVals[d])
	newDOFVals[d] = desiredDOFVals[d];
      else if (stepSize[d] < 0 && newDOFVals[d] < desiredDOFVals[d])
	newDOFVals[d] = desiredDOFVals[d];
      else if (stepSize[d] != 0) done = false;
    }

	
    setDOFVals(newDOFVals);

    numCols = myWorld->getCollisionReport(colReport);
    if (numCols) done = true;
    else if (renderIt && (itercount%25==0) && 
	  graspItGUI && graspItGUI->getIVmgr()->getWorld()==myWorld)
      graspItGUI->getIVmgr()->getViewer()->render();


  } while (!done);

  if (!numCols) {
    delete [] origDOFVals;
    delete [] prevDOFVals; delete [] currDOFVals; delete [] newDOFVals;
    return colReport;
  }

#ifdef GRASPITDBG
  printf("%d collision(s) found!\n",numCols);
  for (i=0;i<numCols;i++) {
    printf("%s collided with %s\n",colReport[i].first->getName().latin1(),
	   colReport[i].second->getName().latin1());
  }
#endif
  
  memcpy(prevDOFVals,currDOFVals,numDOF*sizeof(double));
  t = 0.5;
  deltat = 0.5;
  done = false;

  while (!done && deltat > 1.0e-20) {
    deltat *= 0.5;
    for (d=0;d<numDOF;d++)
      currDOFVals[d] = t*newDOFVals[d] + (1.0-t)*prevDOFVals[d];
    
#ifdef GRASPITDBG
     printf("moving to time: %le\n",t);
#endif
    
    setDOFVals(currDOFVals);
    
    minDist = myWorld->getDist(colReport[0].first,colReport[0].second);
    for (i=1;i<numCols;i++)
      minDist = MIN(minDist,myWorld->getDist(colReport[i].first,
					     colReport[i].second));
#ifdef GRASPITDBG
       printf("minDist: %le\n",minDist);
#endif
    
    if (minDist > 0) {
      if (minDist < Contact::THRESHOLD * 0.5)
	break;
      t += deltat;
    }
    else
      t -= deltat;
  }
#ifdef GRASPITDBG
  if (deltat < 1.0e-20) printf("deltat failsafe hit\n");
  printf("deltat: %le\n",deltat);
#endif

  //determine which of the bodies that collided are now touching and add contacts
  result.clear();
  for (i=0;i<numCols;i++)
    if (myWorld->getDist(colReport[i].first,colReport[i].second) < Contact::THRESHOLD)
      result.push_back(colReport[i]);


  //Check that we are not now in collision.  We may have missed one if the
  //step size was to big.  If that's the case, we'll repeat the move with
  //a smaller step size

  numCols = myWorld->getCollisionReport(colReport);
  if (numCols) {
    moveOK = false;
	//myWorld->save("C:/bad.wld");
    setDOFVals(origDOFVals);
#ifdef GRASPITDBG
    printf("moveDOFTo: missed a collision, reducing step size and trying again.\n");
#endif
    for (i=0;i<numDOF;i++) {
      stepSize[i] /= 10.0;
      if (fabs(stepSize[i]) > 0 && fabs(stepSize[i]) < 1e-20) {
#ifdef GRASPITDBG
		printf("moveDOFTo: stepsize < 1e-20 and still could not perform the move\n");
#endif
	    moveOK=true;  // give up
	  }
	}
	if (moveOK) {
	  if (stoppedLinks) {
		for (i=0;i<numCols;i++) {
		  if (colReport[i].first->inherits("Link"))
	  		stoppedLinks->push_back((Link *)colReport[i].first);
	  	  if (colReport[i].second->inherits("Link"))
			stoppedLinks->push_back((Link *)colReport[i].second);
		}
	  }
	
	  delete [] origDOFVals;
	  delete [] prevDOFVals; delete [] currDOFVals; delete [] newDOFVals; 
	  return result;
    }
  }
  if (moveOK) myWorld->findContacts(result);
  } while (!moveOK);
  
  if (renderIt && graspItGUI && graspItGUI->getIVmgr()->getWorld()==myWorld)
    graspItGUI->getIVmgr()->getViewer()->render();


  delete [] origDOFVals;
  delete [] prevDOFVals; delete [] currDOFVals; delete [] newDOFVals; 
  return result;
}


/*!
  Given a kinematic chain number and a vector of chain end poses, this
  computes the inverse kinematics for each pose, and computes a smooth
  trajectory for each DOF to reach each pose.
*/
void
Robot::setChainEndTrajectory(std::vector<transf>& traj,int chainNum)
{
  int i,j,numPts = traj.size();
  double *dofVals = new double[numDOF];
  bool *dofInChain = new bool[numDOF];
  
  if (numPts < 1 || chainNum < 0 || chainNum > numChains-1) return;
  for (j=0;j<numDOF;j++)
    dofInChain[j] = false;

  for (j=0;j<chainVec[chainNum]->getNumJoints();j++)
    dofInChain[chainVec[chainNum]->getJoint(j)->getDOFNum()] = true;

  invKinematics(traj[0],dofVals,chainNum);
  for (j=0;j<numDOF;j++)
    if (dofInChain[j]) dofVec[j]->setTrajectory(&dofVals[j],1);
			 
  for (i=1;i<numPts;i++) {
    invKinematics(traj[i],dofVals,chainNum);
    for (j=0;j<numDOF;j++)
      if (dofInChain[j]) dofVec[j]->addToTrajectory(&dofVals[j],1);
  }
  delete [] dofVals;
  delete [] dofInChain;
}


/*!
  Given a start and end pose, this creates a number of intermediate poses
  that linearly interpolate between the two in cartesian space.  The
  start and end velocities of the end effector default to 0 but can be
  changed.  If the time needed for the move is not set, the trajectory
  will have an average velocity equal to the \a defaultTranVel and
  \a defaultRotVel.  The number of poses generated is determined by the
  amount of time needed for the move divided by the default dyanmic time
  step length.
*/
void
Robot::generateCartesianTrajectory(const transf &startTr, const transf &endTr,
				   std::vector<transf> &traj,
				   double startVel, double endVel,
				   double timeNeeded)
{
  int i,j,numSteps;
  double t,tpow,dist,angle,coeffs[5];    
  vec3 newPos,axis;
  Quaternion newRot;
    
  desiredTran = endTr;
  (endTr.rotation() * startTr.rotation().inverse()).ToAngleAxis(angle,axis);
  
  if (timeNeeded <= 0.0) {
    if (defaultTranslVel == 0.0 || defaultRotVel == 0.0) return;
    timeNeeded =
      MAX((endTr.translation() - startTr.translation()).len()/defaultTranslVel,
	  fabs(angle)/defaultRotVel);
  }

  //make this a whole number of timesteps
  numSteps = (int)ceil(timeNeeded/myWorld->getTimeStep());
  timeNeeded = numSteps*myWorld->getTimeStep();

#ifdef GRASPITDBG
  std::cout << "Desired Tran Traj numSteps " << numSteps<<std::endl;  
#endif

  if (numSteps) {
    traj.clear();
    traj.reserve(numSteps);
  }

  for (i=0;i<numSteps;i++) {
    t = (double)i/(double)(numSteps-1);
    
    coeffs[4] = 6.0 - 3.0*(startVel+endVel)*timeNeeded;
    coeffs[3] = -15.0 + (8.0*startVel + 7.0*endVel)*timeNeeded;
    coeffs[2] = 10.0 - (6.0*startVel + 4.0*endVel)*timeNeeded;
    coeffs[1] = 0.0;
    coeffs[0] = startVel*timeNeeded; 

    dist = 0.0;    
    tpow = 1.0;
    for (j=0;j<5;j++) {
      tpow *= t;
      dist += tpow*coeffs[j];
    }
    newRot = Quaternion::Slerp(dist,startTr.rotation(),endTr.rotation());
    newPos = (1.0-dist)*startTr.translation() + dist*endTr.translation();
    traj.push_back(transf(newRot,newPos));
  }
}


/*!
  Given a set of desired dofVals, this will compute a smooth trajectory
  for each joint so that each has a smooth acceleration and velocity
  profile.  The intermediate values become the setpoints for each
  joint controller.
*/
void
Robot::setDesiredDOFVals(double *dofVals)
{
  int i,j,d,numSteps;
  double timeNeeded;
  double t;
  double coeffs[5];    
  double tpow,q1,q0,qd0,qd1;
  double *traj;

  for (d=0;d<numDOF;d++) {
    if (dofVec[d]->getDesiredVelocity() == 0.0) continue;

#ifdef GRASPITDBG
    std::cout << "DOF "<<d<<" trajectory"<<std::endl;
#endif
    dofVec[d]->setDesiredPos(dofVals[d]);
    if (dofVec[d]->getVal() != dofVals[d]) {

      q0 = dofVec[d]->getVal();
      q1 = dofVals[d];
      qd0 = 0.0;//dofVec[d]->getActualVelocity();
      qd1 = 0.0;

      timeNeeded = fabs(dofVals[d]-dofVec[d]->getVal())/
	dofVec[d]->getDesiredVelocity();

      //make this a whole number of timesteps
      numSteps = (int)ceil(timeNeeded/myWorld->getTimeStep());
      timeNeeded = numSteps*myWorld->getTimeStep();

#ifdef GRASPITDBG      
      std::cout << "numSteps: "<<numSteps;
      std::cout << " time needed: "<<timeNeeded<<std::endl;
#endif
      traj = new double[numSteps];

      for (i=0;i<numSteps;i++) {
	t = (double)i/(double)(numSteps-1);

	coeffs[4] = 6.0*(q1 - q0) - 3.0*(qd1+qd0)*timeNeeded;
	coeffs[3] = -15.0*(q1 - q0) + (8.0*qd0 + 7.0*qd1)*timeNeeded;
	coeffs[2] = 10.0*(q1 - q0) - (6.0*qd0 + 4.0*qd1)*timeNeeded;
	coeffs[1] = 0.0;
	coeffs[0] = qd0*timeNeeded; 
	traj[i] = q0;

	tpow = 1.0;
	for (j=0;j<5;j++) {
	  tpow *= t;
	  traj[i] += tpow*coeffs[j];
	  }
#ifdef GRASPITDBG      
	std::cout <<i<<" "<<t<<" "<<traj[i]<<std::endl;
#endif
      }
      dofVec[d]->setTrajectory(traj,numSteps);
      delete [] traj;
    }
  }
#ifdef GRASPITDBG
  std::cout<<std::endl;
#endif
}


/*!
  This is only called when dynamics is on.  It updates the joint values
  of the dynamic joints and updates the current values of the robot DOF's.
*/
void
Robot::updateJointValues()
{
  int f,l,j;
  double val;

  for (f=0;f<numChains;f++) {
    for (l=0;l<chainVec[f]->getNumLinks();l++) {
      if (chainVec[f]->getLink(l)->getDynJoint())
	chainVec[f]->getLink(l)->getDynJoint()->
	  updateValues();
    }
  }
  for (f=0;f<numChains;f++) {
    for (j=0;j<chainVec[f]->getNumJoints();j++) {
      val = chainVec[f]->getJoint(j)->getDynamicsVal() / chainVec[f]->getJoint(j)->getRatio();
      dofVec[chainVec[f]->getJoint(j)->getDOFNum()]->setVal(val);
    }
  }
}
/*
void
Robot::updateJointValues()
{
  int c,l,j;
  DynamicBody *prevLink,*nextLink;
  Joint *thisJoint;
  transf diffTran,prevTran;
  double val;
  vec3 axis;
  double vel1,vel2;
  int prevLastJoint,lastJoint;

  for (c=0;c<numChains;c++) {
    l=0;
    prevLink = base;
    prevTran = chainVec[c]->getTran()*getTran();

    nextLink = chainVec[c]->getLink(l);
    lastJoint = chainVec[c]->getLastJoint(l);
    prevLastJoint = -1;

    for (j=0;j<chainVec[c]->getNumJoints();j++) {

      if (lastJoint == prevLastJoint + 1) {
	thisJoint = chainVec[c]->getJoint(j);
	if (thisJoint->getType() == REVOLUTE) {	  
	  axis = prevTran.affine().row(2);
	  vel1 = vec3(prevLink->getVelocity()[3],
		      prevLink->getVelocity()[4],
		      prevLink->getVelocity()[5]) % axis;
	  vel2= vec3(nextLink->getVelocity()[3],
		     nextLink->getVelocity()[4],
		     nextLink->getVelocity()[5]) % axis;
	  thisJoint->setVelocity(vel2-vel1);
	  
	  
	  diffTran = thisJoint->getTran(0.0).inverse() * nextLink->getTran() *
	    prevTran.inverse();
	  
	  diffTran.rotation().ToAngleAxis(val,axis);
	  if (axis.z() < 0) val = -val;
	  
	  
#ifdef GRASPITDBG
	  std::cout <<"link "<< l-1 <<" - link "<<l<<" joint angle: "<<val*180.0/M_PI<<" radians: "<<val;
	  //	  std::cout << " velocity: "<<vel2-vel1<<std::endl;
#endif
	  //	  printf("link %d - link %d joint angle: %lf\n",l-1,l,angle);
	  //	  std::cout << axis << std::endl;
	  thisJoint->setDynamicsVal(val);
	  val /= thisJoint->getRatio();
	  dofVec[thisJoint->getDOFNum()]->setVal(val);
#ifdef GRASPITDBG
	  //	  std::cout <<" dofVal: "<< angle*180.0/M_PI << std::endl;
#endif

	}
	else if (thisJoint->getType() == PRISMATIC) {
	  axis = prevTran.affine().row(2);
	  vel1 = vec3(prevLink->getVelocity()[0],
		      prevLink->getVelocity()[1],
		      prevLink->getVelocity()[2]) % axis;
	  vel2 = vec3(nextLink->getVelocity()[0],
		      nextLink->getVelocity()[1],
		      nextLink->getVelocity()[2]) % axis;
	  thisJoint->setVelocity(vel2-vel1);
	  
	  diffTran = nextLink->getTran() * prevTran.inverse() *
	    thisJoint->getTran(0.0).inverse();

	  val = diffTran.translation()[2];//%axis;  

#ifdef GRASPITDBG
	  std::cout <<"link "<< l-1 <<" - link "<<l<<" diff tran "<<diffTran<<" joint dist: "<<val;
	  //	  std::cout << " velocity: "<<vel2-vel1<<std::endl;
#endif
	  //	  printf("link %d - link %d joint angle: %lf\n",l-1,l,angle);
	  //	  std::cout << axis << std::endl;
	  thisJoint->setDynamicsVal(val);
	  val /= thisJoint->getRatio();
	  dofVec[thisJoint->getDOFNum()]->setVal(val);
#ifdef GRASPITDBG
	  //	  std::cout <<" dofVal: "<< angle*180.0/M_PI << std::endl;
#endif  
	}
      }
      else {
	std::cout << "MULTIPLE JOINTS" << std::endl;
      }

      if (j==lastJoint) {
	prevTran = nextLink->getTran();
	prevLink = nextLink;
	l++;
	nextLink = chainVec[c]->getLink(l);
	prevLastJoint = lastJoint;
	lastJoint = chainVec[c]->getLastJoint(l);
      }
    }
  }
}

*/
/*

void
Robot::updateJointValues()
{
  int c,l,j;
  DynamicBody *lastLink,*nextLink;
  Joint *thisJoint;
  transf diffTran,lastTran;
  double angle;
  vec3 axis;
  double vel1,vel2;

  for (c=0;c<numChains;c++) {
    l=0;
    lastLink = base;
    lastTran = chainVec[c]->getTran()*getTran();

    for (j=0;j<chainVec[c]->getNumJoints();j++) {
      nextLink = chainVec[c]->getLink(l);

      if (j==chainVec[c]->getLastJoint(l)) {	
	thisJoint = chainVec[c]->getJoint(j);
	if (thisJoint->getType() == REVOLUTE) {

	  axis = lastTran.affine().row(2);
	  vel1 = vec3(lastLink->getVelocity()[3],
		      lastLink->getVelocity()[4],
		      lastLink->getVelocity()[5]) % axis;
	  vel2= vec3(nextLink->getVelocity()[3],
		     nextLink->getVelocity()[4],
		     nextLink->getVelocity()[5]) % axis;
	  thisJoint->setVelocity(vel2-vel1);
	  
	  
	  diffTran = thisJoint->getTran(0.0).inverse() * nextLink->getTran() *
	    lastTran.inverse();

	  diffTran.rotation().ToAngleAxis(angle,axis);
	  if (axis.z() < 0) angle = -angle;


#ifdef GRASPITDBG
	  //	  std::cout <<"link "<< l-1 <<" - link "<<l<<" joint angle: "<<angle*180.0/M_PI<<" radians: "<<angle;
	  //	  std::cout << " velocity: "<<vel2-vel1<<std::endl;
#endif
	  //	  printf("link %d - link %d joint angle: %lf\n",l-1,l,angle);
	  //	  std::cout << axis << std::endl;
	  thisJoint->setDynamicsVal(angle);
	  angle /= thisJoint->getRatio();
	  dofVec[thisJoint->getDOFNum()]->setVal(angle);
#ifdef GRASPITDBG
	  //	  std::cout <<" dofVal: "<< angle*180.0/M_PI << std::endl;
#endif

	}
	lastTran = nextLink->getTran();
	l++;
      }
    }
  }
}
*/


/*!
  Applies joint friction forces as a pair of equal and opposite forces
  to links connected at each joint.  Frictional forces resist the
  direction of motion of the joint and uses a viscous friction model
  with the coefficients defined in the robot configuration file.
*/
void
Robot::applyJointFriction()
{
  int c,j,l;
  Link *prevLink,*nextLink;
  vec3 jointAxis;
  transf jointTran;
  double force;

#ifdef GRASPITDBG
  std::cout << "applying joint friction "<<std::endl;
#endif
  for (c=0;c<numChains;c++) {
    prevLink = base;

    l=0;
#ifdef GRASPITDBG
    std::cout << "chain "<<c<<std::endl;
#endif
    for (j=0;j<chainVec[c]->getNumJoints();j++) {
      if (j>chainVec[c]->getLastJoint(l)) {
	l++;
	prevLink = nextLink;
#ifdef GRASPITDBG
	std::cout << "link "<<l<<std::endl;
#endif
      }
      nextLink = chainVec[c]->getLink(l);
      force = chainVec[c]->getJoint(j)->getFriction();
      
      // doesn't work for multiple joints
      if (l==0) {
	jointTran = chainVec[c]->getTran()*base->getTran();
	jointAxis = jointTran.affine().row(2);
	
	if (chainVec[c]->getJoint(j)->getType() == REVOLUTE) {
	  prevLink->addTorque(-force*jointAxis);
	  nextLink->addTorque(force*jointAxis);
	}
	else
	  std::cerr << "not handled yet"<< std::endl;
      }
      else {
	jointTran = prevLink->getTran()*nextLink->getTran().inverse();
	jointAxis = jointTran.affine().row(2);
	
	prevLink->addRelTorque(vec3(0,0,-force));
	nextLink->addRelTorque(force*jointAxis);
      }
    }
  }
}


/*!
  Applies DOF forces that were set as part of the joint control step
  of the dynamics.  The forces are applied as equal and opposite forces
  on the links connected to the first joint connected to the DOF.  Other
  joints connected to a DOF are considered passive joints and forces on
  those joints are computed as constraint forces.  Unfortunately, this
  currently only handles revolute joints, prismatic joints will be handled
  soon.
*/
void
Robot::applyMotorForces()
{
  int c,d,j,l;
  Link *prevLink,*nextLink;
  position jointPos;
  vec3 jointAxis;
  transf jointTran;
  bool *dofDone = new bool[numDOF];

  for (d=0;d<numDOF;d++)
    dofDone[d] = false;

  for (c=0;c<numChains;c++) {
    prevLink = base;

    l=0;
#ifdef GRASPITDBG
    std::cout << "chain "<<c<<std::endl;
#endif
    for (j=0;j<chainVec[c]->getNumJoints();j++) {
      if (j>chainVec[c]->getLastJoint(l)) {
	l++;
	prevLink = nextLink;
#ifdef GRASPITDBG
	std::cout << "link "<<l<<std::endl;
#endif
      }
      nextLink = chainVec[c]->getLink(l);
      d = chainVec[c]->getJoint(j)->getDOFNum();

      if (!dofDone[d]) {

	// doesn't work for multiple joints
	if (l==0) {
	  jointTran = chainVec[c]->getTran()*base->getTran();
	  jointPos = position::ORIGIN+jointTran.translation();
	  jointAxis = jointTran.affine().row(2);
	
	  if (chainVec[c]->getJoint(j)->getType() == REVOLUTE) {
	    prevLink->addTorque(-dofVec[d]->getForce()*jointAxis);
	    nextLink->addTorque(dofVec[d]->getForce()*jointAxis);
	  }
	  else
	    std::cerr << "not handled yet"<< std::endl;
	}
	else {
	  jointTran = prevLink->getTran()*nextLink->getTran().inverse();
	  jointPos = position::ORIGIN+jointTran.translation();
	  jointAxis = jointTran.affine().row(2);

	  prevLink->addRelTorque(vec3(0,0,-dofVec[d]->getForce()));
	  nextLink->addRelTorque(dofVec[d]->getForce()*jointAxis);
	}
      }
      dofDone[d] = true;
    }
  }
  delete [] dofDone;
}

//! Helper structure to keep track of joint data during contraint building
/*!
  Keeps track of the joint data from the first joint found for each DOF, so
  that if a another passivley coupled joint is also connected to the same DOF,
  a constraint can be added linking it to this one.
*/
struct masterJointT {
  vec3 freeRotAxis;
  double ratio;
  Body *prevLink,*nextLink;
};

typedef masterJointT *masterJointPtr;

  
/*!
  Adds the constraints for joint limits and passively coupled joints to
  the LCP matrices.
*/
void
Robot::buildDOFConstraints(const std::vector<int> &islandIndices,
			     int numBodies,
			     double* Nu,double *eps,
			     double* H, double *g,
			     double h,int &ncn,int &hcn)
{
  int f,l,j,dof,lastJoint,row,dir;
  int numFreeRotAxes,numFreeTranslAxes;
  transf b1JointTran;
  KinematicChain *chain;
  Link *prevLink,*nextLink;
  double revJointRatio[3];  
  //  double prismJointRatio[3];
  double ratio;
  int revDOF[3];
  //  int prismDOF[3];
  vec3 freeRotAxis[3];
  //  vec3 freeTranslAxis[3];
  //  vec3 constrainedAxis[3];
  masterJointPtr *DOFMasterJoint;

  // deals with compiler warning
  eps = NULL;

  DOFMasterJoint = new masterJointPtr[numDOF];
  for (dof=0;dof<numDOF;dof++) DOFMasterJoint[dof]=NULL;

  for (f=0;f<numChains;f++) {
    chain = chainVec[f];	
    b1JointTran = chain->getTran() * getTran();
    prevLink = getBase();
    numFreeRotAxes = 0;
    numFreeTranslAxes = 0;
      
//       //    frameTransl = -finger->getTran().translation();
//       frameTransl = b1JointTran.translation() - 
// 		     robot->getTran().translation();

//       cross[0]=0.0; cross[3]=-frameTransl.z(); cross[6]= frameTransl.y();
//       cross[1]= frameTransl.z(); cross[4]=0.0; cross[7]=-frameTransl.x();
//       cross[2]=-frameTransl.y(); cross[5]= frameTransl.x(); cross[8]=0.0;
    
//       cross *= b1JointTran.affine().transpose();

//       row = 6*islandIndices[prevLink->getId()];
//       Nu[(ncn)*6*numBodies +row+3]= -cross[0];
//       Nu[(ncn)*6*numBodies +row+4]= -cross[1];
//       Nu[(ncn)*6*numBodies +row+5]= -cross[2];
      
//       Nu[(ncn+1)*6*numBodies +row+3]= -cross[3];
//       Nu[(ncn+1)*6*numBodies +row+4]= -cross[4];
//       Nu[(ncn+1)*6*numBodies +row+5]= -cross[5];
    
//       Nu[(ncn+2)*6*numBodies +row+3]= -cross[6];
//       Nu[(ncn+2)*6*numBodies +row+4]= -cross[7];
//       Nu[(ncn+2)*6*numBodies +row+5]= -cross[8];

    for (l=0,j=0;j<chain->getNumJoints();j++) {
	  numFreeRotAxes = 0;
	  nextLink = chain->getLink(l);
	  lastJoint = chain->getLastJoint(l); 
	  
	  if (chain->getJoint(j)->getType() == REVOLUTE) {
	    freeRotAxis[numFreeRotAxes] = b1JointTran.affine().row(2);
	    revDOF[numFreeRotAxes] = chain->getJoint(j)->getDOFNum()+6;
	    revJointRatio[numFreeRotAxes++] = chain->getJoint(j)->getRatio();

   	    dof = chain->getJoint(j)->getDOFNum();
	    if (DOFMasterJoint[dof]) {
	    
	      ratio = 1.0/revJointRatio[0];
	      row = 6*islandIndices[prevLink->getId()];
	      Nu[(ncn)*6*numBodies + row+3] -= ratio * freeRotAxis[0][0];
	      Nu[(ncn)*6*numBodies + row+4] -= ratio * freeRotAxis[0][1];
	      Nu[(ncn)*6*numBodies + row+5] -= ratio * freeRotAxis[0][2];
	    
	      row = 6*islandIndices[nextLink->getId()];
	      Nu[(ncn)*6*numBodies + row+3] +=  ratio * freeRotAxis[0][0];
	      Nu[(ncn)*6*numBodies + row+4] +=  ratio * freeRotAxis[0][1];
	      Nu[(ncn)*6*numBodies + row+5] +=  ratio * freeRotAxis[0][2];
	    
	      ratio = 1.0/DOFMasterJoint[dof]->ratio;
	    
	      row = 6*islandIndices[DOFMasterJoint[dof]->prevLink->getId()];
	      Nu[(ncn)*6*numBodies + row+3] +=
	        ratio * DOFMasterJoint[dof]->freeRotAxis[0];
	      Nu[(ncn)*6*numBodies + row+4] +=
	        ratio * DOFMasterJoint[dof]->freeRotAxis[1];
	      Nu[(ncn)*6*numBodies + row+5] +=
	        ratio * DOFMasterJoint[dof]->freeRotAxis[2];
	    
	      row = 6*islandIndices[DOFMasterJoint[dof]->nextLink->getId()];
	      Nu[(ncn)*6*numBodies + row+3] +=
	        - ratio * DOFMasterJoint[dof]->freeRotAxis[0];
	      Nu[(ncn)*6*numBodies + row+4] +=
	        - ratio * DOFMasterJoint[dof]->freeRotAxis[1];
	      Nu[(ncn)*6*numBodies + row+5] +=
	        - ratio * DOFMasterJoint[dof]->freeRotAxis[2];

	      ncn++;
		}
	    else {
	      dof = chainVec[f]->getJoint(j)->getDOFNum();
	      DOFMasterJoint[dof] = new masterJointT;
	      DOFMasterJoint[dof]->freeRotAxis = freeRotAxis[0];
	      DOFMasterJoint[dof]->ratio = revJointRatio[0];
	      DOFMasterJoint[dof]->prevLink = prevLink;
	      DOFMasterJoint[dof]->nextLink = nextLink;

	      // check if this DOF is at a limit
	      if (dofVec[dof]->getVal() <= dofVec[dof]->getMin()+0.01) {
	        dir = 1;
		g[hcn] = MIN(0.0,-ERP/h * (0.005 - (dofVec[dof]->getVal() - dofVec[dof]->getMin())));
#ifdef GRASPITDBG
	        std::cout << "adding dof limit constraint for DOF "<<dof<<"  error: "<<g[hcn]<<std::endl;
#endif
		  }
	      else if (dofVec[dof]->getVal() >= dofVec[dof]->getMax()-0.01) {
	        dir = -1;
		g[hcn] = MIN(0.0,-ERP/h * (0.005 - (dofVec[dof]->getMax() - dofVec[dof]->getVal())));
#ifdef GRASPITDBG
	        std::cout << "adding dof limit constraint for DOF "<<dof<<"  error: "<<g[hcn]<<std::endl;
#endif
		  }
	      else dir = 0;
	    
	      if (dir) {
	        row = 6*islandIndices[prevLink->getId()];
	        H[(hcn)*6*numBodies + row+3] -= dir * chainVec[f]->getJoint(j)->getWorldAxis()[0];
	        H[(hcn)*6*numBodies + row+4] -= dir * chainVec[f]->getJoint(j)->getWorldAxis()[1];
	        H[(hcn)*6*numBodies + row+5] -= dir * chainVec[f]->getJoint(j)->getWorldAxis()[2];
	      
	        row = 6*islandIndices[nextLink->getId()];
	        H[(hcn)*6*numBodies + row+3] +=  dir * chainVec[f]->getJoint(j)->getWorldAxis()[0];
	        H[(hcn)*6*numBodies + row+4] +=  dir * chainVec[f]->getJoint(j)->getWorldAxis()[1];
	        H[(hcn)*6*numBodies + row+5] +=  dir * chainVec[f]->getJoint(j)->getWorldAxis()[2];

	        hcn++;
	      }
	    }
	  }
      if (j == lastJoint) {
		l++;
		b1JointTran = nextLink->getTran();
		prevLink = nextLink;
	  }
	  else {
		b1JointTran = chain->getJoint(j+1)->getDynamicsTran() * b1JointTran;
	  }
	}
  }
  for (dof=0;dof<numDOF;dof++)
    if (DOFMasterJoint[dof]) delete DOFMasterJoint[dof];
  delete [] DOFMasterJoint;
}


/*!
  If the current simulation time is past the DOF setpoint update time
  this updates the DOF set points.  Then the PD position controller for
  each DOF computes the control force for the DOF given the length of the
  current timestep.
*/
void
Robot::DOFController(double timeStep)
{
  int d;

#ifdef GRASPITDBG
  std::cout << " in Robot controller"<<std::endl;
#endif
  if (myWorld->getWorldTime() > dofUpdateTime) {
#ifdef GRASPITDBG
    std::cout << "Updating setpoints\n";
#endif
    for (d=0;d<numDOF;d++)
      dofVec[d]->updateSetPoint();
    dofUpdateTime += myWorld->getTimeStep();
  }

  for (d=0;d<numDOF;d++)
    dofVec[d]->PDPositionController(timeStep);
}

/*!
  Reads DOF values from a text stream (usually from a saved world file) and
  sets them
*/
QTextStream&
Robot::readDOFVals(QTextStream &is)
{
  double *dofVals = new double[numDOF];
  int i;
  
  for (i=0;i < numDOF;i++)
    is >> dofVals[i];
  
  setDOFVals(dofVals);

  delete [] dofVals;
  return is;
}

/*!
  Writes DOF values to a text stream (usually a world save file)
*/
QTextStream&
Robot::writeDOFVals(QTextStream &os)
{
  double *dofVals = new double[numDOF];
  int i;

  os << myFilename << endl;
  getDOFVals(dofVals);
  for (i=0;i<numDOF;i++)
    os << ' ' << dofVals[i]; 
  os << endl;

  delete [] dofVals;
  return os;
}

//////////////////////////////////////////////////////////////////////////////
//                           Hand Methods
//////////////////////////////////////////////////////////////////////////////

/*!
  Simply creates a new grasp object
*/
Hand::Hand(World *w,const char *name) : Robot(w,name)
{
  grasp = new Grasp(this);
}

/*!
  Deletes the associate grasp object
*/
Hand::~Hand()
{
  std::cerr << "Deleting Hand: " << std::endl;
  delete grasp;
}

/*!
  Closes each DOF at a rate equal to \a speedFactor * its default velocity.
  The closing continues until a joint limit is reached or a contact
  prevents further motion.  The larger the \a speedFactor, the larger the
  individual steps will be and increases the likelyhood that a collision
  may be missed.  The \a renderIt flag controls whether the intermediate
  steps will be rendered
*/
void
Hand::autoGrasp(bool renderIt,double speedFactor)
{
  int i,j,f,l,d;
  bool done=false;
  double *desiredVals = new double[numDOF];
  std::vector<Link *> stoppedLinks;
  int numStoppedLinks;

  ColReportT colReport;

#ifdef GRASPITDBG
  std::cout << "in autograsp" << std::endl;
#endif

  if (myWorld->dynamicsAreOn()) {
    for (i=0;i<numDOF;i++) {
      if (dofVec[i]->getDefaultVelocity() > 0)
	desiredVals[i] = dofVec[i]->getMax();
      else if (dofVec[i]->getDefaultVelocity() < 0)
	desiredVals[i] = dofVec[i]->getMin();
      else desiredVals[i] = 0.0;
#ifdef GRASPITDBG
      std::cout <<"Desired val "<<i<<" "<<desiredVals[i]<<std::endl;
#endif
      //for now
      dofVec[i]->setDesiredVelocity(dofVec[i]->getDefaultVelocity());
    }
    setDesiredDOFVals(desiredVals);
    delete [] desiredVals;
    return;
  }

  bool *moving = new bool[numDOF];
  double *stepSize= new double[numDOF];
  double *origVals = new double[numDOF];

  for (i=0;i<numDOF;i++) {
    origVals[i] = dofVec[i]->getVal();
    desiredVals[i] = dofVec[i]->getMax();
    stepSize[i] = dofVec[i]->getDefaultVelocity()*speedFactor*
      AUTO_GRASP_TIME_STEP;
    moving[i] = (stepSize[i] != 0.0);
  }


  while (!done) {
#ifdef GRASPITDBG
    for (i=0;i<numDOF;i++)
      if (moving[i]) std::cout << i << " is moving" << std::endl;
      else std::cout << i << " is not moving" <<std::endl;

    std::cout << "calling movedof" << std::endl;
#endif
    colReport = moveDOFTo(desiredVals,stepSize,renderIt,&stoppedLinks);
    
    for (i=0;i<numDOF;i++) {
      if (dofVec[i]->getVal() == desiredVals[i]) moving[i] = false;
     }
      
    numStoppedLinks = stoppedLinks.size();

    for (i=0;i<numStoppedLinks;i++) {
      f = stoppedLinks[i]->getChainNum();
      l = stoppedLinks[i]->getLinkNum();
      if (f>=0)
	for (j=getFinger(f)->getLastJoint(l); j>=0;j--) {
	  d = getFinger(f)->getJoint(j)->getDOFNum();
	  desiredVals[d] = dofVec[d]->getVal();
	  stepSize[d] = 0.0;
	  moving[d] = false;
#ifdef GRASPITDBG
	  std::cout << "stopping " << d<<std::endl;
#endif
	}
    }

      /*
      if ((*cp)->getBody1()->inherits("Link") &&
	  ((Link *)(*cp)->getBody1())->getOwner() == this) {	
	f = ((Link *)(*cp)->getBody1())->getChainNum();
	l = ((Link *)(*cp)->getBody1())->getLinkNum();
	if (f>=0)
	  for (j=getFinger(f)->getLastJoint(l); j>=0;j--) {
	    d = getFinger(f)->getJoint(j)->getDOFNum();
	    desiredVals[d] = dofVec[d]->getVal();
	    moving[d] = false;
#ifdef GRASPITDBG
	    std::cout << "stopping " << d<<std::endl;
#endif
	  }
      }
      if ((*cp)->getBody2()->inherits("Link") &&
	  ((Link *)(*cp)->getBody2())->getOwner() == this) {
	f = ((Link *)(*cp)->getBody2())->getChainNum();
	l = ((Link *)(*cp)->getBody2())->getLinkNum();
	if (f>=0)
	  for (j=getFinger(f)->getLastJoint(l); j>=0;j--) {
	    d = getFinger(f)->getJoint(j)->getDOFNum();
	    desiredVals[d] = dofVec[d]->getVal();
	    moving[d] = false;
#ifdef GRASPITDBG
	    std::cout << "stopping " << d<<std::endl;
#endif
	  }
      }
      */
    
    done = true;
    for (i=0;i<numDOF;i++)
      if (moving[i]) {done=false;}
  }

  delete [] desiredVals;
  delete [] origVals;
  delete [] moving;
  delete [] stepSize;
}


/*!
  Currently this simply calls the robot controller, but this is used
  sometimes to test grasp controllers.
*/
void
Hand::DOFController(double timeStep)
{

#ifdef GRASPITDBG
  std::cout << " in hand controller"<<std::endl;
#endif
  Robot::DOFController(timeStep);

  /*
  int d,numContacts;

if (myWorld->getWorldTime() > dofUpdateTime) {
    std::cout << "Updating grasp forces\n";
      grasp->collectContacts();
      numContacts = grasp->getNumContacts();
  
      if (numContacts > 0) {
	grasp->setGripForce(20.0);
	grasp->buildGraspMap();
	grasp->buildJacobian();    
	if (grasp->findOptimalGraspForce()==SUCCESS) {
	  for (d=0;d<numDOF;d++) {
#ifdef GRASPITDBG
	    printf("setting dof effort %d to: %lf\n",d,grasp->getOptDOFEfforts()[d]);
#endif
	    dofVec[d]->setForce(1.0e+9*grasp->getOptDOFEfforts()[d]);
	  }
	}
      }      
      dofUpdateTime += 10*myWorld->getTimeStep();
      }*/


}
