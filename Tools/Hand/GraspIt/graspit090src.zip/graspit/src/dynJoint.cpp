//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: dynJoint.cpp,v 1.9 2004/02/12 21:35:26 amiller Exp $
//
//######################################################################

/*! \file
\brief Implements the DynJoint classes.
*/

#include "dynJoint.h"
#include "joint.h"
#include "body.h"
#include <math.h>

//#define GRASPITDBG


#define ERP 0.0

/*! With a fixed joint, there are no unconstrained DOF values to update.
    This is a stub.
*/
void
FixedDynJoint::updateValues()
{
}

/*!
  Fills in 6 constraint columns in the joint constraint matrix \a Nu .  It also
  computes the generalized position error between the two links or between the
  one link and the world coordinates it should be fixed to.  The errors are
  copied into the corresponding elements of the \a eps vector.  Nu^T * v = eps.
  
  \a numBodies
  are the number of bodies in this dynamic island, and \a islandIndices
  is a vector that maps a body ID to the index of that body within the vector
  of bodies for this dynamic island.  This allows us to compute the starting
  row numbers for the links connected to this joint. \a ncn is a counter
  that holds the current constraint number, thus the current column to use.  
*/
void
FixedDynJoint::buildConstraints(double *Nu,double *eps,int numBodies,
				const std::vector<int> &islandIndices,int &ncn)
{
  transf b2JointTran,b1JointTran;
  vec3 constrainedAxis[3];
  vec3 prevFrameTransl;
  vec3 nextFrameTransl;
  vec3 prevCOG,nextCOG;
  vec3 errorVec;
  Quaternion errorRot;
  mat3 prevCross,nextCross;
  int c,prevLinkRow,nextLinkRow;

  if (prevLink) {
    prevLinkRow = 6*islandIndices[prevLink->getId()];
    nextLinkRow = 6*islandIndices[nextLink->getId()];
    prevCOG = prevLink->getCoG() * prevLink->getTran()-position::ORIGIN;
    nextCOG = nextLink->getCoG() * nextLink->getTran()-position::ORIGIN;
    b2JointTran = nextFrame * nextLink->getTran();
    b1JointTran = prevFrame * prevLink->getTran();
      
    // constrain 3 translational velocities
    constrainedAxis[0] = b1JointTran.affine().row(0);
    constrainedAxis[1] = b1JointTran.affine().row(1);
    constrainedAxis[2] = b1JointTran.affine().row(2);
    
    prevFrameTransl = b1JointTran.translation() - prevCOG;
    nextFrameTransl = b2JointTran.translation() - nextCOG;
    
    prevCross[0]=0.0;
    prevCross[1]= prevFrameTransl.z();
    prevCross[2]=-prevFrameTransl.y();
    
    prevCross[3]=-prevFrameTransl.z();
    prevCross[4]=0.0;
    prevCross[5]= prevFrameTransl.x();
    
    prevCross[6]= prevFrameTransl.y();
    prevCross[7]=-prevFrameTransl.x();
    prevCross[8]=0.0;
    prevCross *= b1JointTran.affine().transpose();
    
    nextCross[0]=0.0;
    nextCross[1]= nextFrameTransl.z();
    nextCross[2]=-nextFrameTransl.y();
    
    nextCross[3]=-nextFrameTransl.z();
    nextCross[4]=0.0;
    nextCross[5]= nextFrameTransl.x();
    
    nextCross[6]= nextFrameTransl.y();
    nextCross[7]=-nextFrameTransl.x();
    nextCross[8]=0.0;
    nextCross *= b1JointTran.affine().transpose();  // b2?
    
    errorVec = (b2JointTran.translation() - b1JointTran.translation()) *
      b1JointTran.inverse();
    
    for (c=0;c<3;c++) {
      Nu[(ncn)*6*numBodies + prevLinkRow]   -= constrainedAxis[c][0];
      Nu[(ncn)*6*numBodies + prevLinkRow+1] -= constrainedAxis[c][1];
      Nu[(ncn)*6*numBodies + prevLinkRow+2] -= constrainedAxis[c][2];
      Nu[(ncn)*6*numBodies + prevLinkRow+3] -= prevCross[3*c];
      Nu[(ncn)*6*numBodies + prevLinkRow+4] -= prevCross[3*c+1];
      Nu[(ncn)*6*numBodies + prevLinkRow+5] -= prevCross[3*c+2];
      
      Nu[(ncn)*6*numBodies + nextLinkRow]   += constrainedAxis[c][0];
      Nu[(ncn)*6*numBodies + nextLinkRow+1] += constrainedAxis[c][1];
      Nu[(ncn)*6*numBodies + nextLinkRow+2] += constrainedAxis[c][2];
      Nu[(ncn)*6*numBodies + nextLinkRow+3] += nextCross[3*c];
      Nu[(ncn)*6*numBodies + nextLinkRow+4] += nextCross[3*c+1];
      Nu[(ncn)*6*numBodies + nextLinkRow+5] += nextCross[3*c+2];
      
      eps[ncn] = -errorVec[c];
	  constraintError[c] = errorVec[c];
      ncn++;
    }
    
    errorRot = b2JointTran.rotation().inverse() * b1JointTran.rotation();
    
    errorVec[0] = errorRot.x;
    errorVec[1] = errorRot.y;
    errorVec[2] = errorRot.z;
    if (errorRot.w < 0)
      errorVec = -errorVec;
    
    //	errorVec = nextLink->getTran().rotation() * errorVec;
#ifdef GRASPITDBG
    std::cout << "errorVec: "<<errorVec<<std::endl;
#endif
    for (c=0;c<3;c++) {
      Nu[(ncn)*6*numBodies + prevLinkRow+3] -= constrainedAxis[c][0];
      Nu[(ncn)*6*numBodies + prevLinkRow+4] -= constrainedAxis[c][1];
      Nu[(ncn)*6*numBodies + prevLinkRow+5] -= constrainedAxis[c][2];
      
      Nu[(ncn)*6*numBodies + nextLinkRow+3] += constrainedAxis[c][0];
      Nu[(ncn)*6*numBodies + nextLinkRow+4] += constrainedAxis[c][1];
      Nu[(ncn)*6*numBodies + nextLinkRow+5] += constrainedAxis[c][2];
      
      eps[ncn] = 2*errorVec[c];
	  constraintError[c+3] = -2*errorVec[c];
      ncn++;
    }
  }
  else {
    nextLinkRow = 6*islandIndices[nextLink->getId()];
	b2JointTran = nextFrame * nextLink->getTran();
    errorVec = b2JointTran.translation() -
      prevFrame.translation();
    
    for (c=0;c<3;c++) {
      Nu[(ncn)*6*numBodies + nextLinkRow+c]   += 1.0;	    
      eps[ncn] = -errorVec[c];
	  constraintError[c] = errorVec[c];
      ncn++;
    }
      
    errorRot = b2JointTran.rotation().inverse() *
      prevFrame.rotation();
    
    errorVec[0] = errorRot.x;
    errorVec[1] = errorRot.y;
    errorVec[2] = errorRot.z;
    if (errorRot.w < 0)
      errorVec = -errorVec;
    
    errorVec = b2JointTran.rotation() * errorVec;
#ifdef GRASPITDBG
    std::cout << "errorVec: "<<errorVec<<std::endl;
#endif
    
    for (c=3;c<6;c++) {
      Nu[(ncn)*6*numBodies + nextLinkRow+c] += 1.0;
      eps[ncn] = 2*errorVec[c-3];
	  constraintError[c] = -2*errorVec[c-3];
      ncn++;
    }
  }	
}

/*!
  After a timestep has been completed, this computes the current joint angle
  and velocity from the relative positions and velocities of the connected
  links.
*/
void
RevoluteDynJoint::updateValues()
{
  transf b1JointTran,b2JointTran,diffTran;
  vec3 axis;
  double val,vel1,vel2;

  b1JointTran = prevFrame * prevLink->getTran();
  b2JointTran = nextFrame * nextLink->getTran();

  axis = b1JointTran.affine().row(2);
  joint->setWorldAxis(axis);
  vel1 = vec3(prevLink->getVelocity()[3],
	      prevLink->getVelocity()[4],
	      prevLink->getVelocity()[5]) % axis;
  vel2= vec3(nextLink->getVelocity()[3],
	     nextLink->getVelocity()[4],
	     nextLink->getVelocity()[5]) % axis;
  joint->setVelocity(vel2-vel1);


  diffTran = joint->getTran(0.0).inverse() * nextLink->getTran() *
    b1JointTran.inverse();
  
  diffTran.rotation().ToAngleAxis(val,axis);
  if (axis.z() < 0) val = -val;
  
  
#ifdef GRASPITDBG
  std::cout <<"link "<< prevLink->getName().latin1() <<" - link "<<nextLink->getName().latin1()<<" joint angle: "<<val*180.0/M_PI<<" radians: "<<val<<std::endl;
  //	  std::cout << " velocity: "<<vel2-vel1<<std::endl;
#endif
  //	  printf("link %d - link %d joint angle: %lf\n",l-1,l,angle);
  //	  std::cout << axis << std::endl;
  joint->setDynamicsVal(val);


}

/*!
  Fills in 5 constraint columns in the joint constraint matrix \a Nu .  It also
  computes the generalized position error between the two links.  The errors
  are copied into the corresponding elements of the \a eps vector.  Nu^T * v = eps.
  
  \a numBodies are the number of bodies in this dynamic island, and
  \a islandIndices is a vector that maps a body ID to the index of that
  body within the vector of bodies for this dynamic island.  This allows us
  to compute the starting row numbers for the links connected to this joint.
  \a ncn is a counter that holds the current constraint number, thus the
  current column to use.  
*/
void
RevoluteDynJoint::buildConstraints(double *Nu,double *eps,int numBodies,
				const std::vector<int> &islandIndices,int &ncn)
{
  int c;
  transf b1JointTran,b2JointTran;
  mat3 prevCross,nextCross;
  vec3 prevCOG,nextCOG;
  vec3 prevFrameTransl,nextFrameTransl;
  vec3 errorVec,constrainedAxis[3];
  int prevLinkRow,nextLinkRow;

  prevLinkRow = 6*islandIndices[prevLink->getId()];  
  nextLinkRow = 6*islandIndices[nextLink->getId()];  

  prevCOG = (prevLink->getCoG() * prevLink->getTran())-position::ORIGIN;
  nextCOG = (nextLink->getCoG() * nextLink->getTran())-position::ORIGIN;

  b1JointTran = prevFrame * prevLink->getTran();
  b2JointTran = joint->getDynamicsTran().inverse() *  nextLink->getTran();

  //  b2JointTran = b1JointTran * totalTran.inverse() * b2Tran;
  prevFrameTransl = b1JointTran.translation() - prevCOG;
  nextFrameTransl = b2JointTran.translation() - nextCOG;
	
  prevCross[0]=0.0;
  prevCross[1]= prevFrameTransl.z();
  prevCross[2]=-prevFrameTransl.y();
  
  prevCross[3]=-prevFrameTransl.z();
  prevCross[4]=0.0;
  prevCross[5]= prevFrameTransl.x();
  
  prevCross[6]= prevFrameTransl.y();
  prevCross[7]=-prevFrameTransl.x();
  prevCross[8]=0.0;
  prevCross *= b1JointTran.affine().transpose();  // b2?  
  
  nextCross[0]=0.0;
  nextCross[1]= nextFrameTransl.z();
  nextCross[2]=-nextFrameTransl.y();
  
  nextCross[3]=-nextFrameTransl.z();
  nextCross[4]=0.0;
  nextCross[5]= nextFrameTransl.x();
  
  nextCross[6]= nextFrameTransl.y();
  nextCross[7]=-nextFrameTransl.x();
  nextCross[8]=0.0;
  nextCross *= b1JointTran.affine().transpose();  // b2?
	
  constrainedAxis[0] = b1JointTran.affine().row(0);
  constrainedAxis[1] = b1JointTran.affine().row(1);
  constrainedAxis[2] = b1JointTran.affine().row(2);
  errorVec=(b2JointTran.translation() - b1JointTran.translation());

  for (c=0;c<3;c++) {
    Nu[(ncn)*6*numBodies + prevLinkRow]   -= constrainedAxis[c][0];
    Nu[(ncn)*6*numBodies + prevLinkRow+1] -= constrainedAxis[c][1];
    Nu[(ncn)*6*numBodies + prevLinkRow+2] -= constrainedAxis[c][2];
    Nu[(ncn)*6*numBodies + prevLinkRow+3] -= prevCross[3*c];
    Nu[(ncn)*6*numBodies + prevLinkRow+4] -= prevCross[3*c+1];
    Nu[(ncn)*6*numBodies + prevLinkRow+5] -= prevCross[3*c+2];
    
    Nu[(ncn)*6*numBodies + nextLinkRow]   += constrainedAxis[c][0];
    Nu[(ncn)*6*numBodies + nextLinkRow+1] += constrainedAxis[c][1];
    Nu[(ncn)*6*numBodies + nextLinkRow+2] += constrainedAxis[c][2];
    Nu[(ncn)*6*numBodies + nextLinkRow+3] += nextCross[3*c];
    Nu[(ncn)*6*numBodies + nextLinkRow+4] += nextCross[3*c+1];
    Nu[(ncn)*6*numBodies + nextLinkRow+5] += nextCross[3*c+2];
    
    eps[ncn] = -(errorVec % constrainedAxis[c]);
	constraintError[c] = (errorVec % constrainedAxis[c]);
    ncn++;
  }

  // constrain 2 rotational axes
  errorVec = b1JointTran.affine().row(2) * b2JointTran.affine().row(2);
  
  for (c=0;c<2;c++) {
    Nu[(ncn)*6*numBodies + prevLinkRow+3] -= constrainedAxis[c][0];
    Nu[(ncn)*6*numBodies + prevLinkRow+4] -= constrainedAxis[c][1];
    Nu[(ncn)*6*numBodies + prevLinkRow+5] -= constrainedAxis[c][2];
    
    Nu[(ncn)*6*numBodies + nextLinkRow+3] += constrainedAxis[c][0];
    Nu[(ncn)*6*numBodies + nextLinkRow+4] += constrainedAxis[c][1];
    Nu[(ncn)*6*numBodies + nextLinkRow+5] += constrainedAxis[c][2];
    
    eps[ncn] = -(errorVec % constrainedAxis[c]);
    constraintError[c+3] = (errorVec % constrainedAxis[c]);
    ncn++;
  }
}

/*!
  After a timestep has been completed, this computes the current joint angles
  and velocities from the relative positions and velocities of the connected
  links.
*/
void
UniversalDynJoint::updateValues()
{
  transf b1JointTran,b2JointTran;
  //  transf totalTran;
  vec3 axis,ax0,ax1,ax2;
  double val,vel1,vel2;

  b1JointTran = prevFrame * prevLink->getTran();
  b2JointTran = nextFrame * nextLink->getTran();

  ax0 = b1JointTran.affine().row(2);
  ax2 = b2JointTran.affine().row(2);
  ax1 = normalise(ax2*ax0);

#ifdef GRASPITDBG
  std::cout << "ax0: "<<ax0<<" len "<<ax0.len()<<std::endl;
  std::cout << "ax1: "<<ax1<<" len "<<ax1.len()<<std::endl;
  std::cout << "ax2: "<<ax2<<" len "<<ax2.len()<<std::endl;
#endif

  //  axis = b1JointTran.affine().row(2);
  //  joint1->setWorldAxis(axis);
  axis = ax1*ax2;
  joint1->setWorldAxis(axis);
  vel1 = vec3(prevLink->getVelocity()[3],
	      prevLink->getVelocity()[4],
	      prevLink->getVelocity()[5]) % axis;
  vel2= vec3(nextLink->getVelocity()[3],
	     nextLink->getVelocity()[4],
	     nextLink->getVelocity()[5]) % axis;
  joint1->setVelocity(vel2-vel1);

  vec3 ref1 = (joint2->getTran(0.0)*joint1->getTran(0.0)*b1JointTran).affine().row(2);
  val = atan2 (ax2 % (ax0 * ref1), ax2 % ref1);

  //  totalTran = nextLink->getTran()*b1JointTran.inverse();

  //  val = atan2(totalTran.translation()[1],totalTran.translation()[0]);

  //diffTran = joint1->getTran(0.0).inverse() * nextLink->getTran() *
  //  b1JointTran.inverse();
  
 // diffTran.rotation().ToAngleAxis(val,axis);

  
#ifdef GRASPITDBG
  printf("link %s - link %s joint1 angle: %le   %le(rad)\n",prevLink->getName().latin1(),
	 nextLink->getName().latin1(),val*180.0/M_PI,val);
  //	  std::cout << " velocity: "<<vel2-vel1<<std::endl;
#endif
  //	  printf("link %d - link %d joint angle: %lf\n",l-1,l,angle);
  //	  std::cout << axis << std::endl;
  joint1->setDynamicsVal(val);
  //  val /= joint1->getRatio();
//  dofVec[joint1->getDOFNum()]->setVal(val);
#ifdef GRASPITDBG
  //	  std::cout <<" dofVal: "<< angle*180.0/M_PI << std::endl;
#endif
  
  
  axis = b2JointTran.affine().row(2);
  //  joint2->setWorldAxis(axis);
  joint2->setWorldAxis(ax0*ax1);
  vel1 = vec3(prevLink->getVelocity()[3],
	      prevLink->getVelocity()[4],
	      prevLink->getVelocity()[5]) % axis;
  vel2= vec3(nextLink->getVelocity()[3],
	     nextLink->getVelocity()[4],
	     nextLink->getVelocity()[5]) % axis;
  
  joint2->setVelocity(vel2-vel1);
  
  //  totalTran = nextLink->getTran()*b1JointTran.inverse()*joint1->getDynamicsTran().inverse();
  //  val = atan2(totalTran.translation()[1],totalTran.translation()[0]);
  vec3 ref2 = (joint2->getTran(0.0)*joint1->getTran(0.0)).inverse().affine().row(2) * b2JointTran;
  val = atan2 (ref2 % ax1, ref2 % (ax1*ax2));

  #ifdef GRASPITDBG
  printf("link %s - link %s joint2 angle: %le   %le(rad)\n",prevLink->getName().latin1(),
	 nextLink->getName().latin1(),val*180.0/M_PI,val);
  //	  std::cout << " velocity: "<<vel2-vel1<<std::endl;
#endif
  //	  printf("link %d - link %d joint angle: %lf\n",l-1,l,angle);
  //	  std::cout << axis << std::endl;
  joint2->setDynamicsVal(val);
  val /= joint2->getRatio();
//  dofVec[joint1->getDOFNum()]->setVal(val);
#ifdef GRASPITDBG
  //	  std::cout <<" dofVal: "<< angle*180.0/M_PI << std::endl;
#endif
  
    
}


/*!
  Fills in 4 constraint columns in the joint constraint matrix \a Nu .  These
  constraints the relative translational velocity of the links at the joint and
  also prevent rotational motion about an axis perpendicular to the axes of the
  allowed rotations.  It also computes the generalized position error between
  the two links.  The errors are copied into the corresponding elements of the
  \a eps vector.  Nu^T * v = eps.
  
  \a numBodies are the number of bodies in this dynamic island, and
  \a islandIndices is a vector that maps a body ID to the index of that
  body within the vector of bodies for this dynamic island.  This allows us
  to compute the starting row numbers for the links connected to this joint.
  \a ncn is a counter that holds the current constraint number, thus the
  current column to use.  
*/
void
UniversalDynJoint::buildConstraints(double *Nu,double *eps,int numBodies,
				    const std::vector<int> &islandIndices,
				    int &ncn)
{
  int c;
  transf b1JointTran,b2JointTran;
  mat3 prevCross,nextCross;
  vec3 prevCOG,nextCOG;
  vec3 prevFrameTransl,nextFrameTransl;
  vec3 errorVec,constrainedAxis[3];
  int prevLinkRow,nextLinkRow;

  prevLinkRow = 6*islandIndices[prevLink->getId()];  
  nextLinkRow = 6*islandIndices[nextLink->getId()];  

  prevCOG = (prevLink->getCoG() * prevLink->getTran())-position::ORIGIN;
  nextCOG = (nextLink->getCoG() * nextLink->getTran())-position::ORIGIN;

  b1JointTran = prevFrame * prevLink->getTran();
  b2JointTran = nextFrame * nextLink->getTran();

  //  b2JointTran = b1JointTran * totalTran.inverse() * b2Tran;
  prevFrameTransl = b1JointTran.translation() - prevCOG;
  nextFrameTransl = b2JointTran.translation() - nextCOG;
	
  prevCross[0]=0.0;
  prevCross[1]= prevFrameTransl.z();
  prevCross[2]=-prevFrameTransl.y();
  
  prevCross[3]=-prevFrameTransl.z();
  prevCross[4]=0.0;
  prevCross[5]= prevFrameTransl.x();
  
  prevCross[6]= prevFrameTransl.y();
  prevCross[7]=-prevFrameTransl.x();
  prevCross[8]=0.0;
  prevCross *= b1JointTran.affine().transpose();  // b2?  
  
  nextCross[0]=0.0;
  nextCross[1]= nextFrameTransl.z();
  nextCross[2]=-nextFrameTransl.y();
  
  nextCross[3]=-nextFrameTransl.z();
  nextCross[4]=0.0;
  nextCross[5]= nextFrameTransl.x();
  
  nextCross[6]= nextFrameTransl.y();
  nextCross[7]=-nextFrameTransl.x();
  nextCross[8]=0.0;
  nextCross *= b1JointTran.affine().transpose();  // b2?
	
  constrainedAxis[0] = b1JointTran.affine().row(0);
  constrainedAxis[1] = b1JointTran.affine().row(1);
  constrainedAxis[2] = b1JointTran.affine().row(2);
  errorVec=(b2JointTran.translation() - b1JointTran.translation());

  for (c=0;c<3;c++) {
    Nu[(ncn)*6*numBodies + prevLinkRow]   -= constrainedAxis[c][0];
    Nu[(ncn)*6*numBodies + prevLinkRow+1] -= constrainedAxis[c][1];
    Nu[(ncn)*6*numBodies + prevLinkRow+2] -= constrainedAxis[c][2];
    Nu[(ncn)*6*numBodies + prevLinkRow+3] -= prevCross[3*c];
    Nu[(ncn)*6*numBodies + prevLinkRow+4] -= prevCross[3*c+1];
    Nu[(ncn)*6*numBodies + prevLinkRow+5] -= prevCross[3*c+2];
    
    Nu[(ncn)*6*numBodies + nextLinkRow]   += constrainedAxis[c][0];
    Nu[(ncn)*6*numBodies + nextLinkRow+1] += constrainedAxis[c][1];
    Nu[(ncn)*6*numBodies + nextLinkRow+2] += constrainedAxis[c][2];
    Nu[(ncn)*6*numBodies + nextLinkRow+3] += nextCross[3*c];
    Nu[(ncn)*6*numBodies + nextLinkRow+4] += nextCross[3*c+1];
    Nu[(ncn)*6*numBodies + nextLinkRow+5] += nextCross[3*c+2];
    
    eps[ncn] = -(errorVec % constrainedAxis[c]);
    constraintError[c] = (errorVec % constrainedAxis[c]);
    ncn++;
  }

  // constrain 1 rotational axes
  //  constrainedAxis[0]= b1JointTran.affine().row(2) * b2JointTran.affine().row(2);
  constrainedAxis[0]= joint1->getWorldAxis() * joint2->getWorldAxis();
  Nu[(ncn)*6*numBodies + prevLinkRow+3] -= constrainedAxis[0][0];
  Nu[(ncn)*6*numBodies + prevLinkRow+4] -= constrainedAxis[0][1];
  Nu[(ncn)*6*numBodies + prevLinkRow+5] -= constrainedAxis[0][2];
  
  Nu[(ncn)*6*numBodies + nextLinkRow+3] += constrainedAxis[0][0];
  Nu[(ncn)*6*numBodies + nextLinkRow+4] += constrainedAxis[0][1];
  Nu[(ncn)*6*numBodies + nextLinkRow+5] += constrainedAxis[0][2];
  
  //  eps[ncn] = -ERP/0.0025 * (b1JointTran.affine().row(2) %
  //			    b2JointTran.affine().row(2));
  eps[ncn] = -(joint1->getWorldAxis() % joint2->getWorldAxis());
  constraintError[3] = (joint1->getWorldAxis() % joint2->getWorldAxis());
  ncn++;

}

/*!
  After a timestep has been completed, this computes the current joint angles
  and velocities from the relative positions and velocities of the connected
  links.
*/
void
BallDynJoint::updateValues()
{
  transf b1JointTran,b2JointTran;
  //  transf totalTran;
  vec3 axis,ax0,ax1,ax2;
  double val,vel1,vel2;

  b1JointTran = prevFrame * prevLink->getTran();
  b2JointTran = nextFrame * nextLink->getTran();

  ax0 = b1JointTran.affine().row(2);
  ax2 = b2JointTran.affine().row(2);
  ax1 = normalise(ax2*ax0);

#ifdef GRASPITDBG
  std::cout << "ax0: "<<ax0<<" len "<<ax0.len()<<std::endl;
  std::cout << "ax1: "<<ax1<<" len "<<ax1.len()<<std::endl;
  std::cout << "ax2: "<<ax2<<" len "<<ax2.len()<<std::endl;
#endif

  //  axis = b1JointTran.affine().row(2);
  axis = ax1*ax2;
  joint1->setWorldAxis(axis);
  vel1 = vec3(prevLink->getVelocity()[3],
	      prevLink->getVelocity()[4],
	      prevLink->getVelocity()[5]) % axis;
  vel2= vec3(nextLink->getVelocity()[3],
	     nextLink->getVelocity()[4],
	     nextLink->getVelocity()[5]) % axis;
  joint1->setVelocity(vel2-vel1);

  vec3 ref1 = (joint2->getTran(0.0)*joint1->getTran(0.0)*b1JointTran).affine().row(2);
  val = atan2 (ax2 % (ax0 * ref1), ax2 % ref1);


  //  totalTran = nextLink->getTran()*b1JointTran.inverse();

  //  val = atan2(totalTran.translation()[1],totalTran.translation()[0]);

  //diffTran = joint1->getTran(0.0).inverse() * nextLink->getTran() *
  //  b1JointTran.inverse();
  
 // diffTran.rotation().ToAngleAxis(val,axis);

  
#ifdef GRASPITDBG
  printf("link %s - link %s joint1 angle: %le   %le(rad)\n",prevLink->getName().latin1(),
	 nextLink->getName().latin1(),val*180.0/M_PI,val);
  //	  std::cout << " velocity: "<<vel2-vel1<<std::endl;
#endif
  //	  printf("link %d - link %d joint angle: %lf\n",l-1,l,angle);
  //	  std::cout << axis << std::endl;
  joint1->setDynamicsVal(val);
  //  val /= joint1->getRatio();
//  dofVec[joint1->getDOFNum()]->setVal(val);
#ifdef GRASPITDBG
  //	  std::cout <<" dofVal: "<< angle*180.0/M_PI << std::endl;
#endif
  
  axis = ax1;
  joint2->setWorldAxis(axis);
  vel1 = vec3(prevLink->getVelocity()[3],
	      prevLink->getVelocity()[4],
	      prevLink->getVelocity()[5]) % axis;
  vel2= vec3(nextLink->getVelocity()[3],
	     nextLink->getVelocity()[4],
	     nextLink->getVelocity()[5]) % axis;
  
  joint2->setVelocity(vel2-vel1);

  val = atan2 (ax2 % ax0, ax2 % (ax0*ax1));

#ifdef GRASPITDBG
  printf("link %s - link %s joint2 angle: %le   %le(rad)\n",prevLink->getName().latin1(),
	 nextLink->getName().latin1(),val*180.0/M_PI,val);
  //	  std::cout << " velocity: "<<vel2-vel1<<std::endl;
#endif
  //	  printf("link %d - link %d joint angle: %lf\n",l-1,l,angle);
  //	  std::cout << axis << std::endl;
  joint2->setDynamicsVal(val);
  
  axis = ax0*ax1;
  joint3->setWorldAxis(axis);
  vel1 = vec3(prevLink->getVelocity()[3],
	      prevLink->getVelocity()[4],
	      prevLink->getVelocity()[5]) % axis;
  vel2= vec3(nextLink->getVelocity()[3],
	     nextLink->getVelocity()[4],
	     nextLink->getVelocity()[5]) % axis;
  
  joint3->setVelocity(vel2-vel1);

  vec3 ref2 = (joint2->getTran(0.0)*joint1->getTran(0.0)).inverse().affine().row(2) * b2JointTran;
  val = atan2 (ref2 % ax1, ref2 % (ax1*ax2));

#ifdef GRASPITDBG
  printf("link %s - link %s joint3 angle: %le   %le(rad)\n",prevLink->getName().latin1(),
	 nextLink->getName().latin1(),val*180.0/M_PI,val);
  //	  std::cout << " velocity: "<<vel2-vel1<<std::endl;
#endif
  //	  printf("link %d - link %d joint angle: %lf\n",l-1,l,angle);
  //	  std::cout << axis << std::endl;
  joint3->setDynamicsVal(val);
  val /= joint3->getRatio();
//  dofVec[joint1->getDOFNum()]->setVal(val);
#ifdef GRASPITDBG
  //	  std::cout <<" dofVal: "<< angle*180.0/M_PI << std::endl;
#endif
  
    
}

/*!
  Fills in 3 constraint columns in the joint constraint matrix \a Nu .  These
  constrain the relative translational velocity between the links at
  the joint.  It also computes the position error between the two links.
  The errors are copied into the corresponding elements of the \a eps vector.
  Nu^T * v = eps.
  
  \a numBodies are the number of bodies in this dynamic island, and
  \a islandIndices is a vector that maps a body ID to the index of that
  body within the vector of bodies for this dynamic island.  This allows us
  to compute the starting row numbers for the links connected to this joint.
  \a ncn is a counter that holds the current constraint number, thus the
  current column to use.  
*/
void
BallDynJoint::buildConstraints(double *Nu,double *eps,int numBodies,
			       const std::vector<int> &islandIndices,
			       int &ncn)
{
  int c;
  transf b1JointTran,b2JointTran;
  mat3 prevCross,nextCross;
  vec3 prevCOG,nextCOG;
  vec3 prevFrameTransl,nextFrameTransl;
  vec3 errorVec,constrainedAxis[3];
  int prevLinkRow,nextLinkRow;

  prevLinkRow = 6*islandIndices[prevLink->getId()];  
  nextLinkRow = 6*islandIndices[nextLink->getId()];  

  prevCOG = (prevLink->getCoG() * prevLink->getTran())-position::ORIGIN;
  nextCOG = (nextLink->getCoG() * nextLink->getTran())-position::ORIGIN;

  b1JointTran = prevFrame * prevLink->getTran();
  b2JointTran = nextFrame * nextLink->getTran();

  //  b2JointTran = b1JointTran * totalTran.inverse() * b2Tran;
  prevFrameTransl = b1JointTran.translation() - prevCOG;
  nextFrameTransl = b2JointTran.translation() - nextCOG;
	
  prevCross[0]=0.0;
  prevCross[1]= prevFrameTransl.z();
  prevCross[2]=-prevFrameTransl.y();
  
  prevCross[3]=-prevFrameTransl.z();
  prevCross[4]=0.0;
  prevCross[5]= prevFrameTransl.x();
  
  prevCross[6]= prevFrameTransl.y();
  prevCross[7]=-prevFrameTransl.x();
  prevCross[8]=0.0;
  prevCross *= b1JointTran.affine().transpose();  // b2?  
  
  nextCross[0]=0.0;
  nextCross[1]= nextFrameTransl.z();
  nextCross[2]=-nextFrameTransl.y();
  
  nextCross[3]=-nextFrameTransl.z();
  nextCross[4]=0.0;
  nextCross[5]= nextFrameTransl.x();
  
  nextCross[6]= nextFrameTransl.y();
  nextCross[7]=-nextFrameTransl.x();
  nextCross[8]=0.0;
  nextCross *= b1JointTran.affine().transpose();  // b2?
	
  constrainedAxis[0] = b1JointTran.affine().row(0);
  constrainedAxis[1] = b1JointTran.affine().row(1);
  constrainedAxis[2] = b1JointTran.affine().row(2);
  errorVec=(b2JointTran.translation() - b1JointTran.translation());

  for (c=0;c<3;c++) {
    Nu[(ncn)*6*numBodies + prevLinkRow]   -= constrainedAxis[c][0];
    Nu[(ncn)*6*numBodies + prevLinkRow+1] -= constrainedAxis[c][1];
    Nu[(ncn)*6*numBodies + prevLinkRow+2] -= constrainedAxis[c][2];
    Nu[(ncn)*6*numBodies + prevLinkRow+3] -= prevCross[3*c];
    Nu[(ncn)*6*numBodies + prevLinkRow+4] -= prevCross[3*c+1];
    Nu[(ncn)*6*numBodies + prevLinkRow+5] -= prevCross[3*c+2];
    
    Nu[(ncn)*6*numBodies + nextLinkRow]   += constrainedAxis[c][0];
    Nu[(ncn)*6*numBodies + nextLinkRow+1] += constrainedAxis[c][1];
    Nu[(ncn)*6*numBodies + nextLinkRow+2] += constrainedAxis[c][2];
    Nu[(ncn)*6*numBodies + nextLinkRow+3] += nextCross[3*c];
    Nu[(ncn)*6*numBodies + nextLinkRow+4] += nextCross[3*c+1];
    Nu[(ncn)*6*numBodies + nextLinkRow+5] += nextCross[3*c+2];
    
    eps[ncn] = -(errorVec % constrainedAxis[c]);
    constraintError[c] = (errorVec % constrainedAxis[c]);
    ncn++;
  }
}
