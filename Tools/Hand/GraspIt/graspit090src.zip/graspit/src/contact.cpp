//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: contact.cpp,v 1.13 2004/02/12 21:35:26 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Implements the contact class
 */
/* standard C includes */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "contact.h"
#include "world.h"
#include "body.h"
#include "mytools.h"

#include <Inventor/nodes/SoCone.h>
#include <Inventor/nodes/SoCoordinate3.h>
#include <Inventor/nodes/SoCylinder.h>
#include <Inventor/nodes/SoIndexedFaceSet.h>
#include <Inventor/nodes/SoMaterial.h>
#include <Inventor/nodes/SoTransform.h>
#include <Inventor/nodes/SoTranslation.h>

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

int displayFlag;

//#define GRASPITDBG
const double Contact::THRESHOLD = 0.1;
int Contact::numFCVectors = 8;
double Contact::frictionEdges[6*MAX_FRICTION_EDGES];
int Contact::numFrictionEdges = 0;

/*!
  Initializes a new contact on body \a b1.  The other contacting body is \a b2.
  The contact position \a pos and the contact normal \a norm are expressed
  in local body coordinates.
*/
Contact::Contact(Body *b1, Body *b2, const double pos[3],const double norm[3])
{
  body1 = b1;
  body2 = b2;
  mate = NULL;
  wrench = NULL;
  body1Tran = b1->getTran();
  body2Tran = b2->getTran();
  
  updateCof();

  if (cof == 0.0) {
    frictionType = FL;
    contactDim = 1;
    lmiDim = 1;
  }
  else {
    frictionType = PCWF;
    contactDim = 3;
    lmiDim = 3;
  }

  normal = normalise(vec3(norm[0],norm[1],norm[2]));
  loc = position(pos[0],pos[1],pos[2]);
  vec3 tangentX,tangentY;

  if (fabs(normal % vec3(1,0,0)) > 1.0 - MACHINE_ZERO) {
    tangentX = normalise(normal * vec3(0,0,1));
  }
  else tangentX = normalise(normal * vec3(1,0,0));
  tangentY = normalise(normal * tangentX);
  
  frame = coordinate_transf(loc,tangentX,tangentY);
			 
  basisVecs = new double[6*contactDim];
  optimalCoeffs = new double[contactDim]; 

}

/*!
  Deletes contact basis vectors, optimal force coefficients, and
  friction cone boundary wrenches.  If the contact has an undeleted mate,
  it removes the mate's connection to this contact, and removes the mate
  contact from the other body (thus deleting it).
*/
Contact::~Contact()
{
  delete [] basisVecs;
  delete [] optimalCoeffs;
  if (wrench) delete [] wrench;

  if (mate) {
    mate->setMate(NULL);
    body2->removeContact(mate);
  }
#ifdef GRASPITDBG
  printf("deleting contact\n");
#endif
}

/*!
  First computes the new location of the contact point using the motion
  transform (expressed with respect to the body coordinate frame).  If the
  dot product of the contact point motion vector and the contact normal is
  less than zero, then the contact prevents this motion.
*/
bool Contact::preventsMotion(const transf& motion) const
{  
  if ( (loc*motion - loc) % normal < -MACHINE_ZERO) return true;
  return false;
}

/*!
  At each contact is a friction cone whose central axis is the contact
  normal and whose width is determined by the COF.  For the purpose of grasp
  analysis this cone is approximated as a convex sum of a finite number
  (numFCVectors) of force vectors on the cone boundary.  This routine computes
  the set of object wrenches corresponding to those force vectors.
*/
void Contact::computeWrenches()
{
  int i;
  double alpha;
  vec3 radius,forceVec,torqueVec,tangentX,tangentY;
  GraspableBody *object = (GraspableBody *)body1;

  if (wrench) delete [] wrench;
  wrench = new Wrench[Contact::numFCVectors];
#ifdef GRASPITDBG
  printf("COMPUTING WRENCHES\n");
#endif
  radius = loc - object->getCoG();
  tangentX = frame.affine().row(0);
  tangentY = frame.affine().row(1);

  for (alpha=0.0,i=0;i<Contact::numFCVectors;
       alpha+=2.0*M_PI/Contact::numFCVectors,i++) {
    
    forceVec = normal+(tangentX*cos(alpha)*cof)+
              (tangentY*sin(alpha)*cof);
    wrench[i].force = forceVec;
    wrench[i].torque = (radius*forceVec)/object->getMaxRadius();
  }
  
  radius /= 1000.0;  // express radius in meters
  i=0;
  if (contactDim > 1) {
    //    torqueVec = (radius*tangentX)/object->getMaxRadius();
    torqueVec = radius*tangentX;
    basisVecs[i++] = tangentX.x();  
    basisVecs[i++] = tangentX.y();  
    basisVecs[i++] = tangentX.z();  
    basisVecs[i++] = torqueVec.x(); 
    basisVecs[i++] = torqueVec.y(); 
    basisVecs[i++] = torqueVec.z(); 

    //torqueVec = (radius*tangentY)/object->getMaxRadius();
    torqueVec = radius*tangentY;
    basisVecs[i++] = tangentY.x();  
    basisVecs[i++] = tangentY.y();  
    basisVecs[i++] = tangentY.z();  
    basisVecs[i++] = torqueVec.x(); 
    basisVecs[i++] = torqueVec.y(); 
    basisVecs[i++] = torqueVec.z(); 
  }
  
  torqueVec = radius*normal;
  basisVecs[i++] = normal.x();    
  basisVecs[i++] = normal.y();    
  basisVecs[i++] = normal.z();    
  basisVecs[i++] = torqueVec.x(); 
  basisVecs[i++] = torqueVec.y(); 
  basisVecs[i++] = torqueVec.z(); 
}


/*!
  Recomputes the COF for this contact.  This is called when the material of
  one of the two bodies is changed.
*/
void
Contact::updateCof()
{
  cof = body1->getWorld()->getCOF(body1->getMaterial(),body2->getMaterial());
  kcof = body1->getWorld()->getKCOF(body1->getMaterial(),body2->getMaterial());
  body1->setContactsChanged();
  body2->setContactsChanged();
}

/*!
  Returns the correct coefficient of friction for this contact.  If either
  body is dynamic, and the relative velocity between them is greater than
  1.0 mm/sec (should be made a parameter), then it returns the kinetic COF,
  otherwise it returns the static COF.
*/
double
Contact::getCof() const
{
  DynamicBody *db;
  vec3 radius,vel1(vec3::ZERO),vel2(vec3::ZERO),rotvel;

  if (body1->isDynamic()) {
    db = (DynamicBody *)body1;
    radius = db->getTran().rotation() * (loc - db->getCoG());
    vel1.set(db->getVelocity()[0],db->getVelocity()[1],db->getVelocity()[2]);
    rotvel.set(db->getVelocity()[3],db->getVelocity()[4],db->getVelocity()[5]);
    vel1 += radius * rotvel;
  }
  if (body2->isDynamic()) {
    db = (DynamicBody *)body2;
    radius = db->getTran().rotation() * (mate->loc - db->getCoG());
    vel2.set(db->getVelocity()[0],db->getVelocity()[1],db->getVelocity()[2]);
    rotvel.set(db->getVelocity()[3],db->getVelocity()[4],db->getVelocity()[5]);
    vel2 += radius * rotvel;
  }
  if ((vel1 - vel2).len() > 1.0) {
#ifdef GRASPITDBG
    std::cout << "SLIDING!" << std::endl;
#endif
    return kcof;
  }
  else return cof;
}

/*!
  When the grasp force optimization completes it calls this routine to set
  this contact's optimal force.  This force is a compromise between minimizing
  internal grasp forces and how close the force is to the boundary of the
  friction cone, or starting to slip.
*/
void
Contact::setContactForce (double *optmx)
{
  for (int i=0;i<contactDim;i++)
    optimalCoeffs[i] = optmx[i];
}

/*!
  Each body has a thin layer around it that is Contact::THRESHOLD mm thick, and
  when another body is within that layer, the two bodies are in contact.
  During dynamic simulation, contacts provide constraints to prevent the two
  bodies from interpenetrating.  However, the constraint is a velocity
  constraint not a position one, so errors in position due to numerical issues
  can occur.  If the two bodies get closer than half the contact threshold,
  we correct this specifying a constraint error in the dynamics, which will
  serve to move the bodies apart.  This routine returns the distance that
  two bodies have violated that halfway constraint.
*/
double
Contact::getConstraintError()
{
	transf cf = frame * body1->getTran();
	transf cf2 = mate->getContactFrame() * body2->getTran();
	return MAX(0.0,Contact::THRESHOLD/2.0 - (cf.translation() - cf2.translation()).len());
}

/*!
  Takes pointers to the two bodies in contact, and the set of contacts returned
  from the collision detection system, and adds a contact to each body for each
  contact in the set.
 */
void
addContacts(Body *body1, Body *body2,ContactSetT contactSet)
{
  ContactSetT::iterator cp;
  Contact *c1,*c2;
  int i;

  for (i=0,cp=contactSet.begin();cp!=contactSet.end();cp++,i++) {

#ifdef GRASPITDBG
    std::cout << body1->getName().latin1()<<" - "<<body2->getName().latin1()<<
      " contact -> "<<
      cp->b1_pos[0]<<" "<<cp->b1_pos[1]<<" "<<cp->b1_pos[2]<<" "<<
      cp->b1_normal[0]<<" "<<cp->b1_normal[1]<<" "<<cp->b1_normal[2];
#endif

    //    position b1Pos(cp->b1_pos[0],cp->b1_pos[1],cp->b1_pos[2]);
    //    position b2Pos(cp->b2_pos[0],cp->b2_pos[1],cp->b2_pos[2]);

    // separationDist = (b1Pos * body1->getTran() - 
    //                   b2Pos * body2->getTran()).len();

    c1 = new Contact(body1,body2,cp->b1_pos,cp->b1_normal);
    c2 = new Contact(body2,body1,cp->b2_pos,cp->b2_normal);
    c1->setMate(c2);
    c2->setMate(c1);
    body1->addContact(c1);
    body2->addContact(c2);

  }
}

/*!
  This overloaded addContacts performs the same operation, but also returns
  lists of pointers to the contacts created for each body.
*/
void
addContacts(Body *body1, Body *body2,ContactSetT contactSet,
	    std::list<Contact *> &cl1, std::list<Contact *> &cl2)
{
  ContactSetT::iterator cp;
  Contact *c1,*c2;
  int i;

  for (i=0,cp=contactSet.begin();cp!=contactSet.end();cp++,i++) {

#ifdef GRASPITDBG
    std::cout << body1->getName().latin1()<<" - "<<body2->getName().latin1()<<
      " contact -> "<<
      cp->b1_pos[0]<<" "<<cp->b1_pos[1]<<" "<<cp->b1_pos[2]<<" "<<
      cp->b1_normal[0]<<" "<<cp->b1_normal[1]<<" "<<cp->b1_normal[2];
#endif

    c1 = new Contact(body1,body2,cp->b1_pos,cp->b1_normal);
    c2 = new Contact(body2,body1,cp->b2_pos,cp->b2_normal);
    c1->setMate(c2);
    c2->setMate(c1);
    body1->addContact(c1);
    body2->addContact(c2);
    cl1.push_back(c1);
    cl2.push_back(c2);
  }
}

/*!
  This initializes friction cone boundary wrenches that are used in the
  dynamics equations.  It can be used to set up elliptic approximations of
  soft finger contacts.  Consider the friction surface in 3-dimensions, with
  the x and y tangential friction and the torque about the z axis as the three
  axes.  The surface is divided into numLatitudes ellipses that are each
  parallel to the x-y plane.  The latitude of each is specified in the array
  phi.  The eccentricity of the ellipsoid is specified in the 3-vector eccen.
  The array numDirs holds the number of samples to take on each ellipse for
  each latitude.  Currently, we are only simulating point contacts with
  friction, so we only use one latitude at phi = 0, and set the eccentricity
  to [1,1,1].  Each time the number of vectors on the friction cone boundary
  is changed in the user settings this routine is called again with a new
  numDirs.
 */
int
Contact::setUpFrictionEdges(int numLatitudes,int numDirs[], double phi[],
			   double eccen[])
{
  int i,j,col;
  double theta,cosphi,sinphi,num,denom;

  numFrictionEdges = 0;
  for (i=0;i<numLatitudes;i++)
      numFrictionEdges += numDirs[i];

  if (numFrictionEdges > MAX_FRICTION_EDGES) return FAILURE;

  col = 0;
  for (i=0;i<numLatitudes;i++) {
    cosphi = cos(phi[i]);
    sinphi = sin(phi[i]);

    for (j=0;j<numDirs[i];j++) {
      theta = j * 2*M_PI/numDirs[i];
      
      num = cos(theta)*cosphi;
      denom = num*num/(eccen[0]*eccen[0]);
      num = sin(theta)*cosphi;
      denom += num*num/(eccen[1]*eccen[1]);
      num = sinphi;
      denom += num*num/(eccen[2]*eccen[2]);
      denom = sqrt(denom);

      frictionEdges[col*6]   = cos(theta)*cosphi/denom;
      frictionEdges[col*6+1] = sin(theta)*cosphi/denom;
      frictionEdges[col*6+2] = 0;
      frictionEdges[col*6+3] = 0;
      frictionEdges[col*6+4] = 0;
      frictionEdges[col*6+5] = sinphi/denom;
      col++;
    }
  }
  return SUCCESS;
}

