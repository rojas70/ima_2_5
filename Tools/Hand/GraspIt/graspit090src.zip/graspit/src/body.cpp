//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: body.cpp,v 1.28 2004/02/12 21:35:26 amiller Exp $
//
//######################################################################

/*! \file
  \brief Implements the body class hierarchy.
*/

#include <iostream>
#include <iomanip>
#include <qfile.h>

#include "body.h"
#include "world.h"
#include "robot.h"
#include "dynJoint.h"
#include "ivmgr.h"
#include "ivcollide.h"
#include "contact.h"
#include "graspitGUI.h"
extern "C" {
#include "maxdet.h"
}
#include "mytools.h"

#include <Inventor/SoDB.h>
#include <Inventor/SoInput.h>
#include <Inventor/actions/SoGetBoundingBoxAction.h>
#include <Inventor/actions/SoSearchAction.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoCoordinate3.h>
#include <Inventor/nodes/SoCylinder.h>
#include <Inventor/nodes/SoIndexedFaceSet.h>
#include <Inventor/nodes/SoMaterial.h>
#include <Inventor/nodes/SoPickStyle.h>
#include <Inventor/nodes/SoSwitch.h>
#include <Inventor/nodes/SoTransform.h>
#include <Inventor/nodes/SoTranslation.h>
#include <Inventor/draggers/SoRotateDiscDragger.h>
#include <Inventor/nodekits/SoWrapperKit.h>

#ifdef COIN2
#include <Inventor/VRMLnodes/SoVRMLGroup.h>
#endif


#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

//#define GRASPITDBG

#define SQR(x) ((x)*(x))
#define CUBE(x) ((x)*(x)*(x))
#define AXES_SCALE 100.0

SoMaterial *Body::coneMat = NULL;
SoMaterial *Body::zaxisMat = NULL;
const float Body::CONE_HEIGHT = 20.0;
int Body::instanceCount = 0;

double DynamicBody::defaultMass = 1000.0;


/*!
  Constructs an empty body with its material set to invalid, and the
  geometry pointer set to NULL.  Use \c load() to initialize the body from
  a model file.
*/
Body::Body(World *w,const char *name) : WorldElement(w,name)
{
  material = -1;
  id=-1;
  numContacts=0;
  showFC = false;
  IVGeomRoot = NULL; IVTran = NULL; IVMat = NULL; IVCones=NULL;

  instanceCount++;
  if (instanceCount == 1) {
    coneMat = new SoMaterial;
    coneMat->diffuseColor = SbColor(0.8f,0.0f,0.0f);
    coneMat->ambientColor = SbColor(0.2f,0.0f,0.0f);
    coneMat->emissiveColor = SbColor(0.4f,0.0f,0.0f);
    coneMat->transparency = 0.8f;
    coneMat->ref();

    zaxisMat = new SoMaterial;  
    zaxisMat->diffuseColor = SbColor(0,0,0);
    zaxisMat->ambientColor = SbColor(0,0,0);
    zaxisMat->ref();    
  }
}

/*!
  Copy constructor remains protected (should not be called by user)
*/
Body::Body(const Body &b) : WorldElement(b)
{
  material = b.material;
  showFC = b.showFC;
  IVGeomRoot = b.IVGeomRoot;
  IVTran = b.IVTran;
  IVMat = b.IVMat;
  IVCones = b.IVCones;

  // temp
  id = b.id;

  instanceCount++;
}

/*! 
 * Breaks all contacts, and removes the body from the world it occupies
 * (if any), thus removing it from the collision detection system.
 */
Body::~Body()
{
  breakContacts();
#ifdef GRASPITDBG
  std::cerr << "Deleting Body: " << myName <<std::endl;
#endif

  instanceCount--;
  if (instanceCount == 0) {
    coneMat->unref();
    coneMat = NULL;
    zaxisMat->unref();
    zaxisMat = NULL;
  }
}


/*!
  Opens and loads a body geometry file.  \a filename is the complete path to
  the body file, which should be in Inventor format.  If Coin2 is being used
  then the format may also be VRML.  The body is also added to the collision
  detection system. 
*/
int 
Body::load(const QString &filename)
{
  QFile file(filename);
  QString line,matStr;
  SoInput myInput;

  myFilename = filename.section('/',-1);
  if (name(0) == 0) {
    myName = filename.section('/',-1).section('.',0,0);
    setName(myName.latin1());
  }

  if (!file.open(IO_ReadOnly)) {
    QTWARNING("Could not open " + filename);
    return FAILURE;
  }
  QTextStream stream( &file );

  stream.readLine();  // inventor version line 
  line = stream.readLine();
  matStr = line.section('#',1).section(' ',0);
  if (matStr.isEmpty()) matStr = "wood";  //default material

  material = myWorld->getMaterialIdx(matStr);
  if (material==-1) {
	QTWARNING("invalid material type in body file: " + myFilename);
    file.close();
    return FAILURE;
  }
  file.close();
 

  //  eightbitname = (const char *)QFile::encodeName(filename);
  if (!myInput.openFile(filename.latin1())) {
	QTWARNING("Could not open Inventor file " + filename);
    return FAILURE;
  }

  if (!IVRoot) IVRoot = new SoSeparator;
  if (!IVTran) {
    IVTran = new SoTransform;
    IVRoot->insertChild(IVTran,0);
  }

#ifdef COIN2
  if (myInput.isFileVRML2()) {
    IVGeomRoot = SoDB::readAllVRML(&myInput);
  }
  else
#endif

    IVGeomRoot = SoDB::readAll(&myInput);

  myInput.closeFile();
  if (IVGeomRoot == NULL) {
	QTWARNING("A problem occurred while reading Inventor file" + filename);
    return FAILURE;
  }
  IVRoot->addChild(IVGeomRoot);
  SoSearchAction *sa = new SoSearchAction;
  sa->setType(SoMaterial::getClassTypeId());
  sa->setInterest(SoSearchAction::ALL);
  sa->apply(IVGeomRoot);

  IVMat = new SoMaterial;
  IVMat->diffuseColor.setIgnored(true);
  IVMat->ambientColor.setIgnored(true);
  IVMat->specularColor.setIgnored(true);
  IVMat->emissiveColor.setIgnored(true);
  IVMat->shininess.setIgnored(true);

  //insert the new material after every existing material so we can affect
  //the transparency
  if (sa->getPaths().getLength() == 0)
    IVGeomRoot->insertChild(IVMat,0);
  else for (int i=0;i<sa->getPaths().getLength();i++) {
    SoGroup *g = (SoGroup *)sa->getPaths()[i]->getNodeFromTail(1);
	if (((SoMaterial *)sa->getPaths()[i]->getTail())->transparency[0] == 0.0f)
	  g->insertChild(IVMat,sa->getPaths()[i]->getIndexFromTail(0)+1);	
  }
  delete sa;
   
  IVCones = new SoSeparator;
  IVRoot->addChild(IVCones);

  id = myWorld->ivc->addInventorObj(IVGeomRoot);
  col_Mat4 colTran;
  Tran.tocol_Mat4(colTran);
  myWorld->ivc->vc->UpdateTrans(id,colTran);

  return SUCCESS;
}


/*!
  Returns the current transparency value for the body (between 0 and 1).
  \sa setTransparency()
*/
float
Body::getTransparency() const
{
  return IVMat->transparency[0];
}  
  

/*!
  Set the current transparency value for the body.
  \a t is a value between 0 and 1, where 0 is opaque, 1 is transparent.
  \sa getTransparency()
*/
void
Body::setTransparency(float t)
{
  IVMat->transparency = t;
}

  
/*!
  Set the current material of the body to mat
  \sa getMaterial()
*/
void
Body::setMaterial(int mat)
{
  std::list<Contact *>::iterator cp;

  material = mat;
  if (showFC) IVCones->removeAllChildren();

  for (cp=contactList.begin();cp!=contactList.end();cp++) {
    (*cp)->updateCof();
    (*cp)->getMate()->updateCof();
    (*cp)->getBody2()->redrawFrictionCones();
  }
  redrawFrictionCones();
}


/*!
  Sets whether friction cones should be shown for this body.
*/
void
Body::showFrictionCones(bool on)
{
  showFC = on;
  redrawFrictionCones();

  /*
  if (!showFC && on) {
    for (cp=contactList.begin();cp!=contactList.end();cp++)
      drawFrictionCone(*cp);
  }
  else if (!on) IVCones->removeAllChildren();
  */

}


/*!
  Draws all the friction cones on the body
*/
void
Body::redrawFrictionCones()
{
  std::list<Contact *>::iterator cp;

  IVCones->removeAllChildren();
  if (showFC) {
    for (cp=contactList.begin();cp!=contactList.end();cp++)
      drawFrictionCone(*cp);
  }
}


/*!
  Sets the current world pose of the body to \a tr.  Collisions are not
  checked.
*/
int
Body::setTran(transf const &tr)
{
  static col_Mat4 colTran;

  if (tr == Tran) return SUCCESS;
  breakContacts();

  if (!myWorld->wasModified() && tr != Tran)
    myWorld->setModified();

  Tran = tr;
  Tran.tocol_Mat4(colTran);
  myWorld->ivc->vc->UpdateTrans(id,colTran);

  if (IVTran)
    Tran.toSoTransform(IVTran);

  return SUCCESS;
}

 
/*!
  Given a motion relative to body coordinates, this determines whether
  the current contacts allow that motion.
*/
bool
Body::contactsPreventMotion(const transf& motion) const
{
  std::list<Contact *>::iterator cp;
  std::list<Contact *> contactList;

  contactList = getContacts();
  for (cp=contactList.begin();cp!=contactList.end();cp++) {
    if ((*cp)->preventsMotion(motion)) {
      return true;
    }
  }
  return false;
}


/*!
  Breaks all contacts on the body, deleting entire contact list, and removes
  all friction cones if necessary.
*/
void
Body::breakContacts()
{
  std::list<Contact *>::iterator cp;

  if (!contactList.empty()) {
    setContactsChanged();
    for (cp=contactList.begin();cp!=contactList.end();cp++) {
      delete *cp; *cp = NULL;
    }
    contactList.clear();
  }
  numContacts = 0;

  if (showFC) IVCones->removeAllChildren();
}


/*! 
  Adds contact \a c to the body's contact list.  Assumes the contact is not
  already in the list.
  \sa removeContact()
*/
void
Body::addContact(Contact *c)
{
  setContactsChanged();
  contactList.push_back(c);
  numContacts++;

  if (showFC) drawFrictionCone(c);
}


/*!
  Removes contact c from the body's contact list.  Assumes the contact is
  in the list.
  \sa addContact() 
 */
void
Body::removeContact(Contact *c)
{
  int i;
  std::list<Contact *>::iterator cp;

  setContactsChanged();

  if (showFC) {
    for (cp=contactList.begin(),i=0;cp!=contactList.end();cp++,i++)
      if (*cp == c) {
	contactList.erase(cp);
	break;
      }

    IVCones->removeChild(i);
  }
  else contactList.remove(c);

  delete c;
  numContacts--;
}

/*!
  Given a contact this draws a friction cone in the proper place.
*/
void
Body::drawFrictionCone(Contact *contact)
{
  double height,alpha,cof;
  SoSeparator *cne;
  SoTransform *tran;
  SoIndexedFaceSet *ifs;
  SoCoordinate3 *coords;

  SbVec3f *points = new SbVec3f[Contact::numFCVectors+1];
  int32_t *cIndex = new int32_t[5*Contact::numFCVectors+1];
  int i;

  points[0].setValue(0,0,0);

#ifdef GRASPITDBG
  //  printf("adding friction cone for: %s\n",getName());
#endif

  cof = contact->getCof();

  height = Body::CONE_HEIGHT;
  cne = new SoSeparator;
  coords = new SoCoordinate3;
  ifs = new SoIndexedFaceSet;
  tran = new SoTransform;
  
  alpha = 0.0;
  for (i=0;i<Contact::numFCVectors;i++) {
    points[i+1].setValue(cos(alpha)*cof,sin(alpha)*cof,1.0);
    points[i+1] *= height;
    cIndex[4*i] = 0;
    cIndex[4*i+1] = (i+2 <= Contact::numFCVectors ? i+2 : 1);
    cIndex[4*i+2] =  i+1;
    cIndex[4*i+3] = -1;
    cIndex[4*Contact::numFCVectors+i] = i+1;
    alpha += 2.0*M_PI/Contact::numFCVectors;
  }
  cIndex[5*Contact::numFCVectors] = -1;
  
  coords->point.setValues(0,Contact::numFCVectors+1,points);
  ifs->coordIndex.setValues(0,5*Contact::numFCVectors+1,cIndex);
  delete [] points;
  delete [] cIndex;

  contact->getContactFrame().toSoTransform(tran);
  
  SoCylinder *zaxisCyl = new SoCylinder;
  zaxisCyl->radius = 0.05f;
  zaxisCyl->height = height;
  
  SoTransform *zaxisTran = new SoTransform;
  zaxisTran->translation.setValue(0,0,height/2.0);
  zaxisTran->rotation.setValue(SbVec3f(1,0,0),(float)M_PI/2.0f);
  
  SoSeparator *zaxisSep = new SoSeparator;
  zaxisSep->addChild(zaxisTran);
  zaxisSep->addChild(zaxisMat);
  zaxisSep->addChild(zaxisCyl);
  
  cne->addChild(tran);
  cne->addChild(zaxisSep);
  cne->addChild(coneMat);
  cne->addChild(coords);
  cne->addChild(ifs);
  IVCones->addChild(cne);
}


/*!
  Output method for writing body data to a text world configuration file.
*/
QTextStream&
operator<<(QTextStream &os, const Body &b)
{
  os << b.myFilename << endl;
  os << b.myWorld->getMaterialName(b.material) << endl;
  return os;
}

/*
ostream&
operator<<(ostream &os, const Body &b)
{
  os << b.myFilename << endl;
  os << getMaterialStr(b.material) << std::endl;
  return os;
}
*/

///////////////////////////////////////////////////////////////////////////////
//                              DynamicBody
///////////////////////////////////////////////////////////////////////////////

/*!
  Constructs an empty DynamicBody.  Use load() to initialize this class
  from a model file.
*/
DynamicBody::DynamicBody(World *w, const char *name) : Body(w,name)
{
  maxRadius = 0.0; mass = 0.0;
  showAx = showDynCF = false;
  IVAxes = NULL;
  IVWorstCase = NULL;
  fixed = false; dynJoint=NULL; dynamicsComputedFlag = false;
}


/*! 
  Creates a dynamic body from the basic body \a b.  Computes the mass
  properties automatically assuming a mass of \a m and uniform mass
  distribution.
*/
DynamicBody::DynamicBody(const Body &b, double m) : Body(b)
{

  init();

  mass = m;
  CoG = defaultCoG;
  maxRadius = defaultMaxRadius;
  memcpy(I,defaultI,9*sizeof(double));

  for (int i=0;i<9;i++)
    I[i] *= mass;

  Quaternion quat = Tran.rotation();
  vec3 cogOffset = quat * (CoG-position::ORIGIN);

  q[0] = Tran.translation().x()+cogOffset.x();
  q[1] = Tran.translation().y()+cogOffset.y();
  q[2] = Tran.translation().z()+cogOffset.z();
  q[3] = quat.w;
  q[4] = quat.x;
  q[5] = quat.y;
  q[6] = quat.z; 
  
}

/*!
  If there is a dynamic joint connected to this body, it is deleted before the
  body is destroyed.
*/
DynamicBody::~DynamicBody()
{
  if (dynJoint) delete dynJoint;
}

/*!
  Performs operations common to both the copy constructor and the load()
  method.  This include initializing several variables, computing the
  mass properties of the body assuming a uniform mass distribution,
  determining the max radius of the object (the distance from the center
  of gravity to the furthest point on the body), and attaching
  coordinate axes to the body (with a switch node).
*/
void
DynamicBody::init()
{
  double **vlist;
  int i,numpts;
  double tmpRadius;
    
  useDynamics = true;

  externalWrench[0] = externalWrench[1] = externalWrench[2] = 0.0;
  externalWrench[3] = externalWrench[4] = externalWrench[5] = 0.0;

  extWrenchAcc[0] = extWrenchAcc[1] = extWrenchAcc[2] = 0.0;
  extWrenchAcc[3] = extWrenchAcc[4] = extWrenchAcc[5] = 0.0;

  for (i=0;i<6;i++) {
    a[i] = 0.0;
    v[i] = 0.0;
    j[i] = 0.0;
  }

  for (i=0;i<7;i++) {
    q[i] = 0.0;
    startq[i] = 0.0;
  }
  q[3] = 1.0;
  startq[3] = 1.0;

  bbox_min = vec3(-1e+6,-1e+6,-1e+6);
  bbox_max = vec3(1e+6,1e+6,1e+6);

  numpts = 3 * myWorld->ivc->vc->GetObject(id,vlist);

  computeMassProp(vlist,numpts/3);

  defaultMaxRadius = 0.0;

  for (i=0;i<numpts;i++) {
    tmpRadius = (defaultCoG - 
		 position(vlist[i][0],vlist[i][1],vlist[i][2])).len();
    if (tmpRadius > defaultMaxRadius) defaultMaxRadius = tmpRadius;
    free (vlist[i]);
  }

  free(vlist);
  
  IVWorstCase = new SoSeparator;  
  IVAxes = new SoSwitch;
  
  if (graspItGUI) {
    SoSeparator *axesSep = new SoSeparator;
    axesTranToCOG = new SoTranslation;
    axesTranToCOG->translation.setValue((float)defaultCoG.x(),
					(float)defaultCoG.y(),
					(float)defaultCoG.z());
    axesSep->addChild(axesTranToCOG);
    axesSep->addChild(IVWorstCase);
    
    axesScale = new SoScale;
    axesScale->scaleFactor = SbVec3f(defaultMaxRadius/AXES_SCALE,
				     defaultMaxRadius/AXES_SCALE,
				     defaultMaxRadius/AXES_SCALE);

    axesSep->addChild(axesScale);
    axesSep->addChild(graspItGUI->getIVmgr()->getPointers()->getChild(2));
    IVAxes->addChild(axesSep);
  }
  IVRoot->addChild(IVAxes);
  
}


/*!
  Opens and loads a body geometry file.  \a filename is the complete path to
  the body file, which should be in Inventor format.  If Coin2 is being used
  then the format may also be VRML.  The body is also added to the collision
  detection system.  Then it computes the default mass properties using
  the init() routine.  Last it checks if the default mass properties have been
  overridden with comments in the first few lines of the file, and reads those
  in if so.
*/
int
DynamicBody::load(const QString &filename)
{
  QFile file(filename);
  QString line,matStr;
  double x,y,z;

  if (Body::load(filename))  return FAILURE;

  // initialize dynamic properties and compute uniform mass distribution
  init();

  if (!file.open(IO_ReadOnly)) {
    QTWARNING("Could not open " + filename);
    return FAILURE;
  }
  QTextStream stream( &file );

  stream.readLine();  // inventor version line 
  stream.readLine();  // material is read by Body::load
  
  line = stream.readLine().section('#',1);
  if (!line.isEmpty())
    QTextStream(&line,IO_ReadOnly) >> mass;
  else {
    mass = DynamicBody::defaultMass;
    QTWARNING("mass was not specified in dynamic body file " + filename +
	      QString("\nUsing a default of %1 grams.").arg(mass));
    file.close();
  }

  // if the mass was there, look for other specified mass properties
  if (!line.isEmpty()) {
    line = stream.readLine().section('#',1);
    if (!line.isEmpty()) {
      QTextStream(&line,IO_ReadOnly) >> x >> y >> z;
      CoG = position(x,y,z);
#ifdef GRASPITDBG
      std::cout << "mass:"<<mass<<"cog: "<<CoG<<std::endl;
#endif
      
      line = stream.readLine().section('#',1);
      if (!line.isEmpty()) {
	QTextStream(&line,IO_ReadOnly) >> I[0] >> I[1] >> I[2];
	line = stream.readLine().section('#',1);    
	if (!line.isEmpty()) {
	  QTextStream(&line,IO_ReadOnly) >> I[3] >> I[4] >> I[5];
	  line = stream.readLine().section('#',1);
	  if (!line.isEmpty()) {
	    QTextStream(&line,IO_ReadOnly) >> I[6] >> I[7] >> I[8];
	  }
	}
      }
    }
    file.close();
  }

  if (line.isEmpty()) {  // one of the mass prop values couldn't be read    
    CoG = defaultCoG;
    memcpy(I,defaultI,9*sizeof(double));
  }

  for (int i=0;i<9;i++)
    I[i] *= mass;

  setMassProp(CoG,I);  // even though they're already set, this will
                              // adjust the axes and recompute max radius
       
  //   double offCenter = CoG[0]*CoG[0] + CoG[1]*CoG[1] + CoG[2]*CoG[2];
//       if (offCenter > 0.0) {
//         I[0] += offCenter - CoG[0]*CoG[0];
//         I[1] += -CoG[1]*CoG[0];
//         I[2] += -CoG[2]*CoG[0];
//         I[3] += -CoG[0]*CoG[1];
//         I[4] += offCenter - CoG[1]*CoG[1];
//         I[5] += -CoG[2]*CoG[1];
//         I[6] += -CoG[0]*CoG[2];
//         I[7] += -CoG[1]*CoG[2];
//         I[8] += offCenter - CoG[2]*CoG[2];
//       }

//	showAxes(true);

  return SUCCESS;

}

/*!
  Sets the dynamic body's center of gravity to \a newCoG and its inertia
  matrix to \a newI.  If the CoG has been moved, this must also update
  the dynamic position of the body since that is defined with respect to the
  CoG.  It must also update the maxRadius, and the location of the displayed
  coordinate frame.
*/
void
DynamicBody::setMassProp(const position& newCoG,double *newI)
{
  int i,numpts;
  double tmpRadius,**vlist;

  CoG = newCoG;  
  memcpy(I,newI,9*sizeof(double));

  Quaternion quat = Tran.rotation();
  vec3 cogOffset = quat * (CoG-position::ORIGIN);

  q[0] = Tran.translation().x()+cogOffset.x();
  q[1] = Tran.translation().y()+cogOffset.y();
  q[2] = Tran.translation().z()+cogOffset.z();
  q[3] = quat.w;
  q[4] = quat.x;
  q[5] = quat.y;
  q[6] = quat.z; 

  numpts = 3 * myWorld->ivc->vc->GetObject(id,vlist);
  maxRadius = 0.0;

  for (i=0;i<numpts;i++) {
    tmpRadius = (defaultCoG -
		 position(vlist[i][0],vlist[i][1],vlist[i][2])).len();

    if (tmpRadius > maxRadius) maxRadius = tmpRadius;
    free (vlist[i]);
  }
  free(vlist);

  
  axesTranToCOG->translation.setValue((float)CoG.x(),
				      (float)CoG.y(),
				      (float)CoG.z());

  axesScale->scaleFactor = SbVec3f(maxRadius/AXES_SCALE,
				   maxRadius/AXES_SCALE,
				   maxRadius/AXES_SCALE);
  
}

/*!
  Support routine for computing body mass properties.  This code is
  adapted from code written by Brian Mirtich.
*/
void
DynamicBody::compProjectionIntegrals(FACE &f, int A, int B)
{
  double a0, a1, da;
  double b0, b1, db;
  double a0_2, a0_3, a0_4, b0_2, b0_3, b0_4;
  double a1_2, a1_3, b1_2, b1_3;
  double C1, Ca, Caa, Caaa, Cb, Cbb, Cbbb;
  double Cab, Kab, Caab, Kaab, Cabb, Kabb;
  int i;

  P1 = Pa = Pb = Paa = Pab = Pbb = Paaa = Paab = Pabb = Pbbb = 0.0;

  for (i = 0; i < 3; i++) {
    a0 = f.verts[i][A];
    b0 = f.verts[i][B];
    a1 = f.verts[(i+1) % 3][A];
    b1 = f.verts[(i+1) % 3][B];
    da = a1 - a0;
    db = b1 - b0;
    a0_2 = a0 * a0; a0_3 = a0_2 * a0; a0_4 = a0_3 * a0;
    b0_2 = b0 * b0; b0_3 = b0_2 * b0; b0_4 = b0_3 * b0;
    a1_2 = a1 * a1; a1_3 = a1_2 * a1; 
    b1_2 = b1 * b1; b1_3 = b1_2 * b1;

    C1 = a1 + a0;
    Ca = a1*C1 + a0_2; Caa = a1*Ca + a0_3; Caaa = a1*Caa + a0_4;
    Cb = b1*(b1 + b0) + b0_2; Cbb = b1*Cb + b0_3; Cbbb = b1*Cbb + b0_4;
    Cab = 3*a1_2 + 2*a1*a0 + a0_2; Kab = a1_2 + 2*a1*a0 + 3*a0_2;
    Caab = a0*Cab + 4*a1_3; Kaab = a1*Kab + 4*a0_3;
    Cabb = 4*b1_3 + 3*b1_2*b0 + 2*b1*b0_2 + b0_3;
    Kabb = b1_3 + 2*b1_2*b0 + 3*b1*b0_2 + 4*b0_3;

    P1 += db*C1;
    Pa += db*Ca;
    Paa += db*Caa;
    Paaa += db*Caaa;
    Pb += da*Cb;
    Pbb += da*Cbb;
    Pbbb += da*Cbbb;
    Pab += db*(b1*Cab + b0*Kab);
    Paab += db*(b1*Caab + b0*Kaab);
    Pabb += da*(a1*Cabb + a0*Kabb);
  }

  P1 /= 2.0;
  Pa /= 6.0;
  Paa /= 12.0;
  Paaa /= 20.0;
  Pb /= -6.0;
  Pbb /= -12.0;
  Pbbb /= -20.0;
  Pab /= 24.0;
  Paab /= 60.0;
  Pabb /= -60.0;
}

/*!
  Support routine for computing body mass properties.  This code is
  adapted from code written by Brian Mirtich.
*/
void
DynamicBody::compFaceIntegrals(FACE &f,int A, int B, int C)
{
  double *n, w;
  double k1, k2, k3, k4;

  compProjectionIntegrals(f,A,B);

  w = f.w;
  n = f.norm;
  k1 = 1 / n[C]; k2 = k1 * k1; k3 = k2 * k1; k4 = k3 * k1;

  Fa = k1 * Pa;
  Fb = k1 * Pb;
  Fc = -k2 * (n[A]*Pa + n[B]*Pb + w*P1);

  Faa = k1 * Paa;
  Fbb = k1 * Pbb;
  Fcc = k3 * (SQR(n[A])*Paa + 2*n[A]*n[B]*Pab + SQR(n[B])*Pbb
	 + w*(2*(n[A]*Pa + n[B]*Pb) + w*P1));

  Faaa = k1 * Paaa;
  Fbbb = k1 * Pbbb;
  Fccc = -k4 * (CUBE(n[A])*Paaa + 3*SQR(n[A])*n[B]*Paab 
	   + 3*n[A]*SQR(n[B])*Pabb + CUBE(n[B])*Pbbb
	   + 3*w*(SQR(n[A])*Paa + 2*n[A]*n[B]*Pab + SQR(n[B])*Pbb)
	   + w*w*(3*(n[A]*Pa + n[B]*Pb) + w*P1));

  Faab = k1 * Paab;
  Fbbc = -k2 * (n[A]*Pabb + n[B]*Pbbb + w*Pbb);
  Fcca = k3 * (SQR(n[A])*Paaa + 2*n[A]*n[B]*Paab + SQR(n[B])*Pabb
	 + w*(2*(n[A]*Paa + n[B]*Pab) + w*Pa));
}

/*!
  Given a list of the body vertices, and the number of triangles, this
  computes the center of gravity and inertia matrix by assuming a uniform
  mass distribution.  This code is based on code written by Brian Mirtich.
*/
void
DynamicBody::computeMassProp(double **vlist,int numFaces)
{
  FACE f;
  double dx1,dy1,dz1,dx2,dy2,dz2;
  double nx, ny, nz,len;
  int i,A,B,C;
  double r[3];
  double density;

  // volume integrals
  double T0, T1[3], T2[3], TP[3];

  T0 = T1[0] = T1[1] = T1[2] 
     = T2[0] = T2[1] = T2[2] 
     = TP[0] = TP[1] = TP[2] = 0;

  for (i = 0; i < numFaces; i++) {
    f.verts[0] = vlist[3*i];
    f.verts[1] = vlist[3*i+1];
    f.verts[2] = vlist[3*i+2];

    dx1 = f.verts[1][0] - f.verts[0][0];
    dy1 = f.verts[1][1] - f.verts[0][1];
    dz1 = f.verts[1][2] - f.verts[0][2];
    dx2 = f.verts[2][0] - f.verts[1][0];
    dy2 = f.verts[2][1] - f.verts[1][1];
    dz2 = f.verts[2][2] - f.verts[1][2];
    nx = dy1 * dz2 - dy2 * dz1;
    ny = dz1 * dx2 - dz2 * dx1;
    nz = dx1 * dy2 - dx2 * dy1;
    len = sqrt(nx * nx + ny * ny + nz * nz);

    f.norm[0] = nx / len;
    f.norm[1] = ny / len;
    f.norm[2] = nz / len;
    f.w = - f.norm[0] * f.verts[0][0]
           - f.norm[1] * f.verts[0][1]
           - f.norm[2] * f.verts[0][2];

    nx = fabs(f.norm[0]);
    ny = fabs(f.norm[1]);
    nz = fabs(f.norm[2]);
    if (nx > ny && nx > nz) C = 0;
    else C = (ny > nz) ? 1 : 2;
    A = (C + 1) % 3;
    B = (A + 1) % 3;

    compFaceIntegrals(f,A,B,C);

    T0 += f.norm[0] * ((A == 0) ? Fa : ((B == 0) ? Fb : Fc));

    T1[A] += f.norm[A] * Faa;
    T1[B] += f.norm[B] * Fbb;
    T1[C] += f.norm[C] * Fcc;
    T2[A] += f.norm[A] * Faaa;
    T2[B] += f.norm[B] * Fbbb;
    T2[C] += f.norm[C] * Fccc;
    TP[A] += f.norm[A] * Faab;
    TP[B] += f.norm[B] * Fbbc;
    TP[C] += f.norm[C] * Fcca;
  }

  T1[0] /= 2; T1[1] /= 2; T1[2] /= 2;
  T2[0] /= 3; T2[1] /= 3; T2[2] /= 3;
  TP[0] /= 2; TP[1] /= 2; TP[2] /= 2;
#ifdef GRASPITDBG
  printf("\nT1 =   %+20.6f\n\n", T0);

  printf("Tx =   %+20.6f\n", T1[0]);
  printf("Ty =   %+20.6f\n", T1[1]);
  printf("Tz =   %+20.6f\n\n", T1[2]);
  
  printf("Txx =  %+20.6f\n", T2[0]);
  printf("Tyy =  %+20.6f\n", T2[1]);
  printf("Tzz =  %+20.6f\n\n", T2[2]);

  printf("Txy =  %+20.6f\n", TP[0]);
  printf("Tyz =  %+20.6f\n", TP[1]);
  printf("Tzx =  %+20.6f\n\n", TP[2]);
#endif

  //assume unity mass
  density = 1.0 / T0;

  /* compute center of mass */
  r[0] = T1[0] / T0;
  r[1] = T1[1] / T0;
  r[2] = T1[2] / T0;
  defaultCoG.set(r);

  /* compute inertia tensor */
  defaultI[0] = density * (T2[1] + T2[2]);
  defaultI[4] = density * (T2[2] + T2[0]);
  defaultI[8] = density * (T2[0] + T2[1]);
  defaultI[1] = defaultI[3] = - density * TP[0];
  defaultI[5] = defaultI[7] = - density * TP[1];
  defaultI[6] = defaultI[2] = - density * TP[2];

  /* translate inertia tensor to center of mass */
  defaultI[0] -= (r[1]*r[1] + r[2]*r[2]);
  defaultI[4] -= (r[2]*r[2] + r[0]*r[0]);
  defaultI[8] -= (r[0]*r[0] + r[1]*r[1]);
  defaultI[1] = defaultI[3] += r[0] * r[1]; 
  defaultI[5] = defaultI[7] += r[1] * r[2]; 
  defaultI[6] = defaultI[2] += r[2] * r[0]; 

#ifdef GRASPITDBG
  printf("center of mass:  (%+12.6f,%+12.6f,%+12.6f)\n\n", r[0], r[1], r[2]);

  printf("inertia tensor with origin at c.o.m. (scaled for unity mass):\n");
  printf("%+15.6f  %+15.6f  %+15.6f\n", defaultI[0], defaultI[1], defaultI[2]);
  printf("%+15.6f  %+15.6f  %+15.6f\n", defaultI[3], defaultI[4], defaultI[5]);
  printf("%+15.6f  %+15.6f  %+15.6f\n\n", defaultI[6], defaultI[7], defaultI[8]);
#endif
}

/*!
  Changes the state of the Inventor switch node controlling whether the
  coordinate axes on the body are visible
*/
void
DynamicBody::showAxes(bool on)
{
  if (on) IVAxes->whichChild = 0;
  else IVAxes->whichChild = -1;
  
  showAx = on;
}

/*!
  Sets whether dynamic contact forces should be drawn during dynamic
  simulation.
*/
void
DynamicBody::showDynContactForces(bool on)
{
  showDynCF = on;
}


/*!
  Resets the external wrench accumulator to 0.
*/
void
DynamicBody::resetExtWrench()
{
  extWrenchAcc[0] = extWrenchAcc[1] = extWrenchAcc[2] = 0.0;
  extWrenchAcc[3] = extWrenchAcc[4] = extWrenchAcc[5] = 0.0;
}

/*!
  Adds \a extW to the external wrench accumulator.
*/
void
DynamicBody::addExtWrench(double *extW){
  extWrenchAcc[0] += extW[0];
  extWrenchAcc[1] += extW[1];
  extWrenchAcc[2] += extW[2];
  extWrenchAcc[3] += extW[3];
  extWrenchAcc[4] += extW[4];
  extWrenchAcc[5] += extW[5];
}

/*! 
   Adds a force expressed in world coordinates, to the external force
   accumulator for this body.
*/
void
DynamicBody::addForce(vec3 force)
{
  extWrenchAcc[0] += force[0];
  extWrenchAcc[1] += force[1];
  extWrenchAcc[2] += force[2];
}

/*!
  Adds a torque expressed in world coordinates, to the external force
  accumulator for this body.
 */
void
DynamicBody::addTorque(vec3 torque)
{
  extWrenchAcc[3] += torque[0];
  extWrenchAcc[4] += torque[1];
  extWrenchAcc[5] += torque[2];
#ifdef GRASPITDBG
  std::cout << "Adding torque "<< torque <<std::endl;
#endif
}


/*
  Adds a torque expressed in body coordinates, to the external force
  accumulator for this body.
*/
void
DynamicBody::addRelTorque(vec3 torque)
{
  vec3 worldTorque;

#ifdef GRASPITDBG
  std::cout << "Adding rel torque "<< torque <<std::endl;
#endif

  worldTorque = Tran.rotation() * torque;

  extWrenchAcc[3] += worldTorque[0];
  extWrenchAcc[4] += worldTorque[1];
  extWrenchAcc[5] += worldTorque[2];
#ifdef GRASPITDBG
  std::cout << "     world torque "<< worldTorque << std::endl;
#endif
}


/*! 
   Adds a force expressed in world coordinates at a position also expressed
   world coordinates. This force and the computed torque are added to the
   external force accumulator for this body.
*/
void
DynamicBody::addForceAtPos(vec3 force,position pos)
{
  vec3 worldTorque;

  worldTorque = (pos - Tran.rotation() * CoG) * force;
  extWrenchAcc[0] += force[0];
  extWrenchAcc[1] += force[1];
  extWrenchAcc[2] += force[2];

  extWrenchAcc[3] += worldTorque[0];
  extWrenchAcc[4] += worldTorque[1];
  extWrenchAcc[5] += worldTorque[2];
#ifdef GRASPITDBG
  std::cout << "Adding force "<< force << " at " << pos <<std::endl;
  std::cout << "     world torque "<< worldTorque << " worldForce " << force <<std::endl;
#endif
}


/*!
  Adds a force expressed in body coordinates at a position also expressed
  body coordinates. This force and the computed torque are added to the
  external force accumulator for this body.
*/
void
DynamicBody::addForceAtRelPos(vec3 force,position pos)
{
  vec3 worldForce;
  vec3 worldTorque;

  worldForce = Tran.rotation() * force;
  worldTorque = Tran.rotation() * ((pos - CoG) * force);
  extWrenchAcc[0] += worldForce[0];
  extWrenchAcc[1] += worldForce[1];
  extWrenchAcc[2] += worldForce[2];

  extWrenchAcc[3] += worldTorque[0];
  extWrenchAcc[4] += worldTorque[1];
  extWrenchAcc[5] += worldTorque[2];
#ifdef GRASPITDBG
  std::cout << "Adding rel force "<< force << " at " << pos <<std::endl;
  std::cout << "     world torque "<< worldTorque << " worldForce " << worldForce <<std::endl;
#endif
}

// Let the dynamics routine take care of breaking the contacts
bool 
DynamicBody::setPos(double *new_q)
{
  double norm;
  static col_Mat4 colTran;

  // is the object within its permissable area?
  if (new_q[0] < bbox_min.x() || new_q[0] > bbox_max.x()) return false;
  if (new_q[1] < bbox_min.y() || new_q[1] > bbox_max.y()) return false;
  if (new_q[2] < bbox_min.z() || new_q[2] > bbox_max.z()) return false;
  
  memcpy(q,new_q,7*sizeof(double));

  // normalize the quaternion
   norm = sqrt(q[3]*q[3]+q[4]*q[4]+q[5]*q[5]+q[6]*q[6]);
   q[3] /= norm;
   q[4] /= norm;
   q[5] /= norm;
   q[6] /= norm;

   //   transf tr = transf(Quaternion(q[3],q[4],q[5],q[6]),
   //		      vec3(q[0],q[1],q[2])*1000.0);

   Quaternion rot(q[3],q[4],q[5],q[6]);
   vec3 cogOffset = rot * (CoG-position::ORIGIN);
   transf tr = transf(rot,vec3(q[0],q[1],q[2])-cogOffset);

   /*   transf tr = transf(Quaternion(q[3],q[4],q[5],q[6]),vec3::ZERO)*
     translate_transf(vec3(q[0],q[1],q[2]));
   */

  Tran = tr;
  Tran.toSoTransform(IVTran);
  Tran.tocol_Mat4(colTran);

  myWorld->ivc->vc->UpdateTrans(id,colTran);
  return true;
}

/*!
  Save the current dynamic state of the body.
  May soon be replaced by pushState().
*/
void
DynamicBody::markState()
{
  memcpy(markedQ,q,7*sizeof(double));
  memcpy(markedV,v,6*sizeof(double));
}

/*!
  Restore the marked dynamic state of the body.
  May soon be replaced by popState().
*/
void
DynamicBody::returnToMarkedState()
{
  memcpy(v,markedV,6*sizeof(double));
  setPos(markedQ);
}

/*! 
  Push the current dynamic state of the body onto a local stack.
*/
void
DynamicBody::pushState()
{
  double *tmp = new double[6];
  memcpy(tmp,v,6*sizeof(double));
  vStack.push_back(tmp);
  
  tmp = new double[7];
  memcpy(tmp,q,7*sizeof(double));
  qStack.push_back(tmp);

}

/*!
  Pop the current dynamic state of the body from a local stack.
*/
void
DynamicBody::popState()
{
  if (qStack.empty()) return;
  memcpy(v,vStack.back(),6*sizeof(double));
  setPos(qStack.back());

  // don't pop off the first saved state.
  if (++qStack.begin() != qStack.end()) {
    delete [] vStack.back();
    delete [] qStack.back();
    vStack.pop_back(); 
    qStack.pop_back();
  }
}

/*!
  Sets the pose of the body to \a tr relative to world coordinates.  It also
  breaks all contacts on the body, updates the collision detection system
  transform, and updates the dynamic state of the body.
*/
int
DynamicBody::setTran(transf const& tr)
{
  static col_Mat4 colTran;

  if (tr == Tran) return SUCCESS;
  breakContacts();

  if (!myWorld->wasModified() && tr != Tran)
    myWorld->setModified();

  Tran=tr;
  Tran.toSoTransform(IVTran);
  Tran.tocol_Mat4(colTran);
    
  myWorld->ivc->vc->UpdateTrans(id,colTran);
  
  Quaternion quat = Tran.rotation();
  vec3 cogOffset = quat * (CoG-position::ORIGIN);

  q[0] = Tran.translation().x()+cogOffset.x();
  q[1] = Tran.translation().y()+cogOffset.y();
  q[2] = Tran.translation().z()+cogOffset.z();
  q[3] = quat.w;
  q[4] = quat.x;
  q[5] = quat.y;
  q[6] = quat.z;  

  if (fixed) fix();

  return SUCCESS;
}

/*!
  Fixes the body so that it does not move during dynamic simulation.  This
  is done by addind a fixed dynamic joint that will constrain all 6 body
  velocities to 0.
*/
void
DynamicBody::fix()
{
  fixed = true;
  setDynJoint(new FixedDynJoint(NULL,this,Tran));
}

/*!
  Removes the fixed dynamic joint so the body is free to move again during
  dynamic simulation.
*/
void
DynamicBody::unfix()
{
  fixed = false;
  setDynJoint(NULL);
}

/*!
  Sets the dynamic joint connected to this body to \a dj.
*/
void
DynamicBody::setDynJoint(DynJoint *dj)
{
  if (dynJoint) delete dynJoint;
  dynJoint = dj;
}


///////////////////////////////////////////////////////////////////////////////
//                            Link
///////////////////////////////////////////////////////////////////////////////

/*
  Initializes a robot link.  \a r is the pointer to the robot that owns
  this link, \a c is the index of the chain this link is in, and \a l is
  the link number of this link within that chain.
*/
Link::Link(Robot *r,int c, int l,World *w,const char *name) : DynamicBody(w,name)
{
  owner = r; chainNum = c; linkNum = l;
}


/*
  Stub destructor.
*/
Link::~Link()
{
}


/*!
  Sets BOTH the worldElement's AND the robot's \a contactsChanged flag.
*/
void
Link::setContactsChanged()
{
  WorldElement::setContactsChanged();
  owner->setContactsChanged();
}

///////////////////////////////////////////////////////////////////////////////
//                            GraspableBody
///////////////////////////////////////////////////////////////////////////////

/*
  Stub constructor.
*/
GraspableBody::GraspableBody(World *w,const char *name) : DynamicBody(w,name)
{

}

/*
  Stub destructor.
*/
GraspableBody::~GraspableBody()
{

}

/*!
  Performs the normal load operation and sets the defaults display properties
  for graspable bodies.  This includes showing friction cones and the
  coordinate axes, and setting the body to be partially transparent.
*/
int
GraspableBody::load(const QString &filename)
{
  SoInput in;
  int result = DynamicBody::load(filename);
  if (result==FAILURE) return FAILURE;

  showFC = true;
  showAxes(true);
  setTransparency(0.4f);

  return SUCCESS;
}

/*!
  Output method for writing body data to a text world configuration file
*/
QTextStream&
operator<<(QTextStream &os, const GraspableBody &gb)
{
  os << gb.myFilename << endl;
  return os;
}




