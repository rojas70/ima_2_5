//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: robonaut.cpp,v 1.7 2004/02/12 21:35:27 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Implements the special %Robonaut robot class
 */

#include "robonaut.h"
#include "world.h"

int
Robonaut::load(QString filename)
{
  int result = Robot::load(filename);
  if (result != SUCCESS) return result;
  myWorld->turnOffCollisions(base,chainVec[0]->getLink(1));

  return result;
}
  
