//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: barrett.cpp,v 1.13 2004/02/12 21:35:26 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Implements the %Barrett hand class, a specialized hand subclass
 */

#include "barrett.h"
#include "world.h"

#define AUTO_GRASP_TIME_STEP 0.01

#define BADCONFIG                                                   \
{                                                                   \
  QTWARNING("There was a problem reading the configuration file."); \
  file.close();                                                     \
  return FAILURE;                                                   \
}

BarrettDOF::BarrettDOF(const DOF &oldDOF) : DOF(oldDOF)
{

}

int
BarrettDOF::setVal(double q1)
{
  // for reconnecting after breakaway
  if (!tempList.empty() && (q1<reconnectAt || q1==minq) )
	reconnect();	
  
  DOF::setVal(q1);

  return SUCCESS;
}

void
BarrettDOF::breakAway()
{
  tempList = jointList;
  jointList.erase(jointList.begin());
  reconnectAt = q;
}

void
BarrettDOF::reconnect()
{
  jointList = tempList;
  tempList.clear();
}


int
Barrett::load(QString filename)
{
  DOF *tmpDOF;
  if (Robot::load(filename) == FAILURE) return FAILURE;

  tmpDOF = dofVec[1];
  dofVec[1] = new BarrettDOF(*tmpDOF);
  delete tmpDOF;

  tmpDOF = dofVec[2];
  dofVec[2] = new BarrettDOF(*tmpDOF);
  delete tmpDOF;

  tmpDOF = dofVec[3];
  dofVec[3] = new BarrettDOF(*tmpDOF);
  delete tmpDOF;

  return SUCCESS;
}

void
Barrett::fwdKinematics(double* dofVals,std::vector<transf>& trVec,int chainNum)
{
  int numJoints = chainVec[chainNum]->getNumJoints();
  double *jointVals = new double[numJoints];
  Joint *joint;

  for (int j=0;j<numJoints;j++) {
    joint = chainVec[chainNum]->getJoint(j);
    if (((chainNum < 2 && j==1) || (chainNum == 2 && j==0)) &&
	((BarrettDOF *)dofVec[joint->getDOFNum()])->inBreakAway())
      jointVals[j] = joint->getVal();
    else 
      jointVals[j] = dofVals[joint->getDOFNum()] * joint->getRatio();
  }

  chainVec[chainNum]->fwdKinematics(jointVals,trVec);
  delete [] jointVals;
}

ColReportT
Barrett::moveDOFTo(double *desiredDOFVals,double *stepSize,bool renderIt,
		   std::vector<Link *> *stoppedLinks)
{
  std::vector<Link *> localStoppedLinks;
  ColReportT colReport,result;
  int numCols,numStoppedLinks;
  bool done=true;
  int f=-1,l=-1;
  int i,d;

  do {
    done = true;
    localStoppedLinks.clear();
    colReport = Robot::moveDOFTo(desiredDOFVals,stepSize,renderIt,&localStoppedLinks);
    numCols = colReport.size();
    numStoppedLinks = localStoppedLinks.size();

    result.insert(result.end(),colReport.begin(),colReport.end());

    for (i=0;i<numStoppedLinks;i++) {
      f = localStoppedLinks[i]->getChainNum();
      l = localStoppedLinks[i]->getLinkNum();
      d = f+1;
      
      if (d>0 && !((BarrettDOF *)dofVec[d])->inBreakAway() && ((f<2 && l==1) || (f==2 && l==0)) &&
	  stepSize[d]>0 && dofVec[d]->getVal() < dofVec[d]->getMax()) {
	((BarrettDOF *)dofVec[d])->breakAway(); done=false;
#ifdef GRASPITDBG
	std::cout << "BREAKAWAY"<<std::endl;
#endif
      }
    }

    for (i=0;i<numCols;i++) {
      if (colReport[i].first->inherits("Link") &&
	  ((Link *)colReport[i].first)->getOwner() == this) {
	f = ((Link *)colReport[i].first)->getChainNum();
	l = ((Link *)colReport[i].first)->getLinkNum();
	d = f+1;
       
	if (d>0 && !((BarrettDOF *)dofVec[d])->inBreakAway() && ((f<2 && l==1) || (f==2 && l==0)) &&
	    stepSize[d]>0 && dofVec[d]->getVal() < dofVec[d]->getMax()) {
	  ((BarrettDOF *)dofVec[d])->breakAway(); done=false;
#ifdef GRASPITDBG
	  std::cout << "BREAKAWAY"<<std::endl;
#endif
	}

      }
      if (colReport[i].second->inherits("Link") &&
	  ((Link *)colReport[i].second)->getOwner() == this) {
	f = ((Link *)colReport[i].second)->getChainNum();
	l = ((Link *)colReport[i].second)->getLinkNum();
	d = f+1;

	if (d>0 && !((BarrettDOF *)dofVec[d])->inBreakAway() && ((f<2 && l==1) || (f==2 && l==0)) &&
	    stepSize[d]>0 && dofVec[d]->getVal() < dofVec[d]->getMax()) {
	  ((BarrettDOF *)dofVec[d])->breakAway(); done=false;
#ifdef GRASPITDBG
	  std::cout << "BREAKAWAY"<<std::endl;
#endif
	}
      }
    }

  }while(!done);
  if (stoppedLinks)
    stoppedLinks->insert(stoppedLinks->end(),localStoppedLinks.begin(),localStoppedLinks.end());

  return result;
}
/*
void
Barrett::autoGrasp(bool renderIt,double speedFactor)
{
  int i,f,l,numCols;
  bool done=false;
  double *desiredVals = new double[numDOF];
  
  ColReportT colReport;

#ifdef GRASPITDBG
  std::cout << "in autograsp" << std::endl;
#endif

  if (myWorld->dynamicsAreOn()) {
    for (i=0;i<numDOF;i++) {
      if (dofVec[i]->getDefaultVelocity() > 0)
	desiredVals[i] = dofVec[i]->getMax();
      else if (dofVec[i]->getDefaultVelocity() < 0)
	desiredVals[i] = dofVec[i]->getMin();
      else desiredVals[i] = 0.0;
#ifdef GRASPITDBG
      std::cout <<"Desired val "<<i<<" "<<desiredVals[i]<<std::endl;
#endif
      //for now
      dofVec[i]->setDesiredVelocity(dofVec[i]->getDefaultVelocity());
    }
    setDesiredDOFVals(desiredVals);
	delete [] desiredVals;
    return;
  }

  bool *moving = new bool[numDOF];
  double *stepSize= new double[numDOF];
  double *origVals = new double[numDOF];

  for (i=0;i<numDOF;i++) {
    origVals[i] = dofVec[i]->getVal();
    desiredVals[i] = dofVec[i]->getMax();
    stepSize[i] = dofVec[i]->getDefaultVelocity()*speedFactor*
      AUTO_GRASP_TIME_STEP;
    moving[i] = (stepSize[i] != 0.0);
  }

  while (!done) {
#ifdef GRASPITDBG
    for (i=0;i<numDOF;i++)
      if (moving[i]) std::cout << i << " is moving" << std::endl;
      else std::cout << i << " is not moving" <<std::endl;

    std::cout << "calling movedof" << std::endl;
#endif
    colReport = moveDOFTo(desiredVals,stepSize,renderIt);
    for (i=0;i<numDOF;i++) {
      if (dofVec[i]->getVal() == desiredVals[i]) moving[i] = false;
    }
      
    numCols = colReport.size();

    for (i=0;i<numCols;i++) {
      if (colReport[i].first->inherits("Link") &&
	  ((Link *)colReport[i].first)->getOwner() == this) {	
	f = ((Link *)colReport[i].first)->getChainNum();
	l = ((Link *)colReport[i].first)->getLinkNum();
	if (f == 0 && l == 2) {
	  desiredVals[1] = dofVec[1]->getVal();
	  moving[1] = false;
	} else if (f==1 && l==2) {
	  desiredVals[2] = dofVec[2]->getVal();
	  moving[2] = false;
	} else if (f==2 && l==1) {
	  desiredVals[3] = dofVec[3]->getVal();
	  moving[3] = false;
	}
      }
      if (colReport[i].second->inherits("Link") &&
	  ((Link *)colReport[i].second)->getOwner() == this) {
	f = ((Link *)colReport[i].second)->getChainNum();
	l = ((Link *)colReport[i].second)->getLinkNum();
	if (f==0 && l==2) {
	  desiredVals[1] = dofVec[1]->getVal();
	  moving[1] = false;
	} else if (f==1 && l==2) {
	  desiredVals[2] = dofVec[2]->getVal();
	  moving[2] = false;
	} else if (f==2 && l==1) {
	  desiredVals[3] = dofVec[3]->getVal();
	  moving[3] = false;
	}
      }
    }

    done = true;
    for (i=0;i<numDOF;i++)
      if (moving[i]) {done=false;}
  }

  delete [] origVals;
  delete [] desiredVals;
  delete [] moving;
  delete [] stepSize;
}
*/

QTextStream&
Barrett::readDOFVals(QTextStream &is)
{
  double dofVals[4];
  double reconnectAt;
  int i;

  std::cout << "IN BARRETT READ"<<std::endl;
  for (i=0;i<4;i++)
    is >> dofVals[i];

  for (i=1;i<4;i++) {
    is >> reconnectAt;
    if (reconnectAt < dofVals[i]) {
      setDOFVal(i,reconnectAt);
      ((BarrettDOF *)dofVec[i])->breakAway();
    }
  }
  
  setDOFVals(dofVals);
  return is;
}

QTextStream&
Barrett::writeDOFVals(QTextStream &os)
{
  double dofVals[4];
  int i;

  os << myFilename << endl;
  getDOFVals(dofVals);

  for (i=0;i<4;i++)
    os << ' ' << dofVals[i]; 

  for (i=1;i<4;i++)
    if ( ((BarrettDOF *)dofVec[i])->inBreakAway() )
      os << ' ' << ((BarrettDOF *)dofVec[i])->getReconnectAt();
    else
      os << ' ' << dofVals[i];

  os << endl;

  return os;
}

