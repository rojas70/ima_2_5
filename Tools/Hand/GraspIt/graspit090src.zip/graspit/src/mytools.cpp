//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: mytools.cpp,v 1.4 2004/02/12 21:35:27 amiller Exp $
//
//######################################################################

/*! \file
  \brief Implements the load_pixmap() function.  Other misc. functions could go here too.
*/

#include <qmime.h>
#include <qdragobject.h>
#include "mytools.h"

/*!
  Read, decode, and return the pixmap of the given name from the
  QMimeSourceFactory.
*/
QPixmap load_pixmap(const QString &name)
{
    const QMimeSource *m = QMimeSourceFactory::defaultFactory()->data( name );
    if ( !m )
	return QPixmap();
    QPixmap pix;
    QImageDrag::decode( m, pix );
    return pix;
}
