//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: joint.cpp,v 1.9 2004/02/12 21:35:27 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Implements the classes: DHTransform, DOF, RevoluteJoint, and PrismaticJoint.
 */

/* standard C includes */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <iostream>

#include <Inventor/SoDB.h>
#include <Inventor/SoInput.h>
#include <Inventor/actions/SoGetBoundingBoxAction.h>
#include <Inventor/actions/SoGetMatrixAction.h>
#include <Inventor/actions/SoSearchAction.h>
#include <Inventor/nodes/SoSeparator.h>
#include <Inventor/nodes/SoCoordinate3.h>
#include <Inventor/nodes/SoTransform.h>
#include <Inventor/draggers/SoRotateDiscDragger.h>

#include "joint.h"
#include "robot.h"
#include "mytools.h"
#include "body.h"
#include "dynJoint.h"

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

//#define GRASPITDBG

/*! Initializes the DHTransform with the 4 DH parameters. */
DHTransform::DHTransform(double thval,double dval,double aval,double alval) :
  theta(thval),d(dval),a(aval),alpha(alval)
{
  transf tr3,tr4;

  dtrans[0] = 0.0;
  dtrans[1] = 0.0;
  dtrans[2] = d;

  atrans[0] = a;
  atrans[1] = 0.0;
  atrans[2] = 0.0;

  tr1 = rotate_transf(theta,vec3(0,0,1));
  tr2 = translate_transf(dtrans);
  tr3 = translate_transf(atrans);
  tr4 = rotate_transf(alpha,vec3(1,0,0));
  tr4TimesTr3 = tr4 * tr3;

  tran = tr4TimesTr3 * tr2 * tr1;
}

/*!
  Sets a new d value for prismatic joints and recomputes the current value
  of the transform.
*/
void DHTransform::setD(double q)
{
  d = q;
  dtrans[2] = d;
  tr2 = translate_transf(dtrans);

  tran = tr4TimesTr3 * tr2 * tr1;
}

/*!
  Sets a new theta value for revolute joints and recomputes the current value
  of the transform.
*/
void DHTransform::setTheta(double q)
{
  theta = q;
  tr1 = rotate_transf(theta,vec3(0,0,1));
  
  tran = tr4TimesTr3 * tr2 * tr1;
}

/*!
  Unreferences the associated Inventor transform, and deletes the DHTransform
  associated with this joint.
*/
Joint::~Joint()
{
  IVTran->unref(); delete DH;
}

/*!
  Initializes a prismatic joint from a string read from the robot configuration
  file.  It must also be given pointers to the kinematic chain and robot that
  this joint is a part of.  The format of the string should be: "theta d# a
  alpha minVal maxVal viscousFricionCoeff CoulombFrictionValue", where # is
  the index of the DOF that this joint is hooked to.  It creates a new
  DHTransform using the provided DH values (theta and alpha should be
  expressed in degrees), and creates an Inventor transform.  This returns
  FAILURE if it could not read all the necessary values from the provided
  string, otherwise it returns SUCESS.
*/
int
PrismaticJoint::initJoint(const char *info,
			  KinematicChain *myChain,const Robot *myRobot)
{
  char dStr[40],num[40],*tmp;
  double theta,d,a,alpha;
  int argsRead;
  owner = myChain;

  IVTran = new SoTransform();
  IVTran->ref();

  argsRead = sscanf(info,"%lf %s %lf %lf %lf %lf %lf %lf",&theta,dStr,&a,
		    &alpha,&minVal,&maxVal,&f1,&f0);

  if (argsRead < 6)
    return FAILURE;
  
  theta *= M_PI/180.0;
  alpha *= M_PI/180.0;

  d = 0.0;
  tmp = dStr+1;
  sscanf(tmp,"%[0-9]",num);
  DOFnum = atoi(num);
  tmp += strlen(num);

  if (DOFnum > myRobot->getNumDOF()) {
    pr_error("DOF number is out of range\n");
    return FAILURE;
  }

  if (*tmp=='*') {
    tmp++;
    sscanf(tmp,"%[0-9.]",num);
    tmp += strlen(num);
    k = atof(num);
  }
  if (*tmp=='+') {
    tmp++;
    sscanf(tmp,"%lf",&c);
  }

  DH = new DHTransform(theta,d+c,a,alpha);  

  DH->getTran().toSoTransform(IVTran);

  return SUCCESS;
}

/*!
  Sets the current joint value to \a q.  The \a d value of the DHTransform
  is then set to \a q + the joint offset \a c.  It also sets the joints moved
  flag of the owning kinematic chain to notify that an forward kinematics 
  update is necessary.
*/
int
PrismaticJoint::setVal(double q)
{
  //  if (q < min || q > max) {
  //    pr_errArgs((stderr,"%lf - joint value out of range",q));
  //    return FAILURE;
  //  }

  DH->setD(q+c);
  //  if (draggerAttached)
  DH->getTran().toSoTransform(IVTran);

  owner->jointsMoved = true;
  
  return SUCCESS;  
}

/*!
  Applies equal and opposite forces of magnitude \a f along the axis
  \a worldAxis to the two links connected to this joint.
*/
void
PrismaticJoint::applyForce(double f)
{
  dynJoint->getPrevLink()->addForce(-f*worldAxis);
  dynJoint->getNextLink()->addForce(f*worldAxis);
}

/*!
  Initializes a revolute joint from a string read from the robot configuration
  file.  It must also be given pointers to the kinematic chain and robot that
  this joint is a part of.  The format of the string should be: "d# d a
  alpha minVal maxVal viscousFricionCoeff CoulombFrictionValue", where # is
  the index of the DOF that this joint is hooked to.  It creates a new
  DHTransform using the provided DH values (alpha should be
  expressed in degrees), and creates an Inventor transform.  This returns
  FAILURE if it could not read all the necessary values from the provided
  string, otherwise it returns SUCESS.
*/
int
RevoluteJoint::initJoint(const char *info,KinematicChain *myChain,
			 const Robot *myRobot)
{
  char thStr[40],num[40],*tmp;
  double theta,d,a,alpha;
  int argsRead;

  owner = myChain;

  IVTran = new SoTransform();
  IVTran->ref();

  argsRead = sscanf(info,"%s %lf %lf %lf %lf %lf %lf %lf",thStr,&d,&a,
		    &alpha,&minVal,&maxVal,&f1,&f0);

  if (argsRead < 6)
    return FAILURE;
  
  alpha *= M_PI/180.0;
  minVal *= M_PI/180.0;
  maxVal *= M_PI/180.0;

  theta = 0.0;
  tmp = thStr+1;
  sscanf(tmp,"%[0-9]",num);
  DOFnum = atoi(num);
  tmp += strlen(num);

  if (DOFnum > myRobot->getNumDOF()) {
    pr_error("DOF number is out of range\n");
    return FAILURE;
  }

  if (*tmp=='*') {
    tmp++;
    sscanf(tmp,"%[0-9.]",num);
    tmp += strlen(num);
    k = atof(num);
  }
  if (*tmp=='+') {
    tmp++;
    sscanf(tmp,"%lf",&c);
    c *= M_PI/180.0;
  }

  DH = new DHTransform(theta+c,d,a,alpha);  
  DH->getTran().toSoTransform(IVTran);

  return SUCCESS;
}

/*!
  Sets the current joint value to \a q.  The \a theta value of the DHTransform
  is then set to \a q + the joint offset \a c.  It also sets the joints moved
  flag of the owning kinematic chain to notify that an forward kinematics 
  update is necessary.
*/
int
RevoluteJoint::setVal(double q)
{
  //  if (q < min || q > max) {
  //    pr_errArgs((stderr,"%lf - joint value out of range",q));
  //    return FAILURE;
  //  }

  DH->setTheta(q+c);
  //  if (draggerAttached)
    DH->getTran().toSoTransform(IVTran);
  
  owner->jointsMoved = true;
  
  return SUCCESS;  
}

/*!
  Applies equal and opposite torques of magnitude \a f about the axis
  \a worldAxis to the two links connected to this joint.
*/
void
RevoluteJoint::applyForce(double f)
{
  dynJoint->getPrevLink()->addTorque(-f*worldAxis);
  dynJoint->getNextLink()->addTorque(f*worldAxis);
}

/*
void
RevoluteJoint::addLimitConstraint(double *H,int &hcn,int idx1,int idx2,int dir)
{
  if (getVal() <= minVal + 0.01) dir = 1;
  else if (getVal() >= maxVal - 0.01) dir = -1;
  else dir = 0;
  
  if (dir) {
    H[idx1 + 3] -= dir * worldAxis[0];
    H[idx1 + 4] -= dir * worldAxis[1];
    H[idx1 + 5] -= dir * worldAxis[2];
    
    H[idx2 + 3] += dir * worldAxis[0];
    H[idx2 + 4] += dir * worldAxis[1];
    H[idx2 + 5] += dir * worldAxis[2];
    
    hcn++;
  }
}
*/

/*!
  Initializes a DOF by giving it the owning robot \a myRobot, and the list
  of joints connected to this DOF, \a jList.  It sets the max and min vals
  of the DOF from the smallest range of the joint limits.
*/
void
DOF::initDOF(Robot *myRobot,const std::list<Joint *>& jList)
{
  std::list<Joint *>::iterator j;
  double testval;
  owner = myRobot;

  jointList = jList; // copy jList

  maxq = (*jointList.begin())->getMax()/(*jointList.begin())->getRatio();
  minq = (*jointList.begin())->getMin()/(*jointList.begin())->getRatio();

  for(j=++jointList.begin();j!=jointList.end();j++) {
    testval = (*j)->getMax()/(*j)->getRatio();
    maxq = ( testval < maxq ? testval : maxq);
    testval = (*j)->getMin()/(*j)->getRatio();
    minq = ( testval < minq ? testval : minq);
  }
}

/*!
  If a trajectory exists, this increments the \a currTrajPt counter, and
  makes the \a setPoint the next point of the trajectory.  Otherwise, it
  makes the \a setPoint the current desired value.  The \a setPoint is used
  by the PD controller to determine the proper force to apply to this DOF.
*/
void
DOF::updateSetPoint() {
  if (!trajectory.empty()) {    
    setPoint = trajectory[currTrajPt++];

    if (trajectory.begin()+currTrajPt==trajectory.end())
      trajectory.clear();
  }
  else setPoint=desiredq;
}

/*!
  Given an array of DOF values, and the length of the array, this clears the
  current trajectory and sets the trajectory to the given values.
*/
void
DOF::setTrajectory(double *traj,int numPts)
{
  trajectory.clear();
  currTrajPt = 0;
  if (numPts>1)
    trajectory.reserve(numPts);
  for (int i=0;i<numPts;i++)
    trajectory.push_back(traj[i]);
  desiredq = traj[numPts-1];
}

/*!
  This add \a numPts values to the current trajectory.
*/
void
DOF::addToTrajectory(double *traj,int numPts)
{
  for (int i=0;i<numPts;i++)
    trajectory.push_back(traj[i]);
  desiredq = trajectory.back();
}

/*!
  Updates the error between the current DOF value and its setpoint and uses
  this along with the rate of change of the error (first-order approx) to
  compute a force that should be applied to the DOF to correct the error.  The
  gains for this controller are read from the robot configuration file.
*/
void
DOF::PDPositionController(double timeStep)
{
  double newForce;

  lastError = error;
  error = setPoint - q;
#ifdef GRASPITDBG
  std::cout << "setPoint ="<<setPoint<<" error ="<<error<<" edot = "<<(error-lastError)/timeStep<<std::endl;
#endif
  newForce = Kp * error + Kv * (error-lastError)/timeStep;

#ifdef GRASPITDBG
  std::cout << "force = "<<newForce<<std::endl;
#endif

  setForce(newForce);
}

/*!
  Set a new DOF val.  Each connected joint is then set to a new val by
  multiplying this new value to the joint's ratio.
*/
int
DOF::setVal(double q1)
{
  std::list<Joint *>::iterator j;

  if (q1 == q) return SUCCESS;
  q = q1;
    
  // move each of the joints connected to this DOF
  for(j=jointList.begin();j!=jointList.end();j++)
    if ((*j)->setVal(q * (*j)->getRatio())) return FAILURE;
  
  return SUCCESS;
}

/*!
  Sets the current force applied to this DOF, keeping it within the maximum
  force limits.  This force is then applied to the first joint in the connected
  joint list.  Any other joints are considered passive, and the dynamic joint
  constraints will compute their forces automatically.
*/
void
DOF::setForce(double f)
{
  Joint *activeJoint = *(jointList.begin());
  if (f > maxForce) force = maxForce;
  else if (f < -maxForce) force = -maxForce;
  else force = f;

  //set force for the first joint only, passive joint constraints will take care of the others
  activeJoint->applyForce(force);
}
  



