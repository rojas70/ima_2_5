//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: graspitGUI.cpp,v 1.16 2004/02/12 21:35:27 amiller Exp $
//
//######################################################################

/*! \file
  \brief Implements the graspit user interface.  Responsible for creating both MainWindow and IVmgr.
*/

#include <qstring.h>
#include <qgroupbox.h>
#include <Inventor/Qt/SoQt.h>
#include <Inventor/Qt/viewers/SoQtExaminerViewer.h>
#include <qlayout.h>

#ifdef Q_WS_X11
  #include <unistd.h>
#endif

#include "graspitGUI.h"
#include "mainWindow.h"
#include "ivmgr.h"
#include "world.h"
#include "mytools.h"
#include "SoComplexShape.h"
#include "SoArrow.h"
#include "SoTorquePointer.h"

bool GraspItGUI::initialized = false;
int GraspItGUI::initResult = SUCCESS;

// Used by getopt in ProcessArgs
extern int optind,optopt,opterr;
extern char *optarg;

////////////////////////// SYSTEM WIDE GLOBALS ///////////////////////////////

#ifdef GRASPITDBG
FILE *debugfile;
#endif

//! This is the system wide pointer to the graspit user interface.
GraspItGUI *graspItGUI = 0;

//////////////////////////////////////////////////////////////////////////////

/*!
  If this class hasn't been initialized in another instance, it performs
  the following operations:
  - creates a new MainWindow,
  - starts Coin by initializing SoQt,
  - initializes our Coin add on classes,
  - creates a new IVmgr,
  - sets the focus policy of the SoQt viewer so keyboard events are accepted
  - calls a method to process the command line arguments.
 */
GraspItGUI::GraspItGUI(int argc,char **argv)
{
  if (!initialized) {
    mainWindow = new MainWindow; 
    SoQt::init(mainWindow);

    // initialize my Inventor additions
    SoComplexShape::initClass();
    SoArrow::initClass();
    SoTorquePointer::initClass();

    ivmgr = new IVmgr((QWidget *)mainWindow->viewerHolder,"myivmgr");
	
//	mainWindow->viewerHolder->setFocusProxy(ivmgr->getViewer()->getWidget());
//	mainWindow->viewerHolder->setFocusPolicy(QWidget::StrongFocus);
    
    ivmgr->getViewer()->getWidget()->setFocusPolicy(QWidget::StrongFocus);
	
//	mainWindow->resize(QSize(1070,937));
 
    //    ivmgr->useSavedCameraPositions("camera.dat");
    //    ivmgr->saveCameraPositions("camera.dat");
    //    ivmgr->saveImageSequence("data/%1.jpg");

    initialized = true;
    graspItGUI = this;
    initResult = processArgs(argc,argv);
  }
}

/*!
  Deletes both the IVmgr and the MainWindow.
*/
GraspItGUI::~GraspItGUI()
{
  delete ivmgr;
  delete mainWindow;
}

/*!
  Processes the command line arguments.  It first checks to make sure the
  GRASPIT environment variable is set, then if this is run under X11 it
  examines the command line.  The usage is the following:
\p graspit \p [-w worldname] \p [-r robotname] \p [-o objectname]
\p [-b obstaclename]
*/
int
GraspItGUI::processArgs(int argc, char **argv)
{
  QString filename;
  int errflag=0;
  QString graspitRoot = QString(getenv("GRASPIT"));
  if (!graspitRoot) {
    std::cerr << "Please set the GRASPIT environment variable to the root directory of graspIt." << std::endl;
    initResult = FAILURE;
    return FAILURE;
  }
 
#ifdef Q_WS_X11
  char c;
  while((c=getopt(argc, argv, "r:w:o:b:")) != EOF) {
    switch(c) {
    case 'r':
      filename = graspitRoot + QString("/models/robots/")+
	QString(optarg) + QString("/") + QString(optarg) + QString(".cfg");
      if (ivmgr->getWorld()->importRobot(filename)==NULL)
	++errflag;
      break;
    case 'w':
      filename = graspitRoot + QString("/worlds/")+ QString(optarg) +
	QString(".wld");
      if (ivmgr->getWorld()->load(filename)==FAILURE)
	++errflag;
      else
	mainWindow->worldBox->setTitle(filename);
      break;
    case 'o':
      filename = graspitRoot + QString("/models/objects/")+ QString(optarg) +
	QString(".iv");
      if (!ivmgr->getWorld()->importBody("GraspableBody",filename))
	++errflag;
      break;
    case 'b':
      filename = graspitRoot + QString("/models/obstacles/")+ QString(optarg) +
	QString(".iv");
      if (!ivmgr->getWorld()->importBody("Body",filename))
	++errflag;
      break;
    default: 
      ++errflag;
      break;
    }
  }
  if (errflag) {
    std::cerr << "Usage: graspit [-w worldname] [-r robotname] [-o objectname] [-b obstaclename]" << std::endl;
    return FAILURE;
  }
#endif

  return SUCCESS;
}

/*!
  Shows the mainWindow, sets its size, and starts the Qt event loop.
*/
void
GraspItGUI::startMainLoop()
{	
  SoQt::show(mainWindow);
  mainWindow->setMainWorld(ivmgr->getWorld());
  mainWindow->resize(QSize(1070,937));  
  SoQt::mainLoop();

}  

/*!
  Exits the Qt event loop.
*/
void
GraspItGUI::exitMainLoop()
{
  SoQt::exitMainLoop();
}

