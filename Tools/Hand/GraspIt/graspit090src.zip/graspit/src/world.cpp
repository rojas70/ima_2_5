//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: world.cpp,v 1.32 2004/02/15 15:42:27 amiller Exp $
//
//######################################################################

/*! \file 
  \brief Implements the simulation world.
 */

#include <string>
//#include <strstream.h>
#include <qstringlist.h>
#include <qsettings.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qfile.h>
#include <qdatetime.h>

#include "myRegistry.h"
#include "matvecIO.h"
#include "world.h"
#include "worldElement.h"
#include "mytools.h"
#include "body.h"
#include "robot.h"
#include "contact.h"
#include "ivcollide.h"
#include "ivmgr.h"
#include "PQP.h"
#include "dynamics.h"
#include "grasp.h"

#include "dynJoint.h"

#include <Inventor/sensors/SoIdleSensor.h>

#ifdef USE_DMALLOC
#include "dmalloc.h"
#endif

FILE *errFP=NULL;

//#define GRASPITDBG

#define MAXBODIES 256

char graspitVersionStr[] = "GraspIt! version 1.3";

World::World(QObject *parent,const char *name) : QObject(parent,name)
{
  numBodies = numGB = numRobots = numHands = 0;
  numSelectedBodyElements = numSelectedRobotElements = 0;
  numSelectedElements = 0;
  numSelectedBodies = 0;
  currentHand = NULL;

  maxId = -1;
  worldTime = 0.0;
  modified = false;

  allCollisionsOFF = false;

  cofTable=kcofTable=NULL;
  readSettings();  // set up the world parameters 

  double eccen[3] = {1,1,0.2};
  //int numDirs[9] = {1,3,5,7,8,7,5,3,1};
  int numDirs[1] = {8};;
  
  //  double phi[9] = {M_PI_2, M_PI_2*0.6, M_PI_2*0.3, M_PI_2*0.15, 0.0,
  //                   -M_PI_2*0.15, -M_PI_2*0.3, -M_PI_2*0.6, -M_PI_2};
  double phi[1] = {0.0};

  Contact::setUpFrictionEdges(1,numDirs,phi,eccen); 
  
  ivc = new ivcollide;

  IVRoot = new SoSeparator;
  IVRoot->ref();

  idleSensor = NULL;
  dynamicsOn = false;


}

World::~World()
{
  int i;
#ifdef GRASPITDBG
  std::cerr << "Deleting world" << std::endl;
#endif

  saveSettings();

  for (i=0;i<numMaterials;i++) {
	free(cofTable[i]);
	free(kcofTable[i]);
  }
  free(cofTable);
  free(kcofTable);

  for (i=numRobots-1;i>=0;i--)
    destroyElement(robotVec[i]);

  for (i=numBodies-1;i>=0;i--) {
#ifdef GRASPITDBG
    std::cout << "Deleting body: " << i <<" "<<bodyVec[i]->getName().latin1()<<std::endl;
#endif
    destroyElement(bodyVec[i]);
  }
  
  if (idleSensor) delete idleSensor;
  delete ivc;
  IVRoot->unref();
}

int
World::getMaterialIdx(const QString &matName) const
{
  int i;
  for (i=0;i<numMaterials;i++)
	if (materialNames[i] == matName) return i;

  return -1;
}

void
World::setDefaults()
{
  int i;

  dynamicsTimeStep = 0.0025;

  if (cofTable) {
	for (i=0;i<numMaterials;i++) {
	  free(cofTable[i]);
	  free(kcofTable[i]);
	}
	free(cofTable);
	free(kcofTable);
  }

  numMaterials = 6;

  cofTable = (double **)malloc(numMaterials*sizeof(double *));
  kcofTable = (double **)malloc(numMaterials*sizeof(double *));
  for (i=0;i<numMaterials;i++) {
    cofTable[i] = (double *)malloc(numMaterials*sizeof(double));
    kcofTable[i] = (double *)malloc(numMaterials*sizeof(double));
  }

  materialNames.clear();
  materialNames.push_back("frictionless");
  materialNames.push_back("glass");
  materialNames.push_back("metal");
  materialNames.push_back("plastic");
  materialNames.push_back("wood");
  materialNames.push_back("rubber");

  //frictionless
  for (i=0;i<6;i++) {
    cofTable[0][i] = cofTable[i][0] = 0.0;
	kcofTable[0][i] = kcofTable[i][0] = 0.0;
  }

  //glass
  cofTable[1][1] = 0.2;
  cofTable[1][2] = cofTable[2][1] = 0.2;
  cofTable[1][3] = cofTable[3][1] = 0.2;
  cofTable[1][4] = cofTable[4][1] = 0.3;
  cofTable[1][5] = cofTable[5][1] = 1.0;
  kcofTable[1][1] = 0.1;
  kcofTable[1][2] = kcofTable[2][1] = 0.1;
  kcofTable[1][3] = kcofTable[3][1] = 0.1;
  kcofTable[1][4] = kcofTable[4][1] = 0.2;
  kcofTable[1][5] = kcofTable[5][1] = 0.9;
  
  //metal
  cofTable[2][2] = 0.2;
  cofTable[2][3] = cofTable[3][2] = 0.2;
  cofTable[2][4] = cofTable[4][2] = 0.3;
  cofTable[2][5] = cofTable[5][2] = 1.0;
  kcofTable[2][2] = 0.1;
  kcofTable[2][3] = kcofTable[3][2] = 0.1;
  kcofTable[2][4] = kcofTable[4][2] = 0.2;
  kcofTable[2][5] = kcofTable[5][2] = 0.9;

  //plastic
  cofTable[3][3] = 0.3;
  cofTable[3][4] = cofTable[4][3] = 0.4;
  cofTable[3][5] = cofTable[5][3] = 1.0;
  kcofTable[3][3] = 0.2;
  kcofTable[3][4] = kcofTable[4][3] = 0.3;
  kcofTable[3][5] = kcofTable[5][3] = 0.9;

  //wood
  cofTable[4][4] = 0.4;
  cofTable[4][5] = cofTable[5][4] = 1.0;
  kcofTable[4][4] = 0.3;
  kcofTable[4][5] = kcofTable[5][4] = 0.9;

  //rubber
  cofTable[5][5] = 2.0;
  kcofTable[5][5] = 1.9;
}



void
World::readSettings()
{
  QSettings settings;
  int i,j,newNumMaterials;
  double **newcofTable,**newkcofTable;

  setDefaults();

  settings.insertSearchPath(QSettings::Windows, COMPANY_KEY);

  dynamicsTimeStep = settings.readDoubleEntry(APP_KEY + QString("World/dynamicsTimeStep"),dynamicsTimeStep);

  newNumMaterials = settings.readNumEntry(APP_KEY + QString("World/numMaterials"),numMaterials);

  newcofTable = (double **)malloc(newNumMaterials*sizeof(double *));
  newkcofTable = (double **)malloc(newNumMaterials*sizeof(double *));

  for (i=0;i<newNumMaterials;i++) {
	  newcofTable[i] = (double *)malloc(newNumMaterials*sizeof(double));
	  newkcofTable[i] = (double *)malloc(newNumMaterials*sizeof(double));
	}
  
  for (i=0;i<numMaterials;i++) {
    materialNames[i] = settings.readEntry(APP_KEY + QString("World/material%1").arg(i),materialNames[i]);

    for (j=i;j<numMaterials;j++) {
	  newcofTable[i][j] = newcofTable[j][i] =
	    settings.readDoubleEntry(APP_KEY + QString("World/cof%1%2").arg(i).arg(j),cofTable[i][j]);

      newkcofTable[i][j] = newkcofTable[j][i] =
	    settings.readDoubleEntry(APP_KEY + QString("World/kcof%1%2").arg(i).arg(j),kcofTable[i][j]);
	}

	for (;j<newNumMaterials;j++) {
	  newcofTable[i][j] = newcofTable[j][i] =
        settings.readDoubleEntry(APP_KEY + QString("World/cof%1%2").arg(i).arg(j));

	  newkcofTable[i][j] = newkcofTable[j][i] =
        settings.readDoubleEntry(APP_KEY + QString("World/kcof%1%2").arg(i).arg(j));
	}
  }
  for (;i<newNumMaterials;i++){
    materialNames.push_back(settings.readEntry(APP_KEY + QString("World/material%1").arg(i)));

	for (j=i;j<newNumMaterials;j++) {
      newcofTable[i][j] = newcofTable[j][i] =
        settings.readDoubleEntry(APP_KEY + QString("World/cof%1%2").arg(i).arg(j));

	  newkcofTable[i][j] = newkcofTable[j][i] =
        settings.readDoubleEntry(APP_KEY + QString("World/kcof%1%2").arg(i).arg(j));
	}
  }

  for (i=0;i<numMaterials;i++) {
	free(cofTable[i]);
	free(kcofTable[i]);
  }

  free(cofTable);
  free(kcofTable);
  numMaterials = newNumMaterials;
  cofTable = newcofTable;
  kcofTable = newkcofTable;
}

void
World::saveSettings()
{
  int i,j;
  QSettings settings;
  settings.insertSearchPath(QSettings::Windows, COMPANY_KEY);

  settings.writeEntry(APP_KEY + QString("World/numMaterials"),numMaterials);
  for (i=0;i<numMaterials;i++) {
	settings.writeEntry(APP_KEY + QString("World/material%1").arg(i),materialNames[i]);
	for (j=i;j<numMaterials;j++) { 
      settings.writeEntry(APP_KEY + QString("World/cof%1%2").arg(i).arg(j),cofTable[i][j]);
	  settings.writeEntry(APP_KEY + QString("World/kcof%1%2").arg(i).arg(j),kcofTable[i][j]);
	}
  }
}


void
World::destroyElement(WorldElement *e)
{
  std::vector<Body *>::iterator bp;
  std::vector<GraspableBody *>::iterator gp;
  std::vector<Robot *>::iterator rp;
  std::vector<Hand *>::iterator hp;

#ifdef GRASPITDBG
  std::cout << " in remove element: " << e->className() <<std::endl;
#endif

  if (e->inherits("Body")) {
#ifdef GRASPITDBG
    std::cout << " found a body"<<std::endl;
#endif

    ivc->vc->DeleteObject(((Body *)e)->getId());
    bodyIdVec[((Body *)e)->getId()] = NULL;
    for (bp=bodyVec.begin();bp!=bodyVec.end();bp++) 
      if (*bp == e) {
	bodyVec.erase(bp); numBodies--;

#ifdef GRASPITDBG
	std::cerr <<"removed body "<<((Body *)e)->getName()<<
	  " from world"<<std::endl;
#endif
	break;
      }

    for (gp=GBVec.begin();gp!=GBVec.end();gp++) 
      if (*gp == e) {
		GBVec.erase(gp); numGB--;

		for (hp=handVec.begin();hp!=handVec.end();hp++)
		  if ((*hp)->getGrasp()->getObject() == e) {
			if (numGB > 0)
			  (*hp)->getGrasp()->setObject(GBVec[0]);
			else
			  (*hp)->getGrasp()->setObject(NULL);
		  }

#ifdef GRASPITDBG
		std::cerr << "removed GB " << ((Body *)e)->getName()<<
		  " from world"<<std::endl;
#endif

		break;
      }
  }

  if (e->inherits("Robot")) {

#ifdef GRASPITDBG
    std::cout << " found a robot"<<std::endl;
#endif

    for (hp=handVec.begin();hp!=handVec.end();hp++) 
      if (*hp == e) {
		handVec.erase(hp); numHands--;

		if (currentHand == e) {
		  if (numHands > 0) currentHand = handVec[0];
		  else currentHand = NULL;
		}

#ifdef GRASPITDBG
		std::cerr << "removed hand " << ((Robot *)e)->getName() << " from world"<<std::endl;  
#endif
		emit handRemoved();
		break;
      }
    for (rp=robotVec.begin();rp!=robotVec.end();rp++) 
      if (*rp == e) {
		robotVec.erase(rp); numRobots--;

#ifdef GRASPITDBG
      	std::cerr << "removed robot " << ((Robot *)e)->getName() << " from world"<<std::endl; 
#endif

		break;
      }
  }

  int idx = IVRoot->findChild(e->getIVRoot());
  delete e;
  if (idx > -1)
    IVRoot->removeChild(idx);

  emit numElementsChanged();
  modified = true;
}

int
World::load(const QString &filename)
{
  QFile file(filename);
  QString buf, elementType, version, matStr, elementPath, elementName,
    mountFilename;
  QStringList robotPaths;
  Link *mountPiece;
  QString line;
  WorldElement *element;
  int mat;
  transf tr;
  int prevRobNum,chainNum,nextRobNum;
  bool badFile;

  if (!file.open(IO_ReadOnly)) {
    std::cerr << "could not open"<<filename.latin1()<<"for reading.\n";
    return FAILURE;
  }
  QTextStream stream( &file );

  version = stream.readLine();

  while(!file.atEnd()) {
    stream >> elementType;
    if (elementType.isEmpty()) continue;

    if (elementType == "Obstacle") {
      stream >> elementName;
      stream >> matStr;
      mat = getMaterialIdx(matStr);
      if (mat == -1) {
	QTWARNING(elementName + ": " + matStr + " is not a valid material name");
	file.close();
	return FAILURE;
      }
      elementPath = QString(getenv("GRASPIT")) + "/models/obstacles/" + 
	elementName;
#ifdef GRASPITDBG
      std::cerr << "importing " << elementPath.latin1() <<std::endl;
#endif
      element = importBody("Body",elementPath);
      if (!element) {
	QTWARNING("Could not open " + elementPath);
	file.close();
	return FAILURE;
      }
      if (readTransRotFromQTextStream(stream,tr)==FAILURE) {
	file.close();
	return FAILURE;
      }
      element->setTran(tr);
    }
    else if (elementType == "GraspableBody") {
      stream >> elementName;
      elementPath = QString(getenv("GRASPIT")) + "/models/objects/" +
	elementName;
#ifdef GRASPITDBG
      std::cerr << "importing " << elementPath.latin1() <<std::endl;
#endif
      element = importBody("GraspableBody",elementPath);
      if (!element) {
	    QTWARNING("Could not open " + elementPath);
	    file.close();
	    return FAILURE;
      }
      if (readTransRotFromQTextStream(stream,tr)==FAILURE){
	  file.close();
	  return FAILURE;
      }
      element->setTran(tr);
    }
    else if (elementType == "Robot") {
      Robot *robot;
      stream >> elementName;
      elementPath = QString(getenv("GRASPIT")) + "/models/robots/" +
	elementName + '/';
        robotPaths.append(elementPath);
      elementPath += elementName + ".cfg";
#ifdef GRASPITDBG
      std::cerr << "importing " << elementPath.latin1() <<std::endl;
#endif
      if ((robot = importRobot(elementPath))==NULL){
	    QTWARNING("Could not open " + elementPath);
	    file.close();
	    return FAILURE;
      }
      element = robot;
      robot->readDOFVals(stream);
      if (readTransRotFromQTextStream(stream,tr)==FAILURE) {
	    file.close();
	    return FAILURE;
      }
      element->setTran(tr);

    }
    else if (elementType == "Connection") {
      line = stream.readLine();
      line = stream.readLine();
      QTextStream lineStream(&line,IO_ReadOnly);
      lineStream >> prevRobNum >> chainNum >> nextRobNum >> mountFilename;
      if (prevRobNum < 0 || prevRobNum >= numRobots || nextRobNum < 0 ||
	  nextRobNum >= numRobots || chainNum < 0 || 
	  chainNum >= robotVec[prevRobNum]->getNumChains()) {
		badFile = true; break;
	  }
      
	  if (readTransRotFromQTextStream(stream,tr)==FAILURE) {
		badFile = true;
		QTWARNING("Error reading connection transform"); break;
      }
#ifdef GRASPITDBG
      std::cout << "offset tran " << tr <<std::endl;
#endif
      if (!mountFilename.isEmpty()) {
		KinematicChain *prevChain= robotVec[prevRobNum]->getChain(chainNum);
		QStringList::Iterator iter = robotPaths.begin();
		for (int i=0;i<nextRobNum;i++,iter++);
		*iter += "iv/" + mountFilename;	

	    if ((mountPiece = robotVec[nextRobNum]->importMountPiece(*iter))) {
		  addLink(mountPiece);
  
		  turnOffCollisions(prevChain->getLink(prevChain->getNumLinks()-1),
		  	    mountPiece);
		  turnOffCollisions(mountPiece,robotVec[nextRobNum]->getBase());
		}
		mountFilename=(char *)NULL;
	  }
      robotVec[prevRobNum]->attachRobot(robotVec[nextRobNum],chainNum,tr);

      //for paloma
// ivc->vc->DeactivatePair(robotVec[prevRobNum]->getChain(0)->getLink(2)->getId(),
//			     robotVec[nextRobNum]->getBase()->getId());

    }
    else {
      QTWARNING(elementType + " is not a valid WorldElement type");
      file.close();
      return FAILURE;
    }
  }
  file.close();

    //   robotVec[i]->setDesiredTran(robotVec[i]->getTran());



  //  ivmgr->getViewer()->viewAll();
    findAllContacts();

  modified = false;
  return SUCCESS;

}

int
World::save(const QString &filename)
{
  QFile file(filename);
  int i,j,k,l;
  
 if (!file.open(IO_WriteOnly)) {
    QTWARNING("could not open " + filename + "for writing");
    return FAILURE;
  }
  QTextStream stream( &file );

  stream<<"#"<<graspitVersionStr<<endl;

  for (i=0;i<numBodies;i++) {
    if (bodyVec[i]->isA("Body")) {
      stream<<"Obstacle"<<endl;
      stream<<*bodyVec[i];
      stream<< "T " << bodyVec[i]->getTran() << endl << endl;
    }
    else if (bodyVec[i]->inherits("GraspableBody")) {
      stream<<"GraspableBody"<<endl;
      stream<<*((GraspableBody *)bodyVec[i]);
      stream<< "T " << bodyVec[i]->getTran() <<endl <<endl;
    }
  }
   
  for (i=0;i<numRobots;i++) {
    stream<<"Robot"<<endl;
    robotVec[i]->writeDOFVals(stream);
    stream << "T " << robotVec[i]->getTran() <<endl <<endl;
  }

  for(i=0;i<numRobots;i++) {
    for (j=0;j<robotVec[i]->getNumChains();j++) {
      KinematicChain *chain = robotVec[i]->getChain(j);
      for (k=0;k<chain->getNumAttachedRobots();k++) {	
	stream<<"Connection"<<endl;
	stream<< i << ' ' << j <<' ';
	for (l=0;l<numRobots;l++)
	  if (chain->getAttachedRobot(k) == robotVec[l]) break;
	stream<< l;
	if (chain->getAttachedRobot(k)->getMountPiece())
	  stream<<' '<<
	    chain->getAttachedRobot(k)->getMountPiece()->getFilename();
	stream<<endl;
	stream<< "T " << chain->getAttachedRobotOffset(k) << endl << endl;
      }
    }
  }
	  
  file.close();
  modified = false;
  return SUCCESS;
}

Body *
World::importBody(QString bodyType,QString filename)
{  
  Body *newBody = (Body *) WorldElement::createInstance(bodyType,this,NULL);
  if (!newBody) return NULL;

  if (newBody->load(filename)==FAILURE) return NULL;

  bodyVec.push_back(newBody);
  numBodies++;

  if (newBody->getId() > maxId) {
    bodyIdVec.resize(newBody->getId()+1);
    maxId = newBody->getId();
  }
  bodyIdVec[newBody->getId()] = newBody;

  if (newBody->inherits("GraspableBody")) {
    GBVec.push_back((GraspableBody *)newBody);
    if (numGB == 0)
      for (int i=0;i<numHands;i++)
	handVec[i]->getGrasp()->setObject((GraspableBody *)newBody);

    numGB++;
  }
  
  IVRoot->addChild(newBody->getIVRoot());
    
  modified = true;
  emit numElementsChanged();
  return newBody;
}

void
World::addLink(Link *newLink)
{
  bodyVec.push_back(newLink);
  numBodies++;
  //  turnOffCollisions(newLink);
  if (newLink->getId() > maxId) {
    bodyIdVec.resize(newLink->getId()+1);
    maxId = newLink->getId();
  }
  bodyIdVec[newLink->getId()] = newLink;  
}

Robot *
World::importRobot(QString filename)
{
  int f,l,l2;
  QFile file(filename);
  Robot *robot;
  
  if (!file.open(IO_ReadOnly)) {
    QTWARNING("could not open " + filename);
    return NULL;
  }

  QTextStream stream( &file );
  QString line;

  while(!stream.atEnd()) {
    line = stream.readLine();
    if (!(line.isEmpty() || line[0] == '#')) break;
  }
  file.close();
  
  robot = (Robot *)WorldElement::createInstance(line,this,NULL);
  if (!robot) return NULL;

  if (robot->load(filename) == FAILURE) {
    delete robot;
    return NULL;
  }

  robotVec.push_back(robot);
  IVRoot->addChild(robot->getIVRoot());  
  numRobots++;

  if (robot->getBase()) 
    addLink(robot->getBase());

  for (f=0;f<robot->getNumChains();f++)
    for (l=0;l<robot->getChain(f)->getNumLinks();l++)
      addLink(robot->getChain(f)->getLink(l));

  for (f=0;f<robot->getNumChains();f++) {
    ivc->vc->DeactivatePair(robot->getChain(f)->getLink(0)->getId(),
			    robot->getBase()->getId());
    
    for (l=0;l<robot->getChain(f)->getNumLinks();l++)
      for(l2 = 0; l2<robot->getChain(f)->getNumLinks();l2++) 
	ivc->vc->DeactivatePair(robot->getChain(f)->getLink(l)->getId(),
				robot->getChain(f)->getLink(l2)->getId());
  }

  if (robot->inherits("Hand")) {
    // for paloma
   //  ivc->vc->DeactivatePair(robot->getChain(1)->getLink(0)->getId(),
    //		    robot->getChain(2)->getLink(0)->getId());
     
    handVec.push_back((Hand *)robot);

    if (numGB > 0)
      ((Hand *)robot)->getGrasp()->setObject(GBVec[0]);
    
    numHands++;

    if (numHands==1)
      setCurrentHand((Hand *)robot);
  }

  for (int d=0;d<robot->getNumDOF();d++)
    robot->getDOF(d)->setDesiredPos(robot->getDOF(d)->getVal());

  std::cout << robot->getChain(0)->getLink(0)->getTran() << std::endl;
  modified = true;
  emit numElementsChanged();
  return robot;
}

DynamicBody *
World::makeBodyDynamic(const Body *b, double mass)
{ 
  ColReportT colReport;
  int i;
  std::list<Contact *> contactList;
  
  DynamicBody *dynBod = new DynamicBody(*b,mass);
  for (i=0;i<numBodies;i++)
	if (bodyVec[i] == b) {
		bodyVec[i] = dynBod;
		break;
	}
  bodyIdVec[b->getId()] = dynBod;
  delete b;
  findContacts(dynBod);

  return dynBod;
}

void
World::selectElement(WorldElement *e)
{
  std::list<WorldElement *>::iterator ep;
  int c,l;

  std::cout << "selecting element "<<e->getName().latin1()<<std::endl;
  if (e->inherits("Body")) numSelectedBodyElements++;
  else if (e->inherits("Robot")) numSelectedRobotElements++;
  numSelectedElements++;

  selectedElementList.push_back(e);

  selectedBodyVec.clear();
  for (ep=selectedElementList.begin();ep!=selectedElementList.end();ep++) {
    if ((*ep)->inherits("Body")) selectedBodyVec.push_back((Body *)(*ep));
    else if ((*ep)->inherits("Robot")) {
      Robot *r = (Robot *)(*ep);
      selectedBodyVec.push_back(r->getBase());
      for (c=0;c<r->getNumChains();c++)
	for (l=0;l<r->getChain(c)->getNumLinks();l++)
	  selectedBodyVec.push_back(r->getChain(c)->getLink(l));
    }
  }
  numSelectedBodies = selectedBodyVec.size();

  std::cout << "selected elements "<<numSelectedElements<<std::endl;
  std::cout << "selected bodies "<<numSelectedBodies<<std::endl;

  emit selectionsChanged();
}

void
World::deselectElement(WorldElement *e)
{
  std::list<WorldElement *>::iterator ep;
  int c,l;

  std::cout << "deselecting element "<<e->getName().latin1()<<std::endl;
  if (e->inherits("Body")) numSelectedBodyElements--;
  else if (e->inherits("Robot")) numSelectedRobotElements--;
  numSelectedElements--;

  selectedElementList.remove(e);

  selectedBodyVec.clear();
  for (ep=selectedElementList.begin();ep!=selectedElementList.end();ep++) {
    if ((*ep)->inherits("Body")) selectedBodyVec.push_back((Body *)(*ep));
    else if ((*ep)->inherits("Robot")) {
      Robot *r = (Robot *)(*ep);
      selectedBodyVec.push_back(r->getBase());
      for (c=0;c<r->getNumChains();c++)
	for (l=0;l<r->getChain(c)->getNumLinks();l++)
	  selectedBodyVec.push_back(r->getChain(c)->getLink(l));
    }
  }
  numSelectedBodies = selectedBodyVec.size();

  std::cout << "selected elements "<<numSelectedElements<<std::endl;
  std::cout << "selected bodies "<<numSelectedBodies<<std::endl;

  emit selectionsChanged();
}

void
World::deselectAll()
{
  selectedElementList.clear();
  selectedBodyVec.clear();

  numSelectedElements = numSelectedBodyElements = numSelectedRobotElements = 0;
  numSelectedBodies = 0;
  emit selectionsChanged();
}

bool
World::isSelected(WorldElement *e) const
{
  std::list<WorldElement *>::const_iterator ep;
  for (ep=selectedElementList.begin();ep!=selectedElementList.end();ep++)
    if (*ep == e) return true;
  return false;
}

void
World::removeRobot(Robot *robot)
{
  std::vector<Robot *>::iterator rp;
  std::vector<Hand *>::iterator hp;

  for (rp=robotVec.begin();rp!=robotVec.end();rp++)
    if (*rp == robot) {
      robotVec.erase(rp);
      numRobots--;
      break;
    }

  if (robot->inherits("Hand"))
    for (hp=handVec.begin();hp!=handVec.end();hp++)
      if (*hp == robot) {
	handVec.erase(hp);
	numHands--;
	break;
      }

  delete robot;
}

void
World::toggleCollisions(bool off)
{
  std::list<WorldElement *>::iterator ep;

  std::cout << "TOGGLING COLLISIONS"<<std::endl;

  if (numSelectedElements == 0) {
    allCollisionsOFF = off;
  }
  else if (numSelectedElements == 2) {
      if (off) turnOffCollisions(selectedElementList.front(),
				 selectedElementList.back());
      else turnOnCollisions(selectedElementList.front(),
			    selectedElementList.back());
  }
  else {
    for (ep=selectedElementList.begin();ep!=selectedElementList.end();ep++)
      if (off) turnOffCollisions(*ep);
      else turnOnCollisions(*ep);
  }

  findAllContacts();
}

bool
World::collisionsAreOff(WorldElement *e1,WorldElement *e2)
{
  int f,l,f2,l2;
  Body *b1,*b2;
  Robot *r1,*r2;

  if (e1 == NULL && e2 == NULL) return allCollisionsOFF;
  if (e1->inherits("Body")) {
	b1 = (Body *)e1;
	if (e2) {
	  if (e2->inherits("Body")) {
		b2 = (Body *)e2;  
		return !ivc->vc->isPairActivated(b1->getId(),b2->getId());
	  }
	  else if (e2->inherits("Robot")) {
		r2 = (Robot *)e2;
		if (ivc->vc->isPairActivated(b1->getId(),r2->getBase()->getId()))
		  return false;
		for (f=0;f<r2->getNumChains();f++) 
		  for (l=0;l<r2->getChain(f)->getNumLinks();l++)
			if (ivc->vc->isPairActivated(b1->getId(),
			                             r2->getChain(f)->getLink(l)->getId()))
			  return false;
	  }
	}
	else return !ivc->vc->isObjectActivated(b1->getId());
  }
  else if (e1->inherits("Robot")) {
	r1 = (Robot *)e1;
	if (e2) {
	  if (e2->inherits("Body")) {
		b2 = (Body *)e2;
		if (ivc->vc->isPairActivated(r1->getBase()->getId(),b2->getId()))
		  return false;
		for (f=0;f<r1->getNumChains();f++) 
		  for (l=0;l<r1->getChain(f)->getNumLinks();l++)
			if (ivc->vc->isPairActivated(r1->getChain(f)->getLink(l)->getId(),
						 			     b2->getId()))
			  return false;
	  }
	  else if (e2->inherits("Robot")) {
		r2 = (Robot *)e2;
		if (ivc->vc->isPairActivated(r1->getBase()->getId(),
								     r2->getBase()->getId()))
		  return false;
		for (f2=0;f2<r2->getNumChains();f2++) 
		  for (l2=0;l2<r2->getChain(f2)->getNumLinks();l2++)
			if (ivc->vc->isPairActivated(r1->getBase()->getId(),
				    r2->getChain(f2)->getLink(l2)->getId()))
			  return false;


		for (f=0;f<r1->getNumChains();f++) 
		  for (l=0;l<r1->getChain(f)->getNumLinks();l++) 
			if (ivc->vc->isPairActivated(r1->getChain(f)->getLink(l)->getId(),
			  							 r2->getBase()->getId()))
			  return false;

	    for (f2=0;f2<r2->getNumChains();f2++) 
	      for (l2=0;l2<r2->getChain(f2)->getNumLinks();l2++)
			if (ivc->vc->isPairActivated(r1->getChain(f)->getLink(l)->getId(),
									 r2->getChain(f2)->getLink(l2)->getId()))
			  return false;
	  }
	}
	else {
  	  if (ivc->vc->isObjectActivated(r1->getBase()->getId())) return false;
  	  for (f=0;f<r1->getNumChains();f++) 
		for (l=0;l<r1->getChain(f)->getNumLinks();l++)
		  if (ivc->vc->isObjectActivated(r1->getChain(f)->getLink(l)->getId()))
			return false;
    }
  }
  return true;	
}

void
World::turnOffCollisions(WorldElement *e1,WorldElement *e2)
{
  int f,l,f2,l2;
  Body *b1,*b2;
  Robot *r1,*r2;

  if (e1->inherits("Body")) {
    b1 = (Body *)e1;
    if (e2) {
      if (e2->inherits("Body")) {
		b2 = (Body *)e2;
		ivc->vc->DeactivatePair(b1->getId(),b2->getId());
      }
      else if (e2->inherits("Robot")) {
		r2 = (Robot *)e2;
		ivc->vc->DeactivatePair(b1->getId(),r2->getBase()->getId());
		for (f=0;f<r2->getNumChains();f++) 
		  for (l=0;l<r2->getChain(f)->getNumLinks();l++)
			ivc->vc->DeactivatePair(b1->getId(),
			  	                    r2->getChain(f)->getLink(l)->getId());
	  }
	}
	else ivc->vc->DeactivateObject(b1->getId());
  }
  else if (e1->inherits("Robot")) {
    r1 = (Robot *)e1;
    if (e2) {
      if (e2->inherits("Body")) {
	b2 = (Body *)e2;
	ivc->vc->DeactivatePair(r1->getBase()->getId(),b2->getId());
	for (f=0;f<r1->getNumChains();f++) 
	  for (l=0;l<r1->getChain(f)->getNumLinks();l++)
	    ivc->vc->DeactivatePair(r1->getChain(f)->getLink(l)->getId(),
				    b2->getId());
      }
      else if (e2->inherits("Robot")) {
	r2 = (Robot *)e2;
	ivc->vc->DeactivatePair(r1->getBase()->getId(),
				r2->getBase()->getId());

	for (f2=0;f2<r2->getNumChains();f2++) 
	  for (l2=0;l2<r2->getChain(f2)->getNumLinks();l2++)
	    ivc->vc->DeactivatePair(r1->getBase()->getId(),
				    r2->getChain(f2)->getLink(l2)->getId());

	for (f=0;f<r1->getNumChains();f++) 
	  for (l=0;l<r1->getChain(f)->getNumLinks();l++) {
	    ivc->vc->DeactivatePair(r1->getChain(f)->getLink(l)->getId(),
				    r2->getBase()->getId());

	    for (f2=0;f2<r2->getNumChains();f2++) 
	      for (l2=0;l2<r2->getChain(f2)->getNumLinks();l2++)
		ivc->vc->DeactivatePair(r1->getChain(f)->getLink(l)->getId(),
					r2->getChain(f2)->getLink(l2)->getId());
	  }
      }
    }
    else {
      ivc->vc->DeactivateObject(r1->getBase()->getId());
	for (f=0;f<r1->getNumChains();f++) 
	  for (l=0;l<r1->getChain(f)->getNumLinks();l++)
	    ivc->vc->DeactivateObject(r1->getChain(f)->getLink(l)->getId());
	
    }
  }
}

void
World::turnOnCollisions(WorldElement *e1,WorldElement *e2)
{
  int f,l,f2,l2;
  Body *b1,*b2;
  Robot *r1,*r2;

  if (e1->inherits("Body")) {
    b1 = (Body *)e1;
    if (e2) {
      if (e2->inherits("Body")) {
	b2 = (Body *)e2;
	ivc->vc->ActivatePair(b1->getId(),b2->getId());
      }
      else if (e2->inherits("Robot")) {
	r2 = (Robot *)e2;
	ivc->vc->ActivatePair(b1->getId(),r2->getBase()->getId());
	for (f=0;f<r2->getNumChains();f++) 
	  for (l=0;l<r2->getChain(f)->getNumLinks();l++)
	    ivc->vc->ActivatePair(b1->getId(),
				    r2->getChain(f)->getLink(l)->getId());
      }	    
    }
    else ivc->vc->ActivateObject(b1->getId());
  }
  else if (e1->inherits("Robot")) {
    r1 = (Robot *)e1;
    if (e2) {
      if (e2->inherits("Body")) {
	b2 = (Body *)e2;
	ivc->vc->ActivatePair(r1->getBase()->getId(),b2->getId());
	for (f=0;f<r1->getNumChains();f++) 
	  for (l=0;l<r1->getChain(f)->getNumLinks();l++)
	    ivc->vc->ActivatePair(r1->getChain(f)->getLink(l)->getId(),
				    b2->getId());
      }
      else if (e2->inherits("Robot")) {
	r2 = (Robot *)e2;
	ivc->vc->ActivatePair(r1->getBase()->getId(),
				r2->getBase()->getId());

	for (f2=0;f2<r2->getNumChains();f2++) 
	  for (l2=0;l2<r2->getChain(f2)->getNumLinks();l2++)
	    ivc->vc->ActivatePair(r1->getBase()->getId(),
				    r2->getChain(f2)->getLink(l2)->getId());

	for (f=0;f<r1->getNumChains();f++) 
	  for (l=0;l<r1->getChain(f)->getNumLinks();l++) {
	    ivc->vc->ActivatePair(r1->getChain(f)->getLink(l)->getId(),
				    r2->getBase()->getId());

	    for (f2=0;f2<r2->getNumChains();f2++) 
	      for (l2=0;l2<r2->getChain(f2)->getNumLinks();l2++)
		ivc->vc->ActivatePair(r1->getChain(f)->getLink(l)->getId(),
					r2->getChain(f2)->getLink(l2)->getId());
	  }
      }
    }
    else {
      ivc->vc->ActivateObject(r1->getBase()->getId());
	for (f=0;f<r1->getNumChains();f++) 
	  for (l=0;l<r1->getChain(f)->getNumLinks();l++)
	    ivc->vc->ActivateObject(r1->getChain(f)->getLink(l)->getId());
	
    }
  }
}

int
World::getCollisionReport(ColReportT &colReport)
{
  int numCols;
  //static VCReportType VCColReport[MAXBODIES]; 
  VCReportType *VCColReport = new VCReportType[MAXBODIES];
  std::pair<Body *,Body *> colPair;

  if (allCollisionsOFF) return 0;

  colReport.clear();
  ivc->vc->Collide();
  numCols = ivc->vc->Report(MAXBODIES,VCColReport);
  for (int i=0;i<numCols;i++) {
    colPair.first = bodyIdVec[VCColReport[i].id1];
    colPair.second = bodyIdVec[VCColReport[i].id2];
    colReport.push_back(colPair);
  }
  delete [] VCColReport;
  return numCols;
}

double
World::getDist(Body *b1,Body *b2)
{
  return ivc->vc->Dist(b1->getId(),b2->getId());
}


void
World::updateGrasps()
{
  for (int i=0;i<numHands;i++)
    if (handVec[i]->contactsChanged())
      handVec[i]->getGrasp()->update();

  emit graspsUpdated();
}

void
World::findContacts(const ColReportT &colReport)
{
  PQP_ContactResult cres;
  int i;
  int numCols = colReport.size();
  
  for (i=0;i<numCols;i++) {
    ivc->vc->Contact(colReport[i].first->getId(),colReport[i].second->getId(),
		     Contact::THRESHOLD,cres);
    addContacts(colReport[i].first,colReport[i].second,cres.contactSet);
  }
  
}

void
World::findContacts(Body *b)
{
  PQP_ContactResult cres;
  int i;

  for (i=0;i<numBodies;i++) {
	if (bodyVec[i]->getId() != b->getId()) {
		ivc->vc->Contact(b->getId(),bodyVec[i]->getId(),Contact::THRESHOLD,cres);
		addContacts(b,bodyVec[i],cres.contactSet);
	}
  }
}

void
World::findAllContacts()
{
  PQP_ContactResult *cresArr;
  int i,numContacts;

  // Break all previous contacts
#ifdef GRASPITDBG
  printf("breaking contacts\n");
#endif

  for (i=0;i<numBodies;i++)
    bodyVec[i]->breakContacts();
  
  if (allCollisionsOFF) return;

  // Find every contact between all pairs of bodies
  cresArr = new PQP_ContactResult[(maxId+1)*(maxId)/2];
  numContacts = ivc->vc->FindAllContacts(Contact::THRESHOLD,cresArr);
#ifdef GRASPITDBG
  printf("found %d contacts. Adding...\n",numContacts);
#endif
  for (i=0;i<numContacts;i++) {
    addContacts(bodyIdVec[cresArr[i].body1Id],bodyIdVec[cresArr[i].body2Id],
		cresArr[i].contactSet);
#ifdef GRASPITDBG
    std::cout << bodyIdVec[cresArr[i].body1Id]->getName().latin1() << "-" <<bodyIdVec[cresArr[i].body2Id]->getName().latin1()<<std::endl;
#endif
    
    cresArr[i].contactSet.clear();
  }

  delete [] cresArr;
}

void
World::turnOnDynamics()
{
  static bool firstTime = true;
  int i,d;



  // double ext[6] = {0.0,0.0,0.0,0.0,0.0,0.0};
//   ext[2] = -9.81 * grasp->getObject()->getMass()/1000.0;
//   grasp->getObject()->setExtWrench(ext);
//   double totalMass=robotVec[0]->getBase()->getMass();
//   for (int f=0;f<robotVec[0]->getNumChains();f++)
//     for (int l=0;l<robotVec[0]->getChain(f)->getNumLinks();l++)
//       totalMass += robotVec[0]->getChain(f)->getLink(l)->getMass();
//   ext[2] = 9810 * totalMass;
   //   robotVec[0]->getBase()->ResetExtWrench();
   //   robotVec[0]->getBase()->AddExtWrench(ext);


   // std::cout << "total mass: "<<totalMass<<std::endl;
  
  if (firstTime) pushDynamicState();
   
  
  //  mainWindow->clearContactsList();
  //  mainWindow->playButton->setPixmap(load_pixmap( "pause.xpm" ));

  dynamicsOn = true;
  //  UpdateDynamicsToggleButton();  // update the menu item
  // this should be done from the contact class

  for (i=0;i<numRobots;i++) {
    robotVec[i]->getBaseRobot()->getBase()->fix();
    for (d=0;d<robotVec[i]->getNumDOF();d++)
      robotVec[i]->getDOF(d)->setDesiredPos(robotVec[i]->getDOF(d)->getVal());
  }

  if (firstTime) {
    //
    firstTime = false;

    //temp
   //     getCurrentHand()->autoGrasp(false);
  }

  
  if (idleSensor) delete idleSensor;
  idleSensor = new SoIdleSensor(dynamicsCB,this);
  idleSensor->schedule();
}

void
World::turnOffDynamics()
{
  if (idleSensor) delete idleSensor;
  idleSensor = NULL;
  dynamicsOn = false;

  //  UpdateDynamicsToggleButton();  // update the menu item

  // if (hand) {
//     for (int i=0;i<hand->getNumDOF();i++)
//       hand->getDOF(i)->turnOffPower();
  
//     hand->updateJointValues(false);
//   }

  //  for (int i=0;i<numBodies;i++)
  //    if (bodyvec[i]->getType != BODY_TYPE_STATIC)
  //    ((DynamicBody *)bodyVec[i])->returnToMarkedState();

  //  mainWindow->playButton->setPixmap(load_pixmap( "play.xpm" ));
  //  ivmgr->drawDynamicContactForces();
  updateGrasps();

  //  UpdateDOFDlg();

  //  object->setMoving(false);
}

void
World::dynamicsCB(void *data,SoSensor *)
{
  World *myWorld = (World *)data;
  myWorld->internalStepDynamics();
  //myWorld->stepDynamics();
}

void
World::pushDynamicState()
{
  for (int i=0;i<numBodies;i++)
    if (bodyVec[i]->isDynamic())
      ((DynamicBody *)bodyVec[i])->pushState();
}

void
World::popDynamicState()
{
  for (int i=0;i<numBodies;i++)
    if (bodyVec[i]->isDynamic())
      ((DynamicBody *)bodyVec[i])->popState();
}

double
World::moveDynamicBodies(double timeStep)
{
  int i,j,numDynBodies,numCols,moveErrCode;
  std::vector<DynamicBody *> dynBodies;
  static ColReportT colReport;
  bool jointLimitHit;
  double contactTime,delta,tmpDist,minDist,dofLimitDist;

  for (i=0;i<numBodies;i++)
    if (bodyVec[i]->isDynamic()) {
      dynBodies.push_back((DynamicBody *)bodyVec[i]);
      ((DynamicBody *)bodyVec[i])->markState();
    }
  numDynBodies = dynBodies.size();
 
#ifdef GRASPITDBG
      std::cout << "moving bodies with timestep: " << timeStep << std::endl;
#endif

  moveErrCode = moveBodies(numDynBodies,dynBodies,timeStep);
  if (moveErrCode == 1){ // object out of bounds
    popDynamicState();
    turnOffDynamics();
    return -1.0 ;
  }

  if (numDynBodies > 0)
    numCols = getCollisionReport(colReport);
  else
	numCols = 0;

  jointLimitHit = false;
  for (i=0;i<numRobots;i++) {
    robotVec[i]->updateJointValues();
    for (j=0;j<robotVec[i]->getNumDOF() && !jointLimitHit;j++)
      if (robotVec[i]->getDOF(j)->getVal() > robotVec[i]->getDOF(j)->getMax() + resabs ||
	  robotVec[i]->getDOF(j)->getVal() < robotVec[i]->getDOF(j)->getMin() - resabs){
	jointLimitHit = true;
	//	dofLimits.push_back(robotVec->getDOF(j));
      }
  }

  if (numCols || jointLimitHit) {

    for (i=0;i<numDynBodies;i++)
      dynBodies[i]->returnToMarkedState();

      minDist = 1.0e+255;
      dofLimitDist = 1.0e+255;

#ifdef GRASPITDBG
    if (numCols) {
      std::cout << "COLLIDE!" << std::endl;
      for (i=0;i<numCols;i++) {
	    std::cout << colReport[i].first->getName() << " collided with " <<
	    colReport[i].second->getName() << std::endl;
      }

      for (i=0;i<numCols;i++) {
	    tmpDist = getDist(colReport[i].first,colReport[i].second);
	    if (tmpDist < minDist)
	      minDist = tmpDist;
	
	    std::cout << "minDist: " << tmpDist <<" between " << std::endl;
	    std::cout << colReport[i].first->getName() << " and " <<
	    colReport[i].second->getName() << std::endl;
      }      
    }
#endif      

    /////  this section refines the timestep until the objects are separated
    /////        by a distance less than CONTACT_THRESHOLD

    bool done = false;
    contactTime = timeStep;
    delta = contactTime/2;
    contactTime -= delta;
  
    while (!done) {
      delta /= 2.0;	  
      for (i=0;i<numDynBodies;i++)
	     dynBodies[i]->returnToMarkedState();

#ifdef GRASPITDBG
      std::cout << "moving bodies with timestep: " << contactTime << std::endl;
#endif

      moveErrCode = moveBodies(numDynBodies,dynBodies,contactTime);
      
      if (moveErrCode == 1){ // object out of bounds
	popDynamicState();
	    turnOffDynamics();
	    return -1.0;
      }

      if (numCols) {
	    minDist = 1.0e+255;
	    for (i=0;i<numCols;i++) {
	      tmpDist = getDist(colReport[i].first,colReport[i].second);
	      if (tmpDist < minDist)
	        minDist = tmpDist;
	  
#ifdef GRASPITDBG
	      std::cout << "minDist: " << minDist << " between " <<
	      colReport[i].first->getName() << " and " <<
	      colReport[i].second->getName()<< std::endl;
#endif
		}
      }

      if (jointLimitHit) {
	    dofLimitDist = 1.0e+255;
	    for (i=0;i<numRobots;i++) {
	      robotVec[i]->updateJointValues();
	      for (j=0;j<robotVec[i]->getNumDOF();j++) {
	        dofLimitDist = MIN(dofLimitDist,robotVec[i]->getDOF(j)->getMax()-
			       robotVec[i]->getDOF(j)->getVal());
	        dofLimitDist = MIN(dofLimitDist,robotVec[i]->getDOF(j)->getVal()-
			       robotVec[i]->getDOF(j)->getMin());
#ifdef GRASPITDBG	      
	        std::cout <<"robot "<<i<<" DOF " <<j<<" val: "<<
	        robotVec[i]->getDOF(j)->getVal()<<" dofLimit: "<<dofLimitDist<<std::endl;
#endif
		  }
		}
	  }

      if (minDist <= 0.0 || dofLimitDist < -resabs)
	    contactTime -= delta;
      else if (minDist > Contact::THRESHOLD * 0.5 && dofLimitDist > 0.01)
 	    contactTime += delta;
      else break;
	       
      if (fabs(delta) < 1.0E-15) {
#ifdef GRASPITDBG
	    std::cerr << "DELTA FAILSAFE!" << std::endl;
	    std::cout << "DELTA FAILSAFE!" << std::endl;
#endif
	    done = true;  // failsafe
      }
      if (contactTime < 1.0e-7) {
#ifdef GRASPITDBG
 	    std::cerr << "TIME FAILSAFE!" << std::endl;
	    std::cout << "TIME FAILSAFE!" << std::endl;
#endif
	    done = true;
	  }
	}
    // COULD NOT FIND COLLISION TIME
    if (done && contactTime < 1.0E-7) {
#ifdef GRAPSITDBG
      std::cout << "!! could not find contact time !!" << std::endl;
#endif
      
      for (i=0;i<numDynBodies;i++)
	    dynBodies[i]->returnToMarkedState();    
	}
    /*
    minDist = 1.0e+255;
      for (i=0;i<numCols;i++) {
        ivc->vc->Dist(colReport[i].id1,colReport[i].id2,dres);
	if (dres.Distance() < minDist)
	  minDist = dres.Distance();

      printf("minDist: %le between ",dres.Distance());
      printf("%s and %s\n",bodyVec[colReport[i].id1]->getName(),
	bodyVec[colReport[i].id2]->getName());
      }
    */
    worldTime += contactTime;
  }
  else { // if no collision
    worldTime += timeStep;
    contactTime = timeStep;
  }
       
#ifdef GRASPITDBG
  std::cout << "CHECKING COLLISIONS AT MIDDLE OF STEP: ";
  numCols = getCollisionReport(colReport);

  if (!numCols){ 
    std::cout << "None." << std::endl;
  }
  else {
    std::cout << numCols <<" found!!!" << std::endl;
    for (i=0;i<numCols;i++) {
      std::cout << colReport[i].first->getName() << " collided with " <<
	colReport[i].second->getName() << std::endl;
    }
  }
#endif

  if (numDynBodies > 0)
    findAllContacts();

  for (i=0;i<numDynBodies;i++)
    dynBodies[i]->resetExtWrench();

  if (contactTime<1.0E-7) return -1.0;
  return contactTime;
}

int
World::computeNewVelocities(double timeStep)
{
  bool allDynamicsComputed;
  static std::list<Contact *> contactList;
  std::list<Contact *>::iterator cp;
  std::vector<DynamicBody *> robotLinks;
  std::vector<DynamicBody *> dynIsland;
  std::vector<Robot *> islandRobots;
  int i,j,numLinks,numDynBodies,numIslandRobots,lemkeErrCode;

#ifdef GRASPITDBG
  int islandCount = 0;
#endif

  do {
    // seed the island with one dynamic body
    for (i=0;i<numBodies;i++)
      if (bodyVec[i]->isDynamic() &&
		!((DynamicBody *)bodyVec[i])->dynamicsComputed()) {

        // if this body is a link, add all robots connected to the link
        if (bodyVec[i]->inherits("Link")) {
	      Robot *robot = ((Robot *)((Link *)bodyVec[i])->getOwner())->getBaseRobot();
	      robot->getAllLinks(dynIsland);
	      robot->getAllAttachedRobots(islandRobots);
		}
        else
	      dynIsland.push_back((DynamicBody *)bodyVec[i]);
        break;
	  }
    numDynBodies = dynIsland.size();
    for (i=0;i<numDynBodies;i++)
      dynIsland[i]->setDynamicsFlag();

  // add any bodies that contact any body already in the dynamic island
    for (i=0;i<numDynBodies;i++) {
      contactList = dynIsland[i]->getContacts();
      for (cp=contactList.begin();cp!=contactList.end();cp++) {
	//if the contacting body is dynamic and not already in the list, add it
	    if ((*cp)->getBody2()->isDynamic() &&
	      !((DynamicBody *)(*cp)->getBody2())->dynamicsComputed()) {
	      DynamicBody *contactedBody = (DynamicBody *)(*cp)->getBody2();
	  
	      // is this body is a link, add all robots connected to the link
	      if (contactedBody->isA("Link")) {
	        Robot *robot = ((Robot *)((Link *)contactedBody)->getOwner())->getBaseRobot();
	        robot->getAllLinks(robotLinks);
	        robot->getAllAttachedRobots(islandRobots);
	        numLinks = robotLinks.size();
	        for (j=0;j<numLinks;j++)
	          if (!robotLinks[j]->dynamicsComputed()) {
		        dynIsland.push_back(robotLinks[j]);
		        robotLinks[j]->setDynamicsFlag();
		        numDynBodies++;
			  }
	        robotLinks.clear();
		  }
	      else {
	        dynIsland.push_back(contactedBody);
	        contactedBody->setDynamicsFlag();
	        numDynBodies++;
		  }
		}
	  }
    }

    numIslandRobots = islandRobots.size();

#ifdef GRASPITDBG
    std::cout << "Island "<< ++islandCount<<" Bodies: ";
    for (i=0;i<numDynBodies;i++)
      std::cout << dynIsland[i]->getName() <<" ";
    std::cout << std::endl;
    std::cout << "Island Robots"<< islandCount<<" Robots: ";
    for (i=0;i<numIslandRobots;i++)
      std::cout << islandRobots[i]->getName() <<" ";
    std::cout << std::endl << std::endl;
#endif  
    
    for (i=0;i<numDynBodies;i++)
      dynIsland[i]->markState();

	if (numDynBodies > 0) {
      lemkeErrCode = iterateDynamics(islandRobots,dynIsland,timeStep,true);

      if (lemkeErrCode == 1){ // dynamics could not be solved
        std::cerr << "LCP COULD NOT BE SOLVED!"<<std::endl<<std::endl;
        turnOffDynamics();
        return -1;
	  }
	}

    dynIsland.clear(); 
    islandRobots.clear();
    allDynamicsComputed = true;
    for (i=0;i<numBodies;i++)
      if (bodyVec[i]->isDynamic() &&
	  !((DynamicBody *)bodyVec[i])->dynamicsComputed()) {
	allDynamicsComputed = false;
	break;
      }
  }  while (!allDynamicsComputed);

  // clear all the dynamicsComputed flags
  for (i=0;i<numBodies;i++)
    if (bodyVec[i]->isDynamic())
      ((DynamicBody *)bodyVec[i])->resetDynamicsFlag();

  /*  double conMaxErr = 0.0;

  if (!errFP) errFP=fopen("constraintError.txt","w");
  fprintf(errFP,"%le ",worldTime);
  for (i=0;i<numBodies;i++) {
    contactList = bodyVec[i]->getContacts();
    for (cp=contactList.begin();cp!=contactList.end();cp++) {
	  conMaxErr = MAX(conMaxErr,fabs((*cp)->getConstraintError()));
	}
	
  }
  fprintf(errFP,"%le ",conMaxErr);
  fprintf(errFP," ");
  int k,l;
  double jointErrMax=0.0;
  for (i=0;i<numRobots;i++) {
	if (robotVec[i]->getBase()->getDynJoint())
      for (j=0;j<3;j++)
		jointErrMax = MAX(jointErrMax,fabs(robotVec[i]->getBase()->getDynJoint()->getConstraintError()[j]));
        //fprintf(errFP,"%le ",robotVec[i]->getBase()->getDynJoint()->getConstraintError()[j]);
	for (j=0;j<robotVec[i]->getNumChains();j++) {
      KinematicChain *chain=robotVec[i]->getChain(j);
	  for (k=0;k<chain->getNumLinks();k++)
        if (chain->getLink(k)->getDynJoint())
	  	  for (l=0;l<3;l++)
			jointErrMax = MAX(jointErrMax,fabs(robotVec[i]->getBase()->getDynJoint()->getConstraintError()[j]));
           // fprintf(errFP,"%le ",chain->getLink(k)->getDynJoint()->getConstraintError()[l]);
	}
  }
  fprintf(errFP,"%le",jointErrMax);
  fprintf(errFP,"\n");

  */

  emit dynamicStepTaken();
  return 0;
}

void
World::internalStepDynamics()
{
  int i;
  double actualTimeStep = moveDynamicBodies(dynamicsTimeStep);
  if (actualTimeStep<0) {
	turnOffDynamics();
	emit dynamicsError("Timestep failsafe reached.");
	return;
  }

  for (i=0;i<numRobots;i++) {
    robotVec[i]->DOFController(actualTimeStep);
    //    robotVec[i]->applyJointFriction();
    //robotVec[i]->applyMotorForces();
  }
  if (computeNewVelocities(actualTimeStep)) {
	emit dynamicsError("LCP could not be solved.");
	return;
  } 

  if (idleSensor) idleSensor->schedule();
}
