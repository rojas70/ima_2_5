//######################################################################
//
// GraspIt!
// Copyright (C) 2002-2004  Columbia University in the City of New York.
// All rights reserved.
//
// This software is protected under an Research and Educational Use
// Only license, (found in the file LICENSE.txt), that you should have
// received with this distribution.
//
// Author: Andrew T. Miller (amiller@cs.columbia.edu)
//
// $Id: gwsProjDlg.cpp,v 1.5 2004/02/12 21:35:27 amiller Exp $
//
//######################################################################

/*! \file
  \brief Implements the GWSProjDlg, the Grasp wrench space projection dialog box.
*/

#include "gwsProjDlg.h"

#include <qvariant.h>
#include <qbuttongroup.h>
#include <qcheckbox.h>
#include <qcombobox.h>
#include <qpushbutton.h>
#include <qmime.h>
#include <qdragobject.h>
#include <qimage.h>
#include <qpixmap.h>

#include "gws.h"

/* // not needed?
static QPixmap uic_load_pixmap_GWSProjDlg( const QString &name )
{
    const QMimeSource *m = QMimeSourceFactory::defaultFactory()->data( name );
    if ( !m )
	return QPixmap();
    QPixmap pix;
    QImageDrag::decode( m, pix );
    return pix;
}
*/

/*! 
  Constructs a GWSProjDlg which is a child of \a parent, with the 
  name \a name and widget flags set to \a fl.

  The dialog will by default be modeless, unless you set \a modal to
  TRUE to construct a modal dialog.

  A combo box, created to allow the user to choose the type of GWS that the
  projection will be created from, is populated with items from the GWS type
  list.

  A button group with 6 check boxes in it is also created to allow the user
  to choose the coordinates that are fixed.
 */
GWSProjDlg::GWSProjDlg( QWidget* parent,const char* name,bool modal,WFlags fl )
    : GWSProjDlgBase( parent, name, modal, fl )
{
  coordButtonGroup = new QButtonGroup(this,"coordButtonGroup");
  QObject::connect(coordButtonGroup, SIGNAL(clicked(int)),this, 
		   SLOT(coordBoxClicked(int)));
  coordButtonGroup->insert(fxCheckBox,0);
  coordButtonGroup->insert(fyCheckBox,1);
  coordButtonGroup->insert(fzCheckBox,2);
  coordButtonGroup->insert(txCheckBox,3);
  coordButtonGroup->insert(tyCheckBox,4);
  coordButtonGroup->insert(tzCheckBox,5);
  coordButtonGroup->hide();
  for (int i=0;GWS::TYPE_LIST[i];i++)
    gwsTypeComboBox->insertItem(QString(GWS::TYPE_LIST[i]));
  OKButton->setEnabled(false);
  
}

/*!
  When one of the 6 coordinate check boxes is clicked, this checks to see
  how many are already selected.  It only allows a box to be checked if there
  are fewer than 3 boxes already checked.  If there are 3 checked, the OK
  button is enabled, otherwise it is disabled.  \a whichFixed keeps track of
  the indexes of the currently selected check boxes.  
*/
void GWSProjDlg::coordBoxClicked(int buttonNum)
{
  QButton *b = coordButtonGroup->find(buttonNum);
  if (b->state()) {
    if (whichFixed.size() < 3) {
      whichFixed.insert(buttonNum);
      if (whichFixed.size() == 3) OKButton->setEnabled(true);
    }
    else
      b->toggle();
  }
  else {
    whichFixed.erase(buttonNum);
    OKButton->setEnabled(false);
  }
}

/*!  
  Stub destructor.
 */
GWSProjDlg::~GWSProjDlg()
{
    // no need to delete child widgets, Qt does it all for us
}

