%MOVEDOFS(r,D,deltaD) kinematically moves the DOFs of one robot to desired positions.
%
%   newD = moveDOFs(r,D,deltaD)
%
%This function takes 3 input arguments:
%   r is the index of the robot whose DOFs are being moved
%      An error is returned if r does not correspeond to a robot in the world.
%
%   D is the vector of desired DOF positions
%      An error is returned if the number of elements of D does not match
%      the number of degrees of freedom of robot r.
%
%   deltaD is a vector containing the step size that should be taken for
%      each DOF as it is moved towards its desired position.
%      An error is returned if the number of elements of deltaD does not
%      match the number of degrees of freedom of robot r.
%
%The function returns one output which is a vector of the DOF positions
%at the end of the move operation.
%
%This function is used to kinematically control the DOF positions.  It does
%not use the dynamics module.  It moves the DOFs by steps of size deltaD
%until the desired values are reached or a contact occurs.
%The desired dof positions can be reached in one step by using the following:
%
%  newD = moveDOFs(r,D,D - getDOFVals(r))
%
%However, a smaller stepsize ensures that collisions with small objects
%in the path of the moving links won't be missed.
%
%
%This function is implemented in the C MEX-file moveDOFs.c
%To compile it, use the folloing command:
%
%  mex -DWIN32 moveDOFs.c connectToServer.c ws2_32.lib


