%RENDER connects to GraspIt! and instructs it to render the scene.
%
%The function takes no arguments and produces no output in Matlab.
%GraspIt! will rerender a scene automatically when no other commands
%are being processed.  However, the RENDER command is useful as part of
%script to see the changes in the GraspIt! world between successive commands.
%
%
%This function is implemented in the C MEX-file render.c
%To compile it, use the folloing command:
%
%  mex -DWIN32 render.c connectToServer.c ws2_32.lib

