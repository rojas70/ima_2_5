%GETCONTACTS([BODYVECTOR]) returns all contact forces and positions for a body or bodies.
%
%    [F,P] = getContacts(b)
%
%This function may take at most one argument which is a vector of body
%indices (b) for which information should be returned.  If none is supplied,
%contact information is returned for every body.  An error is returned if a
%body index in b does not correspond to a body in the current world.
%
%It takes one OR two output variables which are matrices for a single body
%or cell arrays for multiple bodies:
%
%Each row of one cell of F contains the 6D contact force vector of one contact
%acting on a single body relative to the body's coordinate frame.
%Each row of one cell of P contains the 3D position vector of one contact on a
%single body relative to the body's coordinate frame. 
%
%The cells of the output cell array correspond to the body indices in b or all
%bodies in the world if b is not supplied.
%
%
%This function is implemented in the C MEX-file getContacts.c
%To compile it, use the folloing command:
%
%  mex -DWIN32 getContacts.c connectToServer.c ws2_32.lib
