%GETDOFVALS([ROBOTVECTOR]) returns the current positions of the degrees of freedom of a robot or robots.
%
%    d = getDOFVals(r)
%
%This function may take at most one argument which is a vector of robot
%indices (r) for which information should be returned.  If none is supplied,
%DOF values are returned for every robot in the GraspIt! world.  An error is
%returned if a robot index in r does not correspond to a robot in the current
%world.
%
%This function returns a vector for a single robot or a cell array of vectors
%for multiple robots.  Each vector contains the current positions of the
%degrees of freedom of a robot.
%
%The cells of the output cell array correspond to the robot indices in r or all
%robots in the world if r is not supplied.
%
%This function is implemented in the C MEX-file getDOFVals.c
%To compile it, use the folloing command:
%
%  mex -DWIN32 getDOFVals.c connectToServer.c ws2_32.lib
