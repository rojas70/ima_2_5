%function p = PDController()
%PDController test
%more help

Kp = [5.0e+9 5.0e+9 1.0e+9 5.0e+8 5.0e+9 5.0e+9 1.0e+9 5.0e+8 5.0e+9 5.0e+9 1.0e+9 5.0e+8]';
Kv = [1.0e+7 1.0e+7 5.0e+6 1.0e+6 1.0e+7 1.0e+7 5.0e+6 1.0e+6 1.0e+7 1.0e+7 5.0e+6 1.0e+6]';
setPoint = [0 0 0 0 0 0 0 0 0 0 0 0]';
lastError = [0 0 0 0 0 0 0 0 0 0 0 0]';

while 1
	timeStep = moveDynamicBodies;
	dofvals = getDOFVals;
		error = setPoint - dofvals;
		velerror = (error-lastError)/timeStep
		forces = Kp .* error + Kv .* velerror;
		lastError = error;

	setDOFForces(forces);
	computeNewVelocities(timeStep);
	render;

end

