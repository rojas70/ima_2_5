%GETROBOTNAME([ROBOTVECTOR]) returns the name of a robot or robots.
%
%    names = getRobotName(r)
%
%This function may take at most one argument which is a vector of robot
%indices (r) for which information should be returned.  If none is supplied,
%a name is returned for every robot in the GraspIt! world.  An error is
%returned if a robot index in r does not correspond to a robot in the current
%world.
%
%This function returns one output which is a cell array of strings.  Each
%string containts the name of a robot whose index is in r.  If r is not given
%the index of each string in the returned array corresponds to the index of
%that robot in the world.
%
%This is a convenient way to determine which robot corresponds to which robot
%index.
%
%
%This function is implemented in the C MEX-file getRobotName.c
%To compile it, use the folloing command:
%
%  mex -DWIN32 getRobotName.c connectToServer.c ws2_32.lib

