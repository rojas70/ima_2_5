%GETAVERAGECONTACTS([BODYVECTOR]) returns the average contact force and position for a body or bodies.
%
%    [F,P] = getAverageContacts(b)
%
%This function may take at most one argument which is a vector of body
%indices (b) for which information should be returned.  If none is supplied,
%average contact information is returned for every body.  An error is
%returned if a body index in b does not correspond to a body in the current
%world.
%
%It takes one or two output variables which are matrices:
%
%Each row of F contains the average of the 6D contact force vectors acting on
%a single body relative to the body's coordinate frame.
%Each row of P contains the average of the 3D positions of the contacts on a
%single body relative to the body's coordinate frame. 
%
%The rows of the output matries correspond to the body indices in b or the
%world if b is not supplied.
%
%
%This function is implemented in the C MEX-file render.c
%To compile it, use the folloing command:
%
%  mex -DWIN32 getAverageContacts.c connectToServer.c ws2_32.lib
