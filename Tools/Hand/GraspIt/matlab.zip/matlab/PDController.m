%function p = PDController()
%PDController test
%more help

Kp{1} = [5.0e+11 5.0e+11 5.0e+11 5.0e+9 5.0e+9 5.0e+9 5.0e+9]';
Kv{1} = [1.0e+8 1.0e+8 1.0e+8 1.0e+7 1.0e+7 1.0e+7 1.0e+7]';
setPoint{1} = [0 0 0 0 0 0 0]';
lastError{1} = [0 0 0 0 0 0 0]';

Kp{2} = [5.0e+9 5.0e+9 1.0e+9 5.0e+8 5.0e+9 5.0e+9 1.0e+9 5.0e+8 5.0e+9 5.0e+9 1.0e+9 5.0e+8]';
Kv{2} = [1.0e+7 1.0e+7 5.0e+6 1.0e+6 1.0e+7 1.0e+7 5.0e+6 1.0e+6 1.0e+7 1.0e+7 5.0e+6 1.0e+6]';
setPoint{2} = [0 0 0 0 0 0 0 0 0 0 0 0]';
lastError{2} = [0 0 0 0 0 0 0 0 0 0 0 0]';

while 1
	timeStep = moveDynamicBodies
	dofvals = getDOFVals;
	for k = 1:length(dofvals)
		error = setPoint{k} - dofvals{k};
		velerror = (error-lastError{k})/timeStep;
		forces{k} = Kp{k} .* error + Kv{k} .* velerror;
		lastError{k} = error;
	end

	setDOFForces(forces);
	computeNewVelocities(timeStep);
	render;

end

