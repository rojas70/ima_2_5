%FUNCTIONS:
%computeNewVelocities.m  -  solves for the new velocity of each dynamic body
%getAverageContacts.m  -  returns the average contact force and position for a body or bodies.
%getBodyName.m  -  returns the name of a body or bodies.
%getContacts.m  -  returns all contact forces and positions for a body or bodies.
%getDOFVals.m  -  returns the current positions of the degrees of freedom of a robot or robots.
%getRobotName.m  -  returns the name of a robot or robots.
%moveDOFs.m  -  kinematically moves the DOFs of one robot to desired positions.
%moveDynamicBodies.m  -  moves every dynamic body by one timestep or until contact occurs.
%render.m  -  instructs GraspIt! to render the scene.
%setDOFForces.m  -  sets the forces acting on the degrees of freedom of a robot or robots.
%
%SCRIPTS:
%PDController.m  -  an example script that uses PD control in a dynamics loop.
