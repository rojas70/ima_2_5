%SETDOFFORCES(F,[ROBOTVEC]) sets the forces acting on the degrees of freedom of a robot or robots.
%
%   currentF = setDOFForces(F,r)
%
%This function takes one OR two input arguments:
%   F is a vector of forces for the degrees of freedom of one robot or a cell
%      array of vectors for multiple robots.  If a force is greater than the
%      maximum allowed for the DOF as defined in the robot configuration file,
%      the DOF force is set to the maximum.
%      An error is returned if the number of elements of each cell of F does
%      not match the number of degrees of freedom of the corresponding robot
%
%   r is a vector of robot indices for which the DOF forces should be set.
%     If r not supplied, then F must contain DOF forces for every robot in the
%     GraspIt! world.  An error is returned if a robot index in r does not
%     correspond to a robot in the current world.
%
%The function returns one output which is a vector or cell array of vectors
%containing the current force acting on each DOF after the operation is
%complete.  These forces will be used in the next call to computeNewVelocities.
%
%
%This function is implemented in the C MEX-file setDOFForces.c
%To compile it, use the folloing command:
%
%  mex -DWIN32 setDOFForces.c connectToServer.c ws2_32.lib


