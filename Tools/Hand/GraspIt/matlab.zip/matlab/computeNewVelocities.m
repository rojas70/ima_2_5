%COMPUTENEWVELOCITIES(h) solves for the velocities of the dynamic bodies given the timestep h.
%
%This function uses the timestep h returned by MOVEDYNAMICBODIES, and
%returns no output.  An error is returned if GraspIt! could not find a
%solution for the current constraints.
%
%COMPUTENEWVELOCITIES calls GraspIt! to solve for the next set of velocities
%for the dynamic bodies within the world. It is the second part of a complete
%time step that solves for the new state of each body.
%
%
%This function is implemented in the C MEX-file computeNewVelocities.c
%To compile it, use the folloing command:
%
%  mex -DWIN32 computeNewVelocities.c connectToServer.c ws2_32.lib


