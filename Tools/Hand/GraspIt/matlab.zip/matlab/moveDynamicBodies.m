%MOVEDYNAMICBODIES(maxTimeStep) moves every dynamic body by one timestep or until contact occurs.
%
%This function takes a scalar input that is the max time step that should be
%taken and returns the timestep actually taken. An error is returned if a body
%cannot be moved without interpenetrating another body or a exceeding a joint
%limit.
%
%Given a default time step, this function computes the new positions of all 
%dynamic bodies in the GraspIt! world as follows:
%
%   qnew = hv + q
%
%where qnew is a vector of the new body positions, v is the vector of current
%body velocities and q is a vector of the current positions.  h is the length
%of the timestep, which is either the defaultTimeStep or the length of time
%before a contact or joint limit event occurs (whichever is less).  This
%function is the first part of a complete time step that solves for the
%new state of each body.
%
%
%This function is implemented in the C MEX-file moveDynamicBodies.c
%To compile it, use the folloing command:
%
%  mex -DWIN32 moveDynamicBodies.c connectToServer.c ws2_32.lib
