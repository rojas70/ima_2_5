%GETBODYNAME([BODYVECTOR]) returns the name of a body or bodies.
%
%    names = getBodyName(b)
%
%This function may take at most one argument which is a vector of body
%indices (b) for which information should be returned.  If none is supplied,
%a name is returned for every body in the GraspIt! world.  An error is
%returned if a body index in b does not correspond to a body in the current
%world.
%
%This function returns one output which is a cell array of strings.  Each
%string containts the name of a body whose index is in b.  If b is not given
%the index of each string in the returned array corresponds to the index of
%that body in the world.
%
%This is a convenient way to determine which body corresponds to which body
%index.
%
%
%This function is implemented in the C MEX-file getBodyName.c
%To compile it, use the folloing command:
%
%  mex -DWIN32 getBodyName.c connectToServer.c ws2_32.lib
